# 🛡️ SIH26002: NER LogiGuard — Production Deployment Guide

> **Intelligent Logistics & High-Altitude Mountain Convoy Intelligence Engine**  
> Designed for the 8 North Eastern States of India (Assam, Meghalaya, Nagaland, Arunachal Pradesh, Manipur, Mizoram, Tripura, Sikkim).

---

## 🌐 100% Free-Tier Architecture Overview

| Component | Service / Technology | Cost / Free Tier Limits | Zero API Key Required? |
| :--- | :--- | :--- | :--- |
| **Frontend** | **Vercel** (Static / PWA / SPA) | **100% FREE** (Unlimited deployments, 100GB bandwidth) | ✅ Yes |
| **Backend** | **Render / Railway / Koyeb** (FastAPI) | **100% FREE** (Free tier web service / 750 free hrs/mo) | ✅ Yes |
| **Database** | **Supabase** (Managed PostgreSQL 15) | **100% FREE** (500MB database, 2 free projects) | ✅ Yes |
| **Tactical Maps** | **OpenStreetMap + Leaflet** | **100% FREE** (Public CartoDB / OSM tiles) | ✅ Yes (No key needed) |
| **Weather** | **Open-Meteo Satellite API** | **100% FREE** (10,000 calls/day free for non-commercial) | ✅ Yes (No key needed) |
| **Tactical AI** | **Google Gemini 2.5 Flash** | **100% FREE** (15 requests/min at Google AI Studio) | 🔑 Free API Key |
| **Mobile App** | **Android Kotlin + Jetpack Compose** | **100% FREE** (Open source Android Studio SDK) | ✅ Yes |

> ℹ️ **Paid Plan Notice:** None of the services above require a credit card or a paid plan. All core features (Routing, Live Fleet tracking, Landslide Risk scoring, PWA offline caching, and WebSockets) run completely free.

---

## 📋 Step-by-Step Beginner Deployment Guide

---

### Step 1: Install Prerequisites

Before starting, ensure you have the following installed on your computer:

1. **Git**: [https://git-scm.com/downloads](https://git-scm.com/downloads)
2. **Python 3.10 or 3.11**: [https://www.python.org/downloads/](https://www.python.org/downloads/)
3. **Node.js (Optional, for local static serving)**: [https://nodejs.org/](https://nodejs.org/)
4. **A Web Browser**: Google Chrome, Mozilla Firefox, or Microsoft Edge.
5. **Free Accounts**:
   - [GitHub Account](https://github.com/)
   - [Supabase Account](https://supabase.com/)
   - [Vercel Account](https://vercel.com/)
   - [Render Account](https://render.com/)

---

### Step 2: Install Frontend

The frontend consists of the **Tactical Command Center Web App** and the **Offline-First Field Officer PWA** inside the `/public` directory.

No heavy build steps or complex node modules are required! To preview or serve locally:

```bash
# Option A: Using Python built-in HTTP server
cd public
python -m http.server 3000

# Option B: Using npx serve (if you have Node.js)
npx serve public -p 3000
```
Open your browser at `http://localhost:3000`.

---

### Step 3: Install Backend

The backend is built with high-performance Python FastAPI, SQLAlchemy, and WebSockets.

```bash
# 1. Open a terminal and navigate to the backend folder
cd backend

# 2. Create a virtual environment
python -m venv venv

# 3. Activate the virtual environment
# On macOS / Linux:
source venv/bin/activate
# On Windows (Command Prompt):
venv\Scripts\activate
# On Windows (PowerShell):
.\venv\Scripts\Activate.ps1

# 4. Install dependencies
pip install --upgrade pip
pip install -r requirements.txt
```

---

### Step 4: Create Database (Supabase PostgreSQL Free Tier)

1. Go to [https://supabase.com](https://supabase.com) and log in.
2. Click **"New Project"**.
3. Fill in:
   - **Name**: `ner-logiguard-db`
   - **Database Password**: Choose a strong password (remember it!).
   - **Region**: Choose `South Asia (Mumbai)` or `Southeast Asia (Singapore)` for lowest latency in India.
4. Once the project is created (takes ~1 minute):
   - Go to **Project Settings** (gear icon in sidebar) ➔ **Database**.
   - Scroll to **Connection string** ➔ Select **URI**.
   - Copy the URI. It looks like:
     ```
     postgresql://postgres.[PROJECT_REF]:[YOUR_PASSWORD]@aws-0-ap-south-1.pooler.supabase.com:6543/postgres?sslmode=require
     ```
   *(Replace `[YOUR_PASSWORD]` with your actual password).*

> 💡 **Zero-Setup Local Dev Alternative**: If you don't want to create Supabase right away, you can use local SQLite out-of-the-box by setting `DATABASE_URL=sqlite:///./ner_logistics.db`.

---

### Step 5: Configure Environment Variables

1. In the `backend` folder, copy `.env.example` to `.env`:
   ```bash
   cp backend/.env.example backend/.env
   ```
2. Open `backend/.env` in your code editor and configure:
   ```env
   ENVIRONMENT=production
   DEBUG=false
   PORT=8000
   SECRET_KEY=generate_a_random_32_character_string_here

   # Paste your Supabase Database URI from Step 4 (or leave SQLite default)
   DATABASE_URL=postgresql://postgres.yourprojectref:yourpassword@aws-0-ap-south-1.pooler.supabase.com:6543/postgres?sslmode=require

   # Allow your frontend to talk to this backend
   BACKEND_CORS_ORIGINS=*,https://*.vercel.app,http://localhost:3000,http://localhost:5173

   # Open-Meteo (Free weather, zero API key needed)
   OPEN_METEO_BASE_URL=https://api.open-meteo.com/v1/forecast

   # Optional: Google Gemini API Key (Get a free key from https://aistudio.google.com/app/apikey)
   GEMINI_API_KEY=your_free_gemini_api_key
   GEMINI_MODEL=gemini-3.5-flash
   ```

---

### Step 6: Run Locally

1. **Start the Backend**:
   ```bash
   cd backend
   # Make sure virtual environment is active
   uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
   ```
   - Database tables are automatically initialized and seeded on startup!
   - API Docs: `http://localhost:8000/docs`
   - Health Check: `http://localhost:8000/health`

2. **Start the Frontend**:
   ```bash
   cd public
   python -m http.server 3000
   ```
   - Open `http://localhost:3000` in your browser.
   - Field Officer PWA: `http://localhost:3000/pwa/index.html`

---

### Step 7: Deploy Frontend to Vercel (100% Free)

1. Push your repository to **GitHub**:
   ```bash
   git add .
   git commit -m "Deploy: SIH26002 NER LogiGuard Production Ready"
   git push origin main
   ```
2. Go to [https://vercel.com](https://vercel.com) and click **"Add New Project"**.
3. Import your GitHub repository.
4. Configuration:
   - **Framework Preset**: `Other`
   - **Root Directory**: `./` (Root directory where `vercel.json` and `/public` reside)
5. Click **"Deploy"**.
6. In ~20 seconds, your frontend will be live at `https://your-project.vercel.app`!

---

### Step 8: Deploy Backend to Render (100% Free)

1. Go to [https://render.com](https://render.com) and log in.
2. Click **"New +"** ➔ **"Web Service"**.
3. Connect your GitHub repository.
4. Fill in the deployment details:
   - **Name**: `ner-logiguard-backend`
   - **Region**: `Singapore` (Fastest for India)
   - **Root Directory**: `backend`
   - **Runtime**: `Python 3`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
   - **Plan Type**: `Free`
5. Click **"Advanced"** ➔ Add **Environment Variables**:
   - `DATABASE_URL`: *(Your Supabase PostgreSQL URI from Step 4)*
   - `SECRET_KEY`: *(Any 32-character random string)*
   - `BACKEND_CORS_ORIGINS`: `*`
   - `ENVIRONMENT`: `production`
   - `GEMINI_API_KEY`: *(Your Google AI Studio key, if using AI Copilot)*
6. Click **"Create Web Service"**.
7. Render will build and deploy your API. Once finished, you will receive your public URL:
   `https://ner-logiguard-backend.onrender.com`

---

### Step 9: Connect Frontend to Backend

1. Open your live deployed Vercel frontend in your browser: `https://your-project.vercel.app`
2. Click the **"⚙️ Backend Link"** button in the top navigation bar.
3. Paste your Render backend URL:
   ```
   https://ner-logiguard-backend.onrender.com
   ```
4. Click **"Test Connection (Ping)"** ➔ You will see `✓ Connected!`.
5. Click **"Save & Reconnect"**.

> 🔗 **Shortcut URL Parameter**: You can also share direct links with the backend pre-configured, e.g.:  
> `https://your-project.vercel.app/?backend=https://ner-logiguard-backend.onrender.com`

---

### Step 10: Test the Deployed Application

Verify each critical feature across the full-stack system:

1. **Health Check**:
   Open `https://your-backend.onrender.com/health` in your browser. Expected response:
   ```json
   {"status":"healthy","database":"connected","websocket_connections":0}
   ```
2. **Interactive API Documentation (Swagger)**:
   Visit `https://your-backend.onrender.com/docs` to test endpoints for Routes, Vehicles, Incidents, and AI.
3. **Tactical GIS Map & Rerouting**:
   On your Vercel frontend, click **"▶ Start Telemetry Stream"** to see live simulated vehicles moving across Assam, Nagaland, Sikkim, and Meghalaya. Click **"⚠️ Simulate Landslide Reroute"** to trigger dynamic hazard avoidance.
4. **Offline Field Officer PWA**:
   - Open `https://your-project.vercel.app/pwa/index.html`.
   - Click **"🛰️ Simulate Offline Mesh"** (or turn off Wi-Fi).
   - Submit a geotagged hazard report (e.g. Landslide on NH-29).
   - Notice the status updates to **⚡ OFFLINE (1 Pending in IndexedDB)**.
   - Click **"Disable Offline Simulation"** (or turn Wi-Fi back on).
   - Watch the indicator transition: `SYNCING` ➔ `✓ SYNC COMPLETE` as the report uploads automatically to the backend!

---

## 👥 Default Demo Credentials

| Role | Username | Password | Operational Sector |
| :--- | :--- | :--- | :--- |
| **Command Admin** | `admin` | `admin123` | North East Regional HQ (Guwahati) |
| **Logistics Operator** | `operator` | `operator123` | Assam & Nagaland Supply Corridors |
| **Field Officer** | `field_officer` | `field123` | Arunachal West / Tawang Frontier |
| **Convoy Driver** | `driver1` | `driver123` | Heavy Carrier Fleet Alpha |

---

## 🔒 Security & Privacy Best Practices

- 🛡️ **Zero Secret Commits**: All `.env`, `debug.keystore`, and private database credentials are protected by `.gitignore`.
- 🔐 **JWT Token Authentication**: Secure role-based authorization for all administrative and dispatch operations.
- 🌐 **CORS Protection**: Enforces origin validation with HTTPS expectation in production environments.
- 📱 **Offline-First Zero-Loss Guarantee**: Field Officer terminal guarantees client-side IndexedDB persistence even during multi-hour high-altitude network washouts.

---

## 📄 License & Team
**SIH26002 • NER LogiGuard Project**  
Developed for high-altitude mountain corridor resilience, disaster response, and convoy supply chain optimization.
