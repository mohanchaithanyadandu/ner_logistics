package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.data.models.LocationPoint
import com.example.data.models.RouteCandidate
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class NavigationLaunchResult {
    data object SuccessDirectApp : NavigationLaunchResult()
    data object SuccessBrowserFallback : NavigationLaunchResult()
    data class Failure(val errorMessage: String) : NavigationLaunchResult()
}

object ExternalNavigationLauncher {

    /**
     * Builds standard navigation endpoint string preferring exact GPS coordinates
     * if valid, or properly URL-encoded location name as fallback.
     */
    fun formatLocationEndpoint(location: LocationPoint): String {
        return if (location.latitude != 0.0 && location.longitude != 0.0) {
            "${location.latitude},${location.longitude}"
        } else {
            encodeQueryParam(location.name)
        }
    }

    private fun encodeQueryParam(value: String): String {
        return URLEncoder.encode(value, StandardCharsets.UTF_8.toString())
    }

    /**
     * Opens Google Maps directions for a RouteCandidate.
     */
    fun openGoogleMapsDirections(context: Context, route: RouteCandidate): NavigationLaunchResult {
        return openGoogleMapsDirections(
            context = context,
            origin = route.origin,
            destination = route.destination,
            corridorName = route.name
        )
    }

    /**
     * Opens Google Maps for given origin and destination endpoints.
     * 1. Attempts direct Google Maps application intent with explicit package target.
     * 2. If app not found or launch fails, falls back gracefully to standard Google Maps directions URL in browser.
     * 3. Never crashes; returns a structured NavigationLaunchResult for clear UI feedback.
     * 4. Does NOT require any Google Maps API Key.
     */
    fun openGoogleMapsDirections(
        context: Context,
        origin: LocationPoint,
        destination: LocationPoint,
        corridorName: String? = null
    ): NavigationLaunchResult {
        val originStr = formatLocationEndpoint(origin)
        val destStr = formatLocationEndpoint(destination)

        // Web URL fallback: https://www.google.com/maps/dir/?api=1&origin=...&destination=...&travelmode=driving
        val webFallbackUrl = "https://www.google.com/maps/dir/?api=1&origin=$originStr&destination=$destStr&travelmode=driving"

        // Provide immediate visual feedback to operator
        try {
            val label = corridorName ?: "${origin.name} ➔ ${destination.name}"
            Toast.makeText(context, "Opening Google Maps for $label...", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {}

        // 1. Try launching Google Maps app directly using google.navigation / maps geo intent with package
        try {
            val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse(webFallbackUrl)).apply {
                setPackage("com.google.android.apps.maps")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (appIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(appIntent)
                return NavigationLaunchResult.SuccessDirectApp
            }
        } catch (_: Exception) {
            // Continue to fallback
        }

        // 2. Try generic intent without restricting package, in case another map app or browser handles it
        try {
            val genericMapsUri = Uri.parse(webFallbackUrl)
            val browserIntent = Intent(Intent.ACTION_VIEW, genericMapsUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(browserIntent)
            return NavigationLaunchResult.SuccessBrowserFallback
        } catch (_: Exception) {
            return NavigationLaunchResult.Failure("Unable to open Google Maps or web browser on this device.")
        }
    }

    /**
     * Directly launches turn-by-turn navigation in Google Maps app.
     */
    fun startTurnByTurnNavigation(context: Context, destination: LocationPoint): NavigationLaunchResult {
        val destStr = formatLocationEndpoint(destination)
        val navUri = Uri.parse("google.navigation:q=$destStr&mode=d")

        try {
            val navIntent = Intent(Intent.ACTION_VIEW, navUri).apply {
                setPackage("com.google.android.apps.maps")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (navIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(navIntent)
                return NavigationLaunchResult.SuccessDirectApp
            }
        } catch (_: Exception) {
            // Fall back to web URL
        }

        // Fallback to web search for destination navigation
        val webFallback = "https://www.google.com/maps/dir/?api=1&destination=$destStr&travelmode=driving"
        try {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(webFallback)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(browserIntent)
            return NavigationLaunchResult.SuccessBrowserFallback
        } catch (_: Exception) {
            return NavigationLaunchResult.Failure("Unable to start navigation on this device.")
        }
    }
}
