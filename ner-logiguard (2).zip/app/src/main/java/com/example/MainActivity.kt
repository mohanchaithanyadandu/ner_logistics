package com.example

import android.os.Bundle
import com.example.ui.theme.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.EditLocation
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Thunderstorm
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.RiskLevel
import com.example.data.models.UserRole
import com.example.ui.components.CommandCenterClockWidget
import com.example.ui.components.DemoModeBar
import com.example.ui.screens.AIAssistantScreen
import com.example.ui.screens.AlertsScreen
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.CommandCenterScreen
import com.example.ui.screens.FieldReportScreen
import com.example.ui.screens.IncidentsScreen
import com.example.ui.screens.LiveFleetScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.RiskIntelligenceScreen
import com.example.ui.screens.RoutePlannerScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.NERLogisticsViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: NERLogisticsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val isAuthenticated by viewModel.isAuthenticated.collectAsState()
                if (isAuthenticated) {
                    MainAppScaffold(viewModel = viewModel)
                } else {
                    LoginScreen(viewModel = viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScaffold(viewModel: NERLogisticsViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val currentRole by viewModel.currentRole.collectAsState()
    val isOffline by viewModel.isOfflineSimulated.collectAsState()
    val pendingCount by viewModel.pendingOfflineCount.collectAsState()
    val alerts by viewModel.allAlerts.collectAsState()
    val isDemoMode by viewModel.isDemoMode.collectAsState()

    var showMoreSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val criticalAlertsCount = alerts.count { it.severity == RiskLevel.CRITICAL || it.severity == RiskLevel.HIGH }

    val primaryTabsList = listOf(
        AppNavTab.COMMAND_CENTER,
        AppNavTab.ROUTE_PLANNER,
        AppNavTab.LIVE_FLEET,
        AppNavTab.FIELD_REPORT
    )
    val isMoreActive = currentTab !in primaryTabsList

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Text(
                            text = "NER LogiGuard",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(if (isOffline) WarningAmber else SuccessGreen)
                        )
                    }
                },
                actions = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                        modifier = Modifier.padding(end = 2.dp)
                    ) {
                        // Three-Line Compact Role Selector
                        HeaderThreeLineRoleSelector(
                            currentRole = currentRole,
                            onRoleSelected = { viewModel.setRole(it) }
                        )

                        // Alerts Bell Action
                        IconButton(
                            onClick = { viewModel.setTab(AppNavTab.ALERTS) },
                            modifier = Modifier
                                .size(38.dp)
                                .semantics { contentDescription = "Alerts desk, $criticalAlertsCount critical alerts active" }
                        ) {
                            BadgedBox(
                                badge = {
                                    if (criticalAlertsCount > 0) {
                                        Badge(containerColor = CriticalRed) {
                                            Text("$criticalAlertsCount", color = Color.White, fontSize = 9.sp)
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = "Alerts desk",
                                    tint = if (criticalAlertsCount > 0) CriticalRed else TextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        // Sign Out Action Button
                        IconButton(
                            onClick = { viewModel.logout() },
                            modifier = Modifier
                                .size(38.dp)
                                .semantics { contentDescription = "Sign Out to Login Screen" }
                                .testTag("app_bar_sign_out_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Logout,
                                contentDescription = "Sign Out",
                                tint = TextSecondary,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PureWhite,
                    titleContentColor = TextPrimary
                )
            )
        },
        bottomBar = {
            // Clean Light 5-Item Bottom Navigation Bar
            NavigationBar(
                containerColor = PureWhite,
                contentColor = TextPrimary,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .height(64.dp)
                    .border(androidx.compose.foundation.BorderStroke(1.dp, BorderLight))
            ) {
                // 1. Dashboard
                val isDashboard = currentTab == AppNavTab.COMMAND_CENTER
                NavigationBarItem(
                    selected = isDashboard,
                    onClick = { viewModel.setTab(AppNavTab.COMMAND_CENTER) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Dashboard,
                            contentDescription = "Dashboard",
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "Dashboard",
                            fontSize = 11.sp,
                            fontWeight = if (isDashboard) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = PrimaryBlue,
                        unselectedIconColor = TextSecondary,
                        selectedTextColor = PrimaryBlue,
                        unselectedTextColor = TextSecondary,
                        indicatorColor = PrimaryBlueLight
                    ),
                    modifier = Modifier.testTag("bottom_nav_dashboard")
                )

                // 2. Routes
                val isRoutes = currentTab == AppNavTab.ROUTE_PLANNER
                NavigationBarItem(
                    selected = isRoutes,
                    onClick = { viewModel.setTab(AppNavTab.ROUTE_PLANNER) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.AltRoute,
                            contentDescription = "Routes",
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "Routes",
                            fontSize = 11.sp,
                            fontWeight = if (isRoutes) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = PrimaryBlue,
                        unselectedIconColor = TextSecondary,
                        selectedTextColor = PrimaryBlue,
                        unselectedTextColor = TextSecondary,
                        indicatorColor = PrimaryBlueLight
                    ),
                    modifier = Modifier.testTag("bottom_nav_routes")
                )

                // 3. Fleet
                val isFleet = currentTab == AppNavTab.LIVE_FLEET
                NavigationBarItem(
                    selected = isFleet,
                    onClick = { viewModel.setTab(AppNavTab.LIVE_FLEET) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.LocalShipping,
                            contentDescription = "Fleet",
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "Fleet",
                            fontSize = 11.sp,
                            fontWeight = if (isFleet) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = PrimaryBlue,
                        unselectedIconColor = TextSecondary,
                        selectedTextColor = PrimaryBlue,
                        unselectedTextColor = TextSecondary,
                        indicatorColor = PrimaryBlueLight
                    ),
                    modifier = Modifier.testTag("bottom_nav_fleet")
                )

                // 4. Reports
                val isReports = currentTab == AppNavTab.FIELD_REPORT
                NavigationBarItem(
                    selected = isReports,
                    onClick = { viewModel.setTab(AppNavTab.FIELD_REPORT) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.EditLocation,
                            contentDescription = "Reports",
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "Reports",
                            fontSize = 11.sp,
                            fontWeight = if (isReports) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = PrimaryBlue,
                        unselectedIconColor = TextSecondary,
                        selectedTextColor = PrimaryBlue,
                        unselectedTextColor = TextSecondary,
                        indicatorColor = PrimaryBlueLight
                    ),
                    modifier = Modifier.testTag("bottom_nav_reports")
                )

                // 5. More (Secondary Navigation)
                NavigationBarItem(
                    selected = isMoreActive,
                    onClick = { showMoreSheet = true },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (criticalAlertsCount > 0 && isMoreActive) {
                                    Badge(containerColor = CriticalRed) {
                                        Text("$criticalAlertsCount", color = Color.White, fontSize = 8.sp)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = if (isMoreActive) Icons.Default.GridView else Icons.Default.MoreHoriz,
                                contentDescription = "More",
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    },
                    label = {
                        Text(
                            text = if (isMoreActive) currentTab.title.take(8) else "More",
                            fontSize = 11.sp,
                            fontWeight = if (isMoreActive) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = PrimaryBlue,
                        unselectedIconColor = TextSecondary,
                        selectedTextColor = PrimaryBlue,
                        unselectedTextColor = TextSecondary,
                        indicatorColor = PrimaryBlueLight
                    ),
                    modifier = Modifier.testTag("bottom_nav_more")
                )
            }
        },
        containerColor = OffWhiteBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Interactive Demo Mode HUD Overlay
            DemoModeBar(viewModel = viewModel)

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (currentTab) {
                    AppNavTab.COMMAND_CENTER -> CommandCenterScreen(viewModel = viewModel)
                    AppNavTab.ROUTE_PLANNER -> RoutePlannerScreen(viewModel = viewModel)
                    AppNavTab.LIVE_FLEET -> LiveFleetScreen(viewModel = viewModel)
                    AppNavTab.RISK_INTELLIGENCE -> RiskIntelligenceScreen(viewModel = viewModel)
                    AppNavTab.INCIDENTS -> IncidentsScreen(viewModel = viewModel)
                    AppNavTab.FIELD_REPORT -> FieldReportScreen(viewModel = viewModel)
                    AppNavTab.OFFLINE_CACHE -> com.example.ui.screens.OfflineTileCacheScreen(viewModel = viewModel)
                    AppNavTab.ALERTS -> AlertsScreen(viewModel = viewModel)
                    AppNavTab.ANALYTICS -> AnalyticsScreen(viewModel = viewModel)
                    AppNavTab.AI_ASSISTANT -> AIAssistantScreen(viewModel = viewModel)
                    AppNavTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                }
            }
        }

        // Secondary Navigation Bottom Sheet for Advanced Tools
        if (showMoreSheet) {
            ModalBottomSheet(
                onDismissRequest = { showMoreSheet = false },
                sheetState = sheetState,
                containerColor = PureWhite,
                scrimColor = Color.Black.copy(alpha = 0.35f)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .padding(bottom = 24.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Advanced Intelligence & Tools",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "Secondary operational modules & analytics",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        IconButton(onClick = { showMoreSheet = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    val secondaryItems = listOf(
                        SecondaryNavItem(
                            tab = AppNavTab.RISK_INTELLIGENCE,
                            title = "Risk Intelligence",
                            subtitle = "8-State vulnerability & radar",
                            icon = Icons.Default.Thunderstorm,
                            color = WarningAmber
                        ),
                        SecondaryNavItem(
                            tab = AppNavTab.ANALYTICS,
                            title = "Analytics",
                            subtitle = "Corridor throughput & delays",
                            icon = Icons.Default.Analytics,
                            color = PrimaryBlue
                        ),
                        SecondaryNavItem(
                            tab = AppNavTab.AI_ASSISTANT,
                            title = "AI Copilot",
                            subtitle = "Route dispatcher & advisor",
                            icon = Icons.Default.AutoAwesome,
                            color = AIPurpleAccent
                        ),
                        SecondaryNavItem(
                            tab = AppNavTab.ALERTS,
                            title = "Alerts Desk",
                            subtitle = "Broadcast warnings ($criticalAlertsCount active)",
                            icon = Icons.Default.Campaign,
                            color = CriticalRed
                        ),
                        SecondaryNavItem(
                            tab = AppNavTab.INCIDENTS,
                            title = "Incidents Log",
                            subtitle = "BRO road blockage history",
                            icon = Icons.Default.ReportProblem,
                            color = CriticalRed
                        ),
                        SecondaryNavItem(
                            tab = AppNavTab.OFFLINE_CACHE,
                            title = "Offline Mode",
                            subtitle = "Tile packs & mesh sync",
                            icon = Icons.Default.WifiOff,
                            color = SuccessGreen
                        ),
                        SecondaryNavItem(
                            tab = AppNavTab.SETTINGS,
                            title = "Settings & Roles",
                            subtitle = "Operator credentials & config",
                            icon = Icons.Default.Settings,
                            color = TextSecondary
                        )
                    )

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(secondaryItems) { item ->
                            val isSelected = currentTab == item.tab
                            Card(
                                onClick = {
                                    viewModel.setTab(item.tab)
                                    showMoreSheet = false
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) PrimaryBlueLight else PureWhite
                                ),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) PrimaryBlue else BorderLight
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(item.color.copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = item.icon,
                                            contentDescription = item.title,
                                            tint = item.color,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = item.title,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = TextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = item.subtitle,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                            fontSize = 9.sp,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class SecondaryNavItem(
    val tab: AppNavTab,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val color: Color
)

@Composable
fun HeaderThreeLineRoleSelector(
    currentRole: UserRole,
    onRoleSelected: (UserRole) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        // Compact white card/pill with subtle light-gray border and very small rounded corners
        Surface(
            onClick = { expanded = !expanded },
            shape = RoundedCornerShape(6.dp),
            color = PureWhite,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier
                .semantics {
                    contentDescription = "User role: ${currentRole.displayName}. Tap to change role."
                }
                .testTag("header_role_selector")
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                // Line 1: USER ROLE (very small uppercase muted-gray text)
                Text(
                    text = "USER ROLE",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF94A3B8),
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp,
                    lineHeight = 10.sp
                )

                // Line 2: Logistics Operator (main text, medium/semi-bold)
                Text(
                    text = currentRole.displayName,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF1E293B),
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 14.sp
                )

                // Line 3: ▼ Change role (small blue clickable action)
                Text(
                    text = "▼ Change role",
                    style = MaterialTheme.typography.labelSmall,
                    color = PrimaryBlue,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 10.sp
                )
            }
        }

        // Clean small dropdown/popover directly below the selector with sliding animation
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            offset = DpOffset(x = 0.dp, y = 4.dp),
            shape = RoundedCornerShape(10.dp),
            containerColor = PureWhite,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
            shadowElevation = 8.dp,
            modifier = Modifier
                .widthIn(min = 255.dp, max = 295.dp)
                .background(PureWhite)
        ) {
            AnimatedVisibility(
                visible = expanded,
                enter = fadeIn(animationSpec = tween(180)) + slideInVertically(
                    initialOffsetY = { -it / 4 },
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioLowBouncy,
                        stiffness = Spring.StiffnessMediumLow
                    )
                ),
                exit = fadeOut(animationSpec = tween(120)) + slideOutVertically(
                    targetOffsetY = { -it / 4 },
                    animationSpec = tween(120)
                )
            ) {
                Column(
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    UserRole.operationalRoles.forEach { role ->
                        val isSelected = currentRole == role
                        val roleIcon = when (role) {
                            UserRole.LOGISTICS_OPERATOR -> Icons.Default.LocalShipping
                            UserRole.COMMAND_CENTER -> Icons.Default.Dashboard
                            UserRole.FLEET_MANAGER -> Icons.Default.DirectionsCar
                            UserRole.DISASTER_RESPONSE -> Icons.Default.Warning
                            UserRole.FIELD_OFFICER -> Icons.Default.Person
                            else -> Icons.Default.Person
                        }

                        Surface(
                            onClick = {
                                onRoleSelected(role)
                                expanded = false
                            },
                            color = if (isSelected) Color(0xFFF0F7FF) else PureWhite,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("role_option_${role.name.lowercase()}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(horizontal = 12.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Small relevant icon on the left
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(
                                            if (isSelected) PrimaryBlue.copy(alpha = 0.12f)
                                            else Color(0xFFF1F5F9)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = roleIcon,
                                        contentDescription = null,
                                        tint = if (isSelected) PrimaryBlue else Color(0xFF64748B),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                // Role name and short description
                                Column(
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = role.displayName,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                        fontSize = 12.5.sp,
                                        color = if (isSelected) PrimaryBlue else Color(0xFF1E293B)
                                    )
                                    Text(
                                        text = role.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontSize = 10.5.sp,
                                        color = Color(0xFF64748B),
                                        lineHeight = 13.sp
                                    )
                                }

                                // Subtle checkmark beside the currently selected role
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = PrimaryBlue,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

