package com.example.engine

import com.example.data.models.DeliveryStatus
import com.example.data.models.LiveVehicle
import com.example.data.models.RoadIncident
import com.example.data.models.VehicleStatus
import com.example.data.models.VehicleType
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class SimulatedCorridor(
    val vehicleId: String,
    val vehicleNumber: String,
    val driverName: String,
    val driverPhone: String,
    val type: VehicleType,
    val cargoDescription: String,
    val isEmergencyPriority: Boolean,
    val originName: String,
    val destinationName: String,
    val activeRouteName: String,
    val waypoints: List<Pair<Double, Double>>,
    val baseAltitude: Int,
    val altitudeGain: Int
)

data class DeviationResult(
    val hasDeviated: Boolean,
    val deviationDistanceKm: Double
)

object FleetSimulationEngine {

    val CORRIDORS: List<SimulatedCorridor> = listOf(
        SimulatedCorridor(
            vehicleId = "V-101",
            vehicleNumber = "AS-01-GC-4921",
            driverName = "Biplab Das",
            driverPhone = "+91 94350 11223",
            type = VehicleType.COLD_CHAIN_MED,
            cargoDescription = "Critical Medical Insulin & Vaccine Kits",
            isEmergencyPriority = true,
            originName = "Guwahati Logistics Hub",
            destinationName = "Silchar Valley Depot",
            activeRouteName = "NH-27 Haflong Expressway",
            waypoints = listOf(
                Pair(26.1859, 91.7478), // Guwahati
                Pair(26.1150, 92.0500),
                Pair(26.1150, 92.2150), // Jagiroad
                Pair(26.2400, 92.4800),
                Pair(26.3450, 92.6850), // Nagaon
                Pair(26.0500, 92.9500),
                Pair(25.7500, 93.1700), // Lumding
                Pair(25.4200, 93.1000),
                Pair(25.1700, 93.0200), // Haflong
                Pair(25.1200, 92.9800), // Jatinga
                Pair(25.0400, 92.8500), // Harangajao
                Pair(24.9500, 92.8100),
                Pair(24.8333, 92.7789)  // Silchar
            ),
            baseAltitude = 55,
            altitudeGain = 820
        ),
        SimulatedCorridor(
            vehicleId = "V-102",
            vehicleNumber = "AR-02-B-8812",
            driverName = "Dorjee Khandu",
            driverPhone = "+91 98620 44556",
            type = VehicleType.COLD_CHAIN_MED,
            cargoDescription = "Critical High-Altitude Medicine & Vaccine Convoy",
            isEmergencyPriority = true,
            originName = "Guwahati Logistics Hub",
            destinationName = "Tawang Forward Outpost",
            activeRouteName = "NH-13 Sela Tunnel Corridor",
            waypoints = listOf(
                Pair(26.1445, 91.7362), // Guwahati
                Pair(26.4500, 92.3200), // Mangaldai
                Pair(26.6528, 92.7926), // Tezpur
                Pair(27.0125, 92.6450), // Bhalukpong
                Pair(27.1500, 92.4800), // Tenga
                Pair(27.2645, 92.4200), // Bomdila
                Pair(27.3580, 92.2420), // Dirang
                Pair(27.5020, 92.1050), // Sela Tunnel
                Pair(27.5450, 92.0500), // Jaswant Garh
                Pair(27.5750, 91.9850), // Jang
                Pair(27.5860, 91.8650)  // Tawang
            ),
            baseAltitude = 55,
            altitudeGain = 3100
        ),
        SimulatedCorridor(
            vehicleId = "V-103",
            vehicleNumber = "MN-01-T-3109",
            driverName = "Khamba Singh",
            driverPhone = "+91 97740 99881",
            type = VehicleType.HEAVY_TRUCK_16T,
            cargoDescription = "FCI Grain & Essential Food Supply",
            isEmergencyPriority = false,
            originName = "Silchar Valley Depot",
            destinationName = "Imphal Central Logistics",
            activeRouteName = "NH-37 Makru Bridge Lifeline",
            waypoints = listOf(
                Pair(24.8333, 92.7789), // Silchar
                Pair(24.7950, 92.9850), // Lakhipur
                Pair(24.7950, 93.1250), // Jiribam
                Pair(24.7800, 93.2800), // Oinamlong
                Pair(24.8100, 93.3500), // Makru Bridge
                Pair(24.7700, 93.4350), // Nungba
                Pair(24.8250, 93.5850), // Noney Gorge
                Pair(24.8350, 93.7250), // Tupul
                Pair(24.8170, 93.9368)  // Imphal
            ),
            baseAltitude = 40,
            altitudeGain = 780
        ),
        SimulatedCorridor(
            vehicleId = "V-104",
            vehicleNumber = "NL-07-F-7220",
            driverName = "Tepok Ao",
            driverPhone = "+91 96120 77112",
            type = VehicleType.FUEL_TANKER,
            cargoDescription = "High-Octane Aviation & Diesel Fuel",
            isEmergencyPriority = true,
            originName = "Dimapur Railhead Hub",
            destinationName = "Kohima Hill Base",
            activeRouteName = "NH-29 Kohima Hill Climb",
            waypoints = listOf(
                Pair(25.9044, 93.7275), // Dimapur
                Pair(25.8450, 93.7550),
                Pair(25.7950, 93.7850), // Chumukedima
                Pair(25.7750, 93.8250), // Kukidolong
                Pair(25.7550, 93.8750), // Medziphema
                Pair(25.7400, 93.9150), // Pherima
                Pair(25.7250, 93.9650), // Piphema
                Pair(25.6950, 94.0350), // Zubza
                Pair(25.6751, 94.1086)  // Kohima
            ),
            baseAltitude = 195,
            altitudeGain = 1444
        ),
        SimulatedCorridor(
            vehicleId = "V-105",
            vehicleNumber = "TR-01-M-4402",
            driverName = "Debashis Roy",
            driverPhone = "+91 94021 33445",
            type = VehicleType.COLD_CHAIN_MED,
            cargoDescription = "Emergency Oxygen Cylinders & Plasma",
            isEmergencyPriority = true,
            originName = "Agartala Central Base",
            destinationName = "Dharmanagar Depot",
            activeRouteName = "NH-8 Tripura Valley Highway",
            waypoints = listOf(
                Pair(23.8315, 91.2868), // Agartala
                Pair(23.8350, 91.4500), // Champaknagar
                Pair(23.8350, 91.6250), // Teliamura
                Pair(23.8650, 91.7350), // Mungiakami
                Pair(23.9250, 91.8550), // Ambassa
                Pair(23.9850, 92.0150), // Manu
                Pair(24.1650, 92.0250), // Kumarghat
                Pair(24.3750, 92.1650)  // Dharmanagar
            ),
            baseAltitude = 35,
            altitudeGain = 210
        ),
        SimulatedCorridor(
            vehicleId = "V-106",
            vehicleNumber = "SK-03-P-5519",
            driverName = "Karma Bhutia",
            driverPhone = "+91 98320 88990",
            type = VehicleType.ALL_TERRAIN_4X4,
            cargoDescription = "BRO Heavy Bridge Spares & Excavators",
            isEmergencyPriority = false,
            originName = "Gangtok Transit Depot",
            destinationName = "Nathu La Pass Outpost",
            activeRouteName = "JN Marg Alpine Highway",
            waypoints = listOf(
                Pair(27.3389, 88.6065), // Gangtok
                Pair(27.3480, 88.6650), // 3rd Mile
                Pair(27.3550, 88.7050), // 7th Mile
                Pair(27.3650, 88.7450), // Kyongnosla
                Pair(27.3750, 88.7620), // Tsomgo Lake
                Pair(27.3750, 88.8150), // Sherathang
                Pair(27.3860, 88.8310)  // Nathu La Pass
            ),
            baseAltitude = 1650,
            altitudeGain = 4310
        )
    )

    fun getInitialVehicles(): List<LiveVehicle> {
        return CORRIDORS.map { corridor ->
            val start = corridor.waypoints.first()
            val next = if (corridor.waypoints.size > 1) corridor.waypoints[1] else start
            val heading = calculateHeading(start.first, start.second, next.first, next.second)

            LiveVehicle(
                id = corridor.vehicleId,
                vehicleNumber = corridor.vehicleNumber,
                driverName = corridor.driverName,
                driverPhone = corridor.driverPhone,
                type = corridor.type,
                cargoDescription = corridor.cargoDescription,
                isEmergencyPriority = corridor.isEmergencyPriority,
                currentLat = start.first,
                currentLng = start.second,
                speedKmH = if (corridor.isEmergencyPriority) 48 else 38,
                headingDegrees = heading,
                altitudeMeters = corridor.baseAltitude,
                fuelLevelPct = 95,
                status = VehicleStatus.IN_TRANSIT,
                deliveryStatus = DeliveryStatus.ON_TIME,
                activeRouteName = corridor.activeRouteName,
                originName = corridor.originName,
                destinationName = corridor.destinationName,
                etaMinutes = 240,
                signalStatus = if (corridor.baseAltitude > 2000) "Satellite GPS" else "4G/5G Live",
                isSimulated = true,
                hasDeviated = false,
                deviationDistanceKm = 0.0,
                lastUpdateTimestamp = System.currentTimeMillis(),
                waypointIndex = 0
            )
        }
    }

    /**
     * Advances simulated vehicles along their predefined corridor waypoints.
     */
    fun tickSimulatedVehicles(
        currentVehicles: List<LiveVehicle>,
        activeIncidents: List<RoadIncident>,
        speedMultiplier: Int
    ): List<LiveVehicle> {
        return currentVehicles.map { v ->
            val corridor = CORRIDORS.find { it.vehicleId == v.id } ?: return@map v
            val waypoints = corridor.waypoints
            if (waypoints.isEmpty()) return@map v

            // Check if vehicle has already completed delivery
            if (v.waypointIndex >= waypoints.size - 1 && !v.hasDeviated) {
                val lastWp = waypoints.last()
                return@map v.copy(
                    currentLat = lastWp.first,
                    currentLng = lastWp.second,
                    speedKmH = 0,
                    status = VehicleStatus.ARRIVED,
                    deliveryStatus = DeliveryStatus.DELIVERED,
                    etaMinutes = 0,
                    lastUpdateTimestamp = System.currentTimeMillis()
                )
            }

            // Next waypoint index progression
            val nextIdx = (v.waypointIndex + 1).coerceAtMost(waypoints.size - 1)
            val currentTarget = waypoints[nextIdx]
            val prevPoint = waypoints[v.waypointIndex.coerceAtMost(waypoints.size - 1)]

            // Interpolate coordinate based on speed multiplier
            val stepFraction = (0.12 * speedMultiplier).coerceAtMost(1.0)
            val newLat = v.currentLat + (currentTarget.first - v.currentLat) * stepFraction
            val newLng = v.currentLng + (currentTarget.second - v.currentLng) * stepFraction

            // Check if arrived at this waypoint segment
            val distToTargetKm = calculateDistanceKm(newLat, newLng, currentTarget.first, currentTarget.second)
            val updatedIdx = if (distToTargetKm < 1.2 && nextIdx < waypoints.size - 1) {
                nextIdx
            } else {
                v.waypointIndex
            }

            // Heading calculation
            val heading = calculateHeading(newLat, newLng, currentTarget.first, currentTarget.second)

            // Altitude calculation
            val progressFraction = updatedIdx.toDouble() / (waypoints.size - 1).coerceAtLeast(1)
            val newAltitude = corridor.baseAltitude + (corridor.altitudeGain * progressFraction).toInt()

            // Check if vehicle is near active incidents on corridor
            val hasNearIncident = activeIncidents.any { inc ->
                calculateDistanceKm(newLat, newLng, inc.latitude, inc.longitude) < 18.0
            }

            // Check corridor deviation
            val devResult = if (v.hasDeviated) {
                DeviationResult(hasDeviated = true, deviationDistanceKm = v.deviationDistanceKm)
            } else {
                checkRouteDeviation(newLat, newLng, waypoints)
            }

            // Determine delivery status
            val deliveryStatus = when {
                updatedIdx >= waypoints.size - 1 && distToTargetKm < 1.5 -> DeliveryStatus.DELIVERED
                devResult.hasDeviated -> DeliveryStatus.AT_RISK
                hasNearIncident -> DeliveryStatus.DELAYED
                else -> DeliveryStatus.ON_TIME
            }

            val vehicleStatus = when {
                deliveryStatus == DeliveryStatus.DELIVERED -> VehicleStatus.ARRIVED
                devResult.hasDeviated -> VehicleStatus.EMERGENCY_STOP
                hasNearIncident -> VehicleStatus.DELAYED_RISK
                else -> VehicleStatus.IN_TRANSIT
            }

            // Speed calculation
            val baseSpeed = if (corridor.isEmergencyPriority) 52 else 40
            val terrainDrag = if (newAltitude > 2000) 12 else 0
            val calculatedSpeed = when {
                deliveryStatus == DeliveryStatus.DELIVERED -> 0
                deliveryStatus == DeliveryStatus.AT_RISK -> 22
                deliveryStatus == DeliveryStatus.DELAYED -> 15
                else -> (baseSpeed - terrainDrag).coerceAtLeast(20)
            }

            // Remaining ETA calculation in minutes
            val remainingWaypointsCount = (waypoints.size - 1 - updatedIdx).coerceAtLeast(0)
            val remainingEtaMin = (remainingWaypointsCount * 25 / speedMultiplier.coerceAtLeast(1)).coerceAtLeast(5)

            v.copy(
                currentLat = newLat,
                currentLng = newLng,
                speedKmH = calculatedSpeed,
                headingDegrees = heading,
                altitudeMeters = newAltitude,
                fuelLevelPct = (v.fuelLevelPct - (0.05 * speedMultiplier).toInt()).coerceAtLeast(12),
                status = vehicleStatus,
                deliveryStatus = deliveryStatus,
                etaMinutes = if (deliveryStatus == DeliveryStatus.DELIVERED) 0 else remainingEtaMin,
                hasDeviated = devResult.hasDeviated,
                deviationDistanceKm = devResult.deviationDistanceKm,
                lastUpdateTimestamp = System.currentTimeMillis(),
                waypointIndex = updatedIdx
            )
        }
    }

    /**
     * Calculates the minimum perpendicular distance from coordinate to planned polyline.
     */
    fun checkRouteDeviation(
        lat: Double,
        lng: Double,
        plannedWaypoints: List<Pair<Double, Double>>
    ): DeviationResult {
        if (plannedWaypoints.size < 2) return DeviationResult(false, 0.0)

        var minDistanceKm = Double.MAX_VALUE

        for (i in 0 until plannedWaypoints.size - 1) {
            val p1 = plannedWaypoints[i]
            val p2 = plannedWaypoints[i + 1]
            val dist = pointToSegmentDistanceKm(lat, lng, p1.first, p1.second, p2.first, p2.second)
            if (dist < minDistanceKm) {
                minDistanceKm = dist
            }
        }

        // Deviation threshold: > 2.5 km off planned highway corridor
        val hasDeviated = minDistanceKm > 2.5
        return DeviationResult(
            hasDeviated = hasDeviated,
            deviationDistanceKm = if (hasDeviated) minDistanceKm else 0.0
        )
    }

    /**
     * Deliberately moves vehicle off planned corridor to demonstrate route deviation detection.
     */
    fun triggerVehicleDeviation(
        vehicles: List<LiveVehicle>,
        targetVehicleId: String = "V-102"
    ): List<LiveVehicle> {
        return vehicles.map { v ->
            if (v.id == targetVehicleId) {
                // Offset latitude and longitude significantly into an unauthorized mountain side valley (~4.5 km)
                v.copy(
                    currentLat = v.currentLat + 0.038,
                    currentLng = v.currentLng + 0.035,
                    hasDeviated = true,
                    deviationDistanceKm = 4.6,
                    deliveryStatus = DeliveryStatus.AT_RISK,
                    status = VehicleStatus.EMERGENCY_STOP,
                    lastUpdateTimestamp = System.currentTimeMillis()
                )
            } else {
                v
            }
        }
    }

    fun clearVehicleDeviation(
        vehicles: List<LiveVehicle>,
        targetVehicleId: String = "V-102"
    ): List<LiveVehicle> {
        val corridor = CORRIDORS.find { it.vehicleId == targetVehicleId } ?: return vehicles
        return vehicles.map { v ->
            if (v.id == targetVehicleId) {
                val wp = corridor.waypoints.getOrNull(v.waypointIndex) ?: corridor.waypoints.first()
                v.copy(
                    currentLat = wp.first,
                    currentLng = wp.second,
                    hasDeviated = false,
                    deviationDistanceKm = 0.0,
                    deliveryStatus = DeliveryStatus.ON_TIME,
                    status = VehicleStatus.IN_TRANSIT,
                    lastUpdateTimestamp = System.currentTimeMillis()
                )
            } else {
                v
            }
        }
    }

    /**
     * Reroutes the Guwahati to Tawang medicine vehicle to the safe Bhairabkunda bypass corridor.
     */
    fun rerouteVehicleToTawangBypass(
        vehicles: List<LiveVehicle>,
        targetVehicleId: String = "V-102"
    ): List<LiveVehicle> {
        return vehicles.map { v ->
            if (v.id == targetVehicleId) {
                v.copy(
                    activeRouteName = "Diverted via Bhairabkunda Bypass",
                    status = VehicleStatus.REROUTING,
                    deliveryStatus = DeliveryStatus.ON_TIME,
                    currentLat = 26.8800,
                    currentLng = 92.1100,
                    altitudeMeters = 650,
                    hasDeviated = false,
                    deviationDistanceKm = 0.0,
                    etaMinutes = 680,
                    signalStatus = "Satellite Mesh Diverted",
                    lastUpdateTimestamp = System.currentTimeMillis()
                )
            } else {
                v
            }
        }
    }

    // --- Math & Geospatial Utilities ---

    fun calculateDistanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0 // Earth radius in km
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    fun calculateHeading(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Float {
        val dLon = Math.toRadians(lon2 - lon1)
        val lat1Rad = Math.toRadians(lat1)
        val lat2Rad = Math.toRadians(lat2)

        val y = sin(dLon) * cos(lat2Rad)
        val x = cos(lat1Rad) * sin(lat2Rad) - sin(lat1Rad) * cos(lat2Rad) * cos(dLon)
        val radians = atan2(y, x)
        var degrees = Math.toDegrees(radians).toFloat()
        if (degrees < 0) degrees += 360f
        return degrees
    }

    private fun pointToSegmentDistanceKm(
        pLat: Double, pLng: Double,
        aLat: Double, aLng: Double,
        bLat: Double, bLng: Double
    ): Double {
        val l2 = (bLat - aLat) * (bLat - aLat) + (bLng - aLng) * (bLng - aLng)
        if (l2 == 0.0) return calculateDistanceKm(pLat, pLng, aLat, aLng)

        val t = (((pLat - aLat) * (bLat - aLat) + (pLng - aLng) * (bLng - aLng)) / l2).coerceIn(0.0, 1.0)
        val projLat = aLat + t * (bLat - aLat)
        val projLng = aLng + t * (bLng - aLng)
        return calculateDistanceKm(pLat, pLng, projLat, projLng)
    }
}
