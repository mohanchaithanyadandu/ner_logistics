package com.example.engine

import com.example.data.models.IncidentSeverity
import com.example.data.models.IncidentType
import com.example.data.models.NERState
import com.example.data.models.UserRole
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.NERLogisticsViewModel

/**
 * Data model for a single step in the SIH 2026 End-to-End Demo Workflow.
 */
data class DemoStep(
    val stepIndex: Int, // 1..23
    val title: String,
    val categoryBadge: String,
    val description: String,
    val keyActionLabel: String,
    val targetTab: AppNavTab,
    val targetRole: UserRole = UserRole.LOGISTICS_OPERATOR,
    val isSimulationActive: Boolean = false,
    val autoAdvanceDelayMs: Long = 8000L
)

/**
 * Orchestrates the official 23-Step SIH 2026 End-to-End Hackathon Demonstration.
 * Guides the presenter through authentic application capabilities with 1-click execution.
 */
object DemoWorkflowManager {

    val STEPS: List<DemoStep> = listOf(
        DemoStep(
            stepIndex = 1,
            title = "1. NER Command Center Overview",
            categoryBadge = "COMMAND CENTER",
            description = "Start at the Command Center dashboard monitoring 8 North Eastern states, vital mountain corridors, and real-time operational status.",
            keyActionLabel = "View Command Center",
            targetTab = AppNavTab.COMMAND_CENTER,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = false
        ),
        DemoStep(
            stepIndex = 2,
            title = "2. Active Logistics Fleet",
            categoryBadge = "FLEET TELEMATICS",
            description = "Inspect active logistics vehicles moving across high-altitude corridors with live GPS coordinates, altitude profiles, and speeds.",
            keyActionLabel = "Inspect Active Fleet",
            targetTab = AppNavTab.LIVE_FLEET,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = false
        ),
        DemoStep(
            stepIndex = 3,
            title = "3. Select Delivery: Guwahati ➔ Tawang",
            categoryBadge = "HIGH-PRIORITY CARGO",
            description = "Select the high-priority medicine & vaccine delivery convoy (Vehicle V-102) transiting from Guwahati Hub to Tawang Outpost.",
            keyActionLabel = "Select Medicine Shipment",
            targetTab = AppNavTab.ROUTE_PLANNER,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = false
        ),
        DemoStep(
            stepIndex = 4,
            title = "4. Open AI Route Planner",
            categoryBadge = "ROUTE PLANNER",
            description = "Compute multi-criteria mountain routes from Guwahati to Tawang factoring road grade, elevation gain, and weather exposure.",
            keyActionLabel = "Compute Route Candidates",
            targetTab = AppNavTab.ROUTE_PLANNER,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = false
        ),
        DemoStep(
            stepIndex = 5,
            title = "5. Display Multiple Route Options",
            categoryBadge = "MULTI-CRITERIA GIS",
            description = "Compare Candidate 1 (NH-13 via Sela Tunnel: 448km, 11.5h) vs Candidate 2 (Bhairabkunda Bypass: 422km, 12.5h) with distance, ETA, and risk factors.",
            keyActionLabel = "Review Route Comparison",
            targetTab = AppNavTab.ROUTE_PLANNER,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = false
        ),
        DemoStep(
            stepIndex = 6,
            title = "6. AI Recommends the Safer Route",
            categoryBadge = "AI RECOMMENDATION",
            description = "AI optimization algorithm selects NH-13 via Sela Tunnel as recommended due to high-capacity infrastructure and lower slope vulnerability in clear weather.",
            keyActionLabel = "Inspect AI Recommendation",
            targetTab = AppNavTab.ROUTE_PLANNER,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = false
        ),
        DemoStep(
            stepIndex = 7,
            title = "7. Trigger: Simulate Heavy Rain",
            categoryBadge = "DISASTER SIMULATION",
            description = "Simulate a severe monsoon cloudburst (>90mm/hr precipitation) over Western Arunachal & Assam border corridors.",
            keyActionLabel = "Simulate Heavy Rain",
            targetTab = AppNavTab.ROUTE_PLANNER,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = true
        ),
        DemoStep(
            stepIndex = 8,
            title = "8. Risk Engine Updates Affected Corridors",
            categoryBadge = "RISK ENGINE",
            description = "Dynamic risk engine immediately recalculates soil moisture saturation to 98% and elevates landslide early warnings across mountain passes.",
            keyActionLabel = "View Recalculated Risks",
            targetTab = AppNavTab.ROUTE_PLANNER,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = true
        ),
        DemoStep(
            stepIndex = 9,
            title = "9. Trigger: Simulate Road Blockage",
            categoryBadge = "INCIDENT INJECTION",
            description = "Simulate a 4,200 m³ rockfall and mudslide blockage at Bhalukpong Ghat (NH-13 Km 42) obstructing Sela Tunnel passage.",
            keyActionLabel = "Simulate Road Blockage",
            targetTab = AppNavTab.ROUTE_PLANNER,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = true
        ),
        DemoStep(
            stepIndex = 10,
            title = "10. Incident Appears on Map",
            categoryBadge = "GIS MAP HUD",
            description = "Critical hazard pin and 12km danger radius are dynamically rendered on the interactive OpenStreetMap and Canvas GIS layers.",
            keyActionLabel = "Focus Incident on Map",
            targetTab = AppNavTab.ROUTE_PLANNER,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = true
        ),
        DemoStep(
            stepIndex = 11,
            title = "11. Existing Route Risk Increases",
            categoryBadge = "RISK ESCALATION",
            description = "Direct collision with the rockfall elevates NH-13 composite risk to 95/100 (CRITICAL) and adds +180 min clearance delay.",
            keyActionLabel = "Observe Risk Elevation",
            targetTab = AppNavTab.ROUTE_PLANNER,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = true
        ),
        DemoStep(
            stepIndex = 12,
            title = "12. AI Recommends Alternate Route",
            categoryBadge = "DYNAMIC REROUTING",
            description = "AI route engine automatically shifts recommended route to the safe Bhairabkunda - Rupa Bypass corridor.",
            keyActionLabel = "Select Alternate Bypass",
            targetTab = AppNavTab.ROUTE_PLANNER,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = true
        ),
        DemoStep(
            stepIndex = 13,
            title = "13. ETA Changes & Reroute Scoring",
            categoryBadge = "ETA RECALCULATION",
            description = "Updated comparison metrics display safe transit time on the bypass route vs indefinite bottleneck delays at the rockfall zone.",
            keyActionLabel = "Review New Route ETA",
            targetTab = AppNavTab.ROUTE_PLANNER,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = true
        ),
        DemoStep(
            stepIndex = 14,
            title = "14. Emergency Broadcast Alert Appears",
            categoryBadge = "EMERGENCY BROADCAST",
            description = "Automated high-priority broadcast alert distributed across all regional control terminals and convoy drivers.",
            keyActionLabel = "View Broadcast Alert",
            targetTab = AppNavTab.ALERTS,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = true
        ),
        DemoStep(
            stepIndex = 15,
            title = "15. Vehicle Rerouted in Demo Simulation",
            categoryBadge = "LIVE FLEET REROUTE",
            description = "Active medical transport (V-102) telematics dynamically diverts onto the Bhairabkunda Bypass in real-time.",
            keyActionLabel = "Inspect Diverted Convoy",
            targetTab = AppNavTab.LIVE_FLEET,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = true
        ),
        DemoStep(
            stepIndex = 16,
            title = "16. Open Field Officer Mode",
            categoryBadge = "ROLE SWITCH",
            description = "Switch operator role to Field Officer (Border Roads Organisation) on the ground in a low-connectivity mountain sector.",
            keyActionLabel = "Switch to Field Officer",
            targetTab = AppNavTab.FIELD_REPORT,
            targetRole = UserRole.FIELD_OFFICER,
            isSimulationActive = false
        ),
        DemoStep(
            stepIndex = 17,
            title = "17. Submit Road-Blockage Report",
            categoryBadge = "FIELD INCIDENT REPORT",
            description = "Prepare an incident report for Chumukedima Ghat mudslide with 60% blockage, clearance estimate, and geo-tagged photo.",
            keyActionLabel = "Prepare Incident Report",
            targetTab = AppNavTab.FIELD_REPORT,
            targetRole = UserRole.FIELD_OFFICER,
            isSimulationActive = false
        ),
        DemoStep(
            stepIndex = 18,
            title = "18. Demonstrate Offline Saving",
            categoryBadge = "OFFLINE SQLITE PERSISTENCE",
            description = "Sever internet connectivity. Submit report to store in local Room database; report queues with 'QUEUED IN LOCAL ROOM DB' status.",
            keyActionLabel = "Save Offline to Room DB",
            targetTab = AppNavTab.FIELD_REPORT,
            targetRole = UserRole.FIELD_OFFICER,
            isSimulationActive = true
        ),
        DemoStep(
            stepIndex = 19,
            title = "19. Restore Connectivity",
            categoryBadge = "CONNECTIVITY RESTORE",
            description = "Vehicle enters satellite/cellular coverage zone; terminal connectivity status updates to ONLINE.",
            keyActionLabel = "Restore Connectivity",
            targetTab = AppNavTab.FIELD_REPORT,
            targetRole = UserRole.FIELD_OFFICER,
            isSimulationActive = false
        ),
        DemoStep(
            stepIndex = 20,
            title = "20. Synchronize Report",
            categoryBadge = "DATABASE SYNC",
            description = "Execute zero-data-loss synchronization, uploading queued offline reports to the central SQLite/Room database.",
            keyActionLabel = "Synchronize Offline Reports",
            targetTab = AppNavTab.FIELD_REPORT,
            targetRole = UserRole.FIELD_OFFICER,
            isSimulationActive = false
        ),
        DemoStep(
            stepIndex = 21,
            title = "21. Return to Command Center",
            categoryBadge = "COMMAND CENTER",
            description = "Switch role back to Logistics Operator and return to central Command Center dashboard.",
            keyActionLabel = "Return to Command Center",
            targetTab = AppNavTab.COMMAND_CENTER,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = false
        ),
        DemoStep(
            stepIndex = 22,
            title = "22. Show Report Appearing on Map",
            categoryBadge = "GIS SYNCHRONIZATION",
            description = "The freshly synchronized field report is live on the tactical GIS map and ingested by the regional risk engine.",
            keyActionLabel = "Inspect Synchronized Hazard",
            targetTab = AppNavTab.COMMAND_CENTER,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = false
        ),
        DemoStep(
            stepIndex = 23,
            title = "23. Open AI Assistant (Tactical Query)",
            categoryBadge = "GROUNDED AI COPILOT",
            description = "Ask AI Copilot: 'What is the most critical operational issue right now?' Grounded response analyzes live application state.",
            keyActionLabel = "Ask Grounded AI Assistant",
            targetTab = AppNavTab.AI_ASSISTANT,
            targetRole = UserRole.LOGISTICS_OPERATOR,
            isSimulationActive = false
        )
    )

    /**
     * Executes the application state transitions associated with a given demo step.
     */
    suspend fun executeStepAction(step: DemoStep, viewModel: NERLogisticsViewModel) {
        // Switch tab and role
        viewModel.setTab(step.targetTab)
        viewModel.setRole(step.targetRole)

        when (step.stepIndex) {
            1 -> {
                // Command Center baseline: clear test simulations if needed
                viewModel.clearLandslideSimNH6()
                viewModel.clearLandslideSimTawang()
                viewModel.setOfflineSimulation(false)
                viewModel.startFleetSimulation()
            }
            2 -> {
                // Live fleet view
                viewModel.startFleetSimulation()
            }
            3, 4 -> {
                // Route planner for Guwahati -> Tawang
                val ghy = RouteOptimizer.getLocationById("GHY")
                val twg = RouteOptimizer.getLocationById("TWG")
                if (ghy != null && twg != null) {
                    viewModel.setOrigin(ghy)
                    viewModel.setDestination(twg)
                }
            }
            5 -> {
                // Display options
                viewModel.calculateCurrentRoute()
            }
            6 -> {
                // Safer route recommended (Candidate 0)
                val candidates = viewModel.routeCandidates.value
                if (candidates.isNotEmpty()) {
                    viewModel.selectRouteCandidate(candidates[0])
                }
            }
            7 -> {
                // Simulate Heavy Rain
                viewModel.simulateHeavyMonsoonRain()
            }
            8 -> {
                // Recalculate routes with heavy rain
                viewModel.calculateCurrentRoute()
            }
            9, 10, 11 -> {
                // Simulate Road Blockage on NH-13
                viewModel.triggerLandslideSimTawang()
                viewModel.calculateCurrentRoute()
            }
            12, 13 -> {
                // Alternate route recommendation (Candidate 1 - Bypass)
                val candidates = viewModel.routeCandidates.value
                val bypass = candidates.find { it.name.contains("Bypass", ignoreCase = true) }
                    ?: candidates.minByOrNull { it.compositeRiskScore }
                if (bypass != null) {
                    viewModel.selectRouteCandidate(bypass)
                }
            }
            14 -> {
                // Alerts tab
                viewModel.setTab(AppNavTab.ALERTS)
            }
            15 -> {
                // Live fleet tab with diverted convoy
                viewModel.setTab(AppNavTab.LIVE_FLEET)
            }
            16 -> {
                // Field officer mode
                viewModel.setRole(UserRole.FIELD_OFFICER)
                viewModel.setTab(AppNavTab.FIELD_REPORT)
            }
            17 -> {
                // Field Report prepared
                viewModel.setRole(UserRole.FIELD_OFFICER)
                viewModel.setTab(AppNavTab.FIELD_REPORT)
            }
            18 -> {
                // Sever connectivity and submit offline report
                viewModel.setOfflineSimulation(true)
                viewModel.submitFieldReport(
                    reporterName = "Officer T. Jamir",
                    locationName = "Chumukedima Ghat (NH-29)",
                    state = NERState.NAGALAND,
                    type = IncidentType.LANDSLIDE,
                    severity = IncidentSeverity.MODERATE,
                    blockagePct = 60f,
                    clearanceEtaHours = 3.5,
                    notes = "Soil liquefaction and loose boulders blocking northbound lane. Single line convoy operating.",
                    photoUri = "IMG_20260902_NH29_SLIDE.JPG",
                    photoFileSize = "2.4 MB"
                )
            }
            19 -> {
                // Restore connectivity
                viewModel.setOfflineSimulation(false)
            }
            20 -> {
                // Synchronize offline reports
                viewModel.syncAllOfflineReports()
            }
            21 -> {
                // Return to Command Center
                viewModel.setRole(UserRole.LOGISTICS_OPERATOR)
                viewModel.setTab(AppNavTab.COMMAND_CENTER)
            }
            22 -> {
                // Incident appearing on map
                viewModel.setTab(AppNavTab.COMMAND_CENTER)
            }
            23 -> {
                // AI Assistant Tactical Query
                viewModel.setTab(AppNavTab.AI_ASSISTANT)
                viewModel.sendAIPrompt("What is the most critical operational issue right now?")
            }
        }
    }
}
