package com.example.engine

import android.util.Log
import com.example.data.models.GpsTelemetryPing
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

enum class TelemetryMode(val label: String, val badge: String) {
    DEMO_SIMULATION("Demo Simulation Mode", "SIMULATED"),
    REAL_WEBSOCKET_GPS("Real-Time GPS Ingestion", "LIVE GPS")
}

enum class WebSocketStatus(val label: String) {
    DISCONNECTED("Disconnected"),
    CONNECTING("Connecting..."),
    CONNECTED("Connected (Live Stream)"),
    LISTENING_LOCAL("Listening on Telemetry Channel"),
    ERROR("Connection Failed")
}

data class TelemetryLogEntry(
    val timestamp: Long = System.currentTimeMillis(),
    val direction: String, // "INCOMING_WS", "OUTGOING_WS", "LOCAL_PING"
    val rawPayload: String,
    val isRealGps: Boolean
)

class GpsWebSocketManager(
    private val onGpsPingReceived: suspend (GpsTelemetryPing) -> Unit
) {
    private val scope = CoroutineScope(Dispatchers.IO)
    private val okHttpClient = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .build()

    private var activeWebSocket: WebSocket? = null

    private val _telemetryMode = MutableStateFlow(TelemetryMode.DEMO_SIMULATION)
    val telemetryMode: StateFlow<TelemetryMode> = _telemetryMode.asStateFlow()

    private val _webSocketStatus = MutableStateFlow(WebSocketStatus.LISTENING_LOCAL)
    val webSocketStatus: StateFlow<WebSocketStatus> = _webSocketStatus.asStateFlow()

    private val _incomingTelemetryFlow = MutableSharedFlow<GpsTelemetryPing>(extraBufferCapacity = 64)
    val incomingTelemetryFlow: SharedFlow<GpsTelemetryPing> = _incomingTelemetryFlow.asSharedFlow()

    private val _recentLogs = MutableStateFlow<List<TelemetryLogEntry>>(emptyList())
    val recentLogs: StateFlow<List<TelemetryLogEntry>> = _recentLogs.asStateFlow()

    private val _connectedEndpoint = MutableStateFlow("ws://10.0.2.2:8080/fleet/gps")
    val connectedEndpoint: StateFlow<String> = _connectedEndpoint.asStateFlow()

    fun setTelemetryMode(mode: TelemetryMode) {
        _telemetryMode.value = mode
        appendLog("MODE_SWITCH", "Switched telemetry mode to ${mode.label}", mode == TelemetryMode.REAL_WEBSOCKET_GPS)
    }

    fun setEndpoint(url: String) {
        _connectedEndpoint.value = url
    }

    /**
     * Connects to a remote or local WebSocket GPS server
     */
    fun connectWebSocket(endpointUrl: String = _connectedEndpoint.value) {
        _connectedEndpoint.value = endpointUrl
        _webSocketStatus.value = WebSocketStatus.CONNECTING
        appendLog("CONNECT_REQ", "Initiating WebSocket connection to $endpointUrl", true)

        try {
            activeWebSocket?.close(1000, "Reconnecting")
            val request = Request.Builder().url(endpointUrl).build()

            activeWebSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    _webSocketStatus.value = WebSocketStatus.CONNECTED
                    appendLog("INCOMING_WS", "WebSocket stream connected: ${response.message}", true)
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    handleIncomingRawJson(text, isFromWebSocket = true)
                }

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    webSocket.close(1000, null)
                    _webSocketStatus.value = WebSocketStatus.DISCONNECTED
                    appendLog("WS_CLOSED", "WebSocket closed: $reason (code $code)", true)
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    _webSocketStatus.value = WebSocketStatus.ERROR
                    appendLog("WS_ERROR", "Connection error: ${t.localizedMessage ?: "Unknown"}", true)
                }
            })
        } catch (e: Exception) {
            _webSocketStatus.value = WebSocketStatus.ERROR
            appendLog("WS_EXCEPTION", "Failed to initialize WebSocket: ${e.message}", true)
        }
    }

    fun disconnectWebSocket() {
        activeWebSocket?.close(1000, "User disconnected")
        activeWebSocket = null
        _webSocketStatus.value = WebSocketStatus.DISCONNECTED
        appendLog("WS_DISCONNECT", "WebSocket disconnected by user", true)
    }

    /**
     * Ingests a raw JSON GPS packet (from WebSocket, HTTP webhook, or manual test console).
     */
    fun handleIncomingRawJson(jsonText: String, isFromWebSocket: Boolean = false) {
        try {
            val json = JSONObject(jsonText)
            val vehicleId = json.optString("vehicleId", json.optString("id", "V-102"))
            val lat = json.optDouble("latitude", json.optDouble("lat", 25.125))
            val lng = json.optDouble("longitude", json.optDouble("lng", 92.365))
            val speed = json.optInt("speedKmH", json.optInt("speed", 45))
            val heading = json.optDouble("headingDegrees", json.optDouble("heading", 0.0)).toFloat()
            val altitude = json.optInt("altitudeMeters", json.optInt("altitude", 600))
            val isReal = json.optBoolean("isRealGps", true)

            val ping = GpsTelemetryPing(
                vehicleId = vehicleId,
                latitude = lat,
                longitude = lng,
                speedKmH = speed,
                headingDegrees = heading,
                altitudeMeters = altitude,
                timestamp = System.currentTimeMillis(),
                isRealGps = isReal
            )

            appendLog(
                direction = if (isFromWebSocket) "INCOMING_WS" else "LOCAL_INGEST",
                rawPayload = jsonText,
                isRealGps = isReal
            )

            scope.launch {
                _incomingTelemetryFlow.emit(ping)
                onGpsPingReceived(ping)
            }
        } catch (e: Exception) {
            Log.e("GpsWebSocketManager", "Failed to parse incoming GPS JSON: ${e.message}", e)
            appendLog("PARSE_ERROR", "Error parsing GPS frame: ${e.message}", false)
        }
    }

    /**
     * Emits a simulated or live telemetry frame out over the active WebSocket
     */
    fun broadcastVehicleTelemetry(ping: GpsTelemetryPing) {
        val json = JSONObject().apply {
            put("vehicleId", ping.vehicleId)
            put("latitude", ping.latitude)
            put("longitude", ping.longitude)
            put("speedKmH", ping.speedKmH)
            put("headingDegrees", ping.headingDegrees)
            put("altitudeMeters", ping.altitudeMeters)
            put("timestamp", ping.timestamp)
            put("isRealGps", ping.isRealGps)
        }.toString()

        activeWebSocket?.send(json)
        appendLog("OUTGOING_WS", json, ping.isRealGps)
    }

    private fun appendLog(direction: String, rawPayload: String, isRealGps: Boolean) {
        val entry = TelemetryLogEntry(
            timestamp = System.currentTimeMillis(),
            direction = direction,
            rawPayload = rawPayload,
            isRealGps = isRealGps
        )
        val current = _recentLogs.value.toMutableList()
        if (current.size >= 40) {
            current.removeAt(current.size - 1)
        }
        current.add(0, entry)
        _recentLogs.value = current
    }
}
