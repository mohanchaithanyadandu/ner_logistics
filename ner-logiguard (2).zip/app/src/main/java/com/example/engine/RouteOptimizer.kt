package com.example.engine

import com.example.data.models.IncidentSeverity
import com.example.data.models.LocationPoint
import com.example.data.models.NERState
import com.example.data.models.RiskLevel
import com.example.data.models.RoadIncident
import com.example.data.models.RouteCandidate
import com.example.data.models.RouteSegment
import com.example.data.models.TerrainType
import com.example.data.remote.CompositeRoutingService
import com.example.data.remote.RawRouteResult
import kotlin.math.roundToInt
import kotlinx.coroutines.runBlocking

object RouteOptimizer {

    private val routingService = CompositeRoutingService()

    // Key Logistics Hubs across India and all 8 North Eastern States
    val HUBS = listOf(
        // Pan-India Major Metros & Logistics Gateways
        LocationPoint("BLR", "Bengaluru Tech & Freight Hub", NERState.KARNATAKA, 12.9716, 77.5946, 920, TerrainType.PLAINS),
        LocationPoint("DEL", "Delhi NCR Multi-Modal Cargo Hub", NERState.DELHI, 28.6139, 77.2090, 216, TerrainType.PLAINS),
        LocationPoint("MUM", "Mumbai Port & Container Depot", NERState.MAHARASHTRA, 19.0760, 72.8777, 14, TerrainType.PLAINS),
        LocationPoint("KOL", "Kolkata Eastern Logistics Terminal", NERState.WEST_BENGAL, 22.5726, 88.3639, 9, TerrainType.RIVER_BASIN),
        LocationPoint("HYD", "Hyderabad Central Distribution Hub", NERState.TELANGANA, 17.3850, 78.4867, 542, TerrainType.PLAINS),
        LocationPoint("CHE", "Chennai Automotive Maritime Gateway", NERState.TAMIL_NADU, 13.0827, 80.2707, 10, TerrainType.PLAINS),
        LocationPoint("PUN", "Pune Industrial Freight Depot", NERState.MAHARASHTRA, 18.5204, 73.8567, 560, TerrainType.PLAINS),
        LocationPoint("AHM", "Ahmedabad Commercial Hub", NERState.GUJARAT, 23.0225, 72.5714, 53, TerrainType.PLAINS),
        LocationPoint("JAI", "Jaipur Northern Logistics Node", NERState.RAJASTHAN, 26.9124, 75.7873, 431, TerrainType.PLAINS),
        LocationPoint("LKO", "Lucknow Central Distribution Center", NERState.UTTAR_PRADESH, 26.8467, 80.9462, 123, TerrainType.PLAINS),
        LocationPoint("KOC", "Kochi Deepwater Container Terminal", NERState.KERALA, 9.9312, 76.2673, 5, TerrainType.PLAINS),
        LocationPoint("PAT", "Patna Ganges Freight Depot", NERState.BIHAR, 25.5941, 85.1376, 53, TerrainType.RIVER_BASIN),
        LocationPoint("SXR", "Srinagar Valley Strategic Depot", NERState.JAMMU_AND_KASHMIR, 34.0837, 74.7973, 1585, TerrainType.HILLY_GHAT),
        LocationPoint("IXL", "Leh High-Altitude Base", NERState.LADAKH, 34.1526, 77.5771, 3500, TerrainType.HIGH_ALTITUDE_PASS),
        LocationPoint("SIL", "Siliguri Chicken's Neck Gateway", NERState.WEST_BENGAL, 26.7271, 88.3953, 122, TerrainType.PLAINS),

        // ASSAM
        LocationPoint("GHY", "Guwahati Logistics Hub", NERState.ASSAM, 26.1445, 91.7362, 55, TerrainType.RIVER_BASIN),
        LocationPoint("TZP", "Tezpur Bridge Crossing", NERState.ASSAM, 26.6528, 92.7926, 48, TerrainType.PLAINS),
        LocationPoint("DBR", "Dibrugarh Riverport Hub", NERState.ASSAM, 27.4728, 94.9120, 108, TerrainType.RIVER_BASIN),
        LocationPoint("SLR", "Silchar Valley Depot", NERState.ASSAM, 24.8333, 92.7789, 25, TerrainType.RIVER_BASIN),
        LocationPoint("HFL", "Haflong Hill Bypass", NERState.ASSAM, 25.1764, 93.0185, 513, TerrainType.HILLY_GHAT),
        LocationPoint("JRH", "Jorhat Tea Logistics Base", NERState.ASSAM, 26.7509, 94.2037, 116, TerrainType.PLAINS),

        // MEGHALAYA
        LocationPoint("SHL", "Shillong Civil Depot", NERState.MEGHALAYA, 25.5788, 91.8933, 1520, TerrainType.HILLY_GHAT),
        LocationPoint("JWI", "Jowai Coal Belt Depot", NERState.MEGHALAYA, 25.4450, 92.2050, 1380, TerrainType.HILLY_GHAT),
        LocationPoint("TRA", "Tura Garo Hills Depot", NERState.MEGHALAYA, 25.5140, 90.2030, 349, TerrainType.HILLY_GHAT),

        // ARUNACHAL PRADESH
        LocationPoint("TWG", "Tawang Forward Outpost", NERState.ARUNACHAL_PRADESH, 27.5861, 91.8594, 3048, TerrainType.HIGH_ALTITUDE_PASS),
        LocationPoint("BDL", "Bomdila Pass Junction", NERState.ARUNACHAL_PRADESH, 27.2645, 92.4231, 2415, TerrainType.HIGH_ALTITUDE_PASS),
        LocationPoint("ITA", "Itanagar Capital Depot", NERState.ARUNACHAL_PRADESH, 27.0844, 93.6053, 320, TerrainType.HILLY_GHAT),
        LocationPoint("PSG", "Pasighat Siang River Hub", NERState.ARUNACHAL_PRADESH, 28.0673, 95.3267, 155, TerrainType.RIVER_BASIN),

        // NAGALAND
        LocationPoint("DMP", "Dimapur Railhead Hub", NERState.NAGALAND, 25.9094, 93.7266, 145, TerrainType.PLAINS),
        LocationPoint("KHM", "Kohima Hill Base", NERState.NAGALAND, 25.6751, 94.1086, 1444, TerrainType.HILLY_GHAT),
        LocationPoint("MKG", "Mokokchung Central Hub", NERState.NAGALAND, 26.3256, 94.5244, 1325, TerrainType.HILLY_GHAT),

        // MANIPUR
        LocationPoint("IMP", "Imphal Central Logistics", NERState.MANIPUR, 24.8170, 93.9368, 786, TerrainType.PLAINS),
        LocationPoint("JRB", "Jiribam Border Railhead", NERState.MANIPUR, 24.8000, 93.1200, 32, TerrainType.RIVER_BASIN),
        LocationPoint("CCP", "Churachandpur Transit Depot", NERState.MANIPUR, 24.3300, 93.6800, 914, TerrainType.HILLY_GHAT),

        // MIZORAM
        LocationPoint("AZL", "Aizawl Ridge Depot", NERState.MIZORAM, 23.7271, 92.7176, 1132, TerrainType.HILLY_GHAT),
        LocationPoint("LNG", "Lunglei Southern Depot", NERState.MIZORAM, 22.8800, 92.7300, 722, TerrainType.HILLY_GHAT),
        LocationPoint("CMP", "Champhai Border Terminal", NERState.MIZORAM, 23.4750, 93.3280, 1678, TerrainType.HIGH_ALTITUDE_PASS),

        // TRIPURA
        LocationPoint("AGT", "Agartala Border Terminal", NERState.TRIPURA, 23.8315, 91.2868, 15, TerrainType.PLAINS),
        LocationPoint("DMR", "Dharmanagar Rail Junction", NERState.TRIPURA, 24.3800, 92.1600, 21, TerrainType.PLAINS),

        // SIKKIM
        LocationPoint("GTK", "Gangtok Mountain Base", NERState.SIKKIM, 27.3389, 88.6065, 1650, TerrainType.HILLY_GHAT),
        LocationPoint("MGN", "Mangan North Sikkim Outpost", NERState.SIKKIM, 27.5050, 88.5280, 956, TerrainType.HIGH_ALTITUDE_PASS)
    )

    fun getLocationById(id: String): LocationPoint {
        return HUBS.find { it.id == id } ?: HUBS[0]
    }

    /**
     * Compute multi-candidate routes asynchronously using OSRM with local fallback,
     * and score each candidate with multi-criteria risk weighting.
     */
    suspend fun computeRouteCandidatesAsync(
        origin: LocationPoint,
        destination: LocationPoint,
        currentPrecipitationMm: Double = 25.0,
        currentSoilMoisturePct: Int = 80,
        activeIncidents: List<RoadIncident> = emptyList(),
        forceOffline: Boolean = false
    ): List<RouteCandidate> {
        val rawResults = routingService.getRouteCandidates(origin, destination, forceOffline)
        return scoreAndRankCandidates(origin, destination, rawResults, currentPrecipitationMm, currentSoilMoisturePct, activeIncidents)
    }

    /**
     * Synchronous entry point for initial layout or fast local UI evaluations.
     */
    fun computeRouteCandidates(
        origin: LocationPoint,
        destination: LocationPoint,
        currentPrecipitationMm: Double = 25.0,
        currentSoilMoisturePct: Int = 80,
        activeIncidents: List<RoadIncident> = emptyList(),
        forceOffline: Boolean = false
    ): List<RouteCandidate> {
        val rawResults = runBlocking {
            routingService.getRouteCandidates(origin, destination, forceOffline = forceOffline)
        }
        return scoreAndRankCandidates(origin, destination, rawResults, currentPrecipitationMm, currentSoilMoisturePct, activeIncidents)
    }

    /**
     * Runs our multi-factor route-risk scoring over raw candidate geometry.
     * Evaluates terrain vulnerability, weather hazards, and direct incident blockades.
     */
    private fun scoreAndRankCandidates(
        origin: LocationPoint,
        destination: LocationPoint,
        rawResults: List<RawRouteResult>,
        precipMm: Double,
        moisturePct: Int,
        incidents: List<RoadIncident>
    ): List<RouteCandidate> {
        if (rawResults.isEmpty()) {
            return emptyList()
        }

        val evaluatedCandidates = rawResults.mapIndexed { index, raw ->
            // 1. Proximity scan: Check which active road hazards intersect or lie near this candidate polyline
            val affectedIncidents = findImpactingIncidents(raw.coordinates, incidents)
            val incidentCount = affectedIncidents.size
            val hasCriticalBlockage = affectedIncidents.any { it.severity == IncidentSeverity.CRITICAL_BLOCKAGE }

            // 2. Terrain & Altitude Factors
            val avgAltitude = (origin.altitudeMeters + destination.altitudeMeters + raw.elevationGainMeters) / 3
            val isHighPass = avgAltitude > 2200 || destination.altitudeMeters > 2500
            val terrainType = if (isHighPass) TerrainType.HIGH_ALTITUDE_PASS else if (avgAltitude > 800) TerrainType.HILLY_GHAT else TerrainType.PLAINS

            // 3. Risk Sub-scores
            val weatherMultiplier = if (raw.isViaPrimaryHighCapacityRoad) 1.0 else 1.3
            val landslideScore = RiskEngine.calculateLandslideScore(
                terrainType = terrainType,
                elevationGainMeters = raw.elevationGainMeters,
                rainfallSaturationMm = precipMm * weatherMultiplier,
                humidityPct = (moisturePct + if (raw.isViaPrimaryHighCapacityRoad) 0 else 8).coerceAtMost(100)
            )

            val floodScore = RiskEngine.calculateFloodScore(
                terrainType = origin.terrainType,
                precipitationMm = precipMm,
                altitudeMeters = avgAltitude
            )

            val weatherScore = RiskEngine.calculateWeatherScore(
                precipitationMm = precipMm * weatherMultiplier,
                windSpeedKmH = if (isHighPass) 38.0 else 20.0,
                visibilityKm = if (isHighPass) 3.5 else 7.5
            )

            val roadCondition = if (raw.isViaPrimaryHighCapacityRoad) 30 else 65

            // 1. Disruption / Incident Risk (30% weight)
            val incidentRiskScore = when {
                hasCriticalBlockage -> 98
                incidentCount > 0 -> (incidentCount * 28 + 15).coerceIn(30, 85)
                else -> 10
            }

            // 2. Road Accessibility Risk (25% weight)
            val accessibilityRiskScore = when {
                hasCriticalBlockage -> 100
                raw.isViaPrimaryHighCapacityRoad -> 15
                isHighPass -> 65
                else -> 40
            }

            // 3. Weather Risk (20% weight)
            val weatherRiskScore = RiskEngine.calculateWeatherScore(
                precipitationMm = precipMm * weatherMultiplier,
                windSpeedKmH = if (isHighPass) 38.0 else 20.0,
                visibilityKm = if (isHighPass) 3.5 else 7.5
            )

            // Duration calculation: Add incident clearance delay
            val baseDurationMin = (raw.durationSeconds / 60.0).toInt().coerceAtLeast(30)
            val delayFromIncidents = if (hasCriticalBlockage) 180 else (incidentCount * 35)
            val totalDurationMin = baseDurationMin + delayFromIncidents

            // 4. ETA Risk (15% weight)
            val etaRiskScore = ((totalDurationMin.toDouble() / 1000.0) * 100.0).roundToInt().coerceIn(10, 100)

            // 5. Distance Risk (10% weight)
            val distanceRiskScore = ((raw.distanceKm / 600.0) * 100.0).roundToInt().coerceIn(10, 100)

            // Composite risk (for terrain & hazard classification)
            val (compRisk, riskLevel) = RiskEngine.calculateCompositeRisk(
                landslideScore = landslideScore,
                floodScore = floodScore,
                weatherScore = weatherRiskScore,
                roadConditionScore = roadCondition,
                activeIncidentCount = incidentCount + (if (hasCriticalBlockage) 3 else 0)
            )

            // Transparent multi-factor normalized route score (0-100, LOWER IS BETTER)
            val routeScore = RiskEngine.calculateMultiFactorRouteScore(
                incidentRisk = incidentRiskScore,
                accessibilityRisk = accessibilityRiskScore,
                weatherRisk = weatherRiskScore,
                etaRisk = etaRiskScore,
                distanceRisk = distanceRiskScore,
                isCriticalBlockage = hasCriticalBlockage
            )

            val isSimulated = !raw.providerName.contains("OSRM", ignoreCase = true)
            val dataLabel = if (isSimulated) "DEMO / SIMULATED TOPOLOGY" else "OSRM (OpenStreetMap Live API)"

            RouteCandidate(
                id = "RC_${origin.id}_${destination.id}_${index}_${raw.corridorCode.replace(" ", "_")}",
                name = raw.routeName,
                corridorCode = raw.corridorCode,
                origin = origin,
                destination = destination,
                distanceKm = raw.distanceKm,
                estimatedDurationMin = totalDurationMin,
                elevationGainM = raw.elevationGainMeters,
                weatherRiskScore = weatherRiskScore,
                landslideRiskScore = landslideScore,
                floodRiskScore = floodScore,
                roadConditionScore = roadCondition,
                incidentRiskScore = incidentRiskScore,
                compositeRiskScore = compRisk,
                riskLevel = riskLevel,
                routeScore = routeScore,
                isRecommended = false, // Assigned below
                recommendationReason = "",
                keyCheckpoints = raw.checkpoints,
                segments = emptyList(),
                polylineCoordinates = raw.coordinates,
                affectedIncidents = affectedIncidents.map { it.id },
                accessibilityRiskScore = accessibilityRiskScore,
                etaRiskScore = etaRiskScore,
                distanceRiskScore = distanceRiskScore,
                statusLabel = if (hasCriticalBlockage) "BLOCKED / AFFECTED" else "ALTERNATIVE",
                whyNotRecommended = null,
                isBlocked = hasCriticalBlockage,
                isSimulatedData = isSimulated,
                dataSourceLabel = dataLabel
            )
        }

        // Rank candidates:
        // Filter feasible (unblocked) routes. Lowest routeScore among feasible routes is recommended.
        val feasibleRoutes = evaluatedCandidates.filter { !it.isBlocked }
        val bestRoute = if (feasibleRoutes.isNotEmpty()) {
            feasibleRoutes.minByOrNull { it.routeScore }
        } else {
            evaluatedCandidates.minByOrNull { it.routeScore }
        }

        val fullyEvaluated = evaluatedCandidates.map { c ->
            val isRec = (c.id == bestRoute?.id)
            val status = when {
                isRec -> "RECOMMENDED"
                c.isBlocked -> "BLOCKED / AFFECTED"
                c.routeScore > 65 -> "HIGHER RISK"
                else -> "ALTERNATIVE"
            }

            val reason = if (isRec) {
                RiskEngine.generateWhyThisRouteExplanation(c, evaluatedCandidates.filter { it.id != c.id })
            } else {
                buildRecommendationReason(
                    isPrimary = c.accessibilityRiskScore < 30,
                    hasBlockage = c.isBlocked,
                    incidentCount = c.affectedIncidents.size,
                    riskLevel = c.riskLevel,
                    elevationGain = c.elevationGainM,
                    corridorCode = c.corridorCode
                )
            }

            val whyNot = if (!isRec && bestRoute != null) {
                RiskEngine.generateWhyNotRecommendedExplanation(c, bestRoute)
            } else null

            c.copy(
                isRecommended = isRec,
                statusLabel = status,
                recommendationReason = reason,
                whyNotRecommended = whyNot
            )
        }

        // Sort: Recommended first, then remaining feasible by score ascending, then blocked
        return fullyEvaluated.sortedWith(
            compareByDescending<RouteCandidate> { it.isRecommended }
                .thenBy { it.isBlocked }
                .thenBy { it.routeScore }
        )
    }

    private fun findImpactingIncidents(
        routeCoords: List<Pair<Double, Double>>,
        incidents: List<RoadIncident>
    ): List<RoadIncident> {
        if (routeCoords.isEmpty() || incidents.isEmpty()) return emptyList()

        return incidents.filter { inc ->
            // Check if incident is within 12 km radius of any point on the route polyline
            routeCoords.any { pt ->
                calculateHaversineKm(pt.first, pt.second, inc.latitude, inc.longitude) <= 12.0
            }
        }
    }

    private fun buildRecommendationReason(
        isPrimary: Boolean,
        hasBlockage: Boolean,
        incidentCount: Int,
        riskLevel: RiskLevel,
        elevationGain: Int,
        corridorCode: String
    ): String {
        return when {
            hasBlockage -> "CRITICAL BLOCKAGE DETECTED: Route obstructed by road hazard/landslide. Diverting convoys to bypass corridor."
            incidentCount > 0 -> "CAUTION: $incidentCount active road hazard(s) reported along corridor. Proceed with reduced speed."
            riskLevel == RiskLevel.LOW && isPrimary -> "RECOMMENDED: High-stability national highway corridor with 4-lane structural slope stabilization and lowest transit risk."
            riskLevel == RiskLevel.LOW -> "SAFE ALTERNATIVE: Optimal mountain bypass with clear road clearance and minimal hazard exposure."
            riskLevel == RiskLevel.MODERATE -> "MODERATE RISK: Typical North East mountain pass elevation ($elevationGain m gain). Weather monitors active."
            riskLevel == RiskLevel.HIGH -> "HIGH VULNERABILITY: Steep ghat slopes prone to monsoon slurry runoff. Extra caution required."
            else -> "CORRIDOR ACTIVE: Monitored 24/7 by Border Roads Organisation and State Disaster Management Authority."
        }
    }

    private fun calculateHaversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return r * c
    }
}
