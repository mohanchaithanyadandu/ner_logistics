package com.example.engine

import com.example.data.models.LocationPoint
import com.example.data.models.RiskLevel
import com.example.data.models.RouteCandidate
import com.example.data.models.TerrainType
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object RiskEngine {

    /**
     * Deterministic calculation of Landslide Vulnerability Score (0 - 100)
     * Factors:
     * - Terrain type (Alpine/Ghat > Basin > Plains)
     * - Elevation gain / steepness
     * - 24-hour rainfall saturation (mm)
     * - Soil moisture / humidity
     */
    fun calculateLandslideScore(
        terrainType: TerrainType,
        elevationGainMeters: Int,
        rainfallSaturationMm: Double,
        humidityPct: Int
    ): Int {
        val terrainWeight = when (terrainType) {
            TerrainType.HIGH_ALTITUDE_PASS -> 40.0
            TerrainType.HILLY_GHAT -> 32.0
            TerrainType.FOREST_CORRIDOR -> 18.0
            TerrainType.RIVER_BASIN -> 10.0
            TerrainType.PLAINS -> 4.0
        }

        val elevationFactor = (elevationGainMeters / 3000.0).coerceIn(0.0, 1.0) * 25.0
        val rainFactor = (rainfallSaturationMm / 120.0).coerceIn(0.0, 1.0) * 25.0
        val saturationFactor = (humidityPct / 100.0) * 10.0

        val total = terrainWeight + elevationFactor + rainFactor + saturationFactor
        return total.roundToInt().coerceIn(0, 100)
    }

    /**
     * Deterministic calculation of Flood / Inundation Hazard Score (0 - 100)
     * Factors:
     * - River basin & floodplain proximity
     * - Precipitation rate
     * - Low elevation drainage stagnation
     */
    fun calculateFloodScore(
        terrainType: TerrainType,
        precipitationMm: Double,
        altitudeMeters: Int
    ): Int {
        val basinWeight = when (terrainType) {
            TerrainType.RIVER_BASIN -> 45.0
            TerrainType.PLAINS -> 25.0
            TerrainType.FOREST_CORRIDOR -> 15.0
            TerrainType.HILLY_GHAT -> 10.0
            TerrainType.HIGH_ALTITUDE_PASS -> 5.0
        }

        val precipFactor = (precipitationMm / 80.0).coerceIn(0.0, 1.0) * 35.0
        val elevationDrainageBonus = if (altitudeMeters < 150) 20.0 else if (altitudeMeters < 500) 10.0 else 0.0

        val total = basinWeight + precipFactor + elevationDrainageBonus
        return total.roundToInt().coerceIn(0, 100)
    }

    /**
     * Calculate Weather Risk Score (0 - 100)
     * Factors: Rain intensity, wind velocity, fog visibility reduction
     */
    fun calculateWeatherScore(
        precipitationMm: Double,
        windSpeedKmH: Double,
        visibilityKm: Double
    ): Int {
        val rainImpact = (precipitationMm / 50.0).coerceIn(0.0, 1.0) * 40.0
        val windImpact = (windSpeedKmH / 70.0).coerceIn(0.0, 1.0) * 25.0
        val fogImpact = ((10.0 - visibilityKm.coerceIn(0.0, 10.0)) / 10.0) * 35.0

        val total = rainImpact + windImpact + fogImpact
        return total.roundToInt().coerceIn(0, 100)
    }

    /**
     * Calculate Composite Risk Score (0 - 100)
     * Transparent deterministic weighted formula
     */
    fun calculateCompositeRisk(
        landslideScore: Int,
        floodScore: Int,
        weatherScore: Int,
        roadConditionScore: Int,
        activeIncidentCount: Int
    ): Pair<Int, RiskLevel> {
        val incidentScore = (activeIncidentCount * 28).coerceAtMost(100)

        val composite = (
            landslideScore * 0.30 +
            floodScore * 0.25 +
            weatherScore * 0.20 +
            roadConditionScore * 0.15 +
            incidentScore * 0.10
        ).roundToInt().coerceIn(0, 100)

        val level = when {
            composite <= 30 -> RiskLevel.LOW
            composite <= 60 -> RiskLevel.MODERATE
            composite <= 80 -> RiskLevel.HIGH
            else -> RiskLevel.CRITICAL
        }

        return Pair(composite, level)
    }

    /**
     * Transparent Multi-Factor Route Scoring Function (0 - 100).
     * LOWER SCORE = BETTER ROUTE.
     * Weights:
     * - Disruption / Incident Risk: 30%
     * - Road Accessibility Risk: 25%
     * - Weather Risk: 20%
     * - ETA Risk: 15%
     * - Distance Risk: 10%
     * Total = 100%
     */
    fun calculateMultiFactorRouteScore(
        incidentRisk: Int,
        accessibilityRisk: Int,
        weatherRisk: Int,
        etaRisk: Int,
        distanceRisk: Int,
        isCriticalBlockage: Boolean = false
    ): Int {
        val baseScore = (
            incidentRisk.coerceIn(0, 100) * 0.30 +
            accessibilityRisk.coerceIn(0, 100) * 0.25 +
            weatherRisk.coerceIn(0, 100) * 0.20 +
            etaRisk.coerceIn(0, 100) * 0.15 +
            distanceRisk.coerceIn(0, 100) * 0.10
        ).roundToInt().coerceIn(1, 100)

        return if (isCriticalBlockage) {
            max(baseScore, 85).coerceIn(1, 100)
        } else {
            baseScore
        }
    }

    /**
     * Backward-compatible helper for legacy callers.
     * Maps to normalized score (lower is better).
     */
    fun calculateRouteScore(
        compositeRiskScore: Int,
        durationMinutes: Int,
        bestDurationMinutes: Int
    ): Int {
        val etaRisk = ((durationMinutes.toDouble() / 900.0) * 100.0).roundToInt().coerceIn(10, 100)
        val distanceRisk = 30
        val accessibilityRisk = 25
        val weatherRisk = compositeRiskScore.coerceIn(10, 90)
        val incidentRisk = compositeRiskScore.coerceIn(10, 95)
        return calculateMultiFactorRouteScore(
            incidentRisk = incidentRisk,
            accessibilityRisk = accessibilityRisk,
            weatherRisk = weatherRisk,
            etaRisk = etaRisk,
            distanceRisk = distanceRisk
        )
    }

    /**
     * Generates a transparent, natural-language explanation for WHY the recommended route was selected.
     */
    fun generateWhyThisRouteExplanation(
        recommended: RouteCandidate,
        alternatives: List<RouteCandidate>
    ): String {
        if (alternatives.isEmpty()) {
            return "Recommended because it has the lowest current disruption risk (${recommended.incidentRiskScore}/100) with a safe travel time of ${recommended.estimatedDurationMin / 60}h ${recommended.estimatedDurationMin % 60}m."
        }

        val blockedAlt = alternatives.find { it.isBlocked }
        if (blockedAlt != null) {
            val distDiff = (recommended.distanceKm - blockedAlt.distanceKm).roundToInt()
            val distNote = if (distDiff > 0) "${distDiff} km longer but " else ""
            return "${recommended.name} is ${distNote}preferred because alternative ${blockedAlt.name} has a critical road blockage."
        }

        val bestAlt = alternatives.minByOrNull { it.routeScore }
        if (bestAlt != null) {
            val riskDiff = bestAlt.incidentRiskScore - recommended.incidentRiskScore
            val timeDiff = bestAlt.estimatedDurationMin - recommended.estimatedDurationMin
            return when {
                riskDiff > 10 && timeDiff >= 0 -> {
                    "Recommended because it has lower disruption risk (${recommended.incidentRiskScore}/100 vs ${bestAlt.incidentRiskScore}/100) and faster transit time."
                }
                riskDiff > 10 && timeDiff < 0 -> {
                    val extraMin = -timeDiff
                    "Recommended over ${bestAlt.name}: Although requiring ${extraMin}m additional transit, its disruption risk is significantly lower (${recommended.incidentRiskScore}/100 vs ${bestAlt.incidentRiskScore}/100)."
                }
                recommended.weatherRiskScore < bestAlt.weatherRiskScore - 15 -> {
                    "Recommended because it exhibits lower weather-induced landslide vulnerability (${recommended.weatherRiskScore}/100 vs ${bestAlt.weatherRiskScore}/100) along mountain ghats."
                }
                else -> {
                    "Lowest overall route score (${recommended.routeScore}/100) balancing safety, road accessibility (${recommended.accessibilityRiskScore}/100), and transit time."
                }
            }
        }

        return "Recommended because it has the lowest current disruption risk while maintaining an acceptable ETA."
    }

    /**
     * Generates a transparent, natural-language explanation for WHY an alternative route was NOT recommended.
     */
    fun generateWhyNotRecommendedExplanation(
        candidate: RouteCandidate,
        recommended: RouteCandidate
    ): String {
        if (candidate.isBlocked) {
            return "Affected by a critical road blockage and therefore excluded from the recommendation."
        }

        val timeDiff = candidate.estimatedDurationMin - recommended.estimatedDurationMin
        val riskDiff = candidate.incidentRiskScore - recommended.incidentRiskScore
        val scoreDiff = candidate.routeScore - recommended.routeScore

        return when {
            candidate.affectedIncidents.isNotEmpty() -> {
                "Not preferred because ${candidate.affectedIncidents.size} active road incident(s) increase its disruption risk to ${candidate.incidentRiskScore}/100."
            }
            riskDiff > 15 -> {
                "Higher disruption exposure (${candidate.incidentRiskScore}/100 vs ${recommended.incidentRiskScore}/100) along narrower road corridors."
            }
            timeDiff > 30 -> {
                "Longer travel time (+${timeDiff / 60}h ${timeDiff % 60}m) and higher route score (${candidate.routeScore}/100 vs ${recommended.routeScore}/100)."
            }
            candidate.accessibilityRiskScore > recommended.accessibilityRiskScore + 15 -> {
                "Lower road accessibility rating (${candidate.accessibilityRiskScore}/100 risk) due to steep terrain gradients and unpaved sections."
            }
            else -> {
                "Alternative route with higher composite route score (${candidate.routeScore}/100 vs ${recommended.routeScore}/100)."
            }
        }
    }

    /**
     * Legacy explanation generator for backward compatibility.
     */
    fun generateDeterministicExplanation(
        primary: RouteCandidate,
        alternates: List<RouteCandidate>
    ): String {
        return generateWhyThisRouteExplanation(primary, alternates)
    }
}
