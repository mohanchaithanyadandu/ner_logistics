package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.DeliveryStatus
import com.example.data.models.LiveVehicle
import com.example.data.models.LocationPoint
import com.example.data.models.NERState
import com.example.data.models.RiskLevel
import com.example.data.models.RoadIncident
import com.example.data.models.VehicleStatus
import com.example.engine.RouteOptimizer
import com.example.engine.TelemetryMode
import com.example.engine.WebSocketStatus
import com.example.ui.components.InteractiveGISMap
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CriticalRedBg
import com.example.ui.theme.CriticalRedBorder
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.InfoBlueBg
import com.example.ui.theme.InfoBlueBorder
import com.example.ui.theme.OffWhiteBackground
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueBorder
import com.example.ui.theme.PrimaryBlueLight
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RiskOrange
import com.example.ui.theme.RiskOrangeBg
import com.example.ui.theme.RiskOrangeBorder
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenBg
import com.example.ui.theme.SuccessGreenBorder
import com.example.ui.theme.SurfaceSubtle
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberBg
import com.example.ui.theme.WarningAmberBorder
import com.example.ui.viewmodel.NERLogisticsViewModel
import com.example.util.ExternalNavigationLauncher

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveFleetScreen(
    viewModel: NERLogisticsViewModel,
    modifier: Modifier = Modifier
) {
    val vehicles by viewModel.allVehicles.collectAsState()
    val incidents by viewModel.allIncidents.collectAsState()
    val simSpeed by viewModel.simulationSpeed.collectAsState()
    val isSimRunning by viewModel.isSimulationRunning.collectAsState()
    val telemetryMode by viewModel.telemetryMode.collectAsState()
    val wsStatus by viewModel.webSocketStatus.collectAsState()
    val wsLogs by viewModel.wsTelemetryLogs.collectAsState()

    val selectedVehicleFromVm by viewModel.selectedFleetVehicle.collectAsState()
    var selectedVehicle by remember(selectedVehicleFromVm) { mutableStateOf(selectedVehicleFromVm ?: vehicles.firstOrNull()) }
    var activeVehicleForDetail by remember { mutableStateOf<LiveVehicle?>(null) }
    var showVehicleDetailModal by remember { mutableStateOf(false) }

    LaunchedEffect(selectedVehicleFromVm) {
        if (selectedVehicleFromVm != null) {
            activeVehicleForDetail = selectedVehicleFromVm
            showVehicleDetailModal = true
        }
    }

    var searchQuery by remember { mutableStateOf("") }
    var selectedStatusFilter by remember { mutableStateOf<DeliveryStatus?>(null) }
    var showTelemetryConsole by remember { mutableStateOf(false) }

    val context = LocalContext.current

    val filteredVehicles = vehicles.filter { vehicle ->
        val matchesQuery = searchQuery.isBlank() ||
                vehicle.vehicleNumber.contains(searchQuery, ignoreCase = true) ||
                vehicle.driverName.contains(searchQuery, ignoreCase = true) ||
                vehicle.activeRouteName.contains(searchQuery, ignoreCase = true) ||
                vehicle.originName.contains(searchQuery, ignoreCase = true) ||
                vehicle.destinationName.contains(searchQuery, ignoreCase = true)

        val matchesStatus = selectedStatusFilter == null || vehicle.deliveryStatus == selectedStatusFilter
        matchesQuery && matchesStatus
    }

    val onTimeCount = vehicles.count { it.deliveryStatus == DeliveryStatus.ON_TIME }
    val delayedCount = vehicles.count { it.deliveryStatus == DeliveryStatus.DELAYED }
    val atRiskCount = vehicles.count { it.deliveryStatus == DeliveryStatus.AT_RISK }
    val deliveredCount = vehicles.count { it.deliveryStatus == DeliveryStatus.DELIVERED }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OffWhiteBackground),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "Live Fleet Operations Hub",
                subtitle = "Real-time convoy telemetry, corridor tracking & emergency response"
            )
        }

        // Telemetry Mode Switcher (Hardware GPS vs Demo Sim)
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                color = PureWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (telemetryMode == TelemetryMode.DEMO_SIMULATION) PrimaryBlue else SuccessGreen)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (telemetryMode == TelemetryMode.DEMO_SIMULATION) "DEMO SIMULATION ACTIVE" else "LIVE HARDWARE GPS RECEIVER",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (telemetryMode == TelemetryMode.DEMO_SIMULATION) PrimaryBlue else SuccessGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Mode Selector Pills
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Surface(
                                onClick = { viewModel.setTelemetryMode(TelemetryMode.DEMO_SIMULATION) },
                                shape = RoundedCornerShape(6.dp),
                                color = if (telemetryMode == TelemetryMode.DEMO_SIMULATION) PrimaryBlueLight else SurfaceSubtle,
                                border = BorderStroke(1.dp, if (telemetryMode == TelemetryMode.DEMO_SIMULATION) PrimaryBlue else BorderLight)
                            ) {
                                Text(
                                    text = "DEMO SIM",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (telemetryMode == TelemetryMode.DEMO_SIMULATION) PrimaryBlue else TextSecondary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }

                            Surface(
                                onClick = { viewModel.setTelemetryMode(TelemetryMode.REAL_WEBSOCKET_GPS) },
                                shape = RoundedCornerShape(6.dp),
                                color = if (telemetryMode == TelemetryMode.REAL_WEBSOCKET_GPS) SuccessGreenBg else SurfaceSubtle,
                                border = BorderStroke(1.dp, if (telemetryMode == TelemetryMode.REAL_WEBSOCKET_GPS) SuccessGreen else BorderLight)
                            ) {
                                Text(
                                    text = "REAL GPS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (telemetryMode == TelemetryMode.REAL_WEBSOCKET_GPS) SuccessGreen else TextSecondary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (telemetryMode == TelemetryMode.DEMO_SIMULATION)
                            "Notice: Displaying synthetic GPS waypoints along national highway corridors for demonstration. Not real physical vehicle telemetry."
                        else
                            "Listening for real-world GPS NMEA/JSON telemetry over WebSocket and local REST ingestion port.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Delivery Status Summary Strip
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatusCountPill(
                    label = "ON TIME",
                    count = onTimeCount,
                    isSelected = selectedStatusFilter == DeliveryStatus.ON_TIME,
                    color = SuccessGreen,
                    bgColor = SuccessGreenBg,
                    borderColor = SuccessGreenBorder,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        selectedStatusFilter = if (selectedStatusFilter == DeliveryStatus.ON_TIME) null else DeliveryStatus.ON_TIME
                    }
                )
                StatusCountPill(
                    label = "DELAYED",
                    count = delayedCount,
                    isSelected = selectedStatusFilter == DeliveryStatus.DELAYED,
                    color = WarningAmber,
                    bgColor = WarningAmberBg,
                    borderColor = WarningAmberBorder,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        selectedStatusFilter = if (selectedStatusFilter == DeliveryStatus.DELAYED) null else DeliveryStatus.DELAYED
                    }
                )
                StatusCountPill(
                    label = "AT RISK",
                    count = atRiskCount,
                    isSelected = selectedStatusFilter == DeliveryStatus.AT_RISK,
                    color = CriticalRed,
                    bgColor = CriticalRedBg,
                    borderColor = CriticalRedBorder,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        selectedStatusFilter = if (selectedStatusFilter == DeliveryStatus.AT_RISK) null else DeliveryStatus.AT_RISK
                    }
                )
                StatusCountPill(
                    label = "DELIVERED",
                    count = deliveredCount,
                    isSelected = selectedStatusFilter == DeliveryStatus.DELIVERED,
                    color = InfoBlue,
                    bgColor = InfoBlueBg,
                    borderColor = InfoBlueBorder,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        selectedStatusFilter = if (selectedStatusFilter == DeliveryStatus.DELIVERED) null else DeliveryStatus.DELIVERED
                    }
                )
            }
        }

        // Search & Filter Bar
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                color = PureWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search Fleet",
                        tint = PrimaryBlue,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search by vehicle, driver, or route corridor...", fontSize = 13.sp, color = TextTertiary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        singleLine = true
                    )
                    if (searchQuery.isNotBlank() || selectedStatusFilter != null) {
                        IconButton(
                            onClick = {
                                searchQuery = ""
                                selectedStatusFilter = null
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Clear Filters", tint = TextSecondary, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // Corridor Alert Banner if any vehicle is flagged for deviation or critical risk
        val flaggedVehicles = vehicles.filter { it.hasDeviated || it.deliveryStatus == DeliveryStatus.AT_RISK }
        if (flaggedVehicles.isNotEmpty()) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clickable {
                            val first = flaggedVehicles.first()
                            activeVehicleForDetail = first
                            showVehicleDetailModal = true
                            viewModel.selectFleetVehicle(first)
                        }
                        .testTag("corridor_alert_banner"),
                    shape = RoundedCornerShape(12.dp),
                    color = CriticalRedBg,
                    border = BorderStroke(1.dp, CriticalRedBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Alert", tint = CriticalRed, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "CORRIDOR ALERT: ${flaggedVehicles.size} CONVOY(S) FLAGGED",
                                style = MaterialTheme.typography.labelSmall,
                                color = CriticalRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "${flaggedVehicles.first().vehicleNumber} reported security envelope breach along ${flaggedVehicles.first().activeRouteName}. Tap to inspect.",
                                style = MaterialTheme.typography.bodySmall,
                                color = CriticalRed,
                                fontSize = 11.sp
                            )
                        }
                        Icon(Icons.Default.ExpandMore, contentDescription = null, tint = CriticalRed, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Fleet List Header
        item {
            SectionHeader(
                title = "All Deployed Vehicles & Convoys (${filteredVehicles.size})",
                subtitle = "Select any vehicle to inspect assigned route, telemetry & open navigation"
            )
        }

        // Fleet Vehicles List
        if (filteredVehicles.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 20.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = PureWhite,
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.LocalShipping, contentDescription = null, tint = TextTertiary, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No vehicles match the filter criteria",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        } else {
            items(filteredVehicles) { vehicle ->
                val isSelected = selectedVehicle?.id == vehicle.id
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedVehicle = vehicle
                                activeVehicleForDetail = vehicle
                                showVehicleDetailModal = true
                                viewModel.selectFleetVehicle(vehicle)
                            }
                            .testTag("vehicle_card_${vehicle.id}"),
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) PrimaryBlueLight else PureWhite,
                        border = BorderStroke(
                            if (isSelected) 1.5.dp else 1.dp,
                            if (isSelected) PrimaryBlue
                            else if (vehicle.hasDeviated) CriticalRed
                            else BorderLight
                        ),
                        shadowElevation = if (isSelected) 2.dp else 0.dp
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            // Top Row: Icon, ID, Driver & Status
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (vehicle.hasDeviated) CriticalRedBg else PrimaryBlueLight),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DirectionsCar,
                                            contentDescription = null,
                                            tint = if (vehicle.hasDeviated) CriticalRed else PrimaryBlue,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = vehicle.vehicleNumber,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = TextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = "${vehicle.driverName} • ${vehicle.type.title}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                                StatusPill(status = vehicle.status)
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Route Corridor Row
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = SurfaceSubtle,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.AltRoute, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = vehicle.activeRouteName,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextPrimary,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 11.sp
                                        )
                                    }
                                    Text(
                                        text = "${vehicle.originName} ➔ ${vehicle.destinationName}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            // Deviation Alert if any
                            if (vehicle.hasDeviated) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = CriticalRedBg,
                                    border = BorderStroke(0.5.dp, CriticalRedBorder),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Warning, contentDescription = null, tint = CriticalRed, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Corridor Breach: +${"%.1f".format(vehicle.deviationDistanceKm)} km off track",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = CriticalRed,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Telemetry Metrics Strip
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = "SPEED", style = MaterialTheme.typography.labelSmall, color = TextTertiary, fontSize = 9.sp)
                                    Text(text = "${vehicle.speedKmH} km/h", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                                Column {
                                    Text(text = "FUEL", style = MaterialTheme.typography.labelSmall, color = TextTertiary, fontSize = 9.sp)
                                    Text(text = "${vehicle.fuelLevelPct}%", style = MaterialTheme.typography.bodySmall, color = if (vehicle.fuelLevelPct > 25) SuccessGreen else CriticalRed, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                                Column {
                                    Text(text = "ESTIMATED ETA", style = MaterialTheme.typography.labelSmall, color = TextTertiary, fontSize = 9.sp)
                                    Text(text = "${vehicle.etaMinutes} min", style = MaterialTheme.typography.bodySmall, color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                                Column {
                                    Text(text = "STATUS", style = MaterialTheme.typography.labelSmall, color = TextTertiary, fontSize = 9.sp)
                                    Text(
                                        text = vehicle.deliveryStatus.label,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = when(vehicle.deliveryStatus) {
                                            DeliveryStatus.ON_TIME -> SuccessGreen
                                            DeliveryStatus.DELAYED -> WarningAmber
                                            DeliveryStatus.AT_RISK -> CriticalRed
                                            DeliveryStatus.DELIVERED -> InfoBlue
                                        },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Inspect Route & Live Map Button
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                Surface(
                                    onClick = {
                                        selectedVehicle = vehicle
                                        activeVehicleForDetail = vehicle
                                        showVehicleDetailModal = true
                                        viewModel.selectFleetVehicle(vehicle)
                                    },
                                    shape = RoundedCornerShape(6.dp),
                                    color = PrimaryBlueLight,
                                    border = BorderStroke(1.dp, PrimaryBlueBorder),
                                    modifier = Modifier.testTag("inspect_route_${vehicle.id}")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Map, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Inspect Route & Live Map ➔",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = PrimaryBlue,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Dedicated Fleet Route Detail Modal (opens when clicking any vehicle / route)
    if (showVehicleDetailModal && activeVehicleForDetail != null) {
        FleetRouteDetailModal(
            vehicle = activeVehicleForDetail!!,
            incidents = incidents,
            telemetryMode = telemetryMode,
            onDismiss = { showVehicleDetailModal = false },
            onViewInPlanner = {
                showVehicleDetailModal = false
                viewModel.loadFleetRouteInPlanner(activeVehicleForDetail!!)
            },
            onBroadcastAdvisory = { title, desc, risk ->
                viewModel.broadcastAlert(
                    title = title,
                    description = desc,
                    severity = risk,
                    corridor = activeVehicleForDetail!!.activeRouteName,
                    state = NERState.ASSAM
                )
            },
            onDispatchEmergencySOS = { title, desc ->
                viewModel.broadcastAlert(
                    title = title,
                    description = desc,
                    severity = RiskLevel.CRITICAL,
                    corridor = activeVehicleForDetail!!.activeRouteName,
                    state = NERState.ASSAM
                )
            }
        )
    }
}

@Composable
private fun StatusCountPill(
    label: String,
    count: Int,
    isSelected: Boolean,
    color: Color,
    bgColor: Color,
    borderColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) color.copy(alpha = 0.2f) else bgColor,
        border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, if (isSelected) color else borderColor),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "$count",
                style = MaterialTheme.typography.titleMedium,
                color = color,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = color,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun FleetTelemetryCell(label: String, value: String, color: Color) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextTertiary,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = color,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
    }
}

/**
 * Dedicated Fleet Route Detail Modal/Panel.
 * Shows:
 * - Vehicle ID, Driver/Operator, Current Location, Destination, Current Route,
 *   ETA, Distance Remaining, Vehicle Status, Risk Level, Current Hazard, Last Updated.
 * - Interactive GIS Map with selected vehicle, highlighted corridor route, and hazard pins.
 * - Clear telemetry mode indicator (DEMO/SIMULATED vs HARDWARE GPS).
 * - Action buttons: Open in Google Maps, View in Route Planner, Send Advisory, Emergency SOS, Close.
 * - Robust error and fallback handling (NEVER a blank screen).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FleetRouteDetailModal(
    vehicle: LiveVehicle,
    incidents: List<RoadIncident>,
    telemetryMode: TelemetryMode,
    onDismiss: () -> Unit,
    onViewInPlanner: () -> Unit,
    onBroadcastAdvisory: (title: String, desc: String, risk: RiskLevel) -> Unit,
    onDispatchEmergencySOS: (title: String, desc: String) -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val corridorIncidents = remember(vehicle, incidents) {
        incidents.filter {
            it.corridorName.contains(vehicle.activeRouteName, ignoreCase = true) ||
                    vehicle.activeRouteName.contains(it.corridorName, ignoreCase = true)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = PureWhite,
        contentColor = TextPrimary,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 28.dp)
                .verticalScroll(rememberScrollState())
                .testTag("fleet_route_detail_modal")
        ) {
            // Header Bar
            Surface(
                color = PureWhite,
                border = BorderStroke(0.5.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Close Detail",
                                tint = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "FLEET ROUTE INTELLIGENCE",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                letterSpacing = 0.5.sp,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "${vehicle.vehicleNumber} • ${vehicle.driverName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                    StatusPill(status = vehicle.status)
                }
            }

            Column(modifier = Modifier.padding(16.dp)) {
                // Telemetry Mode Banner
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (telemetryMode == TelemetryMode.DEMO_SIMULATION) PrimaryBlueLight else SuccessGreenBg,
                    border = BorderStroke(1.dp, if (telemetryMode == TelemetryMode.DEMO_SIMULATION) PrimaryBlueBorder else SuccessGreenBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (telemetryMode == TelemetryMode.DEMO_SIMULATION) Icons.Default.Cloud else Icons.Default.GpsFixed,
                            contentDescription = null,
                            tint = if (telemetryMode == TelemetryMode.DEMO_SIMULATION) PrimaryBlue else SuccessGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (telemetryMode == TelemetryMode.DEMO_SIMULATION)
                                    "SIMULATED FLEET TELEMETRY ACTIVE"
                                else
                                    "LIVE HARDWARE GPS RECEIVER CONNECTED",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (telemetryMode == TelemetryMode.DEMO_SIMULATION) PrimaryBlue else SuccessGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                            Text(
                                text = "Satellite Lock: Confirmed • Updates every 1.5s • Zero drift",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Active Route Corridor Waypoints & Elevation Profile Card
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = PureWhite,
                    border = BorderStroke(1.dp, BorderLight),
                    shadowElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AltRoute, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = vehicle.activeRouteName,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = PrimaryBlueLight,
                                border = BorderStroke(0.5.dp, PrimaryBlueBorder)
                            ) {
                                Text(
                                    text = vehicle.cargoDescription.take(28),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = PrimaryBlue,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 9.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Visual Waypoint Transit Corridor Bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Origin Node
                            Column(horizontalAlignment = Alignment.Start, modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(SuccessGreen)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "ORIGIN",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SuccessGreen,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp
                                    )
                                }
                                Text(
                                    text = vehicle.originName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.sp
                                )
                            }

                            // Midpoint Transit Indicator
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1.2f)) {
                                Text(
                                    text = "${vehicle.speedKmH} km/h • ${vehicle.etaMinutes}m ETA",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = PrimaryBlue,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                LinearProgressIndicator(
                                    progress = { 0.65f },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(2.dp)),
                                    color = PrimaryBlue,
                                    trackColor = SurfaceSubtle
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = "Elev: ${vehicle.altitudeMeters}m • ${vehicle.signalStatus}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    fontSize = 9.sp
                                )
                            }

                            // Destination Node
                            Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "DEST",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CriticalRed,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(CriticalRed)
                                    )
                                }
                                Text(
                                    text = vehicle.destinationName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Comprehensive 11-Point Telemetry Grid
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = SurfaceSubtle,
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "CONVOY TELEMETRY SPECIFICATION",
                            style = MaterialTheme.typography.labelSmall,
                            color = PrimaryBlue,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Row 1: Vehicle ID & Driver/Operator
                        DetailKeyValueRow("Vehicle ID", vehicle.vehicleNumber, "Driver / Operator", vehicle.driverName)
                        HorizontalDivider(color = BorderSubtle, modifier = Modifier.padding(vertical = 6.dp))

                        // Row 2: Current Location & Destination
                        DetailKeyValueRow(
                            "Current Location",
                            "${"%.3f".format(vehicle.currentLat)}°N, ${"%.3f".format(vehicle.currentLng)}°E",
                            "Destination",
                            vehicle.destinationName
                        )
                        HorizontalDivider(color = BorderSubtle, modifier = Modifier.padding(vertical = 6.dp))

                        // Row 3: Current Route & ETA
                        DetailKeyValueRow("Current Route", vehicle.activeRouteName, "ETA", "${vehicle.etaMinutes} mins")
                        HorizontalDivider(color = BorderSubtle, modifier = Modifier.padding(vertical = 6.dp))

                        // Row 4: Distance Remaining & Vehicle Status
                        DetailKeyValueRow(
                            "Distance Remaining",
                            "${(vehicle.etaMinutes * 0.75).toInt().coerceAtLeast(12)} km",
                            "Vehicle Status",
                            vehicle.deliveryStatus.label
                        )
                        HorizontalDivider(color = BorderSubtle, modifier = Modifier.padding(vertical = 6.dp))

                        // Row 5: Risk Level & Last Updated
                        DetailKeyValueRow(
                            "Risk Level",
                            if (corridorIncidents.isNotEmpty() || vehicle.hasDeviated) "CRITICAL / ELEVATED" else "LOW RISK",
                            "Last Updated",
                            "Just now (Live GPS)"
                        )
                        HorizontalDivider(color = BorderSubtle, modifier = Modifier.padding(vertical = 6.dp))

                        // Row 6: Current Hazards
                        Column {
                            Text(
                                text = "Current Hazards on Corridor:",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            if (corridorIncidents.isEmpty()) {
                                Text(
                                    text = "✓ Corridor Clear — No active road hazards reported",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SuccessGreen,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.sp
                                )
                            } else {
                                corridorIncidents.forEach { inc ->
                                    Text(
                                        text = "⚠ ${inc.title} at ${inc.locationName} (${inc.severity.label})",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CriticalRed,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Corridor Breach notice if applicable
                if (vehicle.hasDeviated) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = CriticalRedBg,
                        border = BorderStroke(1.dp, CriticalRedBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = CriticalRed, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "CORRIDOR BREACH: Vehicle is ${"%.1f".format(vehicle.deviationDistanceKm)} km outside assigned safety envelope!",
                                style = MaterialTheme.typography.bodySmall,
                                color = CriticalRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Primary Actions: OPEN IN GOOGLE MAPS & VIEW IN PLANNER
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val corridor = com.example.engine.FleetSimulationEngine.CORRIDORS.find { it.vehicleId == vehicle.id }
                            val startWp = corridor?.waypoints?.firstOrNull() ?: Pair(vehicle.currentLat - 0.2, vehicle.currentLng - 0.2)
                            val endWp = corridor?.waypoints?.lastOrNull() ?: Pair(vehicle.currentLat + 0.2, vehicle.currentLng + 0.2)

                            val orig = LocationPoint(
                                id = "ORIG_${vehicle.id}",
                                name = vehicle.originName,
                                state = NERState.ASSAM,
                                latitude = startWp.first,
                                longitude = startWp.second
                            )
                            val dest = LocationPoint(
                                id = "DEST_${vehicle.id}",
                                name = vehicle.destinationName,
                                state = NERState.ASSAM,
                                latitude = endWp.first,
                                longitude = endWp.second
                            )

                            ExternalNavigationLauncher.openGoogleMapsDirections(
                                context = context,
                                origin = orig,
                                destination = dest,
                                corridorName = vehicle.activeRouteName
                            )
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen, contentColor = PureWhite),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("fleet_open_in_google_maps_btn")
                    ) {
                        Icon(Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("OPEN IN GOOGLE MAPS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onViewInPlanner,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue, contentColor = PureWhite),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("fleet_view_in_planner_btn")
                    ) {
                        Icon(Icons.Default.Map, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("View in Planner", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Secondary Actions: Driver Advisory & Emergency SOS
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            onBroadcastAdvisory(
                                "Driver Advisory: ${vehicle.vehicleNumber}",
                                "Live corridor status update for ${vehicle.activeRouteName}. Maintain cautious transit speeds.",
                                RiskLevel.MODERATE
                            )
                            Toast.makeText(context, "Advisory transmitted to ${vehicle.driverName}", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, BorderLight),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(14.dp), tint = PrimaryBlue)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Send Advisory", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }

                    OutlinedButton(
                        onClick = {
                            onDispatchEmergencySOS(
                                "CRITICAL SOS: Emergency Response Dispatched for ${vehicle.vehicleNumber}",
                                "Corridor safety dispatch initiated along ${vehicle.activeRouteName}."
                            )
                            Toast.makeText(context, "SOS Dispatched for ${vehicle.vehicleNumber}", Toast.LENGTH_LONG).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, CriticalRed),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CriticalRed),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Emergency, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Emergency SOS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Close Button
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Close Fleet Details", fontSize = 12.sp, color = TextSecondary)
                }
            }
        }
    }
}

@Composable
private fun DetailKeyValueRow(
    key1: String,
    value1: String,
    key2: String,
    value2: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = key1, style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 9.sp)
            Text(text = value1, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = key2, style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 9.sp)
            Text(text = value2, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
        }
    }
}
