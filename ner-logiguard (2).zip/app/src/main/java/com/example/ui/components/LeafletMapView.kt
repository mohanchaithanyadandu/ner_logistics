package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.models.LiveVehicle
import com.example.data.models.LocationPoint
import com.example.data.models.MapTileProvider
import com.example.data.models.NERState
import com.example.data.models.RoadIncident
import com.example.data.models.RouteCandidate
import com.example.engine.MapTileCacheManager
import com.example.engine.RouteOptimizer
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject

class LeafletBridge(
    private val onMarkerSelected: (type: String, id: String, title: String, info: String) -> Unit,
    private val onRouteSelected: (routeId: String) -> Unit,
    private val onMapLoaded: () -> Unit
) {
    @JavascriptInterface
    fun onMarkerClicked(type: String, id: String, title: String, info: String) {
        onMarkerSelected(type, id, title, info)
    }

    @JavascriptInterface
    fun onRouteClicked(routeId: String) {
        onRouteSelected(routeId)
    }

    @JavascriptInterface
    fun onMapReady() {
        onMapLoaded()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LeafletMapView(
    tileCacheManager: MapTileCacheManager,
    vehicles: List<LiveVehicle>,
    incidents: List<RoadIncident>,
    candidates: List<RouteCandidate> = emptyList(),
    selectedRouteId: String? = null,
    activeCorridorCode: String? = null,
    selectedVehicleId: String? = null,
    autoFitTrigger: Long = 0L,
    onVehicleSelect: ((LiveVehicle) -> Unit)? = null,
    onHubSelect: ((LocationPoint) -> Unit)? = null,
    onRouteSelect: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val activeProvider by tileCacheManager.activeProvider.collectAsState()
    val isOfflineForced by tileCacheManager.isOfflineForced.collectAsState()
    val cacheStats by tileCacheManager.cacheStatsFlow.collectAsState(
        initial = com.example.data.models.TileCacheStats(0, 0L, activeProvider, 0, isOfflineForced)
    )

    var showProviderMenu by remember { mutableStateOf(false) }
    var showStateFilterMenu by remember { mutableStateOf(false) }
    var showLayersMenu by remember { mutableStateOf(false) }
    var showVehiclesLayer by remember { mutableStateOf(true) }
    var showHazardsLayer by remember { mutableStateOf(true) }
    var showCorridorsLayer by remember { mutableStateOf(true) }
    var showSheltersLayer by remember { mutableStateOf(false) }
    var showRiskHeatmap by remember { mutableStateOf(false) }

    var selectedEntityTitle by remember { mutableStateOf<String?>(null) }
    var selectedEntityInfo by remember { mutableStateOf<String?>(null) }
    var isMapReady by remember { mutableStateOf(false) }

    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    // Helper to send data updates to Leaflet
    fun updateMapData(webView: WebView?) {
        if (webView == null || !isMapReady) return

        // 1. Update active tile layer
        webView.evaluateJavascript("javascript:setTileLayer('${activeProvider.code}');", null)

        // 2. Update live vehicles
        val vehJson = JSONArray().apply {
            vehicles.forEach { v ->
                put(JSONObject().apply {
                    put("id", v.id)
                    put("vehNumber", v.vehicleNumber)
                    put("driver", v.driverName)
                    put("type", v.type.title)
                    put("cargo", v.cargoDescription)
                    put("lat", v.currentLat)
                    put("lng", v.currentLng)
                    put("speed", v.speedKmH)
                    put("heading", v.headingDegrees)
                    put("status", v.status.name)
                    put("deliveryStatus", v.deliveryStatus.name)
                    put("deliveryStatusLabel", v.deliveryStatus.label)
                    put("route", v.activeRouteName)
                    put("signal", v.signalStatus)
                    put("isSimulated", v.isSimulated)
                    put("hasDeviated", v.hasDeviated)
                    put("deviationDist", v.deviationDistanceKm)
                    put("selected", v.id == selectedVehicleId)
                })
            }
        }.toString()
        webView.evaluateJavascript("javascript:updateVehicles($vehJson, $showVehiclesLayer);", null)

        // 3. Update active road hazards
        val incJson = JSONArray().apply {
            incidents.forEach { inc ->
                put(JSONObject().apply {
                    put("id", inc.id)
                    put("title", inc.title)
                    put("type", inc.type.label)
                    put("severity", inc.severity.name)
                    put("lat", inc.latitude)
                    put("lng", inc.longitude)
                    put("loc", inc.locationName)
                    put("eta", inc.clearanceEtaHours)
                    put("status", inc.status.label)
                })
            }
        }.toString()
        webView.evaluateJavascript("javascript:updateIncidents($incJson, $showHazardsLayer, $showRiskHeatmap);", null)

        // 4. Update Dynamic Route Candidates Polylines
        val routesJson = JSONArray().apply {
            candidates.forEach { c ->
                put(JSONObject().apply {
                    put("id", c.id)
                    put("name", c.name)
                    put("corridorCode", c.corridorCode)
                    put("distanceKm", c.distanceKm)
                    put("durationMin", c.estimatedDurationMin)
                    put("routeScore", c.routeScore)
                    put("compositeRisk", c.compositeRiskScore)
                    put("riskLevel", c.riskLevel.name)
                    put("isRecommended", c.isRecommended)
                    put("isBlocked", c.isBlocked)
                    put("statusLabel", c.statusLabel)
                    put("whyReason", c.recommendationReason)
                    put("isSelected", c.id == selectedRouteId)
                    put("affectedIncidentsCount", c.affectedIncidents.size)
                    val coordsArr = JSONArray()
                    c.polylineCoordinates.forEach { pt ->
                        val ptArr = JSONArray().apply {
                            put(pt.first)
                            put(pt.second)
                        }
                        coordsArr.put(ptArr)
                    }
                    put("coordinates", coordsArr)
                })
            }
        }.toString()
        webView.evaluateJavascript("javascript:updateRouteCandidates($routesJson, '$selectedRouteId', $showCorridorsLayer);", null)

        // 5. Update Hubs
        val hubsJson = JSONArray().apply {
            RouteOptimizer.HUBS.forEach { h ->
                put(JSONObject().apply {
                    put("id", h.id)
                    put("name", h.name)
                    put("state", h.state.fullName)
                    put("lat", h.latitude)
                    put("lng", h.longitude)
                    put("alt", h.altitudeMeters)
                    put("terrain", h.terrainType.label)
                })
            }
        }.toString()
        webView.evaluateJavascript("javascript:updateHubs($hubsJson, $showCorridorsLayer);", null)

        // 6. Update Shelters
        webView.evaluateJavascript("javascript:toggleShelters($showSheltersLayer);", null)
    }

    LaunchedEffect(activeProvider, isOfflineForced, vehicles, incidents, candidates, selectedRouteId, activeCorridorCode, showVehiclesLayer, showHazardsLayer, showCorridorsLayer, showSheltersLayer, showRiskHeatmap, isMapReady) {
        updateMapData(webViewRef)
    }

    LaunchedEffect(autoFitTrigger) {
        if (autoFitTrigger > 0L && isMapReady) {
            webViewRef?.evaluateJavascript("javascript:fitRouteBounds('$selectedRouteId', true);", null)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            webViewRef?.let { wv ->
                wv.stopLoading()
                wv.onPause()
            }
        }
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(LightBackground)
            .border(1.dp, LightBorder, RoundedCornerShape(16.dp))
    ) {
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    webViewRef = this
                    layoutParams = android.view.ViewGroup.LayoutParams(
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT
                    )

                    // Modern Android WebView uses window hardware compositing directly;
                    // avoid forcing LAYER_TYPE_SOFTWARE which triggers Mesa DRI render node probe warnings in virtualized container environments
                    setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)

                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        cacheMode = WebSettings.LOAD_DEFAULT
                        allowFileAccess = true
                        allowContentAccess = true
                        loadWithOverviewMode = true
                        useWideViewPort = true
                        builtInZoomControls = false
                        displayZoomControls = false
                    }

                    setBackgroundColor(android.graphics.Color.rgb(248, 250, 252))

                    addJavascriptInterface(
                        LeafletBridge(
                            onMarkerSelected = { type, id, title, info ->
                                selectedEntityTitle = title
                                selectedEntityInfo = info
                                if (type == "VEHICLE") {
                                    val v = vehicles.find { it.id == id }
                                    if (v != null) onVehicleSelect?.invoke(v)
                                } else if (type == "HUB") {
                                    val h = RouteOptimizer.HUBS.find { it.id == id }
                                    if (h != null) onHubSelect?.invoke(h)
                                }
                            },
                            onRouteSelected = { routeId ->
                                onRouteSelect?.invoke(routeId)
                            },
                            onMapLoaded = {
                                isMapReady = true
                                coroutineScope.launch(Dispatchers.Main) {
                                    updateMapData(this@apply)
                                }
                            }
                        ),
                        "AndroidBridge"
                    )

                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): WebResourceResponse? {
                            val url = request?.url ?: return null
                            val host = url.host ?: ""

                            // Intercept local tile requests
                            if (host == "local-tiles.app" || host.contains("openstreetmap.org") || host.contains("cartocdn.com") || host.contains("opentopomap.org") || host.contains("arcgisonline.com")) {
                                try {
                                    val segments = url.pathSegments
                                    val z: Int
                                    val x: Int
                                    val y: Int
                                    val layer: String

                                    if (segments.size >= 4) {
                                        layer = segments[0]
                                        z = segments[1].toIntOrNull() ?: 7
                                        x = segments[2].toIntOrNull() ?: 0
                                        val yStr = segments[3].substringBefore(".")
                                        y = yStr.toIntOrNull() ?: 0
                                    } else if (segments.size == 3) {
                                        layer = activeProvider.code
                                        z = segments[0].toIntOrNull() ?: 7
                                        x = segments[1].toIntOrNull() ?: 0
                                        val yStr = segments[2].substringBefore(".")
                                        y = yStr.toIntOrNull() ?: 0
                                    } else {
                                        layer = activeProvider.code
                                        z = 7; x = 96; y = 55
                                    }

                                    val stream = runBlocking {
                                        tileCacheManager.getTileStream(layer, z, x, y)
                                    }
                                    return WebResourceResponse("image/png", "UTF-8", stream)
                                } catch (e: Exception) {
                                    // Fall through
                                }
                            }
                            return super.shouldInterceptRequest(view, request)
                        }

                        override fun onRenderProcessGone(
                            view: WebView?,
                            detail: android.webkit.RenderProcessGoneDetail?
                        ): Boolean {
                            // Gracefully handle render process exit in headless/virtualized containers
                            android.util.Log.w("LeafletMapView", "WebView render process exited, handled gracefully.")
                            return true
                        }

                        override fun onReceivedError(
                            view: WebView?,
                            request: WebResourceRequest?,
                            error: android.webkit.WebResourceError?
                        ) {
                            // Gracefully handle transient network or resource loading errors
                        }
                    }

                    webChromeClient = WebChromeClient()
                    loadDataWithBaseURL("https://local-tiles.app/", getLeafletHtml(), "text/html", "UTF-8", null)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Top Layer Control Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Tile Provider Selector Pill
            Box {
                Surface(
                    onClick = { showProviderMenu = true },
                    color = LightCardWhite.copy(alpha = 0.95f),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, LightBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = "Map Layer",
                            tint = ProfessionalBlue,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = activeProvider.title.take(12).uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = ProfessionalBlue,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }

                DropdownMenu(
                    expanded = showProviderMenu,
                    onDismissRequest = { showProviderMenu = false },
                    modifier = Modifier.background(LightCardWhite)
                ) {
                    MapTileProvider.values().forEach { provider ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(
                                        text = provider.title,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (provider == activeProvider) ProfessionalBlue else TextDarkCharcoal,
                                        fontWeight = if (provider == activeProvider) FontWeight.Bold else FontWeight.Normal
                                    )
                                    Text(
                                        text = provider.subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextGray
                                    )
                                }
                            },
                            onClick = {
                                tileCacheManager.setActiveProvider(provider)
                                showProviderMenu = false
                            }
                        )
                    }
                }
            }

            // Layer Toggle & State Jump Menu
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                // NER 8-State Focus Selector
                Box {
                    Surface(
                        onClick = { showStateFilterMenu = true },
                        shape = RoundedCornerShape(8.dp),
                        color = LightCardWhite.copy(alpha = 0.95f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SafeGreen)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "NER STATES ▾",
                                style = MaterialTheme.typography.labelSmall,
                                color = SafeGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showStateFilterMenu,
                        onDismissRequest = { showStateFilterMenu = false },
                        modifier = Modifier.background(LightCardWhite)
                    ) {
                        DropdownMenuItem(
                            text = { Text("🗺️ All North East Region", color = ProfessionalBlue, fontWeight = FontWeight.Bold) },
                            onClick = {
                                webViewRef?.evaluateJavascript("javascript:focusState('ALL');", null)
                                showStateFilterMenu = false
                            }
                        )
                        NERState.values().forEach { st ->
                            DropdownMenuItem(
                                text = { Text("${st.fullName} (${st.shortCode})", color = TextDarkCharcoal) },
                                onClick = {
                                    webViewRef?.evaluateJavascript("javascript:focusState('${st.shortCode}');", null)
                                    showStateFilterMenu = false
                                }
                            )
                        }
                    }
                }

                // Layer Toggle Pills
                LeafletFilterPill("Fleet", showVehiclesLayer, SafeGreen) { showVehiclesLayer = !showVehiclesLayer }
                LeafletFilterPill("Hazards", showHazardsLayer, CriticalRed) { showHazardsLayer = !showHazardsLayer }
                LeafletFilterPill("Routes", showCorridorsLayer, ProfessionalBlue) { showCorridorsLayer = !showCorridorsLayer }

                // Secondary Layers Dropdown
                Box {
                    Surface(
                        onClick = { showLayersMenu = true },
                        shape = RoundedCornerShape(8.dp),
                        color = LightCardWhite.copy(alpha = 0.95f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, LightBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Layers ▾",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextDarkCharcoal,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showLayersMenu,
                        onDismissRequest = { showLayersMenu = false },
                        modifier = Modifier.background(LightCardWhite)
                    ) {
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (showSheltersLayer) "✓ Emergency Shelters (On)" else "○ Emergency Shelters (Off)",
                                    color = if (showSheltersLayer) ProfessionalBlue else TextDarkCharcoal,
                                    fontSize = 12.sp
                                )
                            },
                            onClick = {
                                showSheltersLayer = !showSheltersLayer
                                showLayersMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (showRiskHeatmap) "✓ Risk Heatmap (On)" else "○ Risk Heatmap (Off)",
                                    color = if (showRiskHeatmap) ProfessionalBlue else TextDarkCharcoal,
                                    fontSize = 12.sp
                                )
                            },
                            onClick = {
                                showRiskHeatmap = !showRiskHeatmap
                                showLayersMenu = false
                            }
                        )
                    }
                }
            }
        }

        // On-Map Zoom Controls (+ / -) & Recenter (Top Right)
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            IconButton(
                onClick = { webViewRef?.evaluateJavascript("javascript:zoomIn();", null) },
                modifier = Modifier
                    .size(32.dp)
                    .background(LightCardWhite.copy(alpha = 0.95f), CircleShape)
                    .border(1.dp, LightBorder, CircleShape)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Zoom In", tint = ProfessionalBlue, modifier = Modifier.size(16.dp))
            }

            IconButton(
                onClick = { webViewRef?.evaluateJavascript("javascript:zoomOut();", null) },
                modifier = Modifier
                    .size(32.dp)
                    .background(LightCardWhite.copy(alpha = 0.95f), CircleShape)
                    .border(1.dp, LightBorder, CircleShape)
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Zoom Out", tint = ProfessionalBlue, modifier = Modifier.size(16.dp))
            }

            IconButton(
                onClick = { webViewRef?.evaluateJavascript("javascript:fitRouteBounds('$selectedRouteId', true);", null) },
                modifier = Modifier
                    .size(32.dp)
                    .background(LightCardWhite.copy(alpha = 0.95f), CircleShape)
                    .border(1.dp, ProfessionalBlue.copy(alpha = 0.6f), CircleShape)
            ) {
                Icon(Icons.Default.Navigation, contentDescription = "Fit Route Corridor", tint = ProfessionalBlue, modifier = Modifier.size(15.dp))
            }

            IconButton(
                onClick = { webViewRef?.evaluateJavascript("javascript:recenterNorthEast();", null) },
                modifier = Modifier
                    .size(32.dp)
                    .background(LightCardWhite.copy(alpha = 0.95f), CircleShape)
                    .border(1.dp, SafeGreen.copy(alpha = 0.6f), CircleShape)
            ) {
                Icon(Icons.Default.MyLocation, contentDescription = "Recenter NER", tint = SafeGreen, modifier = Modifier.size(15.dp))
            }
        }

        // Clean Bottom Legend Bar
        Surface(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(8.dp),
            shape = RoundedCornerShape(8.dp),
            color = PureWhite.copy(alpha = 0.95f),
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(SuccessGreen))
                    Text(text = "Safe", style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(WarningAmber))
                    Text(text = "Moderate", style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(CriticalRed))
                    Text(text = "Critical", style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(PrimaryBlue))
                    Text(text = "Vehicle", style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(RiskOrange))
                    Text(text = "Incident", style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                }
            }
        }

        // Bottom Selected Marker Callout Overlay
        AnimatedVisibility(
            visible = selectedEntityTitle != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = LightCardWhite,
                border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalBlue.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = selectedEntityTitle ?: "",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextDarkCharcoal,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = selectedEntityInfo ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextGray,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(
                        onClick = {
                            selectedEntityTitle = null
                            selectedEntityInfo = null
                        },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextGray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LeafletFilterPill(
    label: String,
    isActive: Boolean,
    color: Color,
    onToggle: () -> Unit
) {
    Surface(
        onClick = onToggle,
        shape = RoundedCornerShape(14.dp),
        color = if (isActive) color.copy(alpha = 0.12f) else LightCardWhite,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isActive) color else LightBorder)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(if (isActive) color else TextGray)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = if (isActive) TextDarkCharcoal else TextGray,
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                fontSize = 9.sp
            )
        }
    }
}

/**
 * Full OpenStreetMap Leaflet Map HTML, CSS and JS scripts
 * Focused on the 8 states of North East India.
 */
private fun getLeafletHtml(): String {
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <title>NER LogiGuard Leaflet Map</title>
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/>
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
        <style>
            html, body { height: 100%; margin: 0; padding: 0; background: #F8FAFC; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; overflow: hidden; }
            #map { height: 100%; width: 100%; background: #F8FAFC; }
            .leaflet-container { background: #F8FAFC; }
            .leaflet-control-zoom { display: none; }
            .leaflet-control-attribution { background: rgba(255, 255, 255, 0.85) !important; color: #64748B !important; font-size: 8px !important; }
            .leaflet-control-attribution a { color: #1D4ED8 !important; }
            
            /* Convoy Location Markers */
            .convoy-marker-wrap {
                display: flex;
                flex-direction: column;
                align-items: center;
                cursor: pointer;
            }
            .convoy-badge {
                display: flex;
                align-items: center;
                background: #FFFFFF;
                border: 2px solid #16A34A;
                border-radius: 12px;
                padding: 2px 6px;
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
                white-space: nowrap;
                gap: 3px;
            }
            .convoy-badge.delayed { border-color: #D97706; }
            .convoy-badge.danger {
                border-color: #DC2626;
                animation: convoy-pulse 1.1s infinite;
            }
            @keyframes convoy-pulse {
                0% { box-shadow: 0 0 0 0 rgba(220, 38, 38, 0.7); }
                70% { box-shadow: 0 0 0 8px rgba(220, 38, 38, 0); }
                100% { box-shadow: 0 0 0 0 rgba(220, 38, 38, 0); }
            }
            .convoy-tag-text {
                color: #172033;
                font-size: 8.5px;
                font-weight: bold;
                font-family: monospace;
            }
            .convoy-pointer {
                width: 0;
                height: 0;
                border-left: 4px solid transparent;
                border-right: 4px solid transparent;
                border-bottom: 6px solid #16A34A;
                margin-bottom: -1px;
            }
            .convoy-pointer.delayed { border-bottom-color: #D97706; }
            .convoy-pointer.danger { border-bottom-color: #DC2626; }

            /* Hazard & Incident Markers */
            .hazard-marker-wrap {
                display: flex;
                flex-direction: column;
                align-items: center;
                cursor: pointer;
            }
            .hazard-bubble {
                width: 28px;
                height: 28px;
                border-radius: 50%;
                background: #DC2626;
                border: 2px solid #FFFFFF;
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 2px 6px rgba(220, 38, 38, 0.4);
                font-size: 13px;
            }
            .hazard-bubble.critical {
                background: #DC2626;
                animation: hazard-wave 1.4s infinite;
            }
            .hazard-bubble.moderate {
                background: #D97706;
                box-shadow: 0 2px 6px rgba(217, 119, 6, 0.4);
            }
            @keyframes hazard-wave {
                0% { box-shadow: 0 0 0 0 rgba(220, 38, 38, 0.75); }
                70% { box-shadow: 0 0 0 9px rgba(220, 38, 38, 0); }
                100% { box-shadow: 0 0 0 0 rgba(220, 38, 38, 0); }
            }
            .hazard-eta-pill {
                background: #FFFFFF;
                color: #172033;
                border: 1px solid #E2E8F0;
                border-radius: 4px;
                font-size: 7.5px;
                font-weight: bold;
                padding: 1px 4px;
                margin-top: -3px;
                white-space: nowrap;
                box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            }

            /* Origin & Destination Waypoint Pins */
            .waypoint-pill {
                display: flex;
                align-items: center;
                background: #FFFFFF;
                color: #172033;
                border-radius: 10px;
                padding: 2px 7px;
                font-size: 8px;
                font-weight: bold;
                box-shadow: 0 2px 5px rgba(0,0,0,0.15);
                white-space: nowrap;
                border: 2px solid #2563EB;
            }
            .waypoint-pill.origin { border: 2px solid #16A34A; }
            .waypoint-pill.dest { border: 2px solid #DC2626; }

            .hub-marker {
                width: 22px;
                height: 22px;
                background: rgba(29, 78, 216, 0.15);
                border: 2px solid #1D4ED8;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #1D4ED8;
                font-size: 8px;
                font-weight: bold;
                cursor: pointer;
            }

            .shelter-marker {
                width: 20px;
                height: 20px;
                background: rgba(131, 56, 236, 0.2);
                border: 1.5px solid #8338EC;
                border-radius: 4px;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #8338EC;
                font-size: 10px;
                cursor: pointer;
            }

            /* Leaflet Popup Light Theme */
            .leaflet-popup-content-wrapper {
                background: #FFFFFF !important;
                color: #0F172A !important;
                border: 1px solid #E2E8F0 !important;
                border-radius: 8px !important;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1) !important;
            }
            .leaflet-popup-tip {
                background: #FFFFFF !important;
                border: 1px solid #E2E8F0 !important;
            }
        </style>
    </head>
    <body>
        <div id="map"></div>
        <script>
            // Default center on North Eastern Region (Assam, Arunachal, Meghalaya, etc.)
            var map = L.map('map', {
                center: [26.1, 92.5],
                zoom: 7,
                minZoom: 5,
                maxZoom: 18,
                zoomControl: false
            });

            var activeLayer = null;
            var currentLayerCode = 'osm_standard';

            function setTileLayer(layerCode) {
                if (activeLayer) {
                    map.removeLayer(activeLayer);
                }
                currentLayerCode = layerCode;
                var tileUrl = 'https://local-tiles.app/' + layerCode + '/{z}/{x}/{y}.png';
                activeLayer = L.tileLayer(tileUrl, {
                    maxZoom: 18,
                    tileSize: 256,
                    attribution: 'OSM & NER LogiGuard GIS Tile Engine'
                }).addTo(map);
            }

            setTileLayer('osm_standard');

            var vehicleLayerGroup = L.layerGroup().addTo(map);
            var incidentLayerGroup = L.layerGroup().addTo(map);
            var routeLayerGroup = L.layerGroup().addTo(map);
            var hubLayerGroup = L.layerGroup().addTo(map);
            var shelterLayerGroup = L.layerGroup().addTo(map);

            // Pre-seed Shelter Locations across Mountain Passes
            var shelters = [
                { name: "BRO 42 BRTF Transit Camp", lat: 27.268, lng: 92.418, type: "BRO Camp", info: "Oxygen cylinders, heavy tow winches & emergency food" },
                { name: "Sela Tunnel North Emergency Shelter", lat: 27.510, lng: 92.108, type: "SDRF Outpost", info: "High-altitude blizzard shelter & warm beds" },
                { name: "Sonapur Mud Tunnel BRO Post", lat: 25.125, lng: 92.365, type: "BRO Post", info: "Excavators & rapid bulldozer clearing detachment" },
                { name: "Noney Gorge SDRF Relief Base", lat: 24.825, lng: 93.585, type: "SDRF Outpost", info: "Mudslide recovery squad & medical triage" },
                { name: "Sherathang Alpine Disaster Shelter", lat: 27.375, lng: 88.815, type: "High Pass Base", info: "4,150m snow avalanche refuge center" }
            ];

            shelters.forEach(function(s) {
                var icon = L.divIcon({
                    className: 'shelter-marker',
                    html: '🏥',
                    iconSize: [22, 22]
                });
                var m = L.marker([s.lat, s.lng], { icon: icon });
                m.bindPopup("<b>" + s.name + "</b><br><span style='color:#8338EC'>" + s.type + "</span><br><small>" + s.info + "</small>");
                m.on('click', function() {
                    if (window.AndroidBridge) {
                        AndroidBridge.onMarkerClicked("SHELTER", s.name, s.name + " (" + s.type + ")", s.info);
                    }
                });
                shelterLayerGroup.addLayer(m);
            });

            function updateVehicles(vehList, isVisible) {
                vehicleLayerGroup.clearLayers();
                if (!isVisible) return;

                vehList.forEach(function(v) {
                    var statusCls = '';
                    var statusColor = '#10B981';
                    if (v.hasDeviated || v.status === 'EMERGENCY_STOP' || v.deliveryStatus === 'AT_RISK') {
                        statusCls = 'danger';
                        statusColor = '#EF4444';
                    } else if (v.deliveryStatus === 'DELAYED' || v.status === 'DELAYED_RISK') {
                        statusCls = 'delayed';
                        statusColor = '#F59E0B';
                    }

                    var markerHtml = '<div class="convoy-marker-wrap">' +
                        '<div class="convoy-badge ' + statusCls + '">' +
                        '<span style="font-size:11px;">🚛</span>' +
                        '<span class="convoy-tag-text">' + v.vehNumber + '</span>' +
                        '</div>' +
                        '<div class="convoy-pointer ' + statusCls + '"></div>' +
                        '</div>';

                    var icon = L.divIcon({
                        className: '',
                        html: markerHtml,
                        iconSize: [68, 26],
                        iconAnchor: [34, 26]
                    });

                    var marker = L.marker([v.lat, v.lng], { icon: icon });

                    var tag = v.isSimulated ? "<span style='background:#0284C7;color:#FFFFFF;padding:1px 5px;border-radius:3px;font-size:9px;font-weight:bold;'>SIMULATED GPS</span>" : "<span style='background:#059669;color:#FFFFFF;padding:1px 5px;border-radius:3px;font-size:9px;font-weight:bold;'>REAL LIVE GPS</span>";
                    var devAlert = v.hasDeviated ? "<br><b style='color:#EF4444'>⚠️ DEVIATED " + v.deviationDist.toFixed(1) + " KM OFF CORRIDOR!</b>" : "";

                    marker.bindPopup("<div style='font-family:sans-serif; min-width:190px;'>" +
                        "<div style='display:flex; justify-content:space-between; align-items:center;'>" +
                        "<b>CONVOY: " + v.vehNumber + "</b>" + tag +
                        "</div>" +
                        "<div style='font-size:11px; margin-top:3px; color:#475569;'>" + v.type + " | Cargo: <b>" + v.cargo + "</b></div>" +
                        "<div style='font-size:11px; color:#475569;'>Driver: " + v.driver + " | Speed: <b>" + v.speed + " km/h</b></div>" +
                        "<div style='font-size:11px; margin-top:2px;'>Status: <b style='color:" + statusColor + "'>" + v.deliveryStatusLabel + "</b></div>" +
                        "<div style='font-size:11px; color:#2563EB;'>Assigned: " + v.route + "</div>" +
                        devAlert + "</div>");

                    marker.on('click', function() {
                        if (window.AndroidBridge) {
                            var title = "Convoy: " + v.vehNumber + " (" + v.type + ")";
                            var info = "Status: " + v.deliveryStatusLabel + (v.hasDeviated ? " [DEVIATION DETECTED]" : "") + "\nCargo: " + v.cargo + "\nDriver: " + v.driver + " | Speed: " + v.speed + " km/h\nRoute: " + v.route + " | Source: " + (v.isSimulated ? "Simulation" : "Real GPS");
                            AndroidBridge.onMarkerClicked("VEHICLE", v.id, title, info);
                        }
                    });
                    vehicleLayerGroup.addLayer(marker);
                });
            }

            function updateIncidents(incList, isVisible, showHeatmap) {
                incidentLayerGroup.clearLayers();
                if (!isVisible) return;

                incList.forEach(function(inc) {
                    var isCrit = inc.severity === 'CRITICAL_BLOCKAGE' || inc.severity === 'CRITICAL';
                    var bubbleCls = isCrit ? 'critical' : 'moderate';
                    
                    var hazardEmoji = '⚠️';
                    var titleLower = (inc.title || '').toLowerCase();
                    if (titleLower.indexOf('landslide') >= 0) hazardEmoji = '🪨';
                    else if (titleLower.indexOf('mudslide') >= 0 || titleLower.indexOf('block') >= 0) hazardEmoji = '🚧';
                    else if (titleLower.indexOf('flood') >= 0 || titleLower.indexOf('rain') >= 0) hazardEmoji = '🌊';
                    else if (titleLower.indexOf('snow') >= 0 || titleLower.indexOf('blizzard') >= 0) hazardEmoji = '❄️';

                    var html = '<div class="hazard-marker-wrap">' +
                        '<div class="hazard-bubble ' + bubbleCls + '">' + hazardEmoji + '</div>' +
                        '<div class="hazard-eta-pill">~' + inc.eta + 'h</div>' +
                        '</div>';

                    var icon = L.divIcon({
                        className: '',
                        html: html,
                        iconSize: [32, 40],
                        iconAnchor: [16, 38]
                    });

                    var marker = L.marker([inc.lat, inc.lng], { icon: icon });
                    marker.bindPopup("<div style='font-family:sans-serif; min-width:190px;'>" +
                        "<b style='color:#DC2626; font-size:13px;'>" + hazardEmoji + " " + inc.title + "</b><br>" +
                        "<div style='font-size:11px; margin-top:2px;'>Severity: <b>" + inc.severity + "</b></div>" +
                        "<div style='font-size:11px; color:#475569;'>Corridor / Loc: " + inc.loc + "</div>" +
                        "<div style='font-size:11px; color:#475569;'>Status: " + inc.status + "</div>" +
                        "<div style='font-size:11px; margin-top:2px; font-weight:bold; color:#D97706;'>Estimated Clearance: ~" + inc.eta + " hrs</div>" +
                        "</div>");

                    marker.on('click', function() {
                        if (window.AndroidBridge) {
                            var title = "Hazard: " + inc.title;
                            var info = "Severity: " + inc.severity + " | Location: " + inc.loc + "\nStatus: " + inc.status + " | Clearance ETA: ~" + inc.eta + "h";
                            AndroidBridge.onMarkerClicked("INCIDENT", inc.id, title, info);
                        }
                    });
                    incidentLayerGroup.addLayer(marker);

                    if (showHeatmap) {
                        var circle = L.circle([inc.lat, inc.lng], {
                            radius: isCrit ? 12000 : 7000,
                            color: isCrit ? '#DC2626' : '#D97706',
                            fillColor: isCrit ? '#DC2626' : '#D97706',
                            fillOpacity: isCrit ? 0.25 : 0.15,
                            weight: 1.5,
                            dashArray: '5, 5'
                        });
                        incidentLayerGroup.addLayer(circle);
                    }
                });
            }

            var globalCandidates = [];
            var globalSelectedRouteId = null;

            function updateRouteCandidates(candidatesList, selectedId, isVisible) {
                routeLayerGroup.clearLayers();
                globalCandidates = candidatesList || [];
                globalSelectedRouteId = selectedId;
                if (!isVisible || !candidatesList || candidatesList.length === 0) return;

                // Pass 1: Draw Alternative Routes first so recommended route sits on top
                var recommendedRoute = null;
                candidatesList.forEach(function(route) {
                    if (!route.coordinates || route.coordinates.length < 2) return;
                    if (route.isRecommended) {
                        recommendedRoute = route;
                        return;
                    }

                    var isSelected = route.id === selectedId || route.isSelected;
                    var isBlocked = route.isBlocked || route.affectedIncidentsCount > 0;
                    
                    var strokeColor = '#2563EB'; // Blue alternative
                    var dashStyle = '8, 6';
                    if (isBlocked) {
                        strokeColor = '#DC2626'; // Red blocked
                        dashStyle = '12, 6';
                    } else if (route.routeScore > 60) {
                        strokeColor = '#D97706'; // Amber elevated risk
                        dashStyle = '6, 6';
                    }

                    if (isSelected) {
                        // Selection casing halo
                        var halo = L.polyline(route.coordinates, {
                            color: '#00E5FF',
                            weight: 8,
                            opacity: 0.5,
                            lineCap: 'round'
                        });
                        routeLayerGroup.addLayer(halo);
                    }

                    var altPolyline = L.polyline(route.coordinates, {
                        color: strokeColor,
                        weight: isSelected ? 5.5 : 3.8,
                        opacity: isSelected ? 0.95 : 0.82,
                        dashArray: dashStyle,
                        lineCap: 'round',
                        lineJoin: 'round'
                    });

                    var popupContent = "<div style='font-family:sans-serif; min-width:190px;'>" +
                        "<b style='font-size:13px; color:#0F172A;'>" + route.name + "</b><br>" +
                        "<div style='margin-top:3px; font-weight:bold; color:" + strokeColor + ";'>" +
                        (isBlocked ? "⚠️ BLOCKED / SEVERE HAZARD" : "ALTERNATIVE ROUTE") +
                        "</div>" +
                        "<div style='margin-top:2px; font-size:12px;'><b>Route Score: " + route.routeScore + " / 100</b> <span style='font-size:10px; color:#64748B;'>(Lower = Safer)</span></div>" +
                        "<div style='font-size:11px; color:#475569;'>Distance: <b>" + route.distanceKm + " km</b> | Duration: <b>" + Math.floor(route.durationMin/60) + "h " + (route.durationMin%60) + "m</b></div>" +
                        (route.whyReason ? "<div style='margin-top:4px; font-size:11px; color:#334155; line-height:1.2; font-style:italic; background:#F1F5F9; padding:4px; border-radius:4px;'>" + route.whyReason + "</div>" : "") +
                        "</div>";

                    altPolyline.bindPopup(popupContent);
                    altPolyline.on('click', function() {
                        if (window.AndroidBridge) {
                            AndroidBridge.onRouteClicked(route.id);
                        }
                    });
                    routeLayerGroup.addLayer(altPolyline);
                });

                // Pass 2: Draw Recommended Route on top with solid distinct dual vector path
                if (recommendedRoute && recommendedRoute.coordinates && recommendedRoute.coordinates.length >= 2) {
                    var isSelected = recommendedRoute.id === selectedId || recommendedRoute.isSelected;
                    
                    // Outer dark casing line for contrast
                    var casing = L.polyline(recommendedRoute.coordinates, {
                        color: '#022C22',
                        weight: isSelected ? 9.5 : 7.5,
                        opacity: 0.65,
                        lineCap: 'round',
                        lineJoin: 'round'
                    });
                    routeLayerGroup.addLayer(casing);

                    // Core bright emerald vector line
                    var recPolyline = L.polyline(recommendedRoute.coordinates, {
                        color: '#10B981',
                        weight: isSelected ? 6.5 : 5.0,
                        opacity: 0.98,
                        dashArray: null,
                        lineCap: 'round',
                        lineJoin: 'round'
                    });

                    var recPopup = "<div style='font-family:sans-serif; min-width:195px;'>" +
                        "<b style='font-size:13px; color:#0F172A;'>" + recommendedRoute.name + "</b><br>" +
                        "<div style='margin-top:3px; font-weight:bold; color:#059669;'>★ RECOMMENDED CORRIDOR (Safest Practical)</div>" +
                        "<div style='margin-top:2px; font-size:12px;'><b>Route Score: " + recommendedRoute.routeScore + " / 100</b> <span style='font-size:10px; color:#059669;'>(Optimal)</span></div>" +
                        "<div style='font-size:11px; color:#475569;'>Distance: <b>" + recommendedRoute.distanceKm + " km</b> | Duration: <b>" + Math.floor(recommendedRoute.durationMin/60) + "h " + (recommendedRoute.durationMin%60) + "m</b></div>" +
                        (recommendedRoute.whyReason ? "<div style='margin-top:4px; font-size:11px; color:#064E3B; line-height:1.2; font-style:italic; background:#ECFDF5; padding:4px; border-radius:4px; border-left:3px solid #10B981;'>" + recommendedRoute.whyReason + "</div>" : "") +
                        "</div>";

                    recPolyline.bindPopup(recPopup);
                    recPolyline.on('click', function() {
                        if (window.AndroidBridge) {
                            AndroidBridge.onRouteClicked(recommendedRoute.id);
                        }
                    });
                    routeLayerGroup.addLayer(recPolyline);
                    recPolyline.bringToFront();

                    // Place Origin & Destination Waypoint Pins
                    var startPt = recommendedRoute.coordinates[0];
                    var endPt = recommendedRoute.coordinates[recommendedRoute.coordinates.length - 1];
                    if (startPt) {
                        var originIcon = L.divIcon({
                            className: '',
                            html: '<div class="waypoint-pill origin">🟢 ORIGIN</div>',
                            iconSize: [68, 20],
                            iconAnchor: [34, 10]
                        });
                        routeLayerGroup.addLayer(L.marker(startPt, { icon: originIcon }));
                    }
                    if (endPt) {
                        var destIcon = L.divIcon({
                            className: '',
                            html: '<div class="waypoint-pill dest">🎯 DEST</div>',
                            iconSize: [60, 20],
                            iconAnchor: [30, 10]
                        });
                        routeLayerGroup.addLayer(L.marker(endPt, { icon: destIcon }));
                    }
                }

                // Automatic bounds adjustment
                fitRouteBounds(selectedId, true);
            }

            function fitRouteBounds(selectedId, fitAll) {
                if (!globalCandidates || globalCandidates.length === 0) return;

                var coords = [];
                if (fitAll) {
                    globalCandidates.forEach(function(r) {
                        if (r.coordinates && r.coordinates.length > 0) {
                            coords = coords.concat(r.coordinates);
                        }
                    });
                } else {
                    var targetRoute = globalCandidates.find(function(r) { return r.id === selectedId; }) ||
                                      globalCandidates.find(function(r) { return r.isRecommended; }) ||
                                      globalCandidates[0];
                    if (targetRoute && targetRoute.coordinates) {
                        coords = targetRoute.coordinates;
                    }
                }

                if (coords.length > 1) {
                    try {
                        var bounds = L.latLngBounds(coords);
                        if (bounds.isValid()) {
                            map.fitBounds(bounds, { padding: [40, 40], maxZoom: 12, animate: true, duration: 1.0 });
                        }
                    } catch(e) {
                        console.error("fitRouteBounds error", e);
                    }
                }
            }

            function updateHubs(hubsList, isVisible) {
                hubLayerGroup.clearLayers();
                if (!isVisible) return;

                hubsList.forEach(function(h) {
                    var icon = L.divIcon({
                        className: 'hub-marker',
                        html: h.id,
                        iconSize: [24, 24]
                    });
                    var m = L.marker([h.lat, h.lng], { icon: icon });
                    m.bindPopup("<b>" + h.name + " (" + h.id + ")</b><br>State: " + h.state + "<br>Altitude: " + h.alt + "m | Terrain: " + h.terrain);
                    m.on('click', function() {
                        if (window.AndroidBridge) {
                            var title = "Hub: " + h.name + " (" + h.id + ")";
                            var info = "State: " + h.state + " | Altitude: " + h.alt + "m\nTerrain: " + h.terrain;
                            AndroidBridge.onMarkerClicked("HUB", h.id, title, info);
                        }
                    });
                    hubLayerGroup.addLayer(m);
                });
            }

            function toggleShelters(isVisible) {
                if (isVisible) {
                    if (!map.hasLayer(shelterLayerGroup)) map.addLayer(shelterLayerGroup);
                } else {
                    if (map.hasLayer(shelterLayerGroup)) map.removeLayer(shelterLayerGroup);
                }
            }

            function zoomIn() {
                map.zoomIn();
            }

            function zoomOut() {
                map.zoomOut();
            }

            function recenterNorthEast() {
                map.flyTo([26.1, 92.5], 7, { duration: 1.0 });
            }

            // Quick focus bounding by State
            function focusState(stateCode) {
                var stateBounds = {
                    'AS': [[24.5, 89.8], [28.0, 96.0]], // Assam
                    'AR': [[26.5, 91.5], [29.5, 97.5]], // Arunachal Pradesh
                    'MN': [[23.8, 93.0], [25.7, 94.8]], // Manipur
                    'ML': [[25.0, 89.8], [26.1, 92.8]], // Meghalaya
                    'MZ': [[21.9, 92.2], [24.5, 93.5]], // Mizoram
                    'NL': [[25.2, 93.3], [27.0, 95.3]], // Nagaland
                    'SK': [[27.0, 88.0], [28.1, 89.0]], // Sikkim
                    'TR': [[22.9, 91.1], [24.6, 92.4]], // Tripura
                    'ALL': [[22.0, 88.0], [29.5, 97.5]]
                };

                var bounds = stateBounds[stateCode] || stateBounds['ALL'];
                map.fitBounds(bounds, { padding: [20, 20], duration: 1.2 });
            }

            // Signal ready to Android
            window.onload = function() {
                if (window.AndroidBridge) {
                    AndroidBridge.onMapReady();
                }
            };
        </script>
    </body>
    </html>
    """.trimIndent()
}
