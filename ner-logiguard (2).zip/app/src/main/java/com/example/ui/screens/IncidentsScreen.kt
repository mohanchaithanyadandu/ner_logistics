package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.IncidentSeverity
import com.example.data.models.IncidentStatus
import com.example.data.models.NERState
import com.example.data.models.RoadIncident
import com.example.ui.components.SectionHeader
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CommandBorder
import com.example.ui.theme.CommandBorderSubtle
import com.example.ui.theme.CommandCard
import com.example.ui.theme.CommandSurface
import com.example.ui.theme.CommandSurfaceElevated
import com.example.ui.theme.CommandSurfaceVariant
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.MonospaceTelemetryStyle
import com.example.ui.theme.ObsidianDarkBackground
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.NERLogisticsViewModel

@Composable
fun IncidentsScreen(
    viewModel: NERLogisticsViewModel,
    modifier: Modifier = Modifier
) {
    val incidents by viewModel.allIncidents.collectAsState()
    var selectedFilter by remember { mutableStateOf("ALL") }

    val filteredIncidents = when (selectedFilter) {
        "ALL" -> incidents
        "CRITICAL" -> incidents.filter { it.severity == IncidentSeverity.CRITICAL_BLOCKAGE }
        "MEGHALAYA" -> incidents.filter { it.state == NERState.MEGHALAYA }
        "ASSAM" -> incidents.filter { it.state == NERState.ASSAM }
        "ARUNACHAL" -> incidents.filter { it.state == NERState.ARUNACHAL_PRADESH }
        else -> incidents
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Road Accessibility Incidents",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Verified field reports & BRO road clearance pipeline",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                Button(
                    onClick = { viewModel.setTab(AppNavTab.FIELD_REPORT) },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color.Black),
                    modifier = Modifier.height(36.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Report", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Filter Pills
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    Pair("ALL", "All Incidents (${incidents.size})"),
                    Pair("CRITICAL", "Critical Blockages"),
                    Pair("MEGHALAYA", "Meghalaya (NH-6)"),
                    Pair("ASSAM", "Assam"),
                    Pair("ARUNACHAL", "Arunachal")
                ).forEach { (key, label) ->
                    item {
                        Surface(
                            onClick = { selectedFilter = key },
                            shape = RoundedCornerShape(8.dp),
                            color = if (selectedFilter == key) CyberCyan else CommandSurface,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (selectedFilter == key) CyberCyan else CommandBorder
                            )
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (selectedFilter == key) Color.Black else TextPrimary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Incident Cards with Status Action Controls
        items(filteredIncidents) { incident ->
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                ManageableIncidentCard(
                    incident = incident,
                    onStatusUpdate = { newStatus -> viewModel.updateIncidentStatus(incident.id, newStatus) }
                )
            }
        }
    }
}

@Composable
private fun ManageableIncidentCard(
    incident: RoadIncident,
    onStatusUpdate: (IncidentStatus) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CommandCard),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (incident.severity == IncidentSeverity.CRITICAL_BLOCKAGE) CrimsonAlert.copy(alpha = 0.6f) else CommandBorder
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = incident.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${incident.corridorName} • ${incident.locationName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberCyan
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (incident.severity == IncidentSeverity.CRITICAL_BLOCKAGE) CrimsonAlert.copy(alpha = 0.2f) else AmberWarning.copy(alpha = 0.2f),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (incident.severity == IncidentSeverity.CRITICAL_BLOCKAGE) CrimsonAlert else AmberWarning
                    )
                ) {
                    Text(
                        text = incident.severity.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (incident.severity == IncidentSeverity.CRITICAL_BLOCKAGE) CrimsonAlert else AmberWarning,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = incident.description,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(10.dp))
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = CommandSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, CommandBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Current Status: ${incident.status.label}",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Est. Clearance: ~${incident.clearanceEtaHours}h",
                        style = MonospaceTelemetryStyle,
                        color = TextPrimary,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons to Progress Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (incident.status != IncidentStatus.DISPATCHING_CREW && incident.status != IncidentStatus.RESOLVED_CLEAR) {
                    OutlinedButton(
                        onClick = { onStatusUpdate(IncidentStatus.DISPATCHING_CREW) },
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AmberWarning),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AmberWarning),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Construction, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Dispatch BRO", fontSize = 11.sp)
                    }
                }

                if (incident.status != IncidentStatus.RESOLVED_CLEAR) {
                    Button(
                        onClick = { onStatusUpdate(IncidentStatus.RESOLVED_CLEAR) },
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen, contentColor = Color.Black),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Mark Resolved", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
