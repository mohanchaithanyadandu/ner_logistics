package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// =========================================================================
// NER LOGIGUARD — CLEAN LIGHT & PROFESSIONAL ENTERPRISE PALETTE
// =========================================================================

// Primary Backgrounds
val PureWhite = Color(0xFFFFFFFF)              // Primary background (#FFFFFF)
val OffWhiteBackground = Color(0xFFF7F9FC)      // Secondary background (#F7F9FC)
val SurfaceSubtle = Color(0xFFF1F5F9)           // Light slate surface (#F1F5F9)
val CardBackground = Color(0xFFFFFFFF)          // Cards (#FFFFFF)
val ElevatedSurface = Color(0xFFFFFFFF)         // Elevated panels (#FFFFFF)

// Borders & Dividers
val BorderLight = Color(0xFFE2E8F0)             // Subtle gray borders (#E2E8F0)
val BorderSubtle = Color(0xFFEDF2F7)            // Soft divider (#EDF2F7)
val BorderFocused = Color(0xFF94A3B8)           // Focused input border

// Primary Actions & Brand Accents
val PrimaryBlue = Color(0xFF2563EB)             // Primary action (#2563EB)
val PrimaryBlueDark = Color(0xFF1D4ED8)         // Hover / Darker blue (#1D4ED8)
val PrimaryBlueLight = Color(0xFFEFF6FF)        // Tinted blue background (#EFF6FF)
val PrimaryBlueBorder = Color(0xFFBFDBFE)       // Soft blue border (#BFDBFE)

// Semantic Status Colors
val SuccessGreen = Color(0xFF16A34A)            // Success / Safe (#16A34A)
val SuccessGreenBg = Color(0xFFF0FDF4)          // Soft green tint (#F0FDF4)
val SuccessGreenBorder = Color(0xFFBBF7D0)      // Soft green border (#BBF7D0)

val WarningAmber = Color(0xFFD97706)            // Warning / Moderate (#D97706)
val WarningAmberBg = Color(0xFFFFFBEB)          // Soft amber tint (#FFFBEB)
val WarningAmberBorder = Color(0xFFFDE68A)      // Soft amber border (#FDE68A)

val CriticalRed = Color(0xFFDC2626)             // Critical / Hazard (#DC2626)
val CriticalRedBg = Color(0xFFFEF2F2)           // Soft red tint (#FEF2F2)
val CriticalRedBorder = Color(0xFFFECACA)       // Soft red border (#FECACA)

val InfoBlue = Color(0xFF0284C7)                // Info / Corridor (#0284C7)
val InfoBlueBg = Color(0xFFF0F9FF)              // Soft sky tint (#F0F9FF)
val InfoBlueBorder = Color(0xFFBAE6FD)          // Soft sky border (#BAE6FD)

val RiskOrange = Color(0xFFEA580C)              // Orange / High Risk (#EA580C)
val RiskOrangeBg = Color(0xFFFFF7ED)            // Soft orange tint (#FFF7ED)
val RiskOrangeBorder = Color(0xFFFED7AA)        // Soft orange border (#FED7AA)

val AIPurpleAccent = Color(0xFF7C3AED)          // AI Purple / Violet (#7C3AED)
val AIPurpleBg = Color(0xFFFAF5FF)              // Soft purple tint (#FAF5FF)
val AIPurpleBorder = Color(0xFFE9D5FF)          // Soft purple border (#E9D5FF)

// Text Colors (High Contrast Light Mode)
val TextPrimary = Color(0xFF172033)             // Primary text (#172033)
val TextSecondary = Color(0xFF64748B)           // Secondary text (#64748B)
val TextTertiary = Color(0xFF94A3B8)            // Muted text (#94A3B8)
val TextMuted = Color(0xFF94A3B8)               // Alias for muted text

// =========================================================================
// COMPATIBILITY ALIASES (Ensures existing references cleanly render in Light Mode)
// =========================================================================

// Dark navy tokens mapped to Clean White & Off-White
val DarkNavyBackground = OffWhiteBackground
val DarkNavyBase = PureWhite
val DarkNavyCard = PureWhite
val DarkNavySurfaceElevated = PureWhite
val DarkNavySurfaceVariant = SurfaceSubtle
val DarkNavyBorder = BorderLight
val DarkNavyBorderSubtle = BorderSubtle
val DarkNavyBorderGlow = PrimaryBlueBorder

// Accents mapped to professional clean palette
val CyanAccent = PrimaryBlue
val ElectricBlue = PrimaryBlue
val CyanAccentMuted = InfoBlue
val CyanAccentGlow = PrimaryBlueLight

// Status aliases
val SafeGreen = SuccessGreen
val SafeGreenBg = SuccessGreenBg
val SafeGreenBorder = SuccessGreenBorder

// Text aliases
val TextWhite = TextPrimary                    // Anywhere expecting white text on dark background now gets primary dark text!
val TextLightBlueGray = TextSecondary
val TextMutedGrayBlue = TextTertiary
val TextCyanAccent = PrimaryBlue

// Legacy command center aliases mapped to light theme
val ObsidianDarkBackground = OffWhiteBackground
val CommandSurface = PureWhite
val CommandSurfaceElevated = PureWhite
val CommandSurfaceVariant = SurfaceSubtle
val CommandCard = PureWhite
val CommandBorder = BorderLight
val CommandBorderSubtle = BorderSubtle
val CommandBorderGlow = PrimaryBlue

val CyberCyan = PrimaryBlue
val CyberCyanMuted = InfoBlue
val TacticalCyanGlow = PrimaryBlueLight

val EmeraldGreen = SuccessGreen
val TacticalGreenGlow = SuccessGreenBg

val AmberWarning = WarningAmber
val TacticalAmberGlow = WarningAmberBg

val CrimsonAlert = CriticalRed
val TacticalCrimsonGlow = CriticalRedBg

val BlueInfo = InfoBlue
val PurpleAccent = AIPurpleAccent
val IndigoTactical = PrimaryBlue

val TextMonospace = PrimaryBlue

val RiskLow = SuccessGreen
val RiskModerate = WarningAmber
val RiskHigh = RiskOrange
val RiskCritical = CriticalRed

val TerrainPlains = InfoBlue
val TerrainHills = WarningAmber
val TerrainHighPass = AIPurpleAccent

val NavyDarkBackground = OffWhiteBackground
val NavySurface = PureWhite
val NavySurfaceVariant = SurfaceSubtle
val NavyCard = PureWhite
val NavyBorder = BorderLight

val LightWhiteBackground = PureWhite
val LightBackground = OffWhiteBackground
val LightCardWhite = PureWhite
val LightSurface = PureWhite
val LightSurfaceElevated = PureWhite
val LightSurfaceVariant = SurfaceSubtle
val LightBorder = BorderLight
val LightBorderSubtle = BorderSubtle

val ProfessionalBlue = PrimaryBlue
val ProfessionalBlueDark = PrimaryBlueDark
val ProfessionalBlueLight = PrimaryBlueLight
val ProfessionalBlueMuted = InfoBlue

val TextDarkCharcoal = TextPrimary
val TextGray = TextSecondary
val TextLightGray = TextTertiary
val TextNavy = PrimaryBlue
