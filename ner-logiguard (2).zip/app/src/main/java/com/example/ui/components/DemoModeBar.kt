package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.DemoStep
import com.example.engine.DemoWorkflowManager
import com.example.ui.theme.*
import com.example.ui.viewmodel.NERLogisticsViewModel

/**
 * Interactive HUD Bar for guiding presenters and judges through the official
 * 23-step SIH 2026 End-to-End logistics resilience workflow.
 */
@Composable
fun DemoModeBar(
    viewModel: NERLogisticsViewModel,
    modifier: Modifier = Modifier
) {
    val isDemoMode by viewModel.isDemoMode.collectAsState()
    val currentStepIndex by viewModel.currentDemoStep.collectAsState()
    val isAutoPlay by viewModel.isDemoAutoPlay.collectAsState()

    if (!isDemoMode) return

    val totalSteps = DemoWorkflowManager.STEPS.size
    val currentStep = DemoWorkflowManager.STEPS.getOrNull(currentStepIndex - 1)
        ?: DemoWorkflowManager.STEPS.first()

    var isExpanded by remember { mutableStateOf(true) }
    var isJumpMenuOpen by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .testTag("demo_mode_bar_hud"),
        shape = RoundedCornerShape(12.dp),
        color = DarkNavyCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmber.copy(alpha = 0.6f)),
        shadowElevation = 0.dp
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // Header: Step Indicator, Auto-Play Status, and Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Indicator dot
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (isAutoPlay) SafeGreen else WarningAmber)
                    )

                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = WarningAmberBg,
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, WarningAmberBorder)
                    ) {
                        Text(
                            text = "SIMULATED DATA • STEP $currentStepIndex/$totalSteps",
                            style = MaterialTheme.typography.labelSmall,
                            color = WarningAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = CyanAccent.copy(alpha = 0.12f),
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, CyanAccent.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = currentStep.categoryBadge,
                            style = MaterialTheme.typography.labelSmall,
                            color = CyanAccent,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                }

                // Right quick actions: Jump menu, Expand/Collapse, Exit
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    // Jump to Step Selector
                    Box {
                        Surface(
                            onClick = { isJumpMenuOpen = true },
                            shape = RoundedCornerShape(4.dp),
                            color = DarkNavySurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkNavyBorder),
                            modifier = Modifier.padding(end = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Jump ▾",
                                    color = TextWhite,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = isJumpMenuOpen,
                            onDismissRequest = { isJumpMenuOpen = false },
                            modifier = Modifier
                                .background(DarkNavyCard)
                                .border(1.dp, DarkNavyBorder)
                        ) {
                            DemoWorkflowManager.STEPS.forEach { step ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(
                                                text = step.title,
                                                color = if (step.stepIndex == currentStepIndex) CyanAccent else TextWhite,
                                                fontSize = 11.sp,
                                                fontWeight = if (step.stepIndex == currentStepIndex) FontWeight.Bold else FontWeight.Normal
                                            )
                                            Text(
                                                text = step.categoryBadge,
                                                color = TextLightBlueGray,
                                                fontSize = 9.sp
                                            )
                                        }
                                    },
                                    onClick = {
                                        viewModel.jumpToDemoStep(step.stepIndex)
                                        isJumpMenuOpen = false
                                    }
                                )
                            }
                        }
                    }

                    // Auto-Play toggle
                    Surface(
                        onClick = { viewModel.toggleDemoAutoPlay() },
                        shape = RoundedCornerShape(4.dp),
                        color = if (isAutoPlay) SafeGreenBg else DarkNavySurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isAutoPlay) SafeGreenBorder else DarkNavyBorder
                        ),
                        modifier = Modifier.padding(end = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isAutoPlay) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Auto Play",
                                tint = if (isAutoPlay) SafeGreen else TextLightBlueGray,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = if (isAutoPlay) "Auto (3m)" else "Auto",
                                color = if (isAutoPlay) SafeGreen else TextWhite,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Expand / Collapse
                    IconButton(
                        onClick = { isExpanded = !isExpanded },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Toggle Expand",
                            tint = TextLightBlueGray,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Exit Demo
                    IconButton(
                        onClick = { viewModel.exitDemoMode() },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Exit Demo",
                            tint = TextMutedGrayBlue,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Step Progress Bar
            Spacer(modifier = Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { currentStepIndex.toFloat() / totalSteps.toFloat() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = CyanAccent,
                trackColor = DarkNavyBorder
            )

            // Expandable Body: Title, Description, Action Button & Controls
            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(modifier = Modifier.padding(top = 6.dp)) {
                    Text(
                        text = currentStep.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = currentStep.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextLightBlueGray,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Buttons Row: Prev, Execute Step Action, Next, Reset
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Previous Step
                        OutlinedButton(
                            onClick = { viewModel.prevDemoStep() },
                            enabled = currentStepIndex > 1,
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkNavyBorder),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = TextWhite,
                                disabledContentColor = TextMutedGrayBlue
                            ),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Prev", modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("Prev", fontSize = 10.sp)
                        }

                        // Primary Step Action Button
                        Button(
                            onClick = { viewModel.executeCurrentDemoStep() },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (currentStep.isSimulationActive) WarningAmber else CyanAccent,
                                contentColor = Color.Black
                            ),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("demo_step_action_button")
                        ) {
                            Text(
                                text = "▶ ${currentStep.keyActionLabel}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }

                        // Next Step
                        Button(
                            onClick = { viewModel.nextDemoStep() },
                            enabled = currentStepIndex < totalSteps,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyanAccent.copy(alpha = 0.15f),
                                contentColor = CyanAccent,
                                disabledContainerColor = DarkNavySurfaceVariant,
                                disabledContentColor = TextMutedGrayBlue
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent.copy(alpha = 0.4f)),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("Next", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(3.dp))
                            Icon(Icons.Default.ArrowForward, contentDescription = "Next", modifier = Modifier.size(13.dp))
                        }

                        // Reset Workflow
                        IconButton(
                            onClick = { viewModel.resetDemoWorkflow() },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Reset Demo",
                                tint = TextLightBlueGray,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }

                    // Simulation Transparency Disclaimer
                    if (currentStep.isSimulationActive) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = WarningAmberBg,
                            border = androidx.compose.foundation.BorderStroke(0.5.dp, WarningAmberBorder)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "Simulation info",
                                    tint = WarningAmber,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "DEMO MODE (SIMULATED DATA) — Running synthetic logistics telemetry alongside OpenStreetMap GIS and Open-Meteo weather models for SIH hackathon evaluation.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = WarningAmber,
                                    fontSize = 9.sp,
                                    lineHeight = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

