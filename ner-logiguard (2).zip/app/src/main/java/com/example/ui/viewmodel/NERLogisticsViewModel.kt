package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.models.AppLanguage
import com.example.data.models.BroadcastAlert
import com.example.data.models.FieldIncidentReport
import com.example.data.models.IncidentSeverity
import com.example.data.models.IncidentStatus
import com.example.data.models.IncidentType
import com.example.data.models.LiveVehicle
import com.example.data.models.LiveWeatherPoint
import com.example.data.models.LocationPoint
import com.example.data.models.NERState
import com.example.data.models.RegionalRiskSummary
import com.example.data.models.RiskLevel
import com.example.data.models.RoadIncident
import com.example.data.models.RouteCandidate
import com.example.data.models.SystemAuditLog
import com.example.data.models.UserRole
import com.example.data.remote.GeminiClient
import com.example.data.remote.GroundedApplicationData
import com.example.data.repository.NERLogisticsRepository
import com.example.data.remote.GeocodingResult
import com.example.data.remote.GeocodingService
import com.example.engine.DemoWorkflowManager
import com.example.engine.RouteOptimizer
import com.example.engine.TelemetryLogEntry
import com.example.engine.TelemetryMode
import com.example.engine.WebSocketStatus
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppNavTab(val title: String, val badgeText: String? = null) {
    COMMAND_CENTER("Command Center"),
    ROUTE_PLANNER("AI Route Planner"),
    LIVE_FLEET("Live Fleet"),
    RISK_INTELLIGENCE("Risk Intelligence"),
    INCIDENTS("Incidents"),
    FIELD_REPORT("Field Report"),
    OFFLINE_CACHE("Map Tile Cache"),
    ALERTS("Alerts"),
    ANALYTICS("Analytics"),
    AI_ASSISTANT("AI Assistant"),
    SETTINGS("Settings")
}

enum class TerminalSyncStatus(val label: String, val badgeColorHex: Long) {
    ONLINE("ONLINE", 0xFF00E676),
    OFFLINE("OFFLINE", 0xFFFF5252),
    SYNCING("SYNCING", 0xFF00E5FF),
    SYNC_COMPLETE("SYNC COMPLETE", 0xFF00E676)
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: String,
    val isUser: Boolean,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

class NERLogisticsViewModel(application: Application) : AndroidViewModel(application) {
    val repository = NERLogisticsRepository(application)
    val tileCacheManager = repository.tileCacheManager

    private val authPrefs = application.getSharedPreferences("ner_logiguard_auth_prefs", android.content.Context.MODE_PRIVATE)

    // Authentication State: Login Page is first screen unless user is logged in with rememberMe
    private val _isAuthenticated = MutableStateFlow(
        authPrefs.getBoolean("is_authenticated", false) && authPrefs.getBoolean("remember_me", false)
    )
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    private val _currentUserEmail = MutableStateFlow(
        authPrefs.getString("user_email", "operator@nerlogiguard.demo") ?: "operator@nerlogiguard.demo"
    )
    val currentUserEmail: StateFlow<String> = _currentUserEmail.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    fun login(email: String, password: String, rememberMe: Boolean): Boolean {
        val trimmedEmail = email.trim()
        val trimmedPass = password.trim()

        if (trimmedEmail.isBlank()) {
            _authError.value = "Operator email or username is required."
            return false
        }
        if (trimmedPass.isBlank()) {
            _authError.value = "Password is required."
            return false
        }

        // Demo accounts and valid credentials check
        val isDemoUser = trimmedEmail.equals("operator@nerlogiguard.demo", ignoreCase = true) && trimmedPass == "Demo@1234"
        val isAdminUser = trimmedEmail.equals("admin@nerlogiguard.gov.in", ignoreCase = true) && trimmedPass == "Admin@2026"
        val isValidGeneralUser = trimmedEmail.contains("@") && trimmedPass.length >= 6

        if (isDemoUser || isAdminUser || isValidGeneralUser) {
            _authError.value = null
            _currentUserEmail.value = trimmedEmail
            _isAuthenticated.value = true

            authPrefs.edit()
                .putBoolean("is_authenticated", true)
                .putBoolean("remember_me", rememberMe)
                .putString("user_email", trimmedEmail)
                .apply()
            return true
        } else {
            _authError.value = "Invalid credentials. Use demo: operator@nerlogiguard.demo / Demo@1234"
            return false
        }
    }

    fun quickDemoLogin() {
        login("operator@nerlogiguard.demo", "Demo@1234", rememberMe = true)
    }

    fun logout() {
        _isAuthenticated.value = false
        _authError.value = null
        authPrefs.edit()
            .putBoolean("is_authenticated", false)
            .apply()
    }

    fun clearAuthError() {
        _authError.value = null
    }

    fun swapOriginDestination() {
        val temp = _selectedOrigin.value
        _selectedOrigin.value = _selectedDestination.value
        _selectedDestination.value = temp
        calculateRoutes()
    }

    // Current Active Navigation
    private val _currentTab = MutableStateFlow(AppNavTab.COMMAND_CENTER)
    val currentTab = _currentTab.asStateFlow()

    // Role-based state
    private val _currentRole = MutableStateFlow(UserRole.LOGISTICS_OPERATOR)
    val currentRole = _currentRole.asStateFlow()

    // Language state
    private val _currentLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val currentLanguage = _currentLanguage.asStateFlow()

    // Route Planner selection
    private val _selectedOrigin = MutableStateFlow(RouteOptimizer.getLocationById("GHY"))
    val selectedOrigin = _selectedOrigin.asStateFlow()

    private val _selectedDestination = MutableStateFlow(RouteOptimizer.getLocationById("SLR"))
    val selectedDestination = _selectedDestination.asStateFlow()

    private val _routeCandidates = MutableStateFlow<List<RouteCandidate>>(emptyList())
    val routeCandidates = _routeCandidates.asStateFlow()

    private val _selectedRouteId = MutableStateFlow<String?>(null)
    val selectedRouteId = _selectedRouteId.asStateFlow()

    private val _isCalculatingRoutes = MutableStateFlow(false)
    val isCalculatingRoutes = _isCalculatingRoutes.asStateFlow()

    private val _routeCalculationMessage = MutableStateFlow<String?>(null)
    val routeCalculationMessage = _routeCalculationMessage.asStateFlow()

    private val _routeCalculationError = MutableStateFlow<String?>(null)
    val routeCalculationError = _routeCalculationError.asStateFlow()

    private val _lastRecommendationChangeExplanation = MutableStateFlow<String?>(null)
    val lastRecommendationChangeExplanation = _lastRecommendationChangeExplanation.asStateFlow()

    // India-Wide Location Search
    private val geocodingService = GeocodingService()

    private val _originSearchQuery = MutableStateFlow("Guwahati Logistics Hub")
    val originSearchQuery = _originSearchQuery.asStateFlow()

    private val _destinationSearchQuery = MutableStateFlow("Silchar Valley Depot")
    val destinationSearchQuery = _destinationSearchQuery.asStateFlow()

    private val _originSuggestions = MutableStateFlow<List<GeocodingResult>>(emptyList())
    val originSuggestions = _originSuggestions.asStateFlow()

    private val _destinationSuggestions = MutableStateFlow<List<GeocodingResult>>(emptyList())
    val destinationSuggestions = _destinationSuggestions.asStateFlow()

    private val _isSearchingOrigin = MutableStateFlow(false)
    val isSearchingOrigin = _isSearchingOrigin.asStateFlow()

    private val _isSearchingDestination = MutableStateFlow(false)
    val isSearchingDestination = _isSearchingDestination.asStateFlow()

    private var originSearchJob: Job? = null
    private var destinationSearchJob: Job? = null

    // Selected Fleet Vehicle & Filtering
    private val _selectedFleetVehicle = MutableStateFlow<LiveVehicle?>(null)
    val selectedFleetVehicle = _selectedFleetVehicle.asStateFlow()

    private val _fleetFilterQuery = MutableStateFlow("")
    val fleetFilterQuery = _fleetFilterQuery.asStateFlow()

    // Trigger timestamp for automatic GIS map bounds adjustment
    private val _routeCalculationCompletedTrigger = MutableStateFlow(0L)
    val routeCalculationCompletedTrigger = _routeCalculationCompletedTrigger.asStateFlow()

    fun triggerAutoFitMapBounds() {
        _routeCalculationCompletedTrigger.value = System.currentTimeMillis()
    }

    // AI Assistant Chat State
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = "NER Logistics AI",
                isUser = false,
                text = "Namaskar! I am your AI Logistics & Terrain Intelligence Assistant for the North Eastern Region. Ask me about weather disruption risks, mountain pass status, or contingency route diversions."
            )
        )
    )
    val chatMessages = _chatMessages.asStateFlow()

    private val _isAILoading = MutableStateFlow(false)
    val isAILoading = _isAILoading.asStateFlow()

    private val _geminiApiKey = MutableStateFlow(GeminiClient.getEffectiveApiKey())
    val geminiApiKey = _geminiApiKey.asStateFlow()

    fun updateGeminiApiKey(key: String) {
        GeminiClient.customApiKey = key.trim()
        _geminiApiKey.value = GeminiClient.getEffectiveApiKey()
    }

    // Repository Flows exposed as StateFlows
    val allIncidents: StateFlow<List<RoadIncident>> = repository.allIncidents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allVehicles: StateFlow<List<LiveVehicle>> = repository.allVehicles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAlerts: StateFlow<List<BroadcastAlert>> = repository.allAlerts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allFieldReports: StateFlow<List<FieldIncidentReport>> = repository.allFieldReports
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingOfflineCount: StateFlow<Int> = repository.pendingOfflineReportsCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _terminalSyncStatus = MutableStateFlow(TerminalSyncStatus.ONLINE)
    val terminalSyncStatus: StateFlow<TerminalSyncStatus> = _terminalSyncStatus.asStateFlow()

    val weatherList: StateFlow<List<LiveWeatherPoint>> = repository.weatherState
    val regionalRiskList: StateFlow<List<RegionalRiskSummary>> = repository.regionalRiskSummaries
    val isOfflineSimulated: StateFlow<Boolean> = repository.isOfflineSimulated
    val simulationSpeed: StateFlow<Int> = repository.simulationSpeedMultiplier
    val isSimulationRunning: StateFlow<Boolean> = repository.isSimulationRunning
    val telemetryMode: StateFlow<TelemetryMode> = repository.gpsWebSocketManager.telemetryMode
    val webSocketStatus: StateFlow<WebSocketStatus> = repository.gpsWebSocketManager.webSocketStatus
    val wsTelemetryLogs: StateFlow<List<TelemetryLogEntry>> = repository.gpsWebSocketManager.recentLogs
    val recentAuditLogs: StateFlow<List<SystemAuditLog>> = repository.recentAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Demo Mode Workflow State (SIH 2026 End-to-End Demonstration)
    private val _isDemoMode = MutableStateFlow(false)
    val isDemoMode = _isDemoMode.asStateFlow()

    private val _currentDemoStep = MutableStateFlow(1)
    val currentDemoStep = _currentDemoStep.asStateFlow()

    private val _isDemoAutoPlay = MutableStateFlow(false)
    val isDemoAutoPlay = _isDemoAutoPlay.asStateFlow()

    private var autoPlayJob: Job? = null

    init {
        viewModelScope.launch {
            allIncidents.collect { incidentsList ->
                calculateRoutes(incidentsList)
            }
        }
        startSimulationTicker()
    }

    private fun startSimulationTicker() {
        viewModelScope.launch {
            while (isActive) {
                delay(4000)
                try {
                    repository.tickFleetSimulation()
                } catch (e: Exception) {
                    // Ignore simulation tick errors
                }
            }
        }
    }

    fun setTab(tab: AppNavTab) {
        _currentTab.value = tab
    }

    fun setRole(role: UserRole) {
        _currentRole.value = role
    }

    fun setLanguage(lang: AppLanguage) {
        _currentLanguage.value = lang
    }

    fun setOrigin(loc: LocationPoint) {
        _selectedOrigin.value = loc
        _originSearchQuery.value = loc.name
        _originSuggestions.value = emptyList()
        calculateRoutes()
    }

    fun setDestination(loc: LocationPoint) {
        _selectedDestination.value = loc
        _destinationSearchQuery.value = loc.name
        _destinationSuggestions.value = emptyList()
        calculateRoutes()
    }

    fun searchOrigin(query: String) {
        _originSearchQuery.value = query
        originSearchJob?.cancel()
        val trimmed = query.trim()
        if (trimmed.length < 2) {
            _originSuggestions.value = emptyList()
            _isSearchingOrigin.value = false
            return
        }
        originSearchJob = viewModelScope.launch {
            _isSearchingOrigin.value = true
            delay(150)
            try {
                val results = geocodingService.searchLocations(trimmed)
                _originSuggestions.value = results
            } catch (e: Exception) {
                _originSuggestions.value = emptyList()
            } finally {
                _isSearchingOrigin.value = false
            }
        }
    }

    fun searchDestination(query: String) {
        _destinationSearchQuery.value = query
        destinationSearchJob?.cancel()
        val trimmed = query.trim()
        if (trimmed.length < 2) {
            _destinationSuggestions.value = emptyList()
            _isSearchingDestination.value = false
            return
        }
        destinationSearchJob = viewModelScope.launch {
            _isSearchingDestination.value = true
            delay(150)
            try {
                val results = geocodingService.searchLocations(trimmed)
                _destinationSuggestions.value = results
            } catch (e: Exception) {
                _destinationSuggestions.value = emptyList()
            } finally {
                _isSearchingDestination.value = false
            }
        }
    }

    fun selectOriginResult(result: GeocodingResult) {
        val point = result.toLocationPoint()
        _selectedOrigin.value = point
        _originSearchQuery.value = result.name
        _originSuggestions.value = emptyList()
        findBestRoute()
    }

    fun selectDestinationResult(result: GeocodingResult) {
        val point = result.toLocationPoint()
        _selectedDestination.value = point
        _destinationSearchQuery.value = result.name
        _destinationSuggestions.value = emptyList()
        findBestRoute()
    }

    fun clearOriginSearch() {
        _originSearchQuery.value = ""
        _originSuggestions.value = emptyList()
    }

    fun clearDestinationSearch() {
        _destinationSearchQuery.value = ""
        _destinationSuggestions.value = emptyList()
    }

    fun swapOriginAndDestination() {
        val tempPoint = _selectedOrigin.value
        _selectedOrigin.value = _selectedDestination.value
        _selectedDestination.value = tempPoint

        val tempQuery = _originSearchQuery.value
        _originSearchQuery.value = _destinationSearchQuery.value
        _destinationSearchQuery.value = tempQuery

        _originSuggestions.value = emptyList()
        _destinationSuggestions.value = emptyList()

        findBestRoute()
    }

    fun selectFleetVehicle(vehicle: LiveVehicle?) {
        _selectedFleetVehicle.value = vehicle
    }

    fun setFleetFilterQuery(query: String) {
        _fleetFilterQuery.value = query
    }

    fun loadFleetRouteInPlanner(vehicle: LiveVehicle) {
        val corridor = com.example.engine.FleetSimulationEngine.CORRIDORS.find { it.vehicleId == vehicle.id }
        val startCoords = corridor?.waypoints?.firstOrNull() ?: Pair(vehicle.currentLat, vehicle.currentLng)
        val endCoords = corridor?.waypoints?.lastOrNull() ?: Pair(vehicle.currentLat + 0.3, vehicle.currentLng + 0.3)

        val hubs = RouteOptimizer.HUBS
        val originPoint = hubs.find { hub ->
            vehicle.originName.contains(hub.name, ignoreCase = true) || hub.name.contains(vehicle.originName.split(" ").first(), ignoreCase = true)
        } ?: LocationPoint(
            id = "ORIG_${vehicle.id}",
            name = vehicle.originName,
            state = NERState.ASSAM,
            latitude = startCoords.first,
            longitude = startCoords.second,
            formattedAddress = "${vehicle.originName}, India"
        )

        val destPoint = hubs.find { hub ->
            vehicle.destinationName.contains(hub.name, ignoreCase = true) || hub.name.contains(vehicle.destinationName.split(" ").first(), ignoreCase = true)
        } ?: LocationPoint(
            id = "DEST_${vehicle.id}",
            name = vehicle.destinationName,
            state = NERState.ASSAM,
            latitude = endCoords.first,
            longitude = endCoords.second,
            formattedAddress = "${vehicle.destinationName}, India"
        )

        _selectedOrigin.value = originPoint
        _originSearchQuery.value = originPoint.name
        _selectedDestination.value = destPoint
        _destinationSearchQuery.value = destPoint.name
        _currentTab.value = AppNavTab.ROUTE_PLANNER
        findBestRoute()
    }

    fun selectRoute(routeId: String) {
        _selectedRouteId.value = routeId
    }

    fun findBestRoute() {
        val origin = _selectedOrigin.value
        val dest = _selectedDestination.value
        if (origin.id == dest.id || (Math.abs(origin.latitude - dest.latitude) < 0.001 && Math.abs(origin.longitude - dest.longitude) < 0.001)) {
            _routeCalculationError.value = "Origin and destination cannot be identical. Please select distinct locations across India."
            return
        }

        viewModelScope.launch {
            _routeCalculationError.value = null
            _isCalculatingRoutes.value = true
            _routeCalculationMessage.value = "CALCULATING SAFEST PRACTICAL ROUTE..."
            delay(350) // Tactical computational pacing for UI feedback

            try {
                val candidates = RouteOptimizer.computeRouteCandidatesAsync(
                    origin = _selectedOrigin.value,
                    destination = _selectedDestination.value,
                    currentPrecipitationMm = 28.0,
                    currentSoilMoisturePct = 82,
                    activeIncidents = allIncidents.value,
                    forceOffline = isOfflineSimulated.value
                )

                if (candidates.isEmpty()) {
                    _routeCalculationError.value = "No feasible route found under current conditions."
                } else {
                    _routeCandidates.value = candidates
                    _selectedRouteId.value = candidates.firstOrNull { it.isRecommended }?.id ?: candidates.firstOrNull()?.id
                    _routeCalculationError.value = null
                    _routeCalculationCompletedTrigger.value = System.currentTimeMillis()
                }
            } catch (e: Exception) {
                _routeCalculationError.value = "Route calculation encountered an issue: ${e.message ?: "Retrying with local topology."}"
            } finally {
                _isCalculatingRoutes.value = false
                _routeCalculationMessage.value = null
            }
        }
    }

    fun calculateRoutes(incidentsList: List<RoadIncident> = allIncidents.value) {
        if (_selectedOrigin.value.id == _selectedDestination.value.id) {
            _routeCandidates.value = emptyList()
            return
        }

        viewModelScope.launch {
            try {
                val candidates = RouteOptimizer.computeRouteCandidatesAsync(
                    origin = _selectedOrigin.value,
                    destination = _selectedDestination.value,
                    currentPrecipitationMm = 28.0,
                    currentSoilMoisturePct = 82,
                    activeIncidents = incidentsList,
                    forceOffline = isOfflineSimulated.value
                )
                _routeCandidates.value = candidates
                if (_selectedRouteId.value == null || candidates.none { it.id == _selectedRouteId.value }) {
                    _selectedRouteId.value = candidates.firstOrNull { it.isRecommended }?.id ?: candidates.firstOrNull()?.id
                }
            } catch (e: Exception) {
                // Keep existing candidates on background refresh error
            }
        }
    }

    fun triggerBlockSimulation() {
        viewModelScope.launch {
            val prevBest = _routeCandidates.value.find { it.isRecommended }
            val originId = _selectedOrigin.value.id
            val destId = _selectedDestination.value.id

            // Trigger appropriate simulated blockage based on active route
            if (destId == "TWG" || originId == "TWG") {
                repository.triggerSimulationLandslideTawang()
            } else {
                repository.triggerSimulationLandslideNH6()
            }

            delay(300)
            val updatedIncidents = allIncidents.value
            val candidates = RouteOptimizer.computeRouteCandidatesAsync(
                origin = _selectedOrigin.value,
                destination = _selectedDestination.value,
                currentPrecipitationMm = 35.0,
                currentSoilMoisturePct = 85,
                activeIncidents = updatedIncidents,
                forceOffline = isOfflineSimulated.value
            )
            _routeCandidates.value = candidates
            val newBest = candidates.firstOrNull { it.isRecommended }
            _selectedRouteId.value = newBest?.id ?: candidates.firstOrNull()?.id

            if (prevBest != null && newBest != null && prevBest.id != newBest.id) {
                val oldScore = candidates.find { it.id == prevBest.id }?.routeScore ?: 95
                _lastRecommendationChangeExplanation.value = "Route recommendation changed because a simulated blockage increased ${prevBest.name}'s disruption risk (Score: $oldScore/100). Recommendation diverted to ${newBest.name} (Score: ${newBest.routeScore}/100)."
            } else if (newBest != null) {
                _lastRecommendationChangeExplanation.value = "Simulated road blockage registered. Route scores and ETAs updated across all corridors."
            }
            _routeCalculationCompletedTrigger.value = System.currentTimeMillis()
        }
    }

    fun triggerHeavyRainSimulation() {
        viewModelScope.launch {
            repository.simulateHeavyMonsoonRain()
            delay(300)
            val updatedIncidents = allIncidents.value
            val candidates = RouteOptimizer.computeRouteCandidatesAsync(
                origin = _selectedOrigin.value,
                destination = _selectedDestination.value,
                currentPrecipitationMm = 95.0, // Severe monsoon cloudburst
                currentSoilMoisturePct = 96,
                activeIncidents = updatedIncidents,
                forceOffline = isOfflineSimulated.value
            )
            _routeCandidates.value = candidates
            val newBest = candidates.firstOrNull { it.isRecommended }
            _selectedRouteId.value = newBest?.id ?: candidates.firstOrNull()?.id

            _lastRecommendationChangeExplanation.value = "Heavy monsoon downpour (95 mm/hr) simulated. Weather disruption risk increased across mountain ghat passes."
            _routeCalculationCompletedTrigger.value = System.currentTimeMillis()
        }
    }

    fun triggerClearSimulation() {
        viewModelScope.launch {
            repository.clearSimulationLandslideNH6()
            repository.clearSimulationLandslideTawang()
            repository.refreshWeatherData()
            delay(300)
            val updatedIncidents = allIncidents.value
            val candidates = RouteOptimizer.computeRouteCandidatesAsync(
                origin = _selectedOrigin.value,
                destination = _selectedDestination.value,
                currentPrecipitationMm = 15.0,
                currentSoilMoisturePct = 70,
                activeIncidents = updatedIncidents,
                forceOffline = isOfflineSimulated.value
            )
            _routeCandidates.value = candidates
            val newBest = candidates.firstOrNull { it.isRecommended }
            _selectedRouteId.value = newBest?.id ?: candidates.firstOrNull()?.id

            _lastRecommendationChangeExplanation.value = "All simulated hazards cleared. Normal operational corridors re-evaluated."
            _routeCalculationCompletedTrigger.value = System.currentTimeMillis()
        }
    }

    fun simulateHazardLandslide() {
        triggerBlockSimulation()
    }

    fun simulateHazardFlood() {
        triggerHeavyRainSimulation()
    }

    fun simulateHazardBlockage() {
        triggerBlockSimulation()
    }

    fun clearAllHazards() {
        triggerClearSimulation()
    }

    fun triggerLandslideSimNH6() {
        viewModelScope.launch {
            repository.triggerSimulationLandslideNH6()
        }
    }

    fun clearLandslideSimNH6() {
        viewModelScope.launch {
            repository.clearSimulationLandslideNH6()
        }
    }

    fun deleteIncident(id: String) {
        viewModelScope.launch {
            repository.deleteIncident(id)
        }
    }

    fun submitFieldReport(
        reporterName: String,
        reporterPhone: String,
        incidentType: IncidentType,
        severity: IncidentSeverity,
        locationName: String,
        state: NERState,
        roadBlockagePct: Int,
        clearanceHours: Double,
        notes: String
    ) {
        viewModelScope.launch {
            val report = FieldIncidentReport(
                id = "FR_${UUID.randomUUID().toString().take(6).uppercase()}",
                reporterName = reporterName.ifBlank { "Field Officer (${_currentRole.value.displayName})" },
                reporterPhone = reporterPhone.ifBlank { "+91 94350 00000" },
                reporterRole = _currentRole.value,
                incidentType = incidentType,
                severity = severity,
                locationName = locationName,
                state = state,
                latitude = 25.5 + (Math.random() - 0.5) * 1.5,
                longitude = 92.0 + (Math.random() - 0.5) * 1.5,
                roadBlockagePct = roadBlockagePct,
                estimatedClearanceHours = clearanceHours,
                notes = notes,
                isOfflinePending = isOfflineSimulated.value,
                timestamp = System.currentTimeMillis()
            )
            repository.reportIncidentFromField(report)
        }
    }

    fun syncAllOfflineReports() {
        viewModelScope.launch {
            if (isOfflineSimulated.value) return@launch
            _terminalSyncStatus.value = TerminalSyncStatus.SYNCING
            delay(600)
            repository.syncOfflineReports()
            _terminalSyncStatus.value = TerminalSyncStatus.SYNC_COMPLETE
            delay(3000)
            if (!isOfflineSimulated.value && _terminalSyncStatus.value == TerminalSyncStatus.SYNC_COMPLETE) {
                _terminalSyncStatus.value = TerminalSyncStatus.ONLINE
            }
        }
    }

    fun updateIncidentStatus(incidentId: String, status: IncidentStatus) {
        viewModelScope.launch {
            repository.updateIncidentStatus(incidentId, status)
        }
    }

    fun broadcastAlert(
        title: String,
        description: String,
        severity: RiskLevel,
        corridor: String,
        state: NERState
    ) {
        viewModelScope.launch {
            repository.broadcastEmergencyAlert(title, description, severity, corridor, state)
        }
    }

    fun toggleOfflineSimulation() {
        val willBeOffline = !isOfflineSimulated.value
        repository.setSimulationOffline(willBeOffline)
        if (willBeOffline) {
            _terminalSyncStatus.value = TerminalSyncStatus.OFFLINE
        } else {
            // Automatically synchronize pending reports when connectivity returns
            syncAllOfflineReports()
        }
    }

    fun setSimulationSpeedMultiplier(speed: Int) {
        repository.setSimulationSpeed(speed)
    }

    fun refreshWeather() {
        viewModelScope.launch {
            repository.refreshWeatherData()
        }
    }

    fun startSimulation() {
        repository.startSimulation()
    }

    fun pauseSimulation() {
        repository.pauseSimulation()
    }

    fun resetSimulation() {
        viewModelScope.launch {
            repository.resetSimulation()
        }
    }

    fun triggerRouteDeviation(vehicleId: String = "V-102") {
        viewModelScope.launch {
            repository.triggerVehicleDeviation(vehicleId)
        }
    }

    fun clearRouteDeviation(vehicleId: String = "V-102") {
        viewModelScope.launch {
            repository.clearVehicleDeviation(vehicleId)
        }
    }

    fun simulateHeavyMonsoonRain() {
        viewModelScope.launch {
            repository.simulateHeavyMonsoonRain()
        }
    }

    fun simulateRoadBlockage() {
        viewModelScope.launch {
            repository.triggerSimulationLandslideNH6()
        }
    }

    fun setTelemetryMode(mode: TelemetryMode) {
        repository.gpsWebSocketManager.setTelemetryMode(mode)
    }

    fun ingestRealGpsRawJson(json: String) {
        repository.ingestRawGpsJson(json)
    }

    fun connectWebSocket(serverUrl: String) {
        repository.gpsWebSocketManager.connectWebSocket(serverUrl)
    }

    fun disconnectWebSocket() {
        repository.gpsWebSocketManager.disconnectWebSocket()
    }

    fun clearAIChat() {
        _chatMessages.value = listOf(
            ChatMessage(
                sender = "NER Logistics AI",
                isUser = false,
                text = "NER Tactical Logistics Copilot initialized. I have real-time visibility into active incidents, weather hazards, mountain passes, and fleet telematics across Northeast India. How can I assist your logistics deployment today?"
            )
        )
    }

    fun triggerLandslideSimTawang() {
        viewModelScope.launch {
            repository.triggerSimulationLandslideTawang()
        }
    }

    fun clearLandslideSimTawang() {
        viewModelScope.launch {
            repository.clearSimulationLandslideTawang()
        }
    }

    fun setOfflineSimulation(isOffline: Boolean) {
        repository.setSimulationOffline(isOffline)
        if (isOffline) {
            _terminalSyncStatus.value = TerminalSyncStatus.OFFLINE
        } else {
            syncAllOfflineReports()
        }
    }

    fun startFleetSimulation() {
        repository.startSimulation()
    }

    fun calculateCurrentRoute() {
        calculateRoutes()
    }

    fun selectRouteCandidate(candidate: RouteCandidate) {
        _selectedRouteId.value = candidate.id
    }

    fun sendAIPrompt(prompt: String) {
        sendAIMessage(prompt)
    }

    fun submitFieldReport(
        reporterName: String,
        locationName: String,
        state: NERState,
        type: IncidentType,
        severity: IncidentSeverity,
        blockagePct: Float,
        clearanceEtaHours: Double,
        notes: String,
        photoUri: String? = null,
        photoFileSize: String? = null
    ) {
        viewModelScope.launch {
            val report = FieldIncidentReport(
                id = "FR_${UUID.randomUUID().toString().take(6).uppercase()}",
                reporterName = reporterName.ifBlank { "Field Officer (${_currentRole.value.displayName})" },
                reporterPhone = "+91 94350 12345",
                reporterRole = _currentRole.value,
                incidentType = type,
                severity = severity,
                locationName = locationName,
                state = state,
                latitude = 25.75 + (Math.random() - 0.5) * 1.5,
                longitude = 93.75 + (Math.random() - 0.5) * 1.5,
                roadBlockagePct = blockagePct.toInt(),
                estimatedClearanceHours = clearanceEtaHours,
                notes = notes,
                isOfflinePending = isOfflineSimulated.value,
                timestamp = System.currentTimeMillis()
            )
            repository.reportIncidentFromField(report)
        }
    }

    // --- DEMO WORKFLOW CONTROLS (SIH 2026 Hackathon) ---

    fun startDemoMode() {
        _isDemoMode.value = true
        _currentDemoStep.value = 1
        executeCurrentDemoStep()
    }

    fun exitDemoMode() {
        _isDemoMode.value = false
        stopDemoAutoPlay()
    }

    fun toggleDemoMode() {
        if (_isDemoMode.value) {
            exitDemoMode()
        } else {
            startDemoMode()
        }
    }

    fun nextDemoStep() {
        if (_currentDemoStep.value < DemoWorkflowManager.STEPS.size) {
            _currentDemoStep.value += 1
            executeCurrentDemoStep()
        }
    }

    fun prevDemoStep() {
        if (_currentDemoStep.value > 1) {
            _currentDemoStep.value -= 1
            executeCurrentDemoStep()
        }
    }

    fun jumpToDemoStep(stepIndex: Int) {
        val clamped = stepIndex.coerceIn(1, DemoWorkflowManager.STEPS.size)
        _currentDemoStep.value = clamped
        executeCurrentDemoStep()
    }

    fun resetDemoWorkflow() {
        stopDemoAutoPlay()
        _currentDemoStep.value = 1
        executeCurrentDemoStep()
    }

    fun toggleDemoAutoPlay() {
        if (_isDemoAutoPlay.value) {
            stopDemoAutoPlay()
        } else {
            startDemoAutoPlay()
        }
    }

    private fun startDemoAutoPlay() {
        _isDemoAutoPlay.value = true
        autoPlayJob?.cancel()
        autoPlayJob = viewModelScope.launch {
            while (isActive && _isDemoAutoPlay.value) {
                val step = DemoWorkflowManager.STEPS.getOrNull(_currentDemoStep.value - 1)
                val delayTime = step?.autoAdvanceDelayMs ?: 8000L
                delay(delayTime)
                if (_currentDemoStep.value < DemoWorkflowManager.STEPS.size) {
                    _currentDemoStep.value += 1
                    executeCurrentDemoStep()
                } else {
                    stopDemoAutoPlay()
                    break
                }
            }
        }
    }

    private fun stopDemoAutoPlay() {
        _isDemoAutoPlay.value = false
        autoPlayJob?.cancel()
        autoPlayJob = null
    }

    fun executeCurrentDemoStep() {
        viewModelScope.launch {
            val step = DemoWorkflowManager.STEPS.getOrNull(_currentDemoStep.value - 1) ?: return@launch
            DemoWorkflowManager.executeStepAction(step, this@NERLogisticsViewModel)
        }
    }

    fun sendAIMessage(prompt: String) {
        if (prompt.isBlank()) return

        val userMsg = ChatMessage(sender = "Operator", isUser = true, text = prompt)
        val currentHistory = _chatMessages.value
        _chatMessages.value = currentHistory + userMsg
        _isAILoading.value = true

        viewModelScope.launch {
            // Build strictly grounded application data snapshot
            val currentOrigin = _selectedOrigin.value
            val currentDest = _selectedDestination.value
            var candidates = _routeCandidates.value
            if (candidates.isEmpty() && currentOrigin != null && currentDest != null) {
                candidates = RouteOptimizer.computeRouteCandidates(
                    origin = currentOrigin,
                    destination = currentDest,
                    activeIncidents = allIncidents.value
                )
                _routeCandidates.value = candidates
            }

            val groundedData = GroundedApplicationData(
                origin = currentOrigin,
                destination = currentDest,
                routeCandidates = candidates,
                activeIncidents = allIncidents.value,
                vehicles = allVehicles.value,
                weatherPoints = weatherList.value,
                regionalRisks = regionalRiskList.value,
                alerts = allAlerts.value,
                fieldReports = allFieldReports.value,
                userRole = _currentRole.value,
                isOffline = isOfflineSimulated.value,
                pendingOfflineCount = pendingOfflineCount.value
            )

            val historyPairs = currentHistory.map { it.text to it.isUser }

            val responseText = GeminiClient.askGroundedAssistant(
                prompt = prompt,
                data = groundedData,
                chatHistory = historyPairs
            )

            val aiMsg = ChatMessage(
                sender = "NER Logistics AI",
                isUser = false,
                text = responseText
            )
            _chatMessages.value = _chatMessages.value + aiMsg
            _isAILoading.value = false
        }
    }
}
