package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.OfflineRoutePackageEntity
import com.example.data.models.ElevationCheckpoint
import com.example.data.models.EmergencyShelterPoint
import com.example.data.models.MapTileProvider
import com.example.data.models.TileCacheStats
import com.example.data.models.TurnNavigationCue
import com.example.engine.MapTileCacheManager
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyDarkBackground
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun OfflineTileCacheDeck(
    tileCacheManager: MapTileCacheManager,
    selectedCorridorCode: String = "NH13_GHY_TWG",
    modifier: Modifier = Modifier
) {
    val activeProvider by tileCacheManager.activeProvider.collectAsState()
    val isOfflineForced by tileCacheManager.isOfflineForced.collectAsState()
    val downloadingPackageId by tileCacheManager.downloadingPackageId.collectAsState()
    val downloadProgress by tileCacheManager.downloadProgressPct.collectAsState()
    val allPackages by tileCacheManager.allOfflinePackagesFlow.collectAsState(initial = emptyList())
    val cacheStats by tileCacheManager.cacheStatsFlow.collectAsState(
        initial = TileCacheStats(0, 0L, activeProvider, 0, isOfflineForced)
    )

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("Offline Corridor Packs", "Turn-by-Turn GPS Hill Cues", "Cache & Layers")

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NavyCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Tile Cache & Navigation Deck
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberCyan.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.OfflinePin,
                            contentDescription = "Offline Cache",
                            tint = CyberCyan,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Mapbox / OSM Offline Cache Engine",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "SQLite Tile Storage • Zero-Connectivity Mountain Navigation",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                // 0G Simulation Toggle Pill
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isOfflineForced) AmberWarning.copy(alpha = 0.25f) else NavySurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isOfflineForced) AmberWarning else NavyBorder),
                    modifier = Modifier.clickable { tileCacheManager.setForceOffline(!isOfflineForced) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudOff,
                            contentDescription = "0G Mode",
                            tint = if (isOfflineForced) AmberWarning else TextSecondary,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isOfflineForced) "0G FORCED" else "ONLINE",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isOfflineForced) AmberWarning else TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Real-time Cache Statistics Metrics Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CacheStatMetric(
                    label = "Stored Tiles",
                    value = "${cacheStats.cachedTilesCount} Tiles",
                    accent = CyberCyan,
                    modifier = Modifier.weight(1f)
                )
                CacheStatMetric(
                    label = "Database Size",
                    value = cacheStats.totalSizeMb,
                    accent = EmeraldGreen,
                    modifier = Modifier.weight(1f)
                )
                CacheStatMetric(
                    label = "Active Provider",
                    value = activeProvider.code.replace("_", " ").uppercase().take(8),
                    accent = Color(0xFF8338EC),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sub-Tabs
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = NavySurface,
                contentColor = CyberCyan,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = CyberCyan
                    )
                },
                modifier = Modifier.clip(RoundedCornerShape(8.dp))
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (selectedTabIndex == index) CyberCyan else TextSecondary,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Tab Content
            when (selectedTabIndex) {
                0 -> OfflinePackagesList(
                    packages = allPackages,
                    downloadingPackageId = downloadingPackageId,
                    downloadProgress = downloadProgress,
                    onDownload = { pkgId -> tileCacheManager.downloadOfflinePackage(pkgId) },
                    onDelete = { pkgId -> tileCacheManager.removeOfflinePackage(pkgId) }
                )
                1 -> TurnByTurnOfflineList(corridorCode = selectedCorridorCode)
                2 -> CacheSettingsAndLayersDeck(
                    tileCacheManager = tileCacheManager,
                    activeProvider = activeProvider,
                    isOfflineForced = isOfflineForced
                )
            }
        }
    }
}

@Composable
private fun CacheStatMetric(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = NavySurface,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, NavyBorder)
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 9.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, style = MaterialTheme.typography.bodyMedium, color = accent, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun OfflinePackagesList(
    packages: List<OfflineRoutePackageEntity>,
    downloadingPackageId: String?,
    downloadProgress: Float,
    onDownload: (String) -> Unit,
    onDelete: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        packages.forEach { pkg ->
            val isCurrentDownloading = pkg.id == downloadingPackageId || pkg.isDownloading
            val progressVal by animateFloatAsState(
                targetValue = if (isCurrentDownloading) downloadProgress else if (pkg.isDownloaded) 1.0f else 0.0f,
                label = "pkgProgress"
            )

            Surface(
                color = NavySurface,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (pkg.isDownloaded) EmeraldGreen.copy(alpha = 0.7f) else NavyBorder
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = pkg.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${pkg.originName} ➔ ${pkg.destinationName} (${pkg.distanceKm.toInt()} km)",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }

                        if (pkg.isDownloaded) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = EmeraldGreen.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(6.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldGreen)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            text = "CACHED",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = EmeraldGreen,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                IconButton(
                                    onClick = { onDelete(pkg.id) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TextSecondary, modifier = Modifier.size(16.dp))
                                }
                            }
                        } else if (isCurrentDownloading) {
                            CircularProgressIndicator(
                                progress = { progressVal },
                                modifier = Modifier.size(24.dp),
                                color = CyberCyan,
                                strokeWidth = 2.5.dp
                            )
                        } else {
                            OutlinedButton(
                                onClick = { onDownload(pkg.id) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberCyan),
                                border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan),
                                modifier = Modifier.height(30.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Download (~${pkg.totalTiles} tiles)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Tile footprint & Zoom depth bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Tile Coverage: Z${pkg.minZoom}-Z${pkg.maxZoom} • ${pkg.downloadedTiles}/${pkg.totalTiles} tiles",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextTertiary,
                            fontSize = 9.sp
                        )
                        Text(
                            text = if (pkg.isDownloaded) String.format(java.util.Locale.US, "%.1f MB (SQLite)", pkg.sizeBytes / (1024.0 * 1024.0)) else "Est. ~25 MB",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                    }

                    if (isCurrentDownloading) {
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { progressVal },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = CyberCyan,
                            trackColor = NavyBorder
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TurnByTurnOfflineList(corridorCode: String) {
    val cues = remember(corridorCode) {
        MapTileCacheManager.generateTurnCuesForCorridor(corridorCode)
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Surface(
            color = NavySurface,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Navigation, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "OFFLINE TURN-BY-TURN CUES (${cues.size} STEPS)",
                    style = MaterialTheme.typography.labelSmall,
                    color = EmeraldGreen,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        cues.forEach { cue ->
            Surface(
                color = NavySurface,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (cue.isSafetyCritical) CrimsonAlert.copy(alpha = 0.6f) else NavyBorder
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(if (cue.isSafetyCritical) CrimsonAlert else CyberCyan),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${cue.stepIndex}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = cue.instruction,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = cue.roadName,
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberCyan
                            )
                            Text(
                                text = "• Elev: ${cue.altitudeMeters}m",
                                style = MaterialTheme.typography.labelSmall,
                                color = AmberWarning
                            )
                        }

                        if (cue.hazardWarning != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                color = CrimsonAlert.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonAlert.copy(alpha = 0.4f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = CrimsonAlert, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = cue.hazardWarning,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CrimsonAlert,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CacheSettingsAndLayersDeck(
    tileCacheManager: MapTileCacheManager,
    activeProvider: MapTileProvider,
    isOfflineForced: Boolean
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // Tile Provider Grid
        Text(
            text = "ACTIVE LEAFLET TILE SOURCE",
            style = MaterialTheme.typography.labelSmall,
            color = CyberCyan,
            fontWeight = FontWeight.Bold
        )

        MapTileProvider.values().forEach { provider ->
            val isSelected = provider == activeProvider
            val color = Color(provider.badgeColorHex)
            Surface(
                onClick = { tileCacheManager.setActiveProvider(provider) },
                color = if (isSelected) color.copy(alpha = 0.2f) else NavySurface,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) color else NavyBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = provider.title,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isSelected) color else TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${provider.subtitle} (Max Zoom: ${provider.maxZoom})",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    if (isSelected) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Cache Management Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = { tileCacheManager.clearUnpinnedCache() },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = AmberWarning),
                border = androidx.compose.foundation.BorderStroke(1.dp, AmberWarning),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Clean Dynamic", fontSize = 10.sp)
            }

            OutlinedButton(
                onClick = { tileCacheManager.clearAllTiles() },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CrimsonAlert),
                border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonAlert),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Purge Cache", fontSize = 10.sp)
            }
        }
    }
}
