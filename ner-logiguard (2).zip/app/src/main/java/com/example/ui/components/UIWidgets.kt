package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.IncidentSeverity
import com.example.data.models.LiveVehicle
import com.example.data.models.RiskLevel
import com.example.data.models.RoadIncident
import com.example.data.models.RouteCandidate
import com.example.data.models.VehicleStatus
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BlueInfo
import com.example.ui.theme.CommandBorder
import com.example.ui.theme.CommandCard
import com.example.ui.theme.CommandSurface
import com.example.ui.theme.CommandSurfaceElevated
import com.example.ui.theme.CommandSurfaceVariant
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.MonospaceMetricValueStyle
import com.example.ui.theme.PureWhite
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.BorderLight
import com.example.ui.theme.MonospaceTelemetryStyle
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyDarkBackground
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Tactical Command Center Operations Clock (Live IST & UTC Ticker)
 */
@Composable
fun CommandCenterClockWidget(
    modifier: Modifier = Modifier
) {
    var currentTimeString by remember { mutableStateOf("") }
    var utcTimeString by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val istFormat = SimpleDateFormat("HH:mm:ss", Locale.ENGLISH).apply {
            timeZone = TimeZone.getTimeZone("Asia/Kolkata")
        }
        val utcFormat = SimpleDateFormat("HH:mm 'UTC'", Locale.ENGLISH).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        while (true) {
            val now = Date()
            currentTimeString = istFormat.format(now)
            utcTimeString = utcFormat.format(now)
            delay(1000)
        }
    }

    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .semantics { contentDescription = "Command Center Live Operational Clock: $currentTimeString IST, $utcTimeString" },
        shape = RoundedCornerShape(8.dp),
        color = CommandSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(1.dp, CommandBorder)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Pulsing Live Operations Dot
            val transition = rememberInfiniteTransition(label = "pulse")
            val alpha by transition.animateFloat(
                initialValue = 0.3f,
                targetValue = 1.0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(800, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "alpha"
            )
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(EmeraldGreen.copy(alpha = alpha))
            )

            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (currentTimeString.isNotEmpty()) currentTimeString else "05:30:00",
                        style = MonospaceTelemetryStyle,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "IST",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = if (utcTimeString.isNotEmpty()) utcTimeString else "00:00 UTC",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextTertiary,
                    fontSize = 9.sp
                )
            }
        }
    }
}

/**
 * High-Density Command Metric Card with Monospace Readouts & Gradient Border
 */
@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .semantics { contentDescription = "$title: $value. Status: $subtitle" },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CommandCard),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            Brush.linearGradient(listOf(accentColor.copy(alpha = 0.4f), CommandBorder))
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.6.sp,
                    fontSize = 10.sp
                )
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(accentColor.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = "$title icon",
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                style = MonospaceMetricValueStyle,
                color = TextPrimary,
                fontSize = 17.sp
            )
            Spacer(modifier = Modifier.height(3.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(4.dp)
                        .clip(CircleShape)
                        .background(accentColor)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = accentColor,
                    fontWeight = FontWeight.Medium,
                    fontSize = 11.sp
                )
            }
        }
    }
}

/**
 * Tactical Risk Badge with color hex support and accessibility description
 */
@Composable
fun RiskBadge(
    score: Int,
    level: RiskLevel,
    modifier: Modifier = Modifier
) {
    val levelColor = Color(level.colorHex)
    Surface(
        modifier = modifier.semantics { contentDescription = "Risk rating: $score out of 100, classification: ${level.label}" },
        shape = RoundedCornerShape(6.dp),
        color = levelColor.copy(alpha = 0.15f),
        border = androidx.compose.foundation.BorderStroke(1.dp, levelColor.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(levelColor)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = "$score/100 ${level.label}",
                style = MaterialTheme.typography.labelSmall,
                color = levelColor,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun StatusPill(
    status: VehicleStatus,
    modifier: Modifier = Modifier
) {
    val color = Color(status.colorHex)
    Surface(
        modifier = modifier.semantics { contentDescription = "Vehicle status: ${status.label}" },
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.15f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = status.label,
                style = MaterialTheme.typography.labelSmall,
                color = color,
                fontWeight = FontWeight.SemiBold,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun TerminalStatusIndicatorPill(
    status: com.example.ui.viewmodel.TerminalSyncStatus,
    modifier: Modifier = Modifier
) {
    val color = Color(status.badgeColorHex)
    Surface(
        modifier = modifier.semantics { contentDescription = "Terminal status: ${status.label}" },
        shape = RoundedCornerShape(12.dp),
        color = color.copy(alpha = 0.16f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.7f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = status.label,
                style = MaterialTheme.typography.labelSmall,
                color = color,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                letterSpacing = 0.4.sp
            )
        }
    }
}

/**
 * Operational Offline/Mesh Status Banner
 */
@Composable
fun OfflineBanner(
    isOffline: Boolean,
    pendingCount: Int,
    onSyncClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (isOffline || pendingCount > 0) {
        Surface(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            shape = RoundedCornerShape(10.dp),
            color = if (isOffline) CrimsonAlert.copy(alpha = 0.12f) else AmberWarning.copy(alpha = 0.12f),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isOffline) CrimsonAlert.copy(alpha = 0.5f) else AmberWarning.copy(alpha = 0.5f)
            )
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isOffline) Icons.Default.CloudOff else Icons.Default.Warning,
                        contentDescription = "Offline Mode Indicator",
                        tint = if (isOffline) CrimsonAlert else AmberWarning,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (isOffline) "OFFLINE MESH ACTIVE (Satellite/Local Cache)" else "LOCAL OFFLINE QUEUE PENDING",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Text(
                            text = if (pendingCount > 0) "$pendingCount incident reports stored safely in local Room DB" else "Operating with cached tiles & deterministic algorithms",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }
                if (pendingCount > 0) {
                    Button(
                        onClick = onSyncClick,
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color.Black),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("offline_sync_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sync,
                            contentDescription = "Sync reports now",
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sync Queue", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * Command Section Header with Operational Dot and Optional Quick Action
 */
@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    actionText: String? = null,
    onActionClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(4.dp)
                        .clip(CircleShape)
                        .background(CyberCyan)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
            }
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextTertiary,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(start = 10.dp, top = 2.dp)
                )
            }
        }
        if (actionText != null && onActionClick != null) {
            Surface(
                onClick = onActionClick,
                shape = RoundedCornerShape(6.dp),
                color = CommandSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, CommandBorder),
                modifier = Modifier.testTag("section_action_${title.take(6).lowercase()}")
            ) {
                Text(
                    text = actionText,
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

/**
 * Command-Center Road Incident Card
 */
@Composable
fun IncidentCard(
    incident: RoadIncident,
    onStatusChange: ((RoadIncident) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isCritical = incident.severity == IncidentSeverity.CRITICAL_BLOCKAGE
    val accentColor = if (isCritical) CrimsonAlert else AmberWarning

    Card(
        modifier = modifier
            .fillMaxWidth()
            .semantics { contentDescription = "Incident: ${incident.title}, corridor ${incident.corridorName}, severity ${incident.severity.label}" },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CommandCard),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isCritical) CrimsonAlert.copy(alpha = 0.5f) else CommandBorder
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = incident.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${incident.corridorName} • ${incident.locationName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberCyan,
                        fontSize = 11.sp
                    )
                }
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = accentColor.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.7f))
                ) {
                    Text(
                        text = incident.severity.label.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = accentColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = incident.description,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = CommandSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Clearance Team",
                            tint = EmeraldGreen,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Status: ${incident.status.label} (~${incident.clearanceEtaHours}h)",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldGreen,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 10.sp
                        )
                    }
                    Text(
                        text = "Source: ${incident.reportedBy}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiary,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

/**
 * Precision Fleet Convoy Telemetry Card
 */
@Composable
fun VehicleCard(
    vehicle: LiveVehicle,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDeviated = vehicle.hasDeviated
    val cardBorderColor = if (isDeviated) CrimsonAlert else CommandBorder

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .semantics { contentDescription = "Convoy ${vehicle.vehicleNumber}, driver ${vehicle.driverName}, status ${vehicle.deliveryStatus.label}" },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CommandCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, cardBorderColor)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isDeviated) CrimsonAlert.copy(alpha = 0.15f) else CyberCyan.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalShipping,
                            contentDescription = "Convoy",
                            tint = if (isDeviated) CrimsonAlert else CyberCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = vehicle.vehicleNumber,
                                style = MonospaceTelemetryStyle,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (vehicle.isSimulated) CyberCyan.copy(alpha = 0.15f) else EmeraldGreen.copy(alpha = 0.15f),
                                border = androidx.compose.foundation.BorderStroke(
                                    0.5.dp,
                                    if (vehicle.isSimulated) CyberCyan else EmeraldGreen
                                )
                            ) {
                                Text(
                                    text = if (vehicle.isSimulated) "DEMO GPS" else "LIVE SATELLITE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (vehicle.isSimulated) CyberCyan else EmeraldGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 8.sp,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = "${vehicle.type.title} • ${vehicle.driverName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                val deliveryColor = when (vehicle.deliveryStatus) {
                    com.example.data.models.DeliveryStatus.ON_TIME -> EmeraldGreen
                    com.example.data.models.DeliveryStatus.DELAYED -> AmberWarning
                    com.example.data.models.DeliveryStatus.AT_RISK -> CrimsonAlert
                    com.example.data.models.DeliveryStatus.DELIVERED -> CyberCyan
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = deliveryColor.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, deliveryColor.copy(alpha = 0.6f))
                ) {
                    Text(
                        text = vehicle.deliveryStatus.label.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = deliveryColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            if (isDeviated) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = CrimsonAlert.copy(alpha = 0.12f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonAlert.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Deviation warning",
                            tint = CrimsonAlert,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ALERT: Convoy deviated by ${"%.1f".format(vehicle.deviationDistanceKm)} km from authorized corridor",
                            style = MaterialTheme.typography.labelSmall,
                            color = CrimsonAlert,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = CommandSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Cargo: ${vehicle.cargoDescription}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (vehicle.isEmergencyPriority) AmberWarning else TextSecondary,
                            fontWeight = if (vehicle.isEmergencyPriority) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "ETA: ${vehicle.etaMinutes} min",
                            style = MonospaceTelemetryStyle,
                            color = CyberCyan,
                            fontSize = 11.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${vehicle.originName} ➔ ${vehicle.destinationName} (${vehicle.activeRouteName})",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${vehicle.speedKmH} km/h • Elev: ${vehicle.altitudeMeters}m",
                    style = MonospaceTelemetryStyle,
                    color = TextTertiary,
                    fontSize = 10.sp
                )
                Text(
                    text = "Signal: ${vehicle.signalStatus}",
                    style = MaterialTheme.typography.labelSmall,
                    color = EmeraldGreen,
                    fontSize = 10.sp
                )
            }
        }
    }
}

/**
 * Route Candidate Comparison Card
 */
@Composable
fun RouteCandidateCard(
    candidate: RouteCandidate,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier,
    isSelected: Boolean = false,
    onViewDetails: (() -> Unit)? = null,
    onLaunchExternalNav: (() -> Unit)? = null,
    onOpenDetails: (() -> Unit)? = null
) {
    val isRecommended = candidate.isRecommended
    val isBlocked = candidate.isBlocked
    val actualOpenDetails = onViewDetails ?: onOpenDetails

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .semantics { contentDescription = "Route ${candidate.name}, score ${candidate.routeScore}, ${candidate.statusLabel}" },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = when {
                isSelected -> PureWhite
                isRecommended -> PureWhite
                isBlocked -> CrimsonAlert.copy(alpha = 0.05f)
                else -> PureWhite
            }
        ),
        border = androidx.compose.foundation.BorderStroke(
            if (isSelected) 2.dp else if (isRecommended) 1.5.dp else 1.dp,
            when {
                isSelected -> PrimaryBlue
                isRecommended -> EmeraldGreen
                isBlocked -> CrimsonAlert
                else -> BorderLight
            }
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Status Badge + Name + Route Score
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = when {
                                isRecommended -> EmeraldGreen.copy(alpha = 0.2f)
                                isBlocked -> CrimsonAlert.copy(alpha = 0.25f)
                                else -> CyberCyan.copy(alpha = 0.15f)
                            },
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                when {
                                    isRecommended -> EmeraldGreen
                                    isBlocked -> CrimsonAlert
                                    else -> CyberCyan.copy(alpha = 0.5f)
                                }
                            ),
                            modifier = Modifier.padding(end = 6.dp)
                        ) {
                            Text(
                                text = when {
                                    isRecommended -> "★ RECOMMENDED"
                                    isBlocked -> "⚠️ BLOCKED / AFFECTED"
                                    else -> candidate.statusLabel
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = when {
                                    isRecommended -> EmeraldGreen
                                    isBlocked -> CrimsonAlert
                                    else -> CyberCyan
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        Text(
                            text = candidate.name,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${candidate.corridorCode} • ${candidate.distanceKm} km",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "• ${candidate.dataSourceLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (candidate.isSimulatedData) AmberWarning else CyberCyan,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Transparent Route Score Badge (Lower is better)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when {
                        isRecommended -> EmeraldGreen.copy(alpha = 0.15f)
                        isBlocked -> CrimsonAlert.copy(alpha = 0.2f)
                        candidate.routeScore > 60 -> AmberWarning.copy(alpha = 0.15f)
                        else -> BlueInfo.copy(alpha = 0.15f)
                    },
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        when {
                            isRecommended -> EmeraldGreen
                            isBlocked -> CrimsonAlert
                            candidate.routeScore > 60 -> AmberWarning
                            else -> BlueInfo
                        }
                    )
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "ROUTE SCORE",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextTertiary,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${candidate.routeScore}",
                            style = MonospaceMetricValueStyle,
                            color = when {
                                isRecommended -> EmeraldGreen
                                isBlocked -> CrimsonAlert
                                candidate.routeScore > 60 -> AmberWarning
                                else -> TextPrimary
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = "LOWER = BETTER",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextTertiary,
                            fontSize = 7.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Key Metrics Row: ETA, Distance, Incidents
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CommandSurfaceElevated, RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "ESTIMATED TIME", style = MaterialTheme.typography.labelSmall, color = TextTertiary, fontSize = 9.sp)
                    Text(
                        text = "${candidate.estimatedDurationMin / 60}h ${candidate.estimatedDurationMin % 60}m",
                        style = MonospaceMetricValueStyle,
                        color = TextPrimary,
                        fontSize = 13.sp
                    )
                }
                Column {
                    Text(text = "DISTANCE", style = MaterialTheme.typography.labelSmall, color = TextTertiary, fontSize = 9.sp)
                    Text(
                        text = "${candidate.distanceKm} km",
                        style = MonospaceMetricValueStyle,
                        color = TextPrimary,
                        fontSize = 13.sp
                    )
                }
                Column {
                    Text(text = "CLIMB", style = MaterialTheme.typography.labelSmall, color = TextTertiary, fontSize = 9.sp)
                    Text(
                        text = "+${candidate.elevationGainM}m",
                        style = MonospaceMetricValueStyle,
                        color = AmberWarning,
                        fontSize = 13.sp
                    )
                }
                Column {
                    Text(text = "HAZARDS", style = MaterialTheme.typography.labelSmall, color = TextTertiary, fontSize = 9.sp)
                    Text(
                        text = if (isBlocked) "BLOCKED" else "${candidate.affectedIncidents.size} Active",
                        style = MonospaceMetricValueStyle,
                        color = if (isBlocked) CrimsonAlert else (if (candidate.affectedIncidents.isNotEmpty()) AmberWarning else EmeraldGreen),
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Transparent Factor Scoring Breakdown (30 / 25 / 20 / 15 / 10)
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                RiskSubMeter(label = "Disruption Risk (30%)", score = candidate.incidentRiskScore, color = if (candidate.incidentRiskScore > 70) CrimsonAlert else AmberWarning)
                RiskSubMeter(label = "Road Access Risk (25%)", score = candidate.accessibilityRiskScore, color = if (candidate.accessibilityRiskScore > 70) CrimsonAlert else CyberCyan)
                RiskSubMeter(label = "Weather Risk (20%)", score = candidate.weatherRiskScore, color = BlueInfo)
                RiskSubMeter(label = "ETA Delay Risk (15%)", score = candidate.etaRiskScore, color = TextSecondary)
                RiskSubMeter(label = "Distance Risk (10%)", score = candidate.distanceRiskScore, color = TextTertiary)
            }

            // Explainable Reason Boxes
            if (isRecommended && candidate.recommendationReason.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = EmeraldGreen.copy(alpha = 0.12f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldGreen.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = "WHY THIS ROUTE?",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = candidate.recommendationReason,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            } else if (!isRecommended && candidate.whyNotRecommended != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isBlocked) CrimsonAlert.copy(alpha = 0.12f) else CommandSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isBlocked) CrimsonAlert.copy(alpha = 0.4f) else CommandBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = "WHY NOT RECOMMENDED?",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isBlocked) CrimsonAlert else AmberWarning,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = candidate.whyNotRecommended ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }

            if (actualOpenDetails != null || onLaunchExternalNav != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (onLaunchExternalNav != null) {
                        Button(
                            onClick = onLaunchExternalNav,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldGreen,
                                contentColor = PureWhite
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Navigation,
                                contentDescription = "Navigate with Google Maps",
                                tint = PureWhite,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Google Maps",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = PureWhite
                            )
                        }
                    }

                    if (actualOpenDetails != null) {
                        OutlinedButton(
                            onClick = actualOpenDetails,
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = PrimaryBlue
                            ),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "View Details",
                                tint = PrimaryBlue,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Audit Details",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = PrimaryBlue
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RiskSubMeter(label: String, score: Int, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
            fontSize = 9.sp
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            LinearProgressIndicator(
                progress = { score / 100f },
                modifier = Modifier
                    .width(60.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = color,
                trackColor = CommandBorder
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "$score%",
                style = MonospaceTelemetryStyle,
                color = color,
                fontSize = 9.sp
            )
        }
    }
}

/**
 * Command Center Radar Loading Sweep Animation
 */
@Composable
fun TacticalLoadingRadar(
    label: String = "Scanning Satellite & Mesh Corridors...",
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "radar")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(CommandSurfaceElevated)
                .border(1.dp, CommandBorder, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(54.dp)) {
                drawCircle(color = CyberCyan.copy(alpha = 0.2f), style = Stroke(1.dp.toPx()))
                drawCircle(color = CyberCyan.copy(alpha = 0.4f), radius = size.minDimension / 4f, style = Stroke(1.dp.toPx()))

                val center = Offset(size.width / 2f, size.height / 2f)
                val rad = Math.toRadians(rotation.toDouble())
                val target = Offset(
                    (center.x + (size.width / 2f) * Math.cos(rad)).toFloat(),
                    (center.y + (size.height / 2f) * Math.sin(rad)).toFloat()
                )
                drawLine(
                    color = CyberCyan,
                    start = center,
                    end = target,
                    strokeWidth = 2.dp.toPx()
                )
            }
            Icon(
                imageVector = Icons.Default.Radar,
                contentDescription = "Radar loading",
                tint = CyberCyan,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            fontSize = 12.sp
        )
    }
}

/**
 * Tactical Command Center Empty State Component
 */
@Composable
fun TacticalEmptyState(
    title: String,
    subtitle: String,
    icon: ImageVector = Icons.Default.Radar,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(CommandSurfaceElevated)
                .border(1.dp, CommandBorder, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = "$title empty state",
                tint = TextTertiary,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            fontSize = 11.sp
        )
        if (actionLabel != null && onAction != null) {
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedButton(
                onClick = onAction,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan)
            ) {
                Text(text = actionLabel, color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * Tactical Error Callout Banner with Retry Action
 */
@Composable
fun TacticalErrorBanner(
    errorMessage: String,
    onRetry: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(8.dp),
        color = CrimsonAlert.copy(alpha = 0.12f),
        border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonAlert.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.ErrorOutline,
                    contentDescription = "Diagnostic error",
                    tint = CrimsonAlert,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimary,
                    fontSize = 11.sp
                )
            }
            if (onRetry != null) {
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert, contentColor = Color.White),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Text("Retry", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
