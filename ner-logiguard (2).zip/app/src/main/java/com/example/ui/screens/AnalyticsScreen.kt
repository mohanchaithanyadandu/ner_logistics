package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.SystemAuditLog
import com.example.ui.components.SectionHeader
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BlueInfo
import com.example.ui.theme.CommandBorder
import com.example.ui.theme.CommandBorderSubtle
import com.example.ui.theme.CommandCard
import com.example.ui.theme.CommandSurface
import com.example.ui.theme.CommandSurfaceElevated
import com.example.ui.theme.CommandSurfaceVariant
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.MonospaceMetricValueStyle
import com.example.ui.theme.MonospaceTelemetryStyle
import com.example.ui.theme.ObsidianDarkBackground
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.viewmodel.NERLogisticsViewModel

@Composable
fun AnalyticsScreen(
    viewModel: NERLogisticsViewModel,
    modifier: Modifier = Modifier
) {
    val auditLogs by viewModel.recentAuditLogs.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            SectionHeader(
                title = "Logistics Accessibility Analytics",
                subtitle = "Historical corridor vulnerability, terrain models & system audit trace"
            )
        }

        // Corridor Risk Ranking Breakdown
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CommandCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CommandBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "NORTH EAST CORRIDOR HAZARD DENSITY",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    AnalyticsBar(label = "NH-6 Shillong-Silchar (Sonapur)", score = 78, color = CrimsonAlert)
                    AnalyticsBar(label = "NH-13 Trans-Arunachal (Sela Pass)", score = 62, color = AmberWarning)
                    AnalyticsBar(label = "NH-37 Silchar-Imphal (Makru Ghat)", score = 58, color = AmberWarning)
                    AnalyticsBar(label = "NH-10 Siliguri-Gangtok (Teesta)", score = 54, color = AmberWarning)
                    AnalyticsBar(label = "NH-29 Dimapur-Kohima 4-Lane", score = 32, color = EmeraldGreen)
                    AnalyticsBar(label = "NH-27 East-West Expressway", score = 18, color = EmeraldGreen)
                }
            }
        }

        // Seasonal Impact Model
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CommandCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CommandBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "MONSOON LOGISTICS RESILIENCE METRICS",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldGreen,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Fleet On-Time Delivery", style = MaterialTheme.typography.labelSmall, color = TextTertiary)
                            Text("91.2%", style = MonospaceMetricValueStyle, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        }
                        Column {
                            Text("Reroute Prevention Gain", style = MaterialTheme.typography.labelSmall, color = TextTertiary)
                            Text("+3.8 hrs/trip", style = MonospaceMetricValueStyle, color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        }
                        Column {
                            Text("Disaster Stoppages", style = MaterialTheme.typography.labelSmall, color = TextTertiary)
                            Text("-64%", style = MonospaceMetricValueStyle, color = EmeraldGreen, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        }
                    }
                }
            }
        }

        // Room Database Audit Logs Feed
        item {
            SectionHeader(
                title = "Local Cryptographic Audit Trail (${auditLogs.size})",
                subtitle = "Tamper-evident logs of all command actions, dispatches & syncs"
            )
        }

        items(auditLogs) { log ->
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                AuditLogItemCard(log = log)
            }
        }
    }
}

@Composable
private fun AnalyticsBar(label: String, score: Int, color: Color) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontSize = 11.sp)
            Text("$score% Risk", style = MonospaceTelemetryStyle, color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { score / 100f },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = color,
            trackColor = CommandBorder
        )
    }
}

@Composable
private fun AuditLogItemCard(log: SystemAuditLog) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CommandCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CommandBorder)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(CyberCyan.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Security, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(14.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = log.action,
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = log.role.displayName,
                        style = MonospaceTelemetryStyle,
                        color = TextTertiary,
                        fontSize = 10.sp
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = log.details,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
    }
}
