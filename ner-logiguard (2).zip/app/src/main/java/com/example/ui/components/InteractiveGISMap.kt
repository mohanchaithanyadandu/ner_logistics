package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Thunderstorm
import androidx.compose.material3.Badge
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.LiveVehicle
import com.example.data.models.LocationPoint
import com.example.data.models.RoadIncident
import com.example.data.models.RouteCandidate
import com.example.engine.RouteOptimizer
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun InteractiveGISMap(
    vehicles: List<LiveVehicle>,
    incidents: List<RoadIncident>,
    candidates: List<RouteCandidate> = emptyList(),
    selectedRouteId: String? = null,
    originPoint: LocationPoint? = null,
    destinationPoint: LocationPoint? = null,
    selectedVehicleId: String? = null,
    onVehicleSelect: ((LiveVehicle) -> Unit)? = null,
    onHubSelect: ((LocationPoint) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var showWeatherRadar by remember { mutableStateOf(true) }
    var showIncidents by remember { mutableStateOf(true) }
    var showVehicles by remember { mutableStateOf(true) }
    var showHighways by remember { mutableStateOf(true) }
    var showRouteLines by remember { mutableStateOf(true) }

    var selectedItemInfo by remember { mutableStateOf<String?>(null) }
    var selectedItemTitle by remember { mutableStateOf<String?>(null) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAnim by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "radarPulse"
    )

    val textMeasurer = rememberTextMeasurer()

    // Dynamic Bounding Box calculation:
    // If candidates or custom origin/destination points are provided, expand bounds to include them across India
    val allLats = mutableListOf<Double>()
    val allLngs = mutableListOf<Double>()

    originPoint?.let { allLats.add(it.latitude); allLngs.add(it.longitude) }
    destinationPoint?.let { allLats.add(it.latitude); allLngs.add(it.longitude) }
    candidates.forEach { cand ->
        cand.polylineCoordinates.forEach { (lat, lng) ->
            allLats.add(lat)
            allLngs.add(lng)
        }
    }

    val (minLat, maxLat, minLng, maxLng) = if (allLats.isNotEmpty() && allLngs.isNotEmpty()) {
        val rawMinLat = allLats.minOrNull() ?: 23.0
        val rawMaxLat = allLats.maxOrNull() ?: 28.5
        val rawMinLng = allLngs.minOrNull() ?: 88.0
        val rawMaxLng = allLngs.maxOrNull() ?: 96.0
        val latSpan = (rawMaxLat - rawMinLat).coerceAtLeast(1.2)
        val lngSpan = (rawMaxLng - rawMinLng).coerceAtLeast(1.5)
        val padLat = latSpan * 0.16
        val padLng = lngSpan * 0.16
        listOf(rawMinLat - padLat, rawMaxLat + padLat, rawMinLng - padLng, rawMaxLng + padLng)
    } else {
        listOf(23.0, 28.5, 88.0, 96.0)
    }

    fun latLngToScreen(lat: Double, lng: Double, width: Float, height: Float): Offset {
        val x = ((lng - minLng) / (maxLng - minLng)).toFloat() * (width - 40f) + 20f
        // Invert Y because latitude increases upwards
        val y = (1.0f - ((lat - minLat) / (maxLat - minLat)).toFloat()) * (height - 60f) + 30f
        return Offset(x.coerceIn(10f, width - 10f), y.coerceIn(10f, height - 10f))
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFFF1F5F9))
            .border(1.dp, LightBorder, RoundedCornerShape(16.dp))
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { tapOffset ->
                        // Check if tapped on any hub
                        val hitHub = RouteOptimizer.HUBS.find { hub ->
                            val pt = latLngToScreen(hub.latitude, hub.longitude, size.width.toFloat(), size.height.toFloat())
                            (tapOffset - pt).getDistance() < 30f
                        }
                        if (hitHub != null) {
                            selectedItemTitle = "Hub: ${hitHub.name}"
                            selectedItemInfo = "State: ${hitHub.state.fullName} | Elev: ${hitHub.altitudeMeters}m\nTerrain: ${hitHub.terrainType.label}"
                            onHubSelect?.invoke(hitHub)
                            return@detectTapGestures
                        }

                        // Check if tapped on any vehicle
                        val hitVeh = vehicles.find { v ->
                            val pt = latLngToScreen(v.currentLat, v.currentLng, size.width.toFloat(), size.height.toFloat())
                            (tapOffset - pt).getDistance() < 35f
                        }
                        if (hitVeh != null) {
                            selectedItemTitle = "Fleet: ${hitVeh.vehicleNumber} (${hitVeh.type.title})"
                            selectedItemInfo = "Driver: ${hitVeh.driverName} | Speed: ${hitVeh.speedKmH} km/h\nRoute: ${hitVeh.activeRouteName}\nSignal: ${hitVeh.signalStatus}"
                            onVehicleSelect?.invoke(hitVeh)
                            return@detectTapGestures
                        }

                        // Check if tapped on any incident
                        val hitInc = incidents.find { inc ->
                            val pt = latLngToScreen(inc.latitude, inc.longitude, size.width.toFloat(), size.height.toFloat())
                            (tapOffset - pt).getDistance() < 30f
                        }
                        if (hitInc != null) {
                            selectedItemTitle = "Hazard: ${hitInc.title}"
                            selectedItemInfo = "Severity: ${hitInc.severity.label}\nStatus: ${hitInc.status.label}\nClearance ETA: ~${hitInc.clearanceEtaHours}h"
                            return@detectTapGestures
                        }

                        selectedItemTitle = null
                        selectedItemInfo = null
                    }
                }
        ) {
            val width = size.width
            val height = size.height

            // 1. Draw Subtle Topography Grid
            val gridSpacing = 50f
            var gx = 0f
            while (gx < width) {
                drawLine(
                    color = Color(0xFF131F37),
                    start = Offset(gx, 0f),
                    end = Offset(gx, height),
                    strokeWidth = 1f
                )
                gx += gridSpacing
            }
            var gy = 0f
            while (gy < height) {
                drawLine(
                    color = Color(0xFF131F37),
                    start = Offset(0f, gy),
                    end = Offset(width, gy),
                    strokeWidth = 1f
                )
                gy += gridSpacing
            }

            // 2. Draw Brahmaputra River Basin Flow
            val riverPath = Path().apply {
                val p1 = latLngToScreen(27.8, 95.8, width, height)
                val p2 = latLngToScreen(27.4, 94.9, width, height)
                val p3 = latLngToScreen(26.6, 92.8, width, height)
                val p4 = latLngToScreen(26.1, 91.7, width, height)
                val p5 = latLngToScreen(25.9, 89.9, width, height)
                moveTo(p1.x, p1.y)
                cubicTo(p2.x, p2.y, p3.x, p3.y, p4.x, p4.y)
                lineTo(p5.x, p5.y)
            }
            drawPath(
                path = riverPath,
                color = Color(0xFF1B4965).copy(alpha = 0.6f),
                style = Stroke(width = 9f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            // 3. Draw National Highway Corridors
            if (showHighways) {
                drawCorridor(
                    listOf("GHY", "TZP", "BDL", "TWG"),
                    CyberCyan.copy(alpha = 0.85f),
                    width,
                    height,
                    isDashed = false
                )
                drawCorridor(
                    listOf("GHY", "SHL", "SLR", "AGT"),
                    AmberWarning.copy(alpha = 0.85f),
                    width,
                    height,
                    isDashed = false
                )
                drawCorridor(
                    listOf("GHY", "HFL", "SLR"),
                    EmeraldGreen.copy(alpha = 0.95f),
                    width,
                    height,
                    isDashed = false
                )
                drawCorridor(
                    listOf("SLR", "IMP"),
                    Color(0xFF8338EC).copy(alpha = 0.85f),
                    width,
                    height,
                    isDashed = false
                )
                drawCorridor(
                    listOf("GHY", "DMP", "KHM"),
                    CyberCyan.copy(alpha = 0.85f),
                    width,
                    height,
                    isDashed = false
                )
            }

            // 4. Draw Weather Hazard Radar Zones
            if (showWeatherRadar) {
                // Meghalaya Rain Cloud Zone
                val meghalayaPt = latLngToScreen(25.5, 91.8, width, height)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF3A86FF).copy(alpha = 0.35f * pulseAnim), Color.Transparent),
                        center = meghalayaPt,
                        radius = 80f
                    ),
                    center = meghalayaPt,
                    radius = 80f
                )

                // High Altitude Snow / Fog Zone around Tawang
                val tawangPt = latLngToScreen(27.5, 91.9, width, height)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF00E5FF).copy(alpha = 0.3f * pulseAnim), Color.Transparent),
                        center = tawangPt,
                        radius = 65f
                    ),
                    center = tawangPt,
                    radius = 65f
                )
            }

            // 5. Draw Hub Nodes
            RouteOptimizer.HUBS.forEach { hub ->
                val pt = latLngToScreen(hub.latitude, hub.longitude, width, height)
                val hubColor = when (hub.state.name) {
                    "ASSAM" -> CyberCyan
                    "MEGHALAYA" -> EmeraldGreen
                    "ARUNACHAL_PRADESH" -> AmberWarning
                    else -> Color(0xFF90E0EF)
                }

                drawCircle(
                    color = hubColor.copy(alpha = 0.3f),
                    radius = 12f,
                    center = pt
                )
                drawCircle(
                    color = hubColor,
                    radius = 6f,
                    center = pt
                )
                drawCircle(
                    color = Color.White,
                    radius = 2.5f,
                    center = pt
                )

                // Draw small label
                val textLayout = textMeasurer.measure(
                    text = hub.id,
                    style = TextStyle(
                        color = TextPrimary.copy(alpha = 0.85f),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
                drawText(
                    textLayoutResult = textLayout,
                    topLeft = Offset(pt.x + 8f, pt.y - 6f)
                )
            }

            // 6. Draw Incidents
            if (showIncidents) {
                incidents.forEach { inc ->
                    val pt = latLngToScreen(inc.latitude, inc.longitude, width, height)
                    val color = when (inc.severity.name) {
                        "CRITICAL_BLOCKAGE" -> CrimsonAlert
                        "MODERATE" -> AmberWarning
                        else -> Color(0xFFFB8500)
                    }

                    // Pulsing hazard ring
                    drawCircle(
                        color = color.copy(alpha = 0.45f * pulseAnim),
                        radius = 20f * pulseAnim,
                        center = pt
                    )
                    drawCircle(
                        color = color,
                        radius = 8f,
                        center = pt
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 3f,
                        center = pt
                    )
                }
            }

            // 7. Draw Live Vehicles
            if (showVehicles) {
                vehicles.forEach { v ->
                    val pt = latLngToScreen(v.currentLat, v.currentLng, width, height)
                    val isSelected = v.id == selectedVehicleId
                    val vehColor = when (v.status.name) {
                        "REROUTING" -> CyberCyan
                        "DELAYED_RISK" -> AmberWarning
                        "EMERGENCY_STOP" -> CrimsonAlert
                        else -> EmeraldGreen
                    }

                    if (isSelected) {
                        drawCircle(
                            color = CyberCyan.copy(alpha = 0.6f),
                            radius = 22f,
                            center = pt,
                            style = Stroke(width = 3f)
                        )
                    }

                    // Outer halo
                    drawCircle(
                        color = vehColor.copy(alpha = 0.4f),
                        radius = 14f,
                        center = pt
                    )
                    // Core icon circle
                    drawCircle(
                        color = vehColor,
                        radius = 8f,
                        center = pt
                    )

                    // Direction vector pointer
                    val rad = Math.toRadians(v.headingDegrees.toDouble() - 90.0)
                    val arrowEnd = Offset(
                        pt.x + (15f * cos(rad)).toFloat(),
                        pt.y + (15f * sin(rad)).toFloat()
                    )
                    drawLine(
                        color = Color.White,
                        start = pt,
                        end = arrowEnd,
                        strokeWidth = 3f,
                        cap = StrokeCap.Round
                    )
                }
            }

            // 8. Draw Route Candidates & Selected Route Polylines
            if (showRouteLines && candidates.isNotEmpty()) {
                val recommendedRoute = candidates.find { it.isRecommended } ?: candidates.firstOrNull()
                val activeRoute = candidates.find { it.id == selectedRouteId } ?: recommendedRoute

                // First pass: Draw alternative non-selected routes
                candidates.forEach { route ->
                    if (route.id != activeRoute?.id && route.polylineCoordinates.size >= 2) {
                        val routePts: List<Offset> = route.polylineCoordinates.map { coord ->
                            latLngToScreen(coord.first, coord.second, width, height)
                        }
                        if (routePts.size >= 2) {
                            val path = Path().apply {
                                moveTo(routePts.first().x, routePts.first().y)
                                for (i in 1 until routePts.size) {
                                    val pt = routePts[i]
                                    lineTo(pt.x, pt.y)
                                }
                            }
                            val strokeColor = if (route.isBlocked) CrimsonAlert else Color(0xFF2563EB).copy(alpha = 0.75f)
                            drawPath(
                                path = path,
                                color = strokeColor,
                                style = Stroke(
                                    width = 5f,
                                    cap = StrokeCap.Round,
                                    join = StrokeJoin.Round,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 8f), 0f)
                                )
                            )
                        }
                    }
                }

                // Second pass: Draw selected/recommended route on top
                activeRoute?.let { route ->
                    if (route.polylineCoordinates.size >= 2) {
                        val routePts: List<Offset> = route.polylineCoordinates.map { coord ->
                            latLngToScreen(coord.first, coord.second, width, height)
                        }
                        if (routePts.size >= 2) {
                            val path = Path().apply {
                                moveTo(routePts.first().x, routePts.first().y)
                                for (i in 1 until routePts.size) {
                                    val pt = routePts[i]
                                    lineTo(pt.x, pt.y)
                                }
                            }

                            // Outer casing shadow for contrast
                            drawPath(
                                path = path,
                                color = Color(0xFF0F172A).copy(alpha = 0.55f),
                                style = Stroke(
                                    width = 11f,
                                    cap = StrokeCap.Round,
                                    join = StrokeJoin.Round
                                )
                            )

                            // Core active vector line
                            val coreColor = when {
                                route.isBlocked -> CrimsonAlert
                                route.routeScore > 60 -> AmberWarning
                                else -> EmeraldGreen
                            }
                            drawPath(
                                path = path,
                                color = coreColor,
                                style = Stroke(
                                    width = 6.5f,
                                    cap = StrokeCap.Round,
                                    join = StrokeJoin.Round
                                )
                            )
                        }
                    }
                }
            }

            // 9. Draw Origin and Destination Pins
            val startLoc: LocationPoint? = originPoint ?: candidates.firstOrNull()?.let { cand ->
                cand.polylineCoordinates.firstOrNull()?.let { (lat, lng) ->
                    LocationPoint(id = "ORIG", name = cand.origin.name, state = cand.origin.state, latitude = lat, longitude = lng)
                }
            }
            val endLoc: LocationPoint? = destinationPoint ?: candidates.firstOrNull()?.let { cand ->
                cand.polylineCoordinates.lastOrNull()?.let { (lat, lng) ->
                    LocationPoint(id = "DEST", name = cand.destination.name, state = cand.destination.state, latitude = lat, longitude = lng)
                }
            }

            if (startLoc != null) {
                val startPt = latLngToScreen(startLoc.latitude, startLoc.longitude, width, height)
                // Pulsing origin ring
                drawCircle(
                    color = SafeGreen.copy(alpha = 0.35f * pulseAnim),
                    radius = 24f * pulseAnim,
                    center = startPt
                )
                // Origin pin body
                drawCircle(color = Color.White, radius = 11f, center = startPt)
                drawCircle(color = SafeGreen, radius = 8f, center = startPt)
                drawCircle(color = Color.White, radius = 3f, center = startPt)

                // Text badge
                val originBadge = textMeasurer.measure(
                    text = "ORIGIN: ${startLoc.name.take(14)}",
                    style = TextStyle(color = Color(0xFF065F46), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                )
                drawText(originBadge, topLeft = Offset(startPt.x + 12f, startPt.y - 14f))
            }

            if (endLoc != null) {
                val endPt = latLngToScreen(endLoc.latitude, endLoc.longitude, width, height)
                // Pulsing destination ring
                drawCircle(
                    color = CriticalRed.copy(alpha = 0.35f * pulseAnim),
                    radius = 24f * pulseAnim,
                    center = endPt
                )
                // Destination pin body
                drawCircle(color = Color.White, radius = 11f, center = endPt)
                drawCircle(color = CriticalRed, radius = 8f, center = endPt)
                drawCircle(color = Color.White, radius = 3f, center = endPt)

                // Text badge
                val destBadge = textMeasurer.measure(
                    text = "DEST: ${endLoc.name.take(14)}",
                    style = TextStyle(color = Color(0xFF991B1B), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                )
                drawText(destBadge, topLeft = Offset(endPt.x + 12f, endPt.y - 14f))
            }
        }

        // Top Layer Control Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = LightCardWhite.copy(alpha = 0.95f),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, LightBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = "GIS Layers",
                        tint = ProfessionalBlue,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "NER HIGHWAYS GIS",
                        style = MaterialTheme.typography.labelSmall,
                        color = ProfessionalBlue,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (candidates.isNotEmpty()) {
                    GISFilterPill(
                        label = "Routes",
                        isActive = showRouteLines,
                        color = ProfessionalBlue,
                        onToggle = { showRouteLines = !showRouteLines }
                    )
                }
                GISFilterPill(
                    label = "Fleet",
                    isActive = showVehicles,
                    color = SafeGreen,
                    onToggle = { showVehicles = !showVehicles }
                )
                GISFilterPill(
                    label = "Hazards",
                    isActive = showIncidents,
                    color = CriticalRed,
                    onToggle = { showIncidents = !showIncidents }
                )
                GISFilterPill(
                    label = "Weather",
                    isActive = showWeatherRadar,
                    color = ProfessionalBlue,
                    onToggle = { showWeatherRadar = !showWeatherRadar }
                )
            }
        }

        // Active Route Overlay Summary Card (Top Right / Center)
        val activeRoute = candidates.find { it.id == selectedRouteId } ?: candidates.firstOrNull { it.isRecommended } ?: candidates.firstOrNull()
        if (activeRoute != null && showRouteLines) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 46.dp, end = 8.dp),
                shape = RoundedCornerShape(8.dp),
                color = PureWhite.copy(alpha = 0.95f),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
                shadowElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(if (activeRoute.isBlocked) CriticalRed else SuccessGreen)
                    )
                    val durH = activeRoute.estimatedDurationMin / 60
                    val durM = activeRoute.estimatedDurationMin % 60
                    Text(
                        text = "${activeRoute.distanceKm.toInt()} km • ${durH}h ${durM}m",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                    Text(
                        text = "Score: ${activeRoute.routeScore}/100",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (activeRoute.routeScore > 60) WarningAmber else SuccessGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                }
            }
        }

        // Clean Bottom Legend Bar
        Surface(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(8.dp),
            shape = RoundedCornerShape(6.dp),
            color = LightCardWhite.copy(alpha = 0.94f),
            border = androidx.compose.foundation.BorderStroke(0.8.dp, LightBorder)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🟢", fontSize = 9.sp)
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(text = "ORIGIN/SAFE", style = MaterialTheme.typography.labelSmall, color = TextGray, fontSize = 8.sp, fontWeight = FontWeight.SemiBold)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🔴", fontSize = 9.sp)
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(text = "DEST/ALERT", style = MaterialTheme.typography.labelSmall, color = TextGray, fontSize = 8.sp, fontWeight = FontWeight.SemiBold)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "═", fontSize = 10.sp, color = ProfessionalBlue, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(text = "ROUTE", style = MaterialTheme.typography.labelSmall, color = TextGray, fontSize = 8.sp, fontWeight = FontWeight.SemiBold)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🚚", fontSize = 9.sp)
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(text = "VEHICLE", style = MaterialTheme.typography.labelSmall, color = TextGray, fontSize = 8.sp, fontWeight = FontWeight.SemiBold)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "⚠", fontSize = 9.sp)
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(text = "INCIDENT", style = MaterialTheme.typography.labelSmall, color = TextGray, fontSize = 8.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // Selected Entity Info Overlay (If tapped)
        if (selectedItemTitle != null) {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(8.dp),
                shape = RoundedCornerShape(10.dp),
                color = LightCardWhite,
                border = androidx.compose.foundation.BorderStroke(1.dp, ProfessionalBlue.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = selectedItemTitle ?: "",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextDarkCharcoal,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = selectedItemInfo ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextGray,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(
                        onClick = {
                            selectedItemTitle = null
                            selectedItemInfo = null
                        },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextGray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawCorridor(
    hubIds: List<String>,
    color: Color,
    width: Float,
    height: Float,
    isDashed: Boolean
) {
    val minLat = 23.0
    val maxLat = 28.5
    val minLng = 88.0
    val maxLng = 96.0

    fun toScreen(lat: Double, lng: Double): Offset {
        val x = ((lng - minLng) / (maxLng - minLng)).toFloat() * (width - 40f) + 20f
        val y = (1.0f - ((lat - minLat) / (maxLat - minLat)).toFloat()) * (height - 60f) + 30f
        return Offset(x.coerceIn(10f, width - 10f), y.coerceIn(10f, height - 10f))
    }

    val pts = hubIds.mapNotNull { id ->
        RouteOptimizer.HUBS.find { it.id == id }?.let { toScreen(it.latitude, it.longitude) }
    }

    if (pts.size >= 2) {
        val path = Path().apply {
            moveTo(pts.first().x, pts.first().y)
            for (i in 1 until pts.size) {
                lineTo(pts[i].x, pts[i].y)
            }
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(
                width = 4f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round,
                pathEffect = if (isDashed) PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f) else null
            )
        )
    }
}

@Composable
private fun GISFilterPill(
    label: String,
    isActive: Boolean,
    color: Color,
    onToggle: () -> Unit
) {
    Surface(
        onClick = onToggle,
        shape = RoundedCornerShape(16.dp),
        color = if (isActive) color.copy(alpha = 0.12f) else LightCardWhite,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isActive) color else LightBorder
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(if (isActive) color else TextGray)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = if (isActive) TextDarkCharcoal else TextGray,
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                fontSize = 10.sp
            )
        }
    }
}
