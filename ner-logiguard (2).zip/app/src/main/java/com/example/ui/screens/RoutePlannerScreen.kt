package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.LocationPoint
import com.example.data.models.NERState
import com.example.data.models.RiskLevel
import com.example.data.models.RouteCandidate
import com.example.data.remote.GeocodingResult
import com.example.engine.RouteOptimizer
import com.example.ui.components.InteractiveGISMap
import com.example.ui.components.LeafletMapView
import com.example.ui.components.RouteCandidateCard
import com.example.ui.components.RouteDetailsDialog
import com.example.ui.components.SectionHeader
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CriticalRedBg
import com.example.ui.theme.CriticalRedBorder
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.InfoBlueBg
import com.example.ui.theme.InfoBlueBorder
import com.example.ui.theme.OffWhiteBackground
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryBlueBorder
import com.example.ui.theme.PrimaryBlueLight
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RiskOrange
import com.example.ui.theme.RiskOrangeBg
import com.example.ui.theme.RiskOrangeBorder
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenBg
import com.example.ui.theme.SuccessGreenBorder
import com.example.ui.theme.SurfaceSubtle
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberBg
import com.example.ui.theme.WarningAmberBorder
import com.example.ui.viewmodel.NERLogisticsViewModel
import com.example.util.ExternalNavigationLauncher

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutePlannerScreen(
    viewModel: NERLogisticsViewModel,
    modifier: Modifier = Modifier
) {
    val origin by viewModel.selectedOrigin.collectAsState()
    val destination by viewModel.selectedDestination.collectAsState()
    val candidates by viewModel.routeCandidates.collectAsState()
    val selectedRouteId by viewModel.selectedRouteId.collectAsState()
    val incidents by viewModel.allIncidents.collectAsState()
    val vehicles by viewModel.allVehicles.collectAsState()

    val originQuery by viewModel.originSearchQuery.collectAsState()
    val destinationQuery by viewModel.destinationSearchQuery.collectAsState()
    val originSuggestions by viewModel.originSuggestions.collectAsState()
    val destinationSuggestions by viewModel.destinationSuggestions.collectAsState()
    val isSearchingOrigin by viewModel.isSearchingOrigin.collectAsState()
    val isSearchingDestination by viewModel.isSearchingDestination.collectAsState()

    val isCalculating by viewModel.isCalculatingRoutes.collectAsState()
    val calculationMessage by viewModel.routeCalculationMessage.collectAsState()
    val calculationError by viewModel.routeCalculationError.collectAsState()
    val rerouteExplanation by viewModel.lastRecommendationChangeExplanation.collectAsState()

    var activeRouteForDetails by remember { mutableStateOf<RouteCandidate?>(null) }
    var useLeafletMap by remember { mutableStateOf(false) }

    val recommendedRoute = candidates.find { it.isRecommended } ?: candidates.firstOrNull()
    val selectedCandidate = candidates.find { it.id == selectedRouteId } ?: recommendedRoute

    val context = LocalContext.current

    // Popular Quick Indian Hub Presets
    val quickHubs = listOf(
        Pair("Guwahati", "GHY"),
        Pair("Silchar", "SLR"),
        Pair("Shillong", "SHL"),
        Pair("Tawang", "TWG"),
        Pair("Delhi", "DEL"),
        Pair("Mumbai", "BOM"),
        Pair("Bengaluru", "BLR"),
        Pair("Kolkata", "CCU"),
        Pair("Jaipur", "JAI"),
        Pair("Hyderabad", "HYD")
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OffWhiteBackground),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Section Header
        item {
            SectionHeader(
                title = "Transparent Route Intelligence Engine",
                subtitle = "India-wide multi-candidate routing & deterministic disaster risk analysis"
            )
        }

        // Provenance Transparency Badge
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 2.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = PureWhite,
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "EVALUATION ENGINE: Disruption (30%) + Road Access (25%) + Weather (20%) + ETA (15%) + Distance (10%). Lower score = safest practical route.",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }

        // Origin & Destination Search Panel
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "PLAN TRANSIT CORRIDOR (ANY INDIA LOCATION)",
                        style = MaterialTheme.typography.labelSmall,
                        color = PrimaryBlue,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Origin Search Field
                    Column {
                        OutlinedTextField(
                            value = originQuery,
                            onValueChange = { viewModel.searchOrigin(it) },
                            label = { Text("Origin (City, Hub, or Landmark)") },
                            leadingIcon = {
                                Icon(Icons.Default.LocationOn, contentDescription = "Origin", tint = PrimaryBlue)
                            },
                            trailingIcon = {
                                if (isSearchingOrigin) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = PrimaryBlue)
                                } else if (originQuery.isNotBlank()) {
                                    IconButton(onClick = { viewModel.clearOriginSearch() }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary, modifier = Modifier.size(18.dp))
                                    }
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PrimaryBlue,
                                unfocusedBorderColor = BorderLight,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedContainerColor = SurfaceSubtle,
                                unfocusedContainerColor = PureWhite
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("origin_location_input"),
                            singleLine = true
                        )

                        // Origin Search Suggestions Dropdown/List
                        AnimatedVisibility(
                            visible = originSuggestions.isNotEmpty(),
                            enter = fadeIn(),
                            exit = fadeOut()
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = PureWhite,
                                border = BorderStroke(1.dp, PrimaryBlueBorder),
                                shadowElevation = 4.dp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(4.dp)) {
                                    originSuggestions.forEach { result ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { viewModel.selectOriginResult(result) }
                                                .padding(horizontal = 10.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(
                                                    text = result.name,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = TextPrimary,
                                                    fontWeight = FontWeight.SemiBold,
                                                    fontSize = 13.sp
                                                )
                                                Text(
                                                    text = "${result.state} • ${result.displayName}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = TextSecondary,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                        HorizontalDivider(color = BorderSubtle)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Swap Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        IconButton(
                            onClick = { viewModel.swapOriginAndDestination() },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(SurfaceSubtle)
                                .border(1.dp, BorderLight, RoundedCornerShape(8.dp))
                                .testTag("swap_locations_btn")
                        ) {
                            Icon(Icons.Default.SwapVert, contentDescription = "Swap Origin and Destination", tint = PrimaryBlue)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Destination Search Field
                    Column {
                        OutlinedTextField(
                            value = destinationQuery,
                            onValueChange = { viewModel.searchDestination(it) },
                            label = { Text("Destination (City, Hub, or Landmark)") },
                            leadingIcon = {
                                Icon(Icons.Default.Navigation, contentDescription = "Destination", tint = SuccessGreen)
                            },
                            trailingIcon = {
                                if (isSearchingDestination) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = SuccessGreen)
                                } else if (destinationQuery.isNotBlank()) {
                                    IconButton(onClick = { viewModel.clearDestinationSearch() }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary, modifier = Modifier.size(18.dp))
                                    }
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SuccessGreen,
                                unfocusedBorderColor = BorderLight,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedContainerColor = SurfaceSubtle,
                                unfocusedContainerColor = PureWhite
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("destination_location_input"),
                            singleLine = true
                        )

                        // Destination Search Suggestions Dropdown/List
                        AnimatedVisibility(
                            visible = destinationSuggestions.isNotEmpty(),
                            enter = fadeIn(),
                            exit = fadeOut()
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = PureWhite,
                                border = BorderStroke(1.dp, SuccessGreenBorder),
                                shadowElevation = 4.dp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(4.dp)) {
                                    destinationSuggestions.forEach { result ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { viewModel.selectDestinationResult(result) }
                                                .padding(horizontal = 10.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.Navigation, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(
                                                    text = result.name,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = TextPrimary,
                                                    fontWeight = FontWeight.SemiBold,
                                                    fontSize = 13.sp
                                                )
                                                Text(
                                                    text = "${result.state} • ${result.displayName}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = TextSecondary,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                        HorizontalDivider(color = BorderSubtle)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick Indian Hub Presets Row
                    Text(
                        text = "Quick Hub Presets:",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        quickHubs.forEach { (name, hubId) ->
                            val hub = RouteOptimizer.getLocationById(hubId)
                            Surface(
                                onClick = {
                                    if (originQuery.isBlank() || origin.id == hub.id) {
                                        viewModel.setOrigin(hub)
                                    } else {
                                        viewModel.setDestination(hub)
                                    }
                                },
                                shape = RoundedCornerShape(6.dp),
                                color = SurfaceSubtle,
                                border = BorderStroke(1.dp, BorderLight)
                            ) {
                                Text(
                                    text = name,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // FIND BEST ROUTE BUTTON
                    Button(
                        onClick = { viewModel.findBestRoute() },
                        enabled = !isCalculating,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PrimaryBlue,
                            contentColor = PureWhite
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("find_best_route_button")
                    ) {
                        if (isCalculating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = PureWhite,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = calculationMessage ?: "CALCULATING CORRIDORS...",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "SEARCH SAFEST ROUTE",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }

                    // Calculation Error Message Banner
                    if (calculationError != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = CriticalRedBg,
                            border = BorderStroke(1.dp, CriticalRedBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = CriticalRed, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = calculationError ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CriticalRed,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Dynamic Re-Routing Explanation Card (If a simulated hazard occurred)
        if (rerouteExplanation != null) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = WarningAmberBg,
                    border = BorderStroke(1.dp, WarningAmberBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Reroute Alert", tint = WarningAmber, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "DYNAMIC CORRIDOR DIVERSION",
                                style = MaterialTheme.typography.labelSmall,
                                color = WarningAmber,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = rerouteExplanation ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // Disaster & Hazard Simulation Sandbox Strip (SIH / Demo Mode)
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                color = PureWhite,
                border = BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "DISASTER SIMULATION SCENARIOS (EVALUATE DYNAMIC REROUTING)",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            onClick = { viewModel.simulateHazardLandslide() },
                            shape = RoundedCornerShape(8.dp),
                            color = CriticalRedBg,
                            border = BorderStroke(1.dp, CriticalRedBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Default.Terrain, contentDescription = null, tint = CriticalRed, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Landslide", style = MaterialTheme.typography.labelSmall, color = CriticalRed, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }

                        Surface(
                            onClick = { viewModel.simulateHazardFlood() },
                            shape = RoundedCornerShape(8.dp),
                            color = InfoBlueBg,
                            border = BorderStroke(1.dp, InfoBlueBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Default.Cloud, contentDescription = null, tint = InfoBlue, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Flood / Rain", style = MaterialTheme.typography.labelSmall, color = InfoBlue, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }

                        Surface(
                            onClick = { viewModel.simulateHazardBlockage() },
                            shape = RoundedCornerShape(8.dp),
                            color = WarningAmberBg,
                            border = BorderStroke(1.dp, WarningAmberBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Blockage", style = MaterialTheme.typography.labelSmall, color = WarningAmber, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }

                        Surface(
                            onClick = { viewModel.clearAllHazards() },
                            shape = RoundedCornerShape(8.dp),
                            color = SuccessGreenBg,
                            border = BorderStroke(1.dp, SuccessGreenBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Clear", style = MaterialTheme.typography.labelSmall, color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Interactive GIS Map Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Map, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "INTERACTIVE ROUTE MAP",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }

                        // Toggle Leaflet Map vs Vector Canvas Map
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (useLeafletMap) "OSM Tiles" else "Vector GIS",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                onClick = { useLeafletMap = !useLeafletMap },
                                shape = RoundedCornerShape(6.dp),
                                color = SurfaceSubtle,
                                border = BorderStroke(0.5.dp, BorderLight)
                            ) {
                                Icon(Icons.Default.Layers, contentDescription = "Toggle Map Layer", tint = PrimaryBlue, modifier = Modifier.size(18.dp).padding(2.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Map Container
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(300.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .border(1.dp, BorderLight, RoundedCornerShape(10.dp))
                    ) {
                        if (useLeafletMap) {
                            LeafletMapView(
                                tileCacheManager = viewModel.tileCacheManager,
                                vehicles = vehicles,
                                incidents = incidents,
                                candidates = candidates,
                                selectedRouteId = selectedCandidate?.id,
                                onRouteSelect = { routeId -> viewModel.selectRoute(routeId) },
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            InteractiveGISMap(
                                vehicles = vehicles,
                                incidents = incidents,
                                candidates = candidates,
                                selectedRouteId = selectedCandidate?.id,
                                originPoint = origin,
                                destinationPoint = destination,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Direct Action Buttons Row under Map
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (selectedCandidate != null) {
                                    ExternalNavigationLauncher.openGoogleMapsDirections(
                                        context = context,
                                        route = selectedCandidate
                                    )
                                } else {
                                    ExternalNavigationLauncher.openGoogleMapsDirections(
                                        context = context,
                                        origin = origin,
                                        destination = destination
                                    )
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen, contentColor = PureWhite),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("open_in_google_maps_btn")
                        ) {
                            Icon(Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("OPEN IN GOOGLE MAPS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                if (selectedCandidate != null) {
                                    activeRouteForDetails = selectedCandidate
                                } else {
                                    viewModel.findBestRoute()
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, PrimaryBlue),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimaryBlue),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("full_audit_details_btn")
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (selectedCandidate != null) "Full Logistics Audit" else "Audit Route", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Calculated Route Options Header
        item {
            SectionHeader(
                title = "Evaluated Route Candidates (${candidates.size})",
                subtitle = "Select any corridor to compare risk metrics, checkpoints & terrain cross-section"
            )
        }

        // Multi-Candidate Route Cards
        if (candidates.isEmpty() && !isCalculating) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = PureWhite,
                    border = BorderStroke(1.dp, BorderLight)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.AltRoute, contentDescription = null, tint = TextTertiary, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No routes calculated yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Select an origin and destination and click 'SEARCH SAFEST ROUTE'.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextTertiary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        } else {
            items(candidates) { candidate ->
                val isSelected = candidate.id == selectedCandidate?.id
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    RouteCandidateCard(
                        candidate = candidate,
                        isSelected = isSelected,
                        onSelect = {
                            viewModel.selectRoute(candidate.id)
                        },
                        onViewDetails = {
                            activeRouteForDetails = candidate
                        },
                        onLaunchExternalNav = {
                            ExternalNavigationLauncher.openGoogleMapsDirections(context, candidate)
                        }
                    )
                }
            }
        }
    }

    // Modal Details Dialog for selected route
    if (activeRouteForDetails != null) {
        val recommendedAlt = candidates.find { it.isRecommended && it.id != activeRouteForDetails?.id }
        RouteDetailsDialog(
            route = activeRouteForDetails!!,
            recommendedAlternative = recommendedAlt,
            onDismiss = { activeRouteForDetails = null },
            onSelectAlternative = { candidate ->
                viewModel.selectRoute(candidate.id)
                activeRouteForDetails = candidate
            }
        )
    }
}
