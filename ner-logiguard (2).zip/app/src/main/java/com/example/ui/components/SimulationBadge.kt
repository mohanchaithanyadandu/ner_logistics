package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyberCyan

/**
 * Standard visual indicator badge displayed when simulation data is actively running.
 */
@Composable
fun SimulationBadge(
    modifier: Modifier = Modifier,
    label: String = "SIMULATION DATA ACTIVE",
    showIcon: Boolean = true
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(4.dp),
        color = AmberWarning.copy(alpha = 0.15f),
        border = androidx.compose.foundation.BorderStroke(0.8.dp, AmberWarning.copy(alpha = 0.8f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (showIcon) {
                Icon(
                    imageVector = Icons.Default.Science,
                    contentDescription = null,
                    tint = AmberWarning,
                    modifier = Modifier.size(11.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = AmberWarning,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
                letterSpacing = 0.4.sp
            )
        }
    }
}

/**
 * Prominent disclaimer banner for screens displaying simulated telemetry.
 */
@Composable
fun SimulationDisclaimerBanner(
    modifier: Modifier = Modifier,
    details: String = "Simulated disaster conditions active alongside authentic OpenStreetMap geospatial data and Open-Meteo atmospheric models."
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = AmberWarning.copy(alpha = 0.10f),
        border = androidx.compose.foundation.BorderStroke(0.8.dp, AmberWarning.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "Simulation Info",
                tint = AmberWarning,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = details,
                style = MaterialTheme.typography.bodySmall,
                color = AmberWarning,
                fontSize = 10.sp,
                lineHeight = 13.sp
            )
        }
    }
}
