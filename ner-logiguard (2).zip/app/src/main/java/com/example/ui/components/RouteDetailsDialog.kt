package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.RouteCandidate
import com.example.ui.theme.*
import com.example.util.ExternalNavigationLauncher
import com.example.util.NavigationLaunchResult
import kotlinx.coroutines.launch

/**
 * Full Tactical Route Details view with Google Maps integration,
 * hazard alert dialogues, provenance disclosure, and transparent scoring breakdown.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RouteDetailsDialog(
    route: RouteCandidate,
    recommendedAlternative: RouteCandidate?,
    onDismiss: () -> Unit,
    onSelectAlternative: (RouteCandidate) -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()

    var showHazardWarningDialog by remember { mutableStateOf(false) }
    var launchFeedbackMessage by remember { mutableStateOf<String?>(null) }
    var launchIsError by remember { mutableStateOf(false) }

    // Evaluates if the route has severe risk conditions
    val isHighRiskOrDisrupted = route.isBlocked ||
            route.incidentRiskScore > 70 ||
            route.compositeRiskScore > 70 ||
            route.affectedIncidents.isNotEmpty()

    fun launchGoogleMaps() {
        val result = ExternalNavigationLauncher.openGoogleMapsDirections(context, route)
        when (result) {
            is NavigationLaunchResult.SuccessDirectApp -> {
                launchIsError = false
                launchFeedbackMessage = "Opening Google Maps app for ${route.origin.name} → ${route.destination.name}..."
            }
            is NavigationLaunchResult.SuccessBrowserFallback -> {
                launchIsError = false
                launchFeedbackMessage = "Google Maps app unavailable; opened web navigation in browser."
            }
            is NavigationLaunchResult.Failure -> {
                launchIsError = true
                launchFeedbackMessage = result.errorMessage
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = ObsidianDarkBackground,
        contentColor = TextPrimary,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Bar
            Surface(
                color = CommandSurfaceElevated,
                border = BorderStroke(0.5.dp, CommandBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                scope.launch {
                                    sheetState.hide()
                                    onDismiss()
                                }
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back to Routes",
                                tint = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "ROUTE DETAILS",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "${route.origin.name} → ${route.destination.name}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Status Pill
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when {
                            route.isRecommended -> EmeraldGreen.copy(alpha = 0.2f)
                            route.isBlocked -> CrimsonAlert.copy(alpha = 0.25f)
                            else -> AmberWarning.copy(alpha = 0.2f)
                        },
                        border = BorderStroke(
                            1.dp,
                            when {
                                route.isRecommended -> EmeraldGreen
                                route.isBlocked -> CrimsonAlert
                                else -> AmberWarning
                            }
                        )
                    ) {
                        Text(
                            text = when {
                                route.isRecommended -> "★ RECOMMENDED"
                                route.isBlocked -> "⚠️ BLOCKED"
                                else -> route.statusLabel
                            },
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                route.isRecommended -> EmeraldGreen
                                route.isBlocked -> CrimsonAlert
                                else -> AmberWarning
                            },
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Route Overview Summary Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CommandCard),
                border = BorderStroke(
                    if (route.isRecommended) 1.5.dp else 1.dp,
                    if (route.isRecommended) EmeraldGreen else CommandBorder
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = route.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontSize = 15.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Corridor Code: ${route.corridorCode}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (route.isRecommended) EmeraldGreen.copy(alpha = 0.15f) else CommandSurfaceElevated,
                            border = BorderStroke(1.dp, if (route.isRecommended) EmeraldGreen else CommandBorder)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "ROUTE SCORE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextTertiary,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${route.routeScore}",
                                    style = MonospaceMetricValueStyle,
                                    fontWeight = FontWeight.Bold,
                                    color = if (route.isRecommended) EmeraldGreen else (if (route.routeScore > 65) CrimsonAlert else AmberWarning),
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = "LOWER = BETTER",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextTertiary,
                                    fontSize = 7.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Metrics Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CommandSurfaceElevated, RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "ESTIMATED TIME", style = MaterialTheme.typography.labelSmall, color = TextTertiary, fontSize = 9.sp)
                            Text(
                                text = "${route.estimatedDurationMin / 60}h ${route.estimatedDurationMin % 60}m",
                                style = MonospaceMetricValueStyle,
                                color = TextPrimary,
                                fontSize = 14.sp
                            )
                        }
                        Column {
                            Text(text = "DISTANCE", style = MaterialTheme.typography.labelSmall, color = TextTertiary, fontSize = 9.sp)
                            Text(
                                text = "${route.distanceKm} km",
                                style = MonospaceMetricValueStyle,
                                color = TextPrimary,
                                fontSize = 14.sp
                            )
                        }
                        Column {
                            Text(text = "CLIMB", style = MaterialTheme.typography.labelSmall, color = TextTertiary, fontSize = 9.sp)
                            Text(
                                text = "+${route.elevationGainM}m",
                                style = MonospaceMetricValueStyle,
                                color = AmberWarning,
                                fontSize = 14.sp
                            )
                        }
                        Column {
                            Text(text = "RISK LEVEL", style = MaterialTheme.typography.labelSmall, color = TextTertiary, fontSize = 9.sp)
                            Text(
                                text = route.riskLevel.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(route.riskLevel.colorHex),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Explanation Box: Why this route / Why not recommended
                    if (route.isRecommended && route.recommendationReason.isNotBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = EmeraldGreen.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, EmeraldGreen.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "WHY THIS ROUTE?",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = route.recommendationReason,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    } else if (!route.isRecommended && route.whyNotRecommended != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (route.isBlocked) CrimsonAlert.copy(alpha = 0.12f) else CommandSurfaceElevated,
                            border = BorderStroke(1.dp, if (route.isBlocked) CrimsonAlert.copy(alpha = 0.4f) else CommandBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "WHY NOT RECOMMENDED?",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (route.isBlocked) CrimsonAlert else AmberWarning,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = route.whyNotRecommended ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // ==========================================
                    // PROMINENT "OPEN IN GOOGLE MAPS" BUTTON
                    // ==========================================
                    Button(
                        onClick = {
                            if (isHighRiskOrDisrupted) {
                                showHazardWarningDialog = true
                            } else {
                                launchGoogleMaps()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (route.isBlocked) CrimsonAlert else EmeraldGreen,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Navigation,
                            contentDescription = "Open in Google Maps",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "OPEN IN GOOGLE MAPS",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp,
                            color = Color.Black
                        )
                    }

                    // Subtext clarifying Google Maps external navigation role
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Opens Google Maps directions for: ${route.origin.name} (${route.origin.latitude}, ${route.origin.longitude}) → ${route.destination.name} (${route.destination.latitude}, ${route.destination.longitude})",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiary,
                        fontSize = 9.sp,
                        lineHeight = 12.sp
                    )

                    // Navigation launch feedback message (direct app, browser, error)
                    if (launchFeedbackMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (launchIsError) CrimsonAlert.copy(alpha = 0.15f) else EmeraldGreen.copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, if (launchIsError) CrimsonAlert else EmeraldGreen),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (launchIsError) Icons.Default.Warning else Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = if (launchIsError) CrimsonAlert else EmeraldGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = launchFeedbackMessage ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (launchIsError) CrimsonAlert else EmeraldGreen,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }

            // Architecture & Topology Disclosure Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = CommandSurface),
                border = BorderStroke(1.dp, CommandBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = BlueInfo,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "NAVIGATION & RISK ARCHITECTURE",
                            style = MaterialTheme.typography.labelSmall,
                            color = BlueInfo,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "NER LogiGuard performs the multi-factor terrain, weather, and incident risk analysis. Google Maps provides the external turn-by-turn navigation layer between the selected origin and destination.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = CommandSurfaceElevated,
                        border = BorderStroke(0.5.dp, CommandBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "DATA SOURCE: ${route.dataSourceLabel}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (route.isSimulatedData) AmberWarning else EmeraldGreen,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Checkpoints List Card
            if (route.keyCheckpoints.isNotEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = CommandSurface),
                    border = BorderStroke(1.dp, CommandBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "CORRIDOR WAYPOINTS & CHECKPOINTS",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextTertiary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        route.keyCheckpoints.forEachIndexed { idx, point ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = CommandSurfaceElevated,
                                    modifier = Modifier.size(20.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = "${idx + 1}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextSecondary,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = point,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }

            // Feedback Banner if Google Maps launch attempted
            if (launchFeedbackMessage != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (launchIsError) CrimsonAlert.copy(alpha = 0.12f) else EmeraldGreen.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, if (launchIsError) CrimsonAlert else EmeraldGreen),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (launchIsError) Icons.Default.Warning else Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = if (launchIsError) CrimsonAlert else EmeraldGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = launchFeedbackMessage ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (launchIsError) CrimsonAlert else EmeraldGreen,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Navigation Actions Card
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CommandCard),
                border = BorderStroke(1.dp, CommandBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "DISPATCH & EXTERNAL NAVIGATION",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Prominent OPEN IN GOOGLE MAPS Button
                    Button(
                        onClick = {
                            if (isHighRiskOrDisrupted) {
                                showHazardWarningDialog = true
                            } else {
                                launchGoogleMaps()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (route.isBlocked) CriticalRed else SuccessGreen,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("dialog_open_in_google_maps_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Navigation,
                            contentDescription = "Open in Google Maps",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (route.isBlocked) "PROCEED TO GOOGLE MAPS (HAZARDOUS)" else "OPEN IN GOOGLE MAPS",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color.White,
                            letterSpacing = 0.5.sp
                        )
                    }

                    if (recommendedAlternative != null && recommendedAlternative.id != route.id) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                onSelectAlternative(recommendedAlternative)
                            },
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, SuccessGreen),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = SuccessGreen
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .testTag("dialog_switch_to_recommended_button")
                        ) {
                            Text(
                                text = "★ SWITCH TO RECOMMENDED ALTERNATIVE",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = SuccessGreen
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, BorderLight),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp)
                    ) {
                        Text(
                            text = "CLOSE DETAILS",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }

    // Hazard / Disruption Warning Dialog before launching Google Maps
    if (showHazardWarningDialog) {
        AlertDialog(
            onDismissRequest = { showHazardWarningDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = CrimsonAlert,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "⚠️ ROUTE HAZARD WARNING",
                    fontWeight = FontWeight.Bold,
                    color = CrimsonAlert,
                    fontSize = 15.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "NER LogiGuard has detected a high-risk condition or active incident on this route (${route.name}).",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    if (route.isBlocked) {
                        Text(
                            text = "Status: Critical corridor blockage reported. Transit through this corridor may not be feasible.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CrimsonAlert,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    } else {
                        Text(
                            text = "Status: Elevated disruption risk (${route.incidentRiskScore}%). Review the recommended alternative before continuing to external navigation.",
                            style = MaterialTheme.typography.bodySmall,
                            color = AmberWarning,
                            fontSize = 11.sp
                        )
                    }

                    if (recommendedAlternative != null && recommendedAlternative.id != route.id) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = EmeraldGreen.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, EmeraldGreen.copy(alpha = 0.4f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showHazardWarningDialog = false
                                    onSelectAlternative(recommendedAlternative)
                                }
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    text = "★ RECOMMENDED ALTERNATIVE AVAILABLE:",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                                Text(
                                    text = "${recommendedAlternative.name} (Score: ${recommendedAlternative.routeScore}/100, ${recommendedAlternative.estimatedDurationMin / 60}h ${recommendedAlternative.estimatedDurationMin % 60}m)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showHazardWarningDialog = false
                        launchGoogleMaps()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (route.isBlocked) CriticalRed else SuccessGreen,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "OPEN IN GOOGLE MAPS",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = Color.White
                    )
                }
            },
            dismissButton = {
                if (recommendedAlternative != null && recommendedAlternative.id != route.id) {
                    OutlinedButton(
                        onClick = {
                            showHazardWarningDialog = false
                            onSelectAlternative(recommendedAlternative)
                        },
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, EmeraldGreen)
                    ) {
                        Text(
                            text = "VIEW ALTERNATIVE",
                            color = EmeraldGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                } else {
                    OutlinedButton(
                        onClick = { showHazardWarningDialog = false },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("CANCEL", color = TextSecondary, fontSize = 11.sp)
                    }
                }
            },
            containerColor = CommandCard,
            tonalElevation = 6.dp
        )
    }
}
