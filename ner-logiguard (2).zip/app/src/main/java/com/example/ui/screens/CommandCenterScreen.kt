package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thunderstorm
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.IncidentSeverity
import com.example.data.models.NERState
import com.example.data.models.RegionalRiskSummary
import com.example.data.models.RiskLevel
import com.example.ui.components.InteractiveGISMap
import com.example.ui.components.LeafletMapView
import com.example.ui.components.OfflineBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.VehicleCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.NERLogisticsViewModel

@Composable
fun CommandCenterScreen(
    viewModel: NERLogisticsViewModel,
    modifier: Modifier = Modifier
) {
    val vehicles by viewModel.allVehicles.collectAsState()
    val incidents by viewModel.allIncidents.collectAsState()
    val alerts by viewModel.allAlerts.collectAsState()
    val regionalRisks by viewModel.regionalRiskList.collectAsState()
    val isOffline by viewModel.isOfflineSimulated.collectAsState()
    val pendingCount by viewModel.pendingOfflineCount.collectAsState()
    val candidates by viewModel.routeCandidates.collectAsState()
    val selectedRouteId by viewModel.selectedRouteId.collectAsState()
    val routeCalculationCompletedTrigger by viewModel.routeCalculationCompletedTrigger.collectAsState()

    val criticalIncidents = incidents.filter { it.severity == IncidentSeverity.CRITICAL_BLOCKAGE }
    val hasCriticalIssues = criticalIncidents.isNotEmpty()
    val criticalAlertsCount = alerts.count { it.severity == RiskLevel.CRITICAL || it.severity == RiskLevel.HIGH }

    val currentRole by viewModel.currentRole.collectAsState()
    val currentTime = remember { java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date()) }

    var selectedStateFilter by remember { mutableStateOf<NERState?>(null) }
    var useLeafletMap by remember { mutableStateOf(true) }
    var isAdvancedExpanded by remember { mutableStateOf(false) }

    // Filtered data based on region selector
    val filteredVehicles = if (selectedStateFilter != null) {
        val stateName = selectedStateFilter!!.fullName
        val capital = selectedStateFilter!!.capital
        vehicles.filter {
            it.originName.contains(stateName, ignoreCase = true) ||
            it.destinationName.contains(stateName, ignoreCase = true) ||
            it.originName.contains(capital, ignoreCase = true) ||
            it.destinationName.contains(capital, ignoreCase = true) ||
            it.activeRouteName.contains(stateName, ignoreCase = true)
        }.ifEmpty { vehicles }
    } else {
        vehicles
    }

    val filteredIncidents = if (selectedStateFilter != null) {
        incidents.filter { it.state == selectedStateFilter }
    } else {
        incidents
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBackground),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Offline Synchronization Banner
        item {
            OfflineBanner(
                isOffline = isOffline,
                pendingCount = pendingCount,
                onSyncClick = { viewModel.syncAllOfflineReports() }
            )
        }

        // =========================================================================
        // 1. TOP SECTION (Clean Operational Overview)
        // =========================================================================
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Text(
                                text = "NER LogiGuard",
                                style = MaterialTheme.typography.titleLarge,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "North East Region Logistics Intelligence",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isOffline) WarningAmberBg else SuccessGreenBg,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isOffline) WarningAmberBorder else SuccessGreenBorder
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(if (isOffline) WarningAmber else SuccessGreen)
                                )
                                Text(
                                    text = if (isOffline) "Offline Mode" else "Operating Normal",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isOffline) WarningAmber else SuccessGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "User Role: ",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                            Text(
                                text = currentRole.displayName,
                                style = MaterialTheme.typography.bodySmall,
                                color = PrimaryBlue,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        Text(
                            text = "Time: $currentTime",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // =========================================================================
        // 2. FOUR SIMPLE SUMMARY CARDS
        // =========================================================================
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Card 1: ACTIVE ALERTS
                    CleanKPICard(
                        title = "ACTIVE ALERTS",
                        value = "07",
                        subtitle = "+2 today",
                        icon = Icons.Default.NotificationsActive,
                        accentColor = CriticalRed,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.setTab(AppNavTab.ALERTS) }
                    )

                    // Card 2: VEHICLES IN TRANSIT
                    CleanKPICard(
                        title = "VEHICLES IN TRANSIT",
                        value = "18",
                        subtitle = "4 delayed",
                        icon = Icons.Default.LocalShipping,
                        accentColor = PrimaryBlue,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.setTab(AppNavTab.LIVE_FLEET) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Card 3: HIGH-RISK ROUTES
                    CleanKPICard(
                        title = "HIGH-RISK ROUTES",
                        value = "04",
                        subtitle = "Above threshold",
                        icon = Icons.Default.Route,
                        accentColor = WarningAmber,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.setTab(AppNavTab.ROUTE_PLANNER) }
                    )

                    // Card 4: REPORTS SYNCED
                    CleanKPICard(
                        title = "REPORTS SYNCED",
                        value = "32",
                        subtitle = "Last 24 hours",
                        icon = Icons.Default.CloudDone,
                        accentColor = SuccessGreen,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.setTab(AppNavTab.FIELD_REPORT) }
                    )
                }
            }
        }

        // =========================================================================
        // 3. DISTRICT / REGION FILTER (Clean Pill Row)
        // =========================================================================
        item {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    val isAllSelected = selectedStateFilter == null
                    Surface(
                        onClick = { selectedStateFilter = null },
                        shape = RoundedCornerShape(20.dp),
                        color = if (isAllSelected) PrimaryBlueLight else PureWhite,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isAllSelected) PrimaryBlue else BorderLight
                        )
                    ) {
                        Text(
                            text = "All North East (8)",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isAllSelected) PrimaryBlue else TextSecondary,
                            fontWeight = if (isAllSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                        )
                    }
                }

                items(NERState.values()) { state ->
                    val isSelected = selectedStateFilter == state
                    Surface(
                        onClick = {
                            selectedStateFilter = if (isSelected) null else state
                        },
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSelected) PrimaryBlueLight else PureWhite,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) PrimaryBlue else BorderLight
                        )
                    ) {
                        Text(
                            text = state.fullName,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) PrimaryBlue else TextSecondary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                        )
                    }
                }
            }
        }

        // =========================================================================
        // 6. LARGE LIVE MAP CARD (Command Center Tactical View)
        // =========================================================================
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkNavyBorder),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column {
                        // Map Card Header
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "LIVE GEOSPATIAL MAP",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyanAccent,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp,
                                    fontSize = 10.sp
                                )
                                Text(
                                    text = "North East Corridors & Convoys",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }

                            // Engine Switcher
                            Surface(
                                onClick = { useLeafletMap = !useLeafletMap },
                                shape = RoundedCornerShape(6.dp),
                                color = DarkNavySurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.dp, DarkNavyBorder)
                            ) {
                                Text(
                                    text = if (useLeafletMap) "🌐 Leaflet Map" else "📐 Canvas HUD",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyanAccent,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    fontSize = 10.sp
                                )
                            }
                        }

                        // Map Viewport
                        if (useLeafletMap) {
                            LeafletMapView(
                                tileCacheManager = viewModel.tileCacheManager,
                                vehicles = filteredVehicles,
                                incidents = filteredIncidents,
                                candidates = candidates,
                                selectedRouteId = selectedRouteId,
                                activeCorridorCode = "NH13_GHY_TWG",
                                autoFitTrigger = routeCalculationCompletedTrigger,
                                onVehicleSelect = { viewModel.setTab(AppNavTab.LIVE_FLEET) },
                                onRouteSelect = { routeId -> viewModel.selectRoute(routeId) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(310.dp)
                            )
                        } else {
                            InteractiveGISMap(
                                vehicles = filteredVehicles,
                                incidents = filteredIncidents,
                                onVehicleSelect = { viewModel.setTab(AppNavTab.LIVE_FLEET) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(310.dp)
                            )
                        }

                        // Map Legend Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkNavySurfaceVariant)
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(SafeGreen))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("Safe Corridor", fontSize = 10.sp, color = TextLightBlueGray, fontWeight = FontWeight.Medium)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(CriticalRed))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("Blocked / Hazard", fontSize = 10.sp, color = TextLightBlueGray, fontWeight = FontWeight.Medium)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(CyanAccent))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("Fleet Vehicle", fontSize = 10.sp, color = TextLightBlueGray, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
        }

        // =========================================================================
        // 7. IMPORTANT OPERATIONAL INFORMATION BELOW THE MAP
        // =========================================================================

        // A. Critical Active Disruption & Recommended Action
        if (hasCriticalIssues) {
            item {
                val topProblem = criticalIncidents.first()
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .testTag("dashboard_critical_incident_card"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CriticalRedBorder),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(26.dp)
                                        .clip(CircleShape)
                                        .background(CriticalRedBg),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ReportProblem,
                                        contentDescription = "Disruption",
                                        tint = CriticalRed,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "ACTIVE ROAD DISRUPTION",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CriticalRed,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp,
                                    fontSize = 10.sp
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = CriticalRedBg,
                                border = androidx.compose.foundation.BorderStroke(0.5.dp, CriticalRedBorder)
                            ) {
                                Text(
                                    text = "HIGH RISK",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CriticalRed,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = topProblem.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )

                        Text(
                            text = "${topProblem.corridorName} • ${topProblem.locationName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyanAccent,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Problem impact metrics
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = DarkNavySurfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "ESTIMATED DELAY",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextLightBlueGray,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "+3.8 Hours (Standstill)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CriticalRed,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "CLEARANCE STATUS",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextLightBlueGray,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "BRO 42 BRTF Deployed (~${topProblem.clearanceEtaHours}h)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = WarningAmber,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Recommended Reroute Action
                        Text(
                            text = "Recommended Action: Reroute via NH-27 (Haflong Bypass)",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextWhite,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )

                        Text(
                            text = "Circumvents the Sonapur mudslide zone. Saves ~3.2 hours of delay.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextLightBlueGray,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    viewModel.selectRoute("ROUTE_NH27_HAFLONG_BYPASS")
                                    viewModel.setTab(AppNavTab.ROUTE_PLANNER)
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyanAccent,
                                    contentColor = Color.Black
                                ),
                                modifier = Modifier
                                    .weight(1.2f)
                                    .height(38.dp)
                                    .testTag("execute_reroute_button")
                            ) {
                                Text("▶ Execute Reroute", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { viewModel.setTab(AppNavTab.ALERTS) },
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, DarkNavyBorder),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextWhite),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                            ) {
                                Icon(Icons.Default.Campaign, contentDescription = "Alert", modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Broadcast", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // B. 8-State Accessibility Matrix
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                SectionHeader(
                    title = "Regional Accessibility Matrix",
                    subtitle = "Real-time road status across 8 states",
                    actionText = "Full Radar",
                    onActionClick = { viewModel.setTab(AppNavTab.RISK_INTELLIGENCE) }
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 0.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(regionalRisks) { summary ->
                        StateAccessCard(summary = summary)
                    }
                }
            }
        }

        // C. Priority Freight Convoys Telemetry
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                SectionHeader(
                    title = "Priority Freight Convoys",
                    subtitle = "Live coordinates & driver telemetry",
                    actionText = "Fleet View (${vehicles.size})",
                    onActionClick = { viewModel.setTab(AppNavTab.LIVE_FLEET) }
                )

                filteredVehicles.take(2).forEach { vehicle ->
                    Box(modifier = Modifier.padding(vertical = 4.dp)) {
                        VehicleCard(
                            vehicle = vehicle,
                            onClick = { viewModel.setTab(AppNavTab.LIVE_FLEET) }
                        )
                    }
                }
            }
        }

        // D. Collapsible Simulation & Demo Controls
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                Surface(
                    onClick = { isAdvancedExpanded = !isAdvancedExpanded },
                    shape = RoundedCornerShape(10.dp),
                    color = DarkNavyCard,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkNavyBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FlashOn,
                                contentDescription = "Sim",
                                tint = WarningAmber,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "DEMO CONTROLS (SIMULATED DATA)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "Synthetic telemetry & scenario triggers for evaluation",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextLightBlueGray,
                                    fontSize = 9.sp
                                )
                            }
                        }

                        Icon(
                            imageVector = if (isAdvancedExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Expand",
                            tint = TextGray,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                AnimatedVisibility(
                    visible = isAdvancedExpanded,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = LightCardWhite),
                        border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmberBorder)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Notice: Running synthetic telemetry alongside authentic OpenStreetMap GIS and Open-Meteo weather models for demonstration purposes.",
                                style = MaterialTheme.typography.bodySmall,
                                color = WarningAmber,
                                fontSize = 10.sp,
                                lineHeight = 14.sp
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.triggerLandslideSimNH6() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CriticalRedBg,
                                        contentColor = CriticalRed
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, CriticalRedBorder),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp)
                                ) {
                                    Text("⚡ Landslide NH-6", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { viewModel.toggleOfflineSimulation() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isOffline) SafeGreenBg else WarningAmberBg,
                                        contentColor = if (isOffline) SafeGreen else WarningAmber
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (isOffline) SafeGreenBorder else WarningAmberBorder
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp)
                                ) {
                                    Text(if (isOffline) "Go Online" else "📶 Drop Signal", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Clean KPI Metric Card matching the Manus visual reference style
 */
@Composable
private fun CleanKPICard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(enabled = onClick != null) { onClick?.invoke() }
            .semantics { contentDescription = "$title: $value. $subtitle" },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.5.sp,
                    fontSize = 11.sp
                )
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(accentColor.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = "$title icon",
                        tint = accentColor,
                        modifier = Modifier.size(17.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(accentColor)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1
                )
            }
        }
    }
}

/**
 * State Access Card in horizontal scroller
 */
@Composable
private fun StateAccessCard(summary: RegionalRiskSummary) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkNavyBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.width(165.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = summary.state.fullName,
                    style = MaterialTheme.typography.titleSmall,
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Color(summary.overallRiskLevel.colorHex).copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, Color(summary.overallRiskLevel.colorHex).copy(alpha = 0.6f))
                ) {
                    Text(
                        text = "${summary.accessibilityIndex}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(summary.overallRiskLevel.colorHex),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                        fontSize = 9.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = summary.keyRoadStatus,
                style = MaterialTheme.typography.bodySmall,
                color = TextLightBlueGray,
                fontSize = 10.sp,
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (summary.activeLandslideAlerts > 0) "⚠️ ${summary.activeLandslideAlerts} Alert" else "✓ Normal",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (summary.activeLandslideAlerts > 0) WarningAmber else SafeGreen,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "+${summary.averageDelayMin}m",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMutedGrayBlue,
                    fontSize = 9.sp
                )
            }
        }
    }
}
