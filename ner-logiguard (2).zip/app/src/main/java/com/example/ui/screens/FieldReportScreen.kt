package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.FieldIncidentReport
import com.example.data.models.IncidentSeverity
import com.example.data.models.IncidentType
import com.example.data.models.NERState
import com.example.ui.components.OfflineBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.TerminalStatusIndicatorPill
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CommandBorder
import com.example.ui.theme.CommandBorderSubtle
import com.example.ui.theme.CommandCard
import com.example.ui.theme.CommandSurface
import com.example.ui.theme.CommandSurfaceElevated
import com.example.ui.theme.CommandSurfaceVariant
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.MonospaceTelemetryStyle
import com.example.ui.theme.ObsidianDarkBackground
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.viewmodel.NERLogisticsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FieldReportScreen(
    viewModel: NERLogisticsViewModel,
    modifier: Modifier = Modifier
) {
    val isOffline by viewModel.isOfflineSimulated.collectAsState()
    val pendingCount by viewModel.pendingOfflineCount.collectAsState()
    val syncStatus by viewModel.terminalSyncStatus.collectAsState()
    val reports by viewModel.allFieldReports.collectAsState()
    val currentRole by viewModel.currentRole.collectAsState()

    var reporterName by remember { mutableStateOf("Officer T. Jamir") }
    var locationName by remember { mutableStateOf("Chumukedima Ghat (NH-29)") }
    var selectedState by remember { mutableStateOf(NERState.NAGALAND) }
    var selectedType by remember { mutableStateOf(IncidentType.LANDSLIDE) }
    var selectedSeverity by remember { mutableStateOf(IncidentSeverity.MODERATE) }
    var blockagePct by remember { mutableFloatStateOf(60f) }
    var estHours by remember { mutableStateOf("3.5") }
    var notes by remember { mutableStateOf("Soil liquefaction and loose boulders blocking northbound lane. Single line convoy operating.") }
    var hasPhotoAttached by remember { mutableStateOf(true) }
    var photoFileName by remember { mutableStateOf("IMG_20260902_NH29_SLIDE.JPG") }
    var photoFileSize by remember { mutableStateOf("2.4 MB") }

    var typeDropdownOpen by remember { mutableStateOf(false) }
    var stateDropdownOpen by remember { mutableStateOf(false) }
    var submittedSuccessMsg by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            OfflineBanner(
                isOffline = isOffline,
                pendingCount = pendingCount,
                onSyncClick = { viewModel.syncAllOfflineReports() }
            )
        }

        // Header with Connectivity Status Indicator
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CommandCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CommandBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Field Officer Terminal",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "NER Disaster Response & Corridor Unit",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        TerminalStatusIndicatorPill(status = syncStatus)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = CommandSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, CommandBorderSubtle)
                        ) {
                            Text(
                                text = "Role: ${currentRole.displayName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberCyan,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Button(
                            onClick = { viewModel.toggleOfflineSimulation() },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isOffline) EmeraldGreen.copy(alpha = 0.2f) else AmberWarning.copy(alpha = 0.2f),
                                contentColor = if (isOffline) EmeraldGreen else AmberWarning
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isOffline) EmeraldGreen else AmberWarning),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text(if (isOffline) "📶 Switch Online" else "⚠️ Drop Network Sim", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // New Incident Report Form
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CommandCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CommandBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "NEW HAZARD / ROAD DISRUPTION REPORT",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Location / Corridor
                    OutlinedTextField(
                        value = locationName,
                        onValueChange = { locationName = it },
                        label = { Text("Corridor & Milestone Location", color = CyberCyan) },
                        leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = CyberCyan) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = CommandBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CommandSurface,
                            unfocusedContainerColor = CommandSurface
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // State Dropdown
                    ExposedDropdownMenuBox(
                        expanded = stateDropdownOpen,
                        onExpandedChange = { stateDropdownOpen = !stateDropdownOpen }
                    ) {
                        OutlinedTextField(
                            value = selectedState.fullName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("State / Territory", color = CyberCyan) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = stateDropdownOpen) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = CommandBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedContainerColor = CommandSurface,
                                unfocusedContainerColor = CommandSurface
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = stateDropdownOpen,
                            onDismissRequest = { stateDropdownOpen = false },
                            modifier = Modifier.background(CommandCard)
                        ) {
                            NERState.values().forEach { st ->
                                DropdownMenuItem(
                                    text = { Text(st.fullName, color = TextPrimary) },
                                    onClick = {
                                        selectedState = st
                                        stateDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Incident Type Dropdown
                    ExposedDropdownMenuBox(
                        expanded = typeDropdownOpen,
                        onExpandedChange = { typeDropdownOpen = !typeDropdownOpen }
                    ) {
                        OutlinedTextField(
                            value = selectedType.label,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Hazard Classification", color = CyberCyan) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeDropdownOpen) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = CommandBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedContainerColor = CommandSurface,
                                unfocusedContainerColor = CommandSurface
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = typeDropdownOpen,
                            onDismissRequest = { typeDropdownOpen = false },
                            modifier = Modifier.background(CommandCard)
                        ) {
                            IncidentType.values().forEach { type ->
                                DropdownMenuItem(
                                    text = { Text(type.label, color = TextPrimary) },
                                    onClick = {
                                        selectedType = type
                                        typeDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Severity Selector Row
                    Text(
                        text = "Severity / Traffic Impact:",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        IncidentSeverity.values().forEach { sev ->
                            val isSelected = selectedSeverity == sev
                            val color = when(sev) {
                                IncidentSeverity.MINOR -> EmeraldGreen
                                IncidentSeverity.MODERATE -> AmberWarning
                                IncidentSeverity.CRITICAL_BLOCKAGE -> CrimsonAlert
                            }
                            Surface(
                                onClick = { selectedSeverity = sev },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) color.copy(alpha = 0.25f) else CommandSurface,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) color else CommandBorder
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = sev.label.split(" ").first(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSelected) color else TextSecondary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Blockage Percentage Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Road Surface Blockage:",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        Text(
                            text = "${blockagePct.toInt()}%",
                            style = MonospaceTelemetryStyle,
                            color = CyberCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Slider(
                        value = blockagePct,
                        onValueChange = { blockagePct = it },
                        valueRange = 0f..100f,
                        steps = 9,
                        colors = SliderDefaults.colors(
                            thumbColor = CyberCyan,
                            activeTrackColor = CyberCyan,
                            inactiveTrackColor = CommandBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Est Hours Text Field
                    OutlinedTextField(
                        value = estHours,
                        onValueChange = { estHours = it },
                        label = { Text("Est. Clearance Hours (BRO / SDRF)", color = CyberCyan) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = CommandBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CommandSurface,
                            unfocusedContainerColor = CommandSurface
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Notes
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Field Situation Notes & Equipment Required", color = CyberCyan) },
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = CommandBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CommandSurface,
                            unfocusedContainerColor = CommandSurface
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Submit Button
                    Button(
                        onClick = {
                            viewModel.submitFieldReport(
                                reporterName = reporterName,
                                reporterPhone = "+91 94350 12345",
                                incidentType = selectedType,
                                severity = selectedSeverity,
                                locationName = locationName,
                                state = selectedState,
                                roadBlockagePct = blockagePct.toInt(),
                                clearanceHours = estHours.toDoubleOrNull() ?: 2.0,
                                notes = notes
                            )
                            submittedSuccessMsg = if (isOffline) {
                                "Report saved locally to SQLite queue (Offline Mode). Will auto-sync when corridor signal is restored."
                            } else {
                                "Report submitted to Regional Emergency Operations Center & BRO dispatch unit."
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberCyan,
                            contentColor = Color.Black
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isOffline) "Save Report Locally (Offline Queue)" else "Dispatch Incident Report",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (submittedSuccessMsg != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isOffline) AmberWarning.copy(alpha = 0.15f) else EmeraldGreen.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isOffline) AmberWarning.copy(alpha = 0.6f) else EmeraldGreen.copy(alpha = 0.6f)
                            )
                        ) {
                            Text(
                                text = submittedSuccessMsg!!,
                                modifier = Modifier.padding(8.dp),
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isOffline) AmberWarning else EmeraldGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Recent Reports Log
        item {
            SectionHeader(
                title = "Incident Reports Queue (${reports.size})",
                subtitle = "Local Room storage with automated background synchronization"
            )
        }

        items(reports) { rep ->
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CommandCard),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (rep.isOfflinePending) AmberWarning.copy(alpha = 0.5f) else CommandBorder
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${rep.incidentType.label} - ${rep.locationName}",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            
                            if (rep.isOfflinePending) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = AmberWarning.copy(alpha = 0.2f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, AmberWarning.copy(alpha = 0.5f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CloudOff,
                                            contentDescription = null,
                                            tint = AmberWarning,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "OFFLINE",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = AmberWarning,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            } else {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = EmeraldGreen.copy(alpha = 0.2f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldGreen.copy(alpha = 0.5f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = EmeraldGreen,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "SYNC COMPLETE",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = EmeraldGreen,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Status badges row for offline clarity
                        if (rep.isOfflinePending) {
                            Row(
                                modifier = Modifier.padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = CommandSurfaceElevated
                                ) {
                                    Text(
                                        text = "Saved locally",
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = AmberWarning.copy(alpha = 0.25f)
                                ) {
                                    Text(
                                        text = "Pending synchronization",
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = AmberWarning,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        } else {
                            Text(
                                text = "✓ Server Synced • ID: ${rep.id}",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldGreen,
                                fontSize = 10.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = rep.notes,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "GPS: ${String.format("%.4f", rep.latitude)}°N, ${String.format("%.4f", rep.longitude)}°E • Blockage: ${rep.roadBlockagePct}% • ETA: ${rep.estimatedClearanceHours}h",
                            style = MonospaceTelemetryStyle,
                            color = TextTertiary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
