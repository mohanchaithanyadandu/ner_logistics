package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightLogisticsColorScheme = lightColorScheme(
    primary = PrimaryBlue,
    onPrimary = PureWhite,
    primaryContainer = PrimaryBlueLight,
    onPrimaryContainer = PrimaryBlueDark,
    secondary = SuccessGreen,
    onSecondary = PureWhite,
    secondaryContainer = SuccessGreenBg,
    onSecondaryContainer = SuccessGreen,
    tertiary = WarningAmber,
    onTertiary = PureWhite,
    tertiaryContainer = WarningAmberBg,
    onTertiaryContainer = WarningAmber,
    error = CriticalRed,
    onError = PureWhite,
    errorContainer = CriticalRedBg,
    onErrorContainer = CriticalRed,
    background = OffWhiteBackground,
    onBackground = TextPrimary,
    surface = PureWhite,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceSubtle,
    onSurfaceVariant = TextSecondary,
    outline = BorderLight,
    outlineVariant = BorderSubtle
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = LightLogisticsColorScheme,
        typography = Typography,
        content = content
    )
}
