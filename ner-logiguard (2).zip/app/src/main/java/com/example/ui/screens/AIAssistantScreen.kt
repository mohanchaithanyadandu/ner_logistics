package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CommandBorder
import com.example.ui.theme.CommandBorderSubtle
import com.example.ui.theme.CommandCard
import com.example.ui.theme.CommandSurface
import com.example.ui.theme.CommandSurfaceElevated
import com.example.ui.theme.CommandSurfaceVariant
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.MonospaceTelemetryStyle
import com.example.ui.theme.ObsidianDarkBackground
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.viewmodel.ChatMessage
import com.example.ui.viewmodel.NERLogisticsViewModel

@Composable
fun AIAssistantScreen(
    viewModel: NERLogisticsViewModel,
    modifier: Modifier = Modifier
) {
    val messages by viewModel.chatMessages.collectAsState()
    val isLoading by viewModel.isAILoading.collectAsState()
    val currentRole by viewModel.currentRole.collectAsState()
    val incidents by viewModel.allIncidents.collectAsState()
    val alerts by viewModel.allAlerts.collectAsState()
    val isOffline by viewModel.isOfflineSimulated.collectAsState()

    var inputPrompt by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    val listState = rememberLazyListState()
    val clipboardManager = LocalClipboardManager.current
    var copyNotice by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    LaunchedEffect(copyNotice) {
        if (copyNotice != null) {
            kotlinx.coroutines.delay(2000)
            copyNotice = null
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground)
    ) {
        // Header with live situational metadata
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = CommandCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, CommandBorder)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(CyberCyan.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "AI",
                            tint = CyberCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "NER Tactical Logistics Copilot",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Gemini Grounded Logistics Copilot • Role: ${currentRole.displayName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = EmeraldGreen,
                                fontSize = 11.sp
                            )
                            if (incidents.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "• ${incidents.size} Active Hazard${if (incidents.size > 1) "s" else ""}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AmberWarning,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.clearAIChat() },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Clear Chat",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Live Telemetry Notice Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = CommandSurface,
            border = androidx.compose.foundation.BorderStroke(0.5.dp, CommandBorderSubtle)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(if (isOffline) CrimsonAlert else EmeraldGreen, RoundedCornerShape(3.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isOffline) "Local Offline Copilot Active" else "Online Multi-turn Cloud Sync Active",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                }

                if (copyNotice != null) {
                    Text(
                        text = "✓ $copyNotice",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Category Filter Chips
        val categories = listOf("Operational Status", "Route & Risk", "Fleet & Incidents", "Weather & Terrain", "Cold Chain & Medical")
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(categories) { cat ->
                val isSelected = selectedCategory == cat
                Surface(
                    onClick = { selectedCategory = cat },
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) CyberCyan.copy(alpha = 0.2f) else CommandSurface,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) CyberCyan else CommandBorder
                    )
                ) {
                    Text(
                        text = cat,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) CyberCyan else TextSecondary,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Tactical Suggestion Chips based on Category
        val suggestions = when (selectedCategory) {
            "Route & Risk" -> listOf(
                "Which route is safest?",
                "Which corridor currently has the highest risk?",
                "Why was this route recommended?",
                "Haflong-Umrangso detour travel time vs NH-6 direct?"
            )
            "Fleet & Incidents" -> listOf(
                "Which vehicles are delayed?",
                "What incidents happened today?",
                "Which deliveries are at risk?",
                "Show me the most critical operational issue."
            )
            "Weather & Terrain" -> listOf(
                "Summarize current weather-related risks.",
                "Guwahati to Tawang weather & Sela Tunnel pass status?",
                "Jaswant Garh sub-zero fog & snow chain requirements?",
                "Meghalaya NH-6 Sonapur mud slurry contingency bypass?"
            )
            "Cold Chain & Medical" -> listOf(
                "Which deliveries are at risk?",
                "Emergency medical convoy protocols in high altitude?",
                "Vaccine cold-chain re-icing hubs between Guwahati and Aizawl?",
                "Green Corridor priority request procedure with SDMA?"
            )
            else -> listOf(
                "Which route is safest?",
                "Which corridor currently has the highest risk?",
                "Why was this route recommended?",
                "Which vehicles are delayed?",
                "What incidents happened today?",
                "Which deliveries are at risk?",
                "Summarize current weather-related risks.",
                "Show me the most critical operational issue."
            )
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(suggestions) { text ->
                Surface(
                    onClick = { viewModel.sendAIMessage(text) },
                    shape = RoundedCornerShape(14.dp),
                    color = CommandSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CommandBorder)
                ) {
                    Text(
                        text = text,
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Chat Message Stream
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { msg ->
                ChatBubble(
                    msg = msg,
                    onCopy = {
                        clipboardManager.setText(AnnotatedString(msg.text))
                        copyNotice = "Copied to clipboard"
                    }
                )
            }

            if (isLoading) {
                item {
                    Row(
                        modifier = Modifier.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            color = CyberCyan,
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Synthesizing terrain topography & weather models...",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Input Box
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 70.dp),
            color = CommandCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, CommandBorder)
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputPrompt,
                    onValueChange = { inputPrompt = it },
                    placeholder = { Text("Ask about NER routes, landslides, or convoys...", color = TextTertiary, fontSize = 12.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = CommandBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = CommandSurface,
                        unfocusedContainerColor = CommandSurface
                    ),
                    modifier = Modifier.weight(1f),
                    maxLines = 3
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        if (inputPrompt.isNotBlank()) {
                            viewModel.sendAIMessage(inputPrompt)
                            inputPrompt = ""
                        }
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .background(CyberCyan, RoundedCornerShape(10.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = Color.Black,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(
    msg: ChatMessage,
    onCopy: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start
    ) {
        Card(
            shape = RoundedCornerShape(
                topStart = 12.dp,
                topEnd = 12.dp,
                bottomStart = if (msg.isUser) 12.dp else 2.dp,
                bottomEnd = if (msg.isUser) 2.dp else 12.dp
            ),
            colors = CardDefaults.cardColors(
                containerColor = if (msg.isUser) CyberCyan.copy(alpha = 0.15f) else CommandCard
            ),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (msg.isUser) CyberCyan.copy(alpha = 0.5f) else CommandBorder
            ),
            modifier = Modifier.fillMaxWidth(0.92f)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = msg.sender,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (msg.isUser) CyberCyan else EmeraldGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )

                    IconButton(
                        onClick = onCopy,
                        modifier = Modifier.size(20.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy message",
                            tint = TextTertiary,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = msg.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary,
                    lineHeight = 20.sp,
                    fontSize = 13.sp
                )
            }
        }
    }
}
