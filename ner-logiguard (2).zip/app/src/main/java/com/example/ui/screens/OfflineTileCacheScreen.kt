package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.components.LeafletMapView
import com.example.ui.components.OfflineBanner
import com.example.ui.components.OfflineTileCacheDeck
import com.example.ui.components.SectionHeader
import com.example.ui.theme.ObsidianDarkBackground
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.NERLogisticsViewModel

@Composable
fun OfflineTileCacheScreen(
    viewModel: NERLogisticsViewModel,
    modifier: Modifier = Modifier
) {
    val vehicles by viewModel.allVehicles.collectAsState()
    val incidents by viewModel.allIncidents.collectAsState()
    val isOffline by viewModel.isOfflineSimulated.collectAsState()
    val pendingCount by viewModel.pendingOfflineCount.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            OfflineBanner(
                isOffline = isOffline,
                pendingCount = pendingCount,
                onSyncClick = { viewModel.syncAllOfflineReports() }
            )
        }

        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                SectionHeader(
                    title = "Interactive Leaflet GIS Tactical Map",
                    subtitle = "Mapbox / OpenStreetMap with Dynamic Local Tile Cache Interception",
                    actionText = "Full Fleet",
                    onActionClick = { viewModel.setTab(AppNavTab.LIVE_FLEET) },
                    modifier = Modifier.padding(horizontal = 0.dp)
                )

                LeafletMapView(
                    tileCacheManager = viewModel.tileCacheManager,
                    vehicles = vehicles,
                    incidents = incidents,
                    activeCorridorCode = "NH13_GHY_TWG",
                    onVehicleSelect = { v -> viewModel.setTab(AppNavTab.LIVE_FLEET) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp)
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            OfflineTileCacheDeck(
                tileCacheManager = viewModel.tileCacheManager,
                selectedCorridorCode = "NH13_GHY_TWG"
            )
        }
    }
}
