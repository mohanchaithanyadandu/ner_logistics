package com.example.data.repository

import android.content.Context
import com.example.data.local.AlertEntity
import com.example.data.local.AuditLogEntity
import com.example.data.local.FieldReportEntity
import com.example.data.local.IncidentEntity
import com.example.data.local.NERLogisticsDatabase
import com.example.data.local.VehicleEntity
import com.example.data.models.BroadcastAlert
import com.example.data.models.DeliveryStatus
import com.example.data.models.FieldIncidentReport
import com.example.data.models.GpsTelemetryPing
import com.example.data.models.IncidentSeverity
import com.example.data.models.IncidentStatus
import com.example.data.models.IncidentType
import com.example.data.models.LiveVehicle
import com.example.data.models.LiveWeatherPoint
import com.example.data.models.LocationPoint
import com.example.data.models.NERState
import com.example.data.models.RegionalRiskSummary
import com.example.data.models.RiskLevel
import com.example.data.models.RoadIncident
import com.example.data.models.RouteCandidate
import com.example.data.models.SystemAuditLog
import com.example.data.models.TerrainType
import com.example.data.models.UserRole
import com.example.data.models.VehicleStatus
import com.example.data.models.VehicleType
import com.example.data.remote.OpenMeteoClient
import com.example.engine.FleetSimulationEngine
import com.example.engine.GpsWebSocketManager
import com.example.engine.RiskEngine
import com.example.engine.RouteOptimizer
import com.example.engine.TelemetryMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.UUID

class NERLogisticsRepository(context: Context) {
    private val database = NERLogisticsDatabase.getDatabase(context)
    private val incidentDao = database.incidentDao()
    private val fieldReportDao = database.fieldReportDao()
    private val vehicleDao = database.vehicleDao()
    private val alertDao = database.alertDao()
    private val auditDao = database.auditDao()

    val tileCacheManager = com.example.engine.MapTileCacheManager(context)

    private val repositoryScope = CoroutineScope(Dispatchers.IO)

    // Real-Time GPS & WebSocket Manager
    val gpsWebSocketManager = GpsWebSocketManager { ping ->
        ingestGpsPing(ping)
    }

    // In-memory real-time state streams
    private val _weatherState = MutableStateFlow<List<LiveWeatherPoint>>(emptyList())
    val weatherState = _weatherState.asStateFlow()

    private val _regionalRiskSummaries = MutableStateFlow<List<RegionalRiskSummary>>(emptyList())
    val regionalRiskSummaries = _regionalRiskSummaries.asStateFlow()

    private val _isOfflineSimulated = MutableStateFlow(false)
    val isOfflineSimulated = _isOfflineSimulated.asStateFlow()

    private val _isSimulationRunning = MutableStateFlow(true)
    val isSimulationRunning = _isSimulationRunning.asStateFlow()

    private val _simulationSpeedMultiplier = MutableStateFlow(1)
    val simulationSpeedMultiplier = _simulationSpeedMultiplier.asStateFlow()

    init {
        repositoryScope.launch {
            seedInitialDataIfEmpty()
            refreshWeatherData()
            updateRegionalRiskSummaries()
        }
    }

    // --- Flow Mappers ---
    val allIncidents: Flow<List<RoadIncident>> = incidentDao.getAllIncidents().map { list ->
        list.map { it.toDomain() }
    }

    val allFieldReports: Flow<List<FieldIncidentReport>> = fieldReportDao.getAllFieldReports().map { list ->
        list.map { it.toDomain() }
    }

    val pendingOfflineReportsCount: Flow<Int> = fieldReportDao.getPendingOfflineReports().map { it.size }

    val allVehicles: Flow<List<LiveVehicle>> = vehicleDao.getAllVehicles().map { list ->
        list.map { it.toDomain() }
    }

    val allAlerts: Flow<List<BroadcastAlert>> = alertDao.getAllAlerts().map { list ->
        list.map { it.toDomain() }
    }

    val recentAuditLogs: Flow<List<SystemAuditLog>> = auditDao.getRecentAuditLogs().map { list ->
        list.map { it.toDomain() }
    }

    // --- Core Operations ---

    suspend fun reportIncidentFromField(report: FieldIncidentReport) {
        val reportEntity = report.toEntity(isOfflinePending = _isOfflineSimulated.value)
        fieldReportDao.insertReport(reportEntity)

        // If high severity, also create active road incident and broadcast alert
        val incidentId = "INC_${UUID.randomUUID().toString().take(6).uppercase()}"
        val incidentEntity = IncidentEntity(
            id = incidentId,
            title = "${report.incidentType.label} near ${report.locationName}",
            typeName = report.incidentType.name,
            severityName = report.severity.name,
            latitude = report.latitude,
            longitude = report.longitude,
            locationName = report.locationName,
            stateCode = report.state.name,
            corridorName = "Regional Corridor (${report.state.shortCode})",
            description = report.notes,
            reportedBy = report.reporterName,
            reportedRole = report.reporterRole.name,
            reportedTimestamp = System.currentTimeMillis(),
            isVerified = report.reporterRole == UserRole.FIELD_OFFICER,
            statusName = if (report.reporterRole == UserRole.FIELD_OFFICER) IncidentStatus.VERIFIED_CLEARING.name else IncidentStatus.ACTIVE.name,
            clearanceEtaHours = report.estimatedClearanceHours,
            affectedVehiclesCount = if (report.severity == IncidentSeverity.CRITICAL_BLOCKAGE) 8 else 2
        )
        incidentDao.insertIncident(incidentEntity)

        // Log audit
        auditDao.insertLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                action = "INCIDENT_REPORTED",
                performedBy = report.reporterName,
                roleName = report.reporterRole.name,
                timestamp = System.currentTimeMillis(),
                details = "Reported ${report.incidentType.label} at ${report.locationName} (${if (_isOfflineSimulated.value) "Queued Offline" else "Live Synced"})"
            )
        )
    }

    suspend fun syncOfflineReports() {
        fieldReportDao.markAllSynced()
        auditDao.insertLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                action = "OFFLINE_REPORTS_SYNCED",
                performedBy = "Command Sync Engine",
                roleName = UserRole.ADMIN.name,
                timestamp = System.currentTimeMillis(),
                details = "Successfully synchronized all local offline field reports with Command Center."
            )
        )
    }

    suspend fun updateIncidentStatus(incidentId: String, newStatus: IncidentStatus) {
        incidentDao.updateStatus(incidentId, newStatus.name)
        auditDao.insertLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                action = "INCIDENT_STATUS_UPDATED",
                performedBy = "Command Center Operator",
                roleName = UserRole.LOGISTICS_OPERATOR.name,
                timestamp = System.currentTimeMillis(),
                details = "Incident $incidentId status changed to ${newStatus.label}"
            )
        )
    }

    suspend fun broadcastEmergencyAlert(
        title: String,
        description: String,
        severity: RiskLevel,
        affectedCorridor: String,
        state: NERState
    ) {
        val alert = AlertEntity(
            id = "ALT_${UUID.randomUUID().toString().take(6).uppercase()}",
            title = title,
            description = description,
            severityName = severity.name,
            affectedCorridor = affectedCorridor,
            stateCode = state.name,
            timestamp = System.currentTimeMillis(),
            isBroadcastActive = true
        )
        alertDao.insertAlert(alert)
        auditDao.insertLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                action = "EMERGENCY_BROADCAST",
                performedBy = "Lead Logistics Commander",
                roleName = UserRole.ADMIN.name,
                timestamp = System.currentTimeMillis(),
                details = "Broadcast alert '$title' for $affectedCorridor"
            )
        )
    }

    fun setSimulationOffline(isOffline: Boolean) {
        _isOfflineSimulated.value = isOffline
        tileCacheManager.setForceOffline(isOffline)
    }

    fun setSimulationSpeed(speed: Int) {
        _simulationSpeedMultiplier.value = speed
    }

    /**
     * Hackathon Simulation Trigger: Injects a major landslide on NH-6 Sonapur Tunnel
     * and automatically sets fleet rerouting in motion!
     */
    suspend fun triggerSimulationLandslideNH6() {
        val id = "SIM_LANDSLIDE_NH6"
        val incident = IncidentEntity(
            id = id,
            title = "CRITICAL: Major Landslide Blockage at Sonapur Tunnel",
            typeName = IncidentType.LANDSLIDE.name,
            severityName = IncidentSeverity.CRITICAL_BLOCKAGE.name,
            latitude = 25.1852,
            longitude = 92.3562,
            locationName = "Sonapur Tunnel Ghat (NH-6)",
            stateCode = NERState.MEGHALAYA.name,
            corridorName = "NH-6 Meghalaya-Barak Corridor",
            description = "Massive mud slurry and boulder landslide covering 120m roadway. Estimated 8+ hours to clear. Total blockade of NH-6.",
            reportedBy = "BRO Project Pushpak Unit",
            reportedRole = UserRole.FIELD_OFFICER.name,
            reportedTimestamp = System.currentTimeMillis(),
            isVerified = true,
            statusName = IncidentStatus.VERIFIED_CLEARING.name,
            clearanceEtaHours = 8.5,
            affectedVehiclesCount = 14
        )
        incidentDao.insertIncident(incident)

        // Reroute vehicles on NH-6
        val vehicles = listOf(
            VehicleEntity(
                id = "VEH_01",
                vehicleNumber = "AS-01-GC-4921",
                driverName = "Biplab Das",
                driverPhone = "+91 94350 11223",
                vehicleTypeName = VehicleType.COLD_CHAIN_MED.name,
                cargoDescription = "Critical Medical Insulin & Vaccine Kits",
                isEmergencyPriority = true,
                currentLat = 25.6800,
                currentLng = 92.1200,
                speedKmH = 45,
                headingDegrees = 110f,
                altitudeMeters = 840,
                fuelLevelPct = 78,
                statusName = VehicleStatus.REROUTING.name,
                activeRouteName = "Diverting via Haflong (NH-27)",
                originName = "Guwahati",
                destinationName = "Silchar Valley",
                etaMinutes = 320,
                signalStatus = "4G Live Reroute"
            )
        )
        vehicleDao.insertVehicles(vehicles)

        broadcastEmergencyAlert(
            title = "EMERGENCY REROUTE ADVISORY: NH-6 Blocked at Sonapur",
            description = "All transit between Guwahati and Silchar/Tripura must divert immediately via NH-27 Haflong Expressway.",
            severity = RiskLevel.CRITICAL,
            affectedCorridor = "NH-6 Sonapur Sector",
            state = NERState.MEGHALAYA
        )
    }

    suspend fun clearSimulationLandslideNH6() {
        incidentDao.deleteIncident("SIM_LANDSLIDE_NH6")
        broadcastEmergencyAlert(
            title = "CORRIDOR RESTORED: NH-6 Sonapur Tunnel Cleared",
            description = "BRO Project Pushpak has cleared the debris. Regular convoy transit on NH-6 has resumed.",
            severity = RiskLevel.LOW,
            affectedCorridor = "NH-6 Sonapur Sector",
            state = NERState.MEGHALAYA
        )
    }

    /**
     * Hackathon Demo Trigger: Injects critical rockfall blockage on NH-13 Bhalukpong Ghat
     * along the Guwahati -> Tawang medical supply corridor and triggers dynamic rerouting!
     */
    suspend fun triggerSimulationLandslideTawang() {
        val id = "SIM_LANDSLIDE_TWG"
        val incident = IncidentEntity(
            id = id,
            title = "CRITICAL: Major Rockfall Blockage on NH-13 at Bhalukpong Ghat",
            typeName = IncidentType.LANDSLIDE.name,
            severityName = IncidentSeverity.CRITICAL_BLOCKAGE.name,
            latitude = 27.0125,
            longitude = 92.6450,
            locationName = "Bhalukpong Ghat (NH-13 Km 42)",
            stateCode = NERState.ARUNACHAL_PRADESH.name,
            corridorName = "NH-13 Bhalukpong-Bomdila Corridor",
            description = "Massive rockfall and debris flow of 4,200 m³ blocking both highway lanes after heavy monsoon rain. Sela Tunnel passage obstructed via primary corridor. Clearance ETA 6.5 hours.",
            reportedBy = "BRO Project Vartak (Border Roads)",
            reportedRole = UserRole.FIELD_OFFICER.name,
            reportedTimestamp = System.currentTimeMillis(),
            isVerified = true,
            statusName = IncidentStatus.VERIFIED_CLEARING.name,
            clearanceEtaHours = 6.5,
            affectedVehiclesCount = 6
        )
        incidentDao.insertIncident(incident)

        // Reroute V-102 (Medical shipment) to Bhairabkunda bypass
        val existingEntities = vehicleDao.getAllVehicles().firstOrNull() ?: emptyList()
        val currentVehicles = existingEntities.map { it.toDomain() }
        val reroutedVehicles = FleetSimulationEngine.rerouteVehicleToTawangBypass(currentVehicles, "V-102")
        vehicleDao.insertVehicles(reroutedVehicles.map { it.toEntity() })

        broadcastEmergencyAlert(
            title = "CRITICAL ADVISORY: NH-13 Blocked at Bhalukpong Ghat",
            description = "Massive rockfall on NH-13. Guwahati to Tawang medical and ration convoys must divert via Bhairabkunda - Rupa Bypass.",
            severity = RiskLevel.CRITICAL,
            affectedCorridor = "NH-13 Bhalukpong Sector",
            state = NERState.ARUNACHAL_PRADESH
        )

        auditDao.insertLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                action = "SIMULATED_BLOCKAGE_TRIGGERED",
                performedBy = "Demo Controller",
                roleName = UserRole.ADMIN.name,
                timestamp = System.currentTimeMillis(),
                details = "Simulated 4,200 m³ rockfall blockage at Bhalukpong Ghat on NH-13. Medical convoys rerouted to Bhairabkunda bypass."
            )
        )
    }

    suspend fun clearSimulationLandslideTawang() {
        incidentDao.deleteIncident("SIM_LANDSLIDE_TWG")
        broadcastEmergencyAlert(
            title = "CORRIDOR RESTORED: NH-13 Bhalukpong Ghat Cleared",
            description = "BRO Project Vartak has cleared the debris. Guwahati-Tawang transit via NH-13 Sela Tunnel resumed.",
            severity = RiskLevel.LOW,
            affectedCorridor = "NH-13 Bhalukpong Sector",
            state = NERState.ARUNACHAL_PRADESH
        )
    }

    suspend fun deleteIncident(id: String) {
        incidentDao.deleteIncident(id)
    }

    fun startSimulation() {
        _isSimulationRunning.value = true
    }

    fun pauseSimulation() {
        _isSimulationRunning.value = false
    }

    suspend fun resetSimulation() {
        _isSimulationRunning.value = true
        val initialVehicles = FleetSimulationEngine.getInitialVehicles().map { it.toEntity() }
        vehicleDao.deleteAllVehicles()
        vehicleDao.insertVehicles(initialVehicles)

        auditDao.insertLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                action = "SIMULATION_RESET",
                performedBy = "Demo Controller",
                roleName = UserRole.ADMIN.name,
                timestamp = System.currentTimeMillis(),
                details = "Reset all 6 fleet vehicle positions, routes, and deviations to origin state."
            )
        )
    }

    /**
     * Advances simulated vehicles along their real geographic corridors.
     */
    suspend fun tickFleetSimulation() {
        if (!_isSimulationRunning.value) return

        val speedMult = _simulationSpeedMultiplier.value
        val existingEntities = vehicleDao.getAllVehicles().firstOrNull() ?: emptyList()
        val currentVehicles = if (existingEntities.isEmpty()) {
            FleetSimulationEngine.getInitialVehicles()
        } else {
            existingEntities.map { it.toDomain() }
        }

        val activeIncidents = incidentDao.getAllIncidents().firstOrNull()?.map { it.toDomain() } ?: emptyList()

        val updatedVehicles = FleetSimulationEngine.tickSimulatedVehicles(
            currentVehicles = currentVehicles,
            activeIncidents = activeIncidents,
            speedMultiplier = speedMult
        )

        // Save updated positions to Room
        vehicleDao.insertVehicles(updatedVehicles.map { it.toEntity() })

        // Broadcast telemetry ping for each vehicle over WebSocket channel
        updatedVehicles.forEach { v ->
            val ping = GpsTelemetryPing(
                vehicleId = v.id,
                latitude = v.currentLat,
                longitude = v.currentLng,
                speedKmH = v.speedKmH,
                headingDegrees = v.headingDegrees,
                altitudeMeters = v.altitudeMeters,
                timestamp = v.lastUpdateTimestamp,
                isRealGps = !v.isSimulated
            )
            gpsWebSocketManager.broadcastVehicleTelemetry(ping)
        }
    }

    /**
     * Demo Action: Triggers route deviation on a vehicle, moving it 4.6km off-course.
     */
    suspend fun triggerVehicleDeviation(vehicleId: String = "V-102") {
        val existingEntities = vehicleDao.getAllVehicles().firstOrNull() ?: emptyList()
        val currentVehicles = existingEntities.map { it.toDomain() }
        val deviatedList = FleetSimulationEngine.triggerVehicleDeviation(currentVehicles, vehicleId)

        vehicleDao.insertVehicles(deviatedList.map { it.toEntity() })

        val target = deviatedList.find { it.id == vehicleId }
        val devDist = target?.deviationDistanceKm ?: 4.6

        // Broadcast critical deviation alert
        broadcastEmergencyAlert(
            title = "ROUTE DEVIATION ALERT: Vehicle $vehicleId",
            description = "Vehicle $vehicleId (${target?.vehicleNumber ?: "AR-02-B-8812"}) has deviated from planned route corridor by ${String.format("%.1f", devDist)} km.",
            severity = RiskLevel.CRITICAL,
            affectedCorridor = target?.activeRouteName ?: "NH-13 Sela Corridor",
            state = NERState.ARUNACHAL_PRADESH
        )

        auditDao.insertLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                action = "ROUTE_DEVIATION_TRIGGERED",
                performedBy = "Simulated GPS Engine",
                roleName = UserRole.LOGISTICS_OPERATOR.name,
                timestamp = System.currentTimeMillis(),
                details = "Vehicle $vehicleId deviated ${String.format("%.1f", devDist)} km off planned corridor."
            )
        )
    }

    suspend fun clearVehicleDeviation(vehicleId: String = "V-102") {
        val existingEntities = vehicleDao.getAllVehicles().firstOrNull() ?: emptyList()
        val currentVehicles = existingEntities.map { it.toDomain() }
        val restoredList = FleetSimulationEngine.clearVehicleDeviation(currentVehicles, vehicleId)

        vehicleDao.insertVehicles(restoredList.map { it.toEntity() })

        broadcastEmergencyAlert(
            title = "ROUTE RESTORED: Vehicle $vehicleId Returned to Corridor",
            description = "Vehicle $vehicleId has realigned with its designated highway route coordinates.",
            severity = RiskLevel.LOW,
            affectedCorridor = "NH-13 Sela Corridor",
            state = NERState.ARUNACHAL_PRADESH
        )
    }

    /**
     * Demo Action: Simulates heavy monsoon downpour (95mm) across NER
     */
    suspend fun simulateHeavyMonsoonRain() {
        val severeWeather = _weatherState.value.map { w ->
            w.copy(
                precipitationMm = 95.0,
                humidityPct = 98,
                landslideEarlyWarning = "CRITICAL: Severe Slope Soil Liquefaction Alert",
                floodRiskColorHex = 0xFFE63946,
                conditionDescription = "Monsoon Cloudburst (>90mm/hr)"
            )
        }
        _weatherState.value = severeWeather
        updateRegionalRiskSummaries()

        broadcastEmergencyAlert(
            title = "REGIONAL WEATHER EMERGENCY: Heavy Cloudburst Alert",
            description = "IMD issues Red Warning: 95mm/hr torrential cloudburst over Brahmaputra Basin & Meghalaya Ghats. Landslide and flash-flood susceptibility elevated to CRITICAL across all corridors.",
            severity = RiskLevel.CRITICAL,
            affectedCorridor = "All NER Highways (NH-6, NH-27, NH-13, NH-37)",
            state = NERState.ASSAM
        )

        auditDao.insertLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                action = "WEATHER_SIMULATION_TRIGGERED",
                performedBy = "Disaster Demo Console",
                roleName = UserRole.ADMIN.name,
                timestamp = System.currentTimeMillis(),
                details = "Simulated 95mm/hr heavy rainfall cloudburst across all 8 NER states."
            )
        )
    }

    /**
     * Ingests real-world GPS ping packet from external hardware or WebSocket stream.
     */
    suspend fun ingestGpsPing(ping: GpsTelemetryPing) {
        val existing = vehicleDao.getVehicleById(ping.vehicleId)
        if (existing != null) {
            val corridor = FleetSimulationEngine.CORRIDORS.find { it.vehicleId == ping.vehicleId }
            val devResult = if (corridor != null) {
                FleetSimulationEngine.checkRouteDeviation(ping.latitude, ping.longitude, corridor.waypoints)
            } else {
                com.example.engine.DeviationResult(false, 0.0)
            }

            val deliveryStatus = if (devResult.hasDeviated) DeliveryStatus.AT_RISK else DeliveryStatus.ON_TIME

            val updated = existing.copy(
                currentLat = ping.latitude,
                currentLng = ping.longitude,
                speedKmH = ping.speedKmH,
                headingDegrees = ping.headingDegrees,
                altitudeMeters = ping.altitudeMeters,
                isSimulated = !ping.isRealGps,
                hasDeviated = devResult.hasDeviated,
                deviationDistanceKm = devResult.deviationDistanceKm,
                deliveryStatusName = deliveryStatus.name,
                lastUpdateTimestamp = ping.timestamp
            )
            vehicleDao.insertVehicle(updated)

            if (devResult.hasDeviated) {
                broadcastEmergencyAlert(
                    title = "ROUTE DEVIATION: Vehicle ${ping.vehicleId}",
                    description = "Live GPS ping indicates Vehicle ${ping.vehicleId} has deviated ${String.format("%.1f", devResult.deviationDistanceKm)} km from corridor.",
                    severity = RiskLevel.CRITICAL,
                    affectedCorridor = updated.activeRouteName,
                    state = NERState.ASSAM
                )
            }
        }
    }

    fun ingestRawGpsJson(jsonText: String) {
        gpsWebSocketManager.handleIncomingRawJson(jsonText, false)
    }

    suspend fun refreshWeatherData() {
        val targets = listOf(
            Pair(RouteOptimizer.getLocationById("GHY"), "Clear Valley"),
            Pair(RouteOptimizer.getLocationById("SHL"), "Highland Rain"),
            Pair(RouteOptimizer.getLocationById("TWG"), "Alpine Fog & Snow"),
            Pair(RouteOptimizer.getLocationById("SLR"), "Tropical Downpour"),
            Pair(RouteOptimizer.getLocationById("IMP"), "Overcast Sky"),
            Pair(RouteOptimizer.getLocationById("DMP"), "Humid Plains"),
            Pair(RouteOptimizer.getLocationById("GTK"), "Mountain Drizzle"),
            Pair(RouteOptimizer.getLocationById("AGT"), "Partly Cloudy")
        )

        val weatherList = mutableListOf<LiveWeatherPoint>()

        for ((loc, conditionFallback) in targets) {
            try {
                val resp = OpenMeteoClient.service.getCurrentWeather(loc.latitude, loc.longitude)
                val curr = resp.current
                val temp = curr?.temperature2m ?: 24.0
                val precip = curr?.precipitation ?: (if (loc.terrainType == TerrainType.HILLY_GHAT) 14.5 else 4.0)
                val humidity = curr?.relativeHumidity2m ?: 78
                val wind = curr?.windSpeed10m ?: 12.0

                val landslideWarning = when {
                    precip > 20.0 && loc.terrainType == TerrainType.HILLY_GHAT -> "HIGH: Slope Saturation Alert"
                    precip > 10.0 -> "MODERATE: Monitor Ghat Curves"
                    else -> "STABLE: Standard Hill Clearance"
                }

                val floodColor = when {
                    precip > 30.0 -> 0xFFE63946
                    precip > 15.0 -> 0xFFFFB703
                    else -> 0xFF06D6A0
                }

                weatherList.add(
                    LiveWeatherPoint(
                        locationName = loc.name,
                        state = loc.state,
                        latitude = loc.latitude,
                        longitude = loc.longitude,
                        tempC = temp,
                        conditionDescription = if (precip > 15.0) "Heavy Mountain Rain" else if (precip > 5.0) "Scattered Rain" else conditionFallback,
                        precipitationMm = precip,
                        windSpeedKmH = wind,
                        humidityPct = humidity,
                        visibilityKm = if (precip > 15.0) 3.5 else 8.5,
                        rainfall24hMm = precip * 3.5 + 12.0,
                        landslideEarlyWarning = landslideWarning,
                        floodRiskColorHex = floodColor
                    )
                )
            } catch (e: Exception) {
                // Graceful fallback with deterministic domain realism for NER
                weatherList.add(
                    LiveWeatherPoint(
                        locationName = loc.name,
                        state = loc.state,
                        latitude = loc.latitude,
                        longitude = loc.longitude,
                        tempC = if (loc.altitudeMeters > 2000) 12.5 else 25.0,
                        conditionDescription = conditionFallback,
                        precipitationMm = if (loc.state == NERState.MEGHALAYA) 28.0 else 8.5,
                        windSpeedKmH = 14.0,
                        humidityPct = 82,
                        visibilityKm = 6.0,
                        rainfall24hMm = if (loc.state == NERState.MEGHALAYA) 64.0 else 22.0,
                        landslideEarlyWarning = if (loc.state == NERState.MEGHALAYA) "HIGH: East Jaintia Hills Warning" else "MODERATE: Precautionary Watch",
                        floodRiskColorHex = if (loc.state == NERState.MEGHALAYA) 0xFFFFB703 else 0xFF06D6A0
                    )
                )
            }
        }
        _weatherState.value = weatherList
    }

    private fun updateRegionalRiskSummaries() {
        val list = NERState.values().map { state ->
            val accessibility = when (state) {
                NERState.ASSAM -> 92
                NERState.MEGHALAYA -> 74
                NERState.ARUNACHAL_PRADESH -> 81
                NERState.NAGALAND -> 86
                NERState.MANIPUR -> 78
                NERState.MIZORAM -> 83
                NERState.TRIPURA -> 95
                NERState.SIKKIM -> 79
                else -> 88
            }

            val landslides = when (state) {
                NERState.MEGHALAYA -> 3
                NERState.ARUNACHAL_PRADESH -> 2
                NERState.SIKKIM -> 2
                NERState.MANIPUR -> 1
                else -> 0
            }

            val floodInundations = when (state) {
                NERState.ASSAM -> 4
                NERState.MEGHALAYA -> 1
                else -> 0
            }

            val avgDelay = when (state) {
                NERState.MEGHALAYA -> 95
                NERState.MANIPUR -> 80
                NERState.ARUNACHAL_PRADESH -> 65
                else -> 25
            }

            val overallRisk = when {
                accessibility < 75 -> RiskLevel.HIGH
                accessibility < 85 -> RiskLevel.MODERATE
                else -> RiskLevel.LOW
            }

            val roadStatus = when (state) {
                NERState.ASSAM -> "NH-27 4-Lane Fully Clear | Kaziranga animal corridor speed limits active"
                NERState.MEGHALAYA -> "NH-6 Sonapur Ghat caution | Moderate mud slurry near Jowai"
                NERState.ARUNACHAL_PRADESH -> "Sela Tunnel pass open | Fog warning at Jaswant Garh"
                NERState.NAGALAND -> "NH-29 Chumukedima 4-lane clear | Kohima town traffic moderate"
                NERState.MANIPUR -> "NH-37 Makru bridge operational | Security convoy escort active"
                NERState.MIZORAM -> "NH-54 Aizawl-Lunglei single lane ghats clear"
                NERState.TRIPURA -> "NH-8 Churaibari border checkpoint flowing smoothly"
                NERState.SIKKIM -> "NH-10 Teesta riverbank monitored | Alternate via Lava open"
                else -> "National highway connectivity operational | All lanes active"
            }

            RegionalRiskSummary(
                state = state,
                accessibilityIndex = accessibility,
                activeLandslideAlerts = landslides,
                floodInundatedCorridors = floodInundations,
                averageDelayMin = avgDelay,
                overallRiskLevel = overallRisk,
                keyRoadStatus = roadStatus
            )
        }
        _regionalRiskSummaries.value = list
    }

    private suspend fun seedInitialDataIfEmpty() {
        val initialIncidents = listOf(
            IncidentEntity(
                id = "INC_001",
                title = "Mud Slurry Inflow near Sonapur Tunnel",
                typeName = IncidentType.HEAVY_MUD_SLIP.name,
                severityName = IncidentSeverity.MODERATE.name,
                latitude = 25.1852,
                longitude = 92.3562,
                locationName = "Sonapur Tunnel, NH-6",
                stateCode = NERState.MEGHALAYA.name,
                corridorName = "NH-6 Shillong-Silchar Corridor",
                description = "Heavy rain caused 30m mud slurry across right lane. Traffic moving in alternating single-lane batches.",
                reportedBy = "Officer Sangma (Meghalaya Police)",
                reportedRole = UserRole.FIELD_OFFICER.name,
                reportedTimestamp = System.currentTimeMillis() - 3600000 * 3,
                isVerified = true,
                statusName = IncidentStatus.VERIFIED_CLEARING.name,
                clearanceEtaHours = 2.5,
                affectedVehiclesCount = 4
            ),
            IncidentEntity(
                id = "INC_002",
                title = "Flash Waterlogging on NH-27 Morigaon Bypass",
                typeName = IncidentType.FLASH_FLOOD.name,
                severityName = IncidentSeverity.MINOR.name,
                latitude = 26.2480,
                longitude = 92.3420,
                locationName = "Morigaon Link, NH-27",
                stateCode = NERState.ASSAM.name,
                corridorName = "NH-27 East-West Expressway",
                description = "Water depth ~15cm along service lane. Main carriageway clear for heavy commercial vehicles.",
                reportedBy = "Citizen CitizenReport#104",
                reportedRole = UserRole.DRIVER.name,
                reportedTimestamp = System.currentTimeMillis() - 3600000 * 5,
                isVerified = true,
                statusName = IncidentStatus.ACTIVE.name,
                clearanceEtaHours = 1.0,
                affectedVehiclesCount = 1
            ),
            IncidentEntity(
                id = "INC_003",
                title = "Rockfall Warning on Bhalukpong-Dirang Ascent",
                typeName = IncidentType.LANDSLIDE.name,
                severityName = IncidentSeverity.MODERATE.name,
                latitude = 27.2400,
                longitude = 92.4100,
                locationName = "Dirang Ghats, NH-13",
                stateCode = NERState.ARUNACHAL_PRADESH.name,
                corridorName = "NH-13 Trans-Arunachal Highway",
                description = "Small boulder fall cleared to shoulder by BRO JCB. Spotters posted for loose rock monitoring.",
                reportedBy = "BRO Project Vartak Spotter",
                reportedRole = UserRole.FIELD_OFFICER.name,
                reportedTimestamp = System.currentTimeMillis() - 3600000 * 8,
                isVerified = true,
                statusName = IncidentStatus.VERIFIED_CLEARING.name,
                clearanceEtaHours = 1.5,
                affectedVehiclesCount = 2
            )
        )
        incidentDao.insertIncidents(initialIncidents)

        // Seed initial vehicles
        tickFleetSimulation()

        // Seed alerts
        val initialAlerts = listOf(
            AlertEntity(
                id = "ALT_001",
                title = "Monsoon Yellow Alert: Meghalaya & Barak Valley",
                description = "IMD predicts heavy to very heavy precipitation (>90mm) over next 24 hours. Logistics operators advised to avoid nighttime ghat transit.",
                severityName = RiskLevel.HIGH.name,
                affectedCorridor = "NH-6 & NH-37 Corridors",
                stateCode = NERState.MEGHALAYA.name,
                timestamp = System.currentTimeMillis() - 7200000,
                isBroadcastActive = true
            ),
            AlertEntity(
                id = "ALT_002",
                title = "High-Altitude Sela Pass Operational Notice",
                description = "Sela Tunnel (Twin Tube) functioning smoothly. Sub-zero temperatures (-2°C) at pass approach; black ice caution for loaded trailers.",
                severityName = RiskLevel.LOW.name,
                affectedCorridor = "NH-13 Tawang Highway",
                stateCode = NERState.ARUNACHAL_PRADESH.name,
                timestamp = System.currentTimeMillis() - 14400000,
                isBroadcastActive = true
            )
        )
        alertDao.insertAlerts(initialAlerts)

        // Seed audit logs
        auditDao.insertLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                action = "SYSTEM_INITIALIZED",
                performedBy = "SIH26002 Bootstrapper",
                roleName = UserRole.ADMIN.name,
                timestamp = System.currentTimeMillis(),
                details = "NER LogiGuard platform initialized with 8 state nodes, GIS topography, and real-time risk engines."
            )
        )
    }

    // Entity converters
    private fun IncidentEntity.toDomain(): RoadIncident {
        val type = try { IncidentType.valueOf(typeName) } catch (e: Exception) { IncidentType.LANDSLIDE }
        val severity = try { IncidentSeverity.valueOf(severityName) } catch (e: Exception) { IncidentSeverity.MODERATE }
        val state = try { NERState.valueOf(stateCode) } catch (e: Exception) { NERState.ASSAM }
        val status = try { IncidentStatus.valueOf(statusName) } catch (e: Exception) { IncidentStatus.ACTIVE }
        val role = try { UserRole.valueOf(reportedRole) } catch (e: Exception) { UserRole.FIELD_OFFICER }

        return RoadIncident(
            id = id,
            title = title,
            type = type,
            severity = severity,
            latitude = latitude,
            longitude = longitude,
            locationName = locationName,
            state = state,
            corridorName = corridorName,
            description = description,
            reportedBy = reportedBy,
            reportedRole = role,
            reportedTimestamp = reportedTimestamp,
            isVerified = isVerified,
            status = status,
            clearanceEtaHours = clearanceEtaHours,
            affectedVehiclesCount = affectedVehiclesCount
        )
    }

    private fun FieldReportEntity.toDomain(): FieldIncidentReport {
        val type = try { IncidentType.valueOf(incidentTypeName) } catch (e: Exception) { IncidentType.LANDSLIDE }
        val severity = try { IncidentSeverity.valueOf(severityName) } catch (e: Exception) { IncidentSeverity.MODERATE }
        val state = try { NERState.valueOf(stateCode) } catch (e: Exception) { NERState.ASSAM }
        val role = try { UserRole.valueOf(reporterRole) } catch (e: Exception) { UserRole.FIELD_OFFICER }

        return FieldIncidentReport(
            id = id,
            reporterName = reporterName,
            reporterPhone = reporterPhone,
            reporterRole = role,
            incidentType = type,
            severity = severity,
            locationName = locationName,
            state = state,
            latitude = latitude,
            longitude = longitude,
            roadBlockagePct = roadBlockagePct,
            estimatedClearanceHours = estimatedClearanceHours,
            notes = notes,
            isOfflinePending = isOfflinePending,
            timestamp = timestamp
        )
    }

    private fun FieldIncidentReport.toEntity(isOfflinePending: Boolean): FieldReportEntity {
        return FieldReportEntity(
            id = id,
            reporterName = reporterName,
            reporterPhone = reporterPhone,
            reporterRole = reporterRole.name,
            incidentTypeName = incidentType.name,
            severityName = severity.name,
            locationName = locationName,
            stateCode = state.name,
            latitude = latitude,
            longitude = longitude,
            roadBlockagePct = roadBlockagePct,
            estimatedClearanceHours = estimatedClearanceHours,
            notes = notes,
            isOfflinePending = isOfflinePending,
            timestamp = timestamp
        )
    }

    private fun VehicleEntity.toDomain(): LiveVehicle {
        val type = try { VehicleType.valueOf(vehicleTypeName) } catch (e: Exception) { VehicleType.HEAVY_TRUCK_16T }
        val status = try { VehicleStatus.valueOf(statusName) } catch (e: Exception) { VehicleStatus.IN_TRANSIT }
        val delStatus = try { DeliveryStatus.valueOf(deliveryStatusName) } catch (e: Exception) { DeliveryStatus.ON_TIME }

        return LiveVehicle(
            id = id,
            vehicleNumber = vehicleNumber,
            driverName = driverName,
            driverPhone = driverPhone,
            type = type,
            cargoDescription = cargoDescription,
            isEmergencyPriority = isEmergencyPriority,
            currentLat = currentLat,
            currentLng = currentLng,
            speedKmH = speedKmH,
            headingDegrees = headingDegrees,
            altitudeMeters = altitudeMeters,
            fuelLevelPct = fuelLevelPct,
            status = status,
            deliveryStatus = delStatus,
            activeRouteName = activeRouteName,
            originName = originName,
            destinationName = destinationName,
            etaMinutes = etaMinutes,
            signalStatus = signalStatus,
            isSimulated = isSimulated,
            hasDeviated = hasDeviated,
            deviationDistanceKm = deviationDistanceKm,
            lastUpdateTimestamp = lastUpdateTimestamp,
            waypointIndex = waypointIndex
        )
    }

    private fun LiveVehicle.toEntity(): VehicleEntity {
        return VehicleEntity(
            id = id,
            vehicleNumber = vehicleNumber,
            driverName = driverName,
            driverPhone = driverPhone,
            vehicleTypeName = type.name,
            cargoDescription = cargoDescription,
            isEmergencyPriority = isEmergencyPriority,
            currentLat = currentLat,
            currentLng = currentLng,
            speedKmH = speedKmH,
            headingDegrees = headingDegrees,
            altitudeMeters = altitudeMeters,
            fuelLevelPct = fuelLevelPct,
            statusName = status.name,
            deliveryStatusName = deliveryStatus.name,
            activeRouteName = activeRouteName,
            originName = originName,
            destinationName = destinationName,
            etaMinutes = etaMinutes,
            signalStatus = signalStatus,
            isSimulated = isSimulated,
            hasDeviated = hasDeviated,
            deviationDistanceKm = deviationDistanceKm,
            lastUpdateTimestamp = lastUpdateTimestamp,
            waypointIndex = waypointIndex
        )
    }

    private fun AlertEntity.toDomain(): BroadcastAlert {
        val severity = try { RiskLevel.valueOf(severityName) } catch (e: Exception) { RiskLevel.MODERATE }
        val state = try { NERState.valueOf(stateCode) } catch (e: Exception) { NERState.ASSAM }

        return BroadcastAlert(
            id = id,
            title = title,
            description = description,
            severity = severity,
            affectedCorridor = affectedCorridor,
            state = state,
            timestamp = timestamp,
            isBroadcastActive = isBroadcastActive
        )
    }

    private fun AuditLogEntity.toDomain(): SystemAuditLog {
        val role = try { UserRole.valueOf(roleName) } catch (e: Exception) { UserRole.ADMIN }
        return SystemAuditLog(
            id = id,
            action = action,
            performedBy = performedBy,
            role = role,
            timestamp = timestamp,
            details = details
        )
    }
}
