package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        IncidentEntity::class,
        FieldReportEntity::class,
        VehicleEntity::class,
        AlertEntity::class,
        AuditLogEntity::class,
        MapTileEntity::class,
        OfflineRoutePackageEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class NERLogisticsDatabase : RoomDatabase() {
    abstract fun incidentDao(): IncidentDao
    abstract fun fieldReportDao(): FieldReportDao
    abstract fun vehicleDao(): VehicleDao
    abstract fun alertDao(): AlertDao
    abstract fun auditDao(): AuditDao
    abstract fun mapTileDao(): MapTileDao
    abstract fun offlineRoutePackageDao(): OfflineRoutePackageDao


    companion object {
        @Volatile
        private var INSTANCE: NERLogisticsDatabase? = null

        fun getDatabase(context: Context): NERLogisticsDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NERLogisticsDatabase::class.java,
                    "ner_logistics_intel_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
