package com.example.data.models

enum class UserRole(
    val displayName: String,
    val description: String,
    val badgeColorHex: Long
) {
    LOGISTICS_OPERATOR("Logistics Operator", "Monitor routes, fleets & alerts", 0xFF1E88E5),
    COMMAND_CENTER("Command Center", "Monitor regional operations", 0xFF7C3AED),
    FLEET_MANAGER("Fleet Manager", "Track vehicles & convoy status", 0xFF0288D1),
    DISASTER_RESPONSE("Disaster Response", "Monitor hazards & emergency routes", 0xFFEA580C),
    FIELD_OFFICER("Field Officer", "Submit incidents & field reports", 0xFF059669),
    ADMIN("System Admin", "Full system control & audit logs", 0xFF8338EC),
    DRIVER("Fleet Driver", "Turn-by-turn hill advisory & SOS emergency alerts", 0xFFFFB703);

    companion object {
        val operationalRoles = listOf(
            LOGISTICS_OPERATOR,
            COMMAND_CENTER,
            FLEET_MANAGER,
            DISASTER_RESPONSE,
            FIELD_OFFICER
        )
    }
}

enum class NERState(val fullName: String, val shortCode: String, val capital: String, val baseVulnerability: Int) {
    // North Eastern States
    ASSAM("Assam", "AS", "Dispur", 58),
    MEGHALAYA("Meghalaya", "ML", "Shillong", 72),
    ARUNACHAL_PRADESH("Arunachal Pradesh", "AR", "Itanagar", 84),
    NAGALAND("Nagaland", "NL", "Kohima", 76),
    MANIPUR("Manipur", "MN", "Imphal", 68),
    MIZORAM("Mizoram", "MZ", "Aizawl", 74),
    TRIPURA("Tripura", "TR", "Agartala", 48),
    SIKKIM("Sikkim", "SK", "Gangtok", 80),

    // Other Indian States & Territories
    ANDHRA_PRADESH("Andhra Pradesh", "AP", "Amaravati", 45),
    BIHAR("Bihar", "BR", "Patna", 65),
    CHHATTISGARH("Chhattisgarh", "CG", "Raipur", 40),
    GOA("Goa", "GA", "Panaji", 35),
    GUJARAT("Gujarat", "GJ", "Gandhinagar", 40),
    HARYANA("Haryana", "HR", "Chandigarh", 30),
    HIMACHAL_PRADESH("Himachal Pradesh", "HP", "Shimla", 75),
    JHARKHAND("Jharkhand", "JH", "Ranchi", 45),
    KARNATAKA("Karnataka", "KA", "Bengaluru", 35),
    KERALA("Kerala", "KL", "Thiruvananthapuram", 55),
    MADHYA_PRADESH("Madhya Pradesh", "MP", "Bhopal", 35),
    MAHARASHTRA("Maharashtra", "MH", "Mumbai", 45),
    ODISHA("Odisha", "OD", "Bhubaneswar", 60),
    PUNJAB("Punjab", "PB", "Chandigarh", 30),
    RAJASTHAN("Rajasthan", "RJ", "Jaipur", 35),
    TAMIL_NADU("Tamil Nadu", "TN", "Chennai", 40),
    TELANGANA("Telangana", "TS", "Hyderabad", 35),
    UTTAR_PRADESH("Uttar Pradesh", "UP", "Lucknow", 45),
    UTTARAKHAND("Uttarakhand", "UK", "Dehradun", 78),
    WEST_BENGAL("West Bengal", "WB", "Kolkata", 55),
    DELHI("Delhi", "DL", "New Delhi", 30),
    JAMMU_AND_KASHMIR("Jammu & Kashmir", "JK", "Srinagar", 75),
    LADAKH("Ladakh", "LA", "Leh", 70),
    CHANDIGARH("Chandigarh", "CH", "Chandigarh", 25),
    PUDUCHERRY("Puducherry", "PY", "Puducherry", 30),
    ANDAMAN_AND_NICOBAR("Andaman & Nicobar", "AN", "Port Blair", 50),
    DADRA_AND_NAGAR_HAVELI("Dadra & Nagar Haveli and Daman & Diu", "DN", "Daman", 30),
    LAKSHADWEEP("Lakshadweep", "LD", "Kavaratti", 40),
    OTHER("India Regional", "IN", "Regional Hub", 35);

    companion object {
        fun fromStateName(name: String?): NERState {
            if (name.isNullOrBlank()) return ASSAM
            val clean = name.trim().lowercase()
            return entries.find {
                it.fullName.lowercase() == clean ||
                it.shortCode.lowercase() == clean ||
                clean.contains(it.fullName.lowercase()) ||
                it.fullName.lowercase().contains(clean)
            } ?: OTHER
        }
    }
}

enum class TerrainType(val label: String, val riskFactor: Double) {
    PLAINS("Alluvial Plains", 1.0),
    RIVER_BASIN("Floodplain Basin", 1.35),
    HILLY_GHAT("Steep Mountain Ghat", 1.65),
    HIGH_ALTITUDE_PASS("Alpine Pass (>2800m)", 2.10),
    FOREST_CORRIDOR("Dense Forest Reserve", 1.25)
}

enum class RiskLevel(val label: String, val colorHex: Long) {
    LOW("Low Risk", 0xFF06D6A0),
    MODERATE("Moderate Risk", 0xFFFFB703),
    HIGH("High Risk", 0xFFFB8500),
    CRITICAL("Critical Risk", 0xFFE63946)
}

enum class VehicleType(val title: String, val maxPayloadTons: Double) {
    HEAVY_TRUCK_16T("16-Ton Multi-Axle Truck", 16.0),
    COLD_CHAIN_MED("Cold-Chain Medical Van", 3.5),
    ALL_TERRAIN_4X4("4x4 High-Clearance Transporter", 4.0),
    FUEL_TANKER("Hazardous Fuel Tanker", 12.0)
}

enum class VehicleStatus(val label: String, val colorHex: Long) {
    IN_TRANSIT("On Schedule", 0xFF06D6A0),
    REROUTING("Dynamic Rerouting", 0xFF00E5FF),
    DELAYED_RISK("Weather / Hazard Hold", 0xFFFFB703),
    ARRIVED("Completed Delivery", 0xFF3A86FF),
    EMERGENCY_STOP("Emergency Alert Stopped", 0xFFE63946)
}

enum class DeliveryStatus(val label: String, val colorHex: Long, val badgeBackgroundHex: Long) {
    ON_TIME("ON TIME", 0xFF06D6A0, 0x3306D6A0),
    DELAYED("DELAYED", 0xFFFFB703, 0x33FFB703),
    AT_RISK("AT RISK", 0xFFE63946, 0x33E63946),
    DELIVERED("DELIVERED", 0xFF00E5FF, 0x3300E5FF)
}

enum class IncidentType(val label: String, val iconName: String) {
    LANDSLIDE("Major Landslide / Rockfall", "Terrain"),
    FLASH_FLOOD("Flash Flood / Road Submerged", "Water"),
    ROAD_SUBSIDENCE("Road Sinking / Mud Slump", "Warning"),
    BRIDGE_DAMAGE("Culvert / Bridge Weakened", "Construction"),
    HEAVY_MUD_SLIP("Heavy Mud Slurry Inflow", "Grain"),
    PROTEST_BLOCKADE("Local Strike / Road Blockade", "Block"),
    DENSE_FOG_AVALANCHE("Zero Visibility Fog / Snow", "Cloud")
}

enum class IncidentSeverity(val label: String, val priority: Int) {
    MINOR("Minor Delay (<30 min)", 1),
    MODERATE("Single Lane Blocked", 2),
    CRITICAL_BLOCKAGE("Total Corridor Blocked", 3)
}

enum class IncidentStatus(val label: String) {
    ACTIVE("Active / Unverified"),
    VERIFIED_CLEARING("Verified / Clearance In Progress"),
    DISPATCHING_CREW("SDRF / BRO Crew En Route"),
    RESOLVED_CLEAR("Resolved & Route Clear")
}

enum class AppLanguage(val code: String, val nativeName: String) {
    ENGLISH("en", "English"),
    HINDI("hi", "हिंदी"),
    ASSAMESE("as", "অসমীয়া"),
    BENGALI("bn", "বাংলা"),
    MANIPURI("mni", "মৈতৈলোন্")
}

data class LocationPoint(
    val id: String,
    val name: String,
    val state: NERState,
    val latitude: Double,
    val longitude: Double,
    val altitudeMeters: Int = 0,
    val terrainType: TerrainType = TerrainType.PLAINS,
    val formattedAddress: String = "",
    val stateName: String = state.fullName
)

data class RouteSegment(
    val id: String,
    val startPoint: LocationPoint,
    val endPoint: LocationPoint,
    val distanceKm: Double,
    val baseDurationMin: Int,
    val roadRoughnessIndex: Int, // 1-10
    val landslideHazardScore: Int, // 0-100
    val floodHazardScore: Int, // 0-100
    val currentIncidentsCount: Int
)

data class RouteCandidate(
    val id: String,
    val name: String,
    val corridorCode: String,
    val origin: LocationPoint,
    val destination: LocationPoint,
    val distanceKm: Double,
    val estimatedDurationMin: Int,
    val elevationGainM: Int,
    val weatherRiskScore: Int,
    val landslideRiskScore: Int,
    val floodRiskScore: Int,
    val roadConditionScore: Int,
    val incidentRiskScore: Int,
    val compositeRiskScore: Int,
    val riskLevel: RiskLevel,
    val routeScore: Int, // 0-100 (LOWER IS BETTER: 30% incident + 25% access + 20% weather + 15% ETA + 10% distance)
    val isRecommended: Boolean,
    val recommendationReason: String,
    val keyCheckpoints: List<String>,
    val segments: List<RouteSegment> = emptyList(),
    val polylineCoordinates: List<Pair<Double, Double>> = emptyList(),
    val affectedIncidents: List<String> = emptyList(),
    // Transparent factor scores (0-100)
    val accessibilityRiskScore: Int = 20,
    val etaRiskScore: Int = 30,
    val distanceRiskScore: Int = 25,
    val statusLabel: String = "RECOMMENDED", // "RECOMMENDED", "ALTERNATIVE", "HIGHER RISK", "AFFECTED", "BLOCKED / UNAVAILABLE"
    val whyNotRecommended: String? = null,
    val isBlocked: Boolean = false,
    val isSimulatedData: Boolean = true,
    val dataSourceLabel: String = "DEMO / SIMULATED TOPOLOGY"
)

data class LiveVehicle(
    val id: String,
    val vehicleNumber: String,
    val driverName: String,
    val driverPhone: String,
    val type: VehicleType,
    val cargoDescription: String,
    val isEmergencyPriority: Boolean,
    val currentLat: Double,
    val currentLng: Double,
    val speedKmH: Int,
    val headingDegrees: Float,
    val altitudeMeters: Int,
    val fuelLevelPct: Int,
    val status: VehicleStatus,
    val deliveryStatus: DeliveryStatus = DeliveryStatus.ON_TIME,
    val activeRouteName: String,
    val originName: String,
    val destinationName: String,
    val etaMinutes: Int,
    val signalStatus: String, // "4G/5G Live", "2G Degraded", "Offline Satellite"
    val isSimulated: Boolean = true,
    val hasDeviated: Boolean = false,
    val deviationDistanceKm: Double = 0.0,
    val lastUpdateTimestamp: Long = System.currentTimeMillis(),
    val waypointIndex: Int = 0
)

data class GpsTelemetryPing(
    val vehicleId: String,
    val latitude: Double,
    val longitude: Double,
    val speedKmH: Int,
    val headingDegrees: Float = 0f,
    val altitudeMeters: Int = 500,
    val timestamp: Long = System.currentTimeMillis(),
    val batteryPct: Int = 85,
    val isRealGps: Boolean = false
)

data class RoadIncident(
    val id: String,
    val title: String,
    val type: IncidentType,
    val severity: IncidentSeverity,
    val latitude: Double,
    val longitude: Double,
    val locationName: String,
    val state: NERState,
    val corridorName: String,
    val description: String,
    val reportedBy: String,
    val reportedRole: UserRole,
    val reportedTimestamp: Long,
    val isVerified: Boolean,
    val status: IncidentStatus,
    val clearanceEtaHours: Double,
    val affectedVehiclesCount: Int
)

data class FieldIncidentReport(
    val id: String,
    val reporterName: String,
    val reporterPhone: String,
    val reporterRole: UserRole,
    val incidentType: IncidentType,
    val severity: IncidentSeverity,
    val locationName: String,
    val state: NERState,
    val latitude: Double,
    val longitude: Double,
    val roadBlockagePct: Int,
    val estimatedClearanceHours: Double,
    val notes: String,
    val isOfflinePending: Boolean,
    val timestamp: Long
)

data class LiveWeatherPoint(
    val locationName: String,
    val state: NERState,
    val latitude: Double,
    val longitude: Double,
    val tempC: Double,
    val conditionDescription: String,
    val precipitationMm: Double,
    val windSpeedKmH: Double,
    val humidityPct: Int,
    val visibilityKm: Double,
    val rainfall24hMm: Double,
    val landslideEarlyWarning: String,
    val floodRiskColorHex: Long
)

data class RegionalRiskSummary(
    val state: NERState,
    val accessibilityIndex: Int, // 0-100% accessible
    val activeLandslideAlerts: Int,
    val floodInundatedCorridors: Int,
    val averageDelayMin: Int,
    val overallRiskLevel: RiskLevel,
    val keyRoadStatus: String
)

data class BroadcastAlert(
    val id: String,
    val title: String,
    val description: String,
    val severity: RiskLevel,
    val affectedCorridor: String,
    val state: NERState,
    val timestamp: Long,
    val isBroadcastActive: Boolean
)

data class SystemAuditLog(
    val id: String,
    val action: String,
    val performedBy: String,
    val role: UserRole,
    val timestamp: Long,
    val details: String
)

enum class MapTileProvider(
    val code: String,
    val title: String,
    val subtitle: String,
    val urlTemplate: String,
    val maxZoom: Int,
    val attribution: String,
    val badgeColorHex: Long
) {
    OSM_STANDARD(
        code = "osm_standard",
        title = "OpenStreetMap Standard",
        subtitle = "Detailed highways, bridges & mountain passes",
        urlTemplate = "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
        maxZoom = 18,
        attribution = "© OpenStreetMap contributors",
        badgeColorHex = 0xFF00E5FF
    ),
    MAPBOX_DARK(
        code = "mapbox_dark",
        title = "Mapbox Dark Tactical HUD",
        subtitle = "High contrast tactical telemetry mode",
        urlTemplate = "https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png",
        maxZoom = 19,
        attribution = "© CARTO / Mapbox / OpenStreetMap",
        badgeColorHex = 0xFF8338EC
    ),
    TOPO_TERRAIN(
        code = "topo_terrain",
        title = "OpenTopo Mountain Terrain",
        subtitle = "Elevation contours, ghat gradients & ridge heights",
        urlTemplate = "https://tile.opentopomap.org/{z}/{x}/{y}.png",
        maxZoom = 17,
        attribution = "© OpenTopoMap, CC-BY-SA",
        badgeColorHex = 0xFFFFB703
    ),
    SATELLITE_HYBRID(
        code = "satellite",
        title = "Satellite Imagery Recon",
        subtitle = "Aerial terrain texture & cloud valley views",
        urlTemplate = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        maxZoom = 18,
        attribution = "© Esri, Maxar, Earthstar Geographics",
        badgeColorHex = 0xFF06D6A0
    )
}

data class EmergencyShelterPoint(
    val name: String,
    val type: String, // "SDRF Outpost", "BRO Transit Camp", "Fuel Reserve", "Helipad"
    val latitude: Double,
    val longitude: Double,
    val altitudeMeters: Int,
    val emergencyContact: String,
    val capacityBeds: Int
)

data class ElevationCheckpoint(
    val kmMarker: Double,
    val placeName: String,
    val altitudeMeters: Int,
    val gradientPct: Double,
    val isRiskHotspot: Boolean
)

data class TurnNavigationCue(
    val stepIndex: Int,
    val instruction: String,
    val roadName: String,
    val distanceMeters: Int,
    val altitudeMeters: Int,
    val hazardWarning: String?,
    val isSafetyCritical: Boolean,
    val latitude: Double,
    val longitude: Double
)

data class OfflineRoutePackage(
    val id: String,
    val name: String,
    val corridorCode: String,
    val originName: String,
    val destinationName: String,
    val distanceKm: Double,
    val minZoom: Int,
    val maxZoom: Int,
    val totalTiles: Int,
    val downloadedTiles: Int,
    val sizeBytes: Long,
    val isDownloaded: Boolean,
    val isDownloading: Boolean,
    val downloadProgress: Float,
    val waypoints: List<LocationPoint>,
    val elevationCheckpoints: List<ElevationCheckpoint>,
    val emergencyShelters: List<EmergencyShelterPoint>,
    val navigationCues: List<TurnNavigationCue>,
    val lastDownloadedAt: Long
) {
    val sizeFormattedMb: String
        get() = String.format(java.util.Locale.US, "%.1f MB", sizeBytes / (1024.0 * 1024.0))
}

data class TileCacheStats(
    val cachedTilesCount: Int,
    val totalSizeBytes: Long,
    val activeProvider: MapTileProvider,
    val downloadedPackagesCount: Int,
    val isOfflineModeForced: Boolean
) {
    val totalSizeMb: String
        get() = String.format(java.util.Locale.US, "%.2f MB", totalSizeBytes / (1024.0 * 1024.0))
}

