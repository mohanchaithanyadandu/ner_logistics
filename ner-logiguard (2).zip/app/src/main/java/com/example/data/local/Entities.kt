package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "road_incidents")
data class IncidentEntity(
    @PrimaryKey val id: String,
    val title: String,
    val typeName: String,
    val severityName: String,
    val latitude: Double,
    val longitude: Double,
    val locationName: String,
    val stateCode: String,
    val corridorName: String,
    val description: String,
    val reportedBy: String,
    val reportedRole: String,
    val reportedTimestamp: Long,
    val isVerified: Boolean,
    val statusName: String,
    val clearanceEtaHours: Double,
    val affectedVehiclesCount: Int
)

@Entity(tableName = "field_reports")
data class FieldReportEntity(
    @PrimaryKey val id: String,
    val reporterName: String,
    val reporterPhone: String,
    val reporterRole: String,
    val incidentTypeName: String,
    val severityName: String,
    val locationName: String,
    val stateCode: String,
    val latitude: Double,
    val longitude: Double,
    val roadBlockagePct: Int,
    val estimatedClearanceHours: Double,
    val notes: String,
    val isOfflinePending: Boolean,
    val timestamp: Long
)

@Entity(tableName = "vehicles")
data class VehicleEntity(
    @PrimaryKey val id: String,
    val vehicleNumber: String,
    val driverName: String,
    val driverPhone: String,
    val vehicleTypeName: String,
    val cargoDescription: String,
    val isEmergencyPriority: Boolean,
    val currentLat: Double,
    val currentLng: Double,
    val speedKmH: Int,
    val headingDegrees: Float,
    val altitudeMeters: Int,
    val fuelLevelPct: Int,
    val statusName: String,
    val deliveryStatusName: String = "ON_TIME",
    val activeRouteName: String,
    val originName: String,
    val destinationName: String,
    val etaMinutes: Int,
    val signalStatus: String,
    val isSimulated: Boolean = true,
    val hasDeviated: Boolean = false,
    val deviationDistanceKm: Double = 0.0,
    val lastUpdateTimestamp: Long = System.currentTimeMillis(),
    val waypointIndex: Int = 0
)

@Entity(tableName = "broadcast_alerts")
data class AlertEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val severityName: String,
    val affectedCorridor: String,
    val stateCode: String,
    val timestamp: Long,
    val isBroadcastActive: Boolean
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val action: String,
    val performedBy: String,
    val roleName: String,
    val timestamp: Long,
    val details: String
)

@Entity(tableName = "map_tiles")
data class MapTileEntity(
    @PrimaryKey val tileKey: String, // e.g. "osm_standard_8_192_110"
    val layer: String, // "osm_standard", "mapbox_dark", "topo_terrain", "satellite"
    val zoom: Int,
    val x: Int,
    val y: Int,
    val mimeType: String,
    val tileData: ByteArray,
    val sizeBytes: Long,
    val cachedAt: Long,
    val corridorTag: String?,
    val isPinned: Boolean
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as MapTileEntity
        return tileKey == other.tileKey
    }

    override fun hashCode(): Int {
        return tileKey.hashCode()
    }
}

@Entity(tableName = "offline_route_packages")
data class OfflineRoutePackageEntity(
    @PrimaryKey val id: String,
    val name: String,
    val corridorCode: String,
    val originName: String,
    val destinationName: String,
    val distanceKm: Double,
    val minZoom: Int,
    val maxZoom: Int,
    val totalTiles: Int,
    val downloadedTiles: Int,
    val sizeBytes: Long,
    val isDownloaded: Boolean,
    val isDownloading: Boolean,
    val downloadProgress: Float,
    val waypointsJson: String,
    val elevationCheckpointsJson: String,
    val emergencySheltersJson: String,
    val lastDownloadedAt: Long
)

