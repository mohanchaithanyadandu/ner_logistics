package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface IncidentDao {
    @Query("SELECT * FROM road_incidents ORDER BY reportedTimestamp DESC")
    fun getAllIncidents(): Flow<List<IncidentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncident(incident: IncidentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncidents(incidents: List<IncidentEntity>)

    @Update
    suspend fun updateIncident(incident: IncidentEntity)

    @Query("UPDATE road_incidents SET statusName = :status WHERE id = :id")
    suspend fun updateStatus(id: String, status: String)

    @Query("DELETE FROM road_incidents WHERE id = :id")
    suspend fun deleteIncident(id: String)
}

@Dao
interface FieldReportDao {
    @Query("SELECT * FROM field_reports ORDER BY timestamp DESC")
    fun getAllFieldReports(): Flow<List<FieldReportEntity>>

    @Query("SELECT * FROM field_reports WHERE isOfflinePending = 1")
    fun getPendingOfflineReports(): Flow<List<FieldReportEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: FieldReportEntity)

    @Query("UPDATE field_reports SET isOfflinePending = 0 WHERE id = :id")
    suspend fun markSynced(id: String)

    @Query("UPDATE field_reports SET isOfflinePending = 0")
    suspend fun markAllSynced()
}

@Dao
interface VehicleDao {
    @Query("SELECT * FROM vehicles ORDER BY vehicleNumber ASC")
    fun getAllVehicles(): Flow<List<VehicleEntity>>

    @Query("SELECT * FROM vehicles WHERE id = :id LIMIT 1")
    suspend fun getVehicleById(id: String): VehicleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVehicles(vehicles: List<VehicleEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVehicle(vehicle: VehicleEntity)

    @Update
    suspend fun updateVehicle(vehicle: VehicleEntity)

    @Query("DELETE FROM vehicles")
    suspend fun deleteAllVehicles()
}

@Dao
interface AlertDao {
    @Query("SELECT * FROM broadcast_alerts ORDER BY timestamp DESC")
    fun getAllAlerts(): Flow<List<AlertEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: AlertEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlerts(alerts: List<AlertEntity>)
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLogEntity)
}

@Dao
interface MapTileDao {
    @Query("SELECT * FROM map_tiles WHERE tileKey = :tileKey LIMIT 1")
    suspend fun getTile(tileKey: String): MapTileEntity?

    @Query("SELECT * FROM map_tiles WHERE layer = :layer AND zoom = :zoom AND x = :x AND y = :y LIMIT 1")
    suspend fun getTileByCoords(layer: String, zoom: Int, x: Int, y: Int): MapTileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTile(tile: MapTileEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTiles(tiles: List<MapTileEntity>)

    @Query("SELECT COUNT(*) FROM map_tiles")
    fun getCachedTilesCount(): Flow<Int>

    @Query("SELECT SUM(sizeBytes) FROM map_tiles")
    fun getTotalCacheSizeBytes(): Flow<Long?>

    @Query("SELECT COUNT(*) FROM map_tiles WHERE corridorTag = :corridorTag")
    suspend fun getCorridorTileCount(corridorTag: String): Int

    @Query("DELETE FROM map_tiles WHERE isPinned = 0")
    suspend fun clearUnpinnedCache()

    @Query("DELETE FROM map_tiles")
    suspend fun clearAllTiles()

    @Query("DELETE FROM map_tiles WHERE corridorTag = :corridorTag")
    suspend fun deleteCorridorTiles(corridorTag: String)
}

@Dao
interface OfflineRoutePackageDao {
    @Query("SELECT * FROM offline_route_packages ORDER BY corridorCode ASC")
    fun getAllPackages(): Flow<List<OfflineRoutePackageEntity>>

    @Query("SELECT * FROM offline_route_packages WHERE id = :id LIMIT 1")
    suspend fun getPackageById(id: String): OfflineRoutePackageEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackage(pkg: OfflineRoutePackageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackages(packages: List<OfflineRoutePackageEntity>)

    @Update
    suspend fun updatePackage(pkg: OfflineRoutePackageEntity)

    @Query("UPDATE offline_route_packages SET isDownloaded = :isDownloaded, isDownloading = :isDownloading, downloadProgress = :progress, downloadedTiles = :downloadedTiles, sizeBytes = :sizeBytes, lastDownloadedAt = :timestamp WHERE id = :id")
    suspend fun updateDownloadStatus(
        id: String,
        isDownloaded: Boolean,
        isDownloading: Boolean,
        progress: Float,
        downloadedTiles: Int,
        sizeBytes: Long,
        timestamp: Long
    )

    @Query("DELETE FROM offline_route_packages WHERE id = :id")
    suspend fun deletePackage(id: String)
}

