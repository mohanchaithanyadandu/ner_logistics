package com.example.data.remote

import android.util.Log
import com.example.data.models.LocationPoint
import com.example.data.models.NERState
import com.example.data.models.TerrainType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

data class GeocodingResult(
    val id: String,
    val name: String,
    val district: String? = null,
    val state: String,
    val country: String = "India",
    val latitude: Double,
    val longitude: Double,
    val altitudeMeters: Int = 100,
    val terrainType: TerrainType = TerrainType.PLAINS,
    val displayName: String,
    val placeType: String = "City / Hub"
) {
    fun toLocationPoint(): LocationPoint {
        val mappedState = NERState.fromStateName(state)
        return LocationPoint(
            id = id,
            name = name,
            state = mappedState,
            latitude = latitude,
            longitude = longitude,
            altitudeMeters = altitudeMeters,
            terrainType = terrainType,
            formattedAddress = displayName,
            stateName = state
        )
    }
}

class GeocodingService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .build()
) {
    private val tag = "GeocodingService"

    /**
     * Comprehensive offline India catalog of major cities, regional logistics hubs,
     * international and domestic airports, rail junctions, and all Northeast terminals.
     */
    private val localCatalog = listOf(
        // Major Metros & Logistics Gateways
        GeocodingResult("LOC_BLR", "Bengaluru", "Bangalore Urban", "Karnataka", "India", 12.9716, 77.5946, 920, TerrainType.PLAINS, "Bengaluru, Bangalore Urban, Karnataka, India", "Major Tech & Logistics Hub"),
        GeocodingResult("LOC_BLR_AIRPORT", "Kempegowda Int'l Airport (BLR)", "Bengaluru", "Karnataka", "India", 13.1986, 77.7066, 915, TerrainType.PLAINS, "Kempegowda International Airport, Devanahalli, Bengaluru, Karnataka", "International Airport"),
        GeocodingResult("LOC_DEL", "New Delhi", "New Delhi", "Delhi", "India", 28.6139, 77.2090, 216, TerrainType.PLAINS, "New Delhi, Central National Capital Region, India", "National Capital Hub"),
        GeocodingResult("LOC_DEL_AIRPORT", "Indira Gandhi Int'l Airport (DEL)", "New Delhi", "Delhi", "India", 28.5562, 77.1000, 237, TerrainType.PLAINS, "Indira Gandhi International Airport, Terminal 3, New Delhi", "International Airport"),
        GeocodingResult("LOC_MUM", "Mumbai", "Mumbai Suburban", "Maharashtra", "India", 19.0760, 72.8777, 14, TerrainType.PLAINS, "Mumbai, Maharashtra, India", "Financial Capital & Major Port"),
        GeocodingResult("LOC_MUM_JNPT", "JNPT Port Nhava Sheva", "Raigad", "Maharashtra", "India", 18.9499, 72.9510, 8, TerrainType.PLAINS, "Jawaharlal Nehru Port Trust (JNPT), Navi Mumbai, Maharashtra", "Container Port"),
        GeocodingResult("LOC_HYD", "Hyderabad", "Hyderabad", "Telangana", "India", 17.3850, 78.4867, 542, TerrainType.PLAINS, "Hyderabad, Telangana, India", "Logistics & Pharma Hub"),
        GeocodingResult("LOC_CHE", "Chennai", "Chennai", "Tamil Nadu", "India", 13.0827, 80.2707, 10, TerrainType.PLAINS, "Chennai, Tamil Nadu, India", "Automotive & Maritime Gateway"),
        GeocodingResult("LOC_KOL", "Kolkata", "Kolkata", "West Bengal", "India", 22.5726, 88.3639, 9, TerrainType.RIVER_BASIN, "Kolkata, West Bengal, India", "Eastern Gateway Hub"),
        GeocodingResult("LOC_PUN", "Pune", "Pune", "Maharashtra", "India", 18.5204, 73.8567, 560, TerrainType.PLAINS, "Pune, Maharashtra, India", "Industrial Center"),
        GeocodingResult("LOC_AHM", "Ahmedabad", "Ahmedabad", "Gujarat", "India", 23.0225, 72.5714, 53, TerrainType.PLAINS, "Ahmedabad, Gujarat, India", "Commercial Hub"),
        GeocodingResult("LOC_JAI", "Jaipur", "Jaipur", "Rajasthan", "India", 26.9124, 75.7873, 431, TerrainType.PLAINS, "Jaipur, Rajasthan, India", "Northern Logistics Node"),
        GeocodingResult("LOC_LKO", "Lucknow", "Lucknow", "Uttar Pradesh", "India", 26.8467, 80.9462, 123, TerrainType.PLAINS, "Lucknow, Uttar Pradesh, India", "Central Distribution Center"),
        GeocodingResult("LOC_KOC", "Kochi", "Ernakulam", "Kerala", "India", 9.9312, 76.2673, 5, TerrainType.PLAINS, "Kochi, Ernakulam, Kerala, India", "Deep Water Port"),
        GeocodingResult("LOC_PAT", "Patna", "Patna", "Bihar", "India", 25.5941, 85.1376, 53, TerrainType.RIVER_BASIN, "Patna, Bihar, India", "Ganges Corridor Depot"),
        GeocodingResult("LOC_BHO", "Bhopal", "Bhopal", "Madhya Pradesh", "India", 23.2599, 77.4126, 500, TerrainType.PLAINS, "Bhopal, Madhya Pradesh, India", "Central Rail Junction"),
        GeocodingResult("LOC_BBU", "Bhubaneswar", "Khordha", "Odisha", "India", 20.2961, 85.8245, 45, TerrainType.PLAINS, "Bhubaneswar, Odisha, India", "East Coast Freight Depot"),
        GeocodingResult("LOC_CHD", "Chandigarh", "Chandigarh", "Chandigarh", "India", 30.7333, 76.7794, 321, TerrainType.PLAINS, "Chandigarh, UT, India", "Northern Distribution Hub"),
        GeocodingResult("LOC_DED", "Dehradun", "Dehradun", "Uttarakhand", "India", 30.3165, 78.0322, 640, TerrainType.HILLY_GHAT, "Dehradun, Uttarakhand, India", "Foothills Transport Gateway"),
        GeocodingResult("LOC_SLV", "Shimla", "Shimla", "Himachal Pradesh", "India", 31.1048, 77.1734, 2206, TerrainType.HIGH_ALTITUDE_PASS, "Shimla, Himachal Pradesh, India", "Himachal Mountain Hub"),
        GeocodingResult("LOC_IXR", "Ranchi", "Ranchi", "Jharkhand", "India", 23.3441, 85.3096, 651, TerrainType.PLAINS, "Ranchi, Jharkhand, India", "Chota Nagpur Industrial Depot"),
        GeocodingResult("LOC_RPR", "Raipur", "Raipur", "Chhattisgarh", "India", 21.2514, 81.6296, 298, TerrainType.PLAINS, "Raipur Central Freight Base, Chhattisgarh, India", "Mineral & Industrial Hub"),
        GeocodingResult("LOC_TRV", "Thiruvananthapuram", "Thiruvananthapuram", "Kerala", "India", 8.5241, 76.9366, 10, TerrainType.PLAINS, "Thiruvananthapuram, Kerala, India", "Southern Terminal & Port"),
        GeocodingResult("LOC_SXR", "Srinagar", "Srinagar", "Jammu & Kashmir", "India", 34.0837, 74.7973, 1585, TerrainType.HILLY_GHAT, "Srinagar, Jammu & Kashmir, India", "Valley Strategic Depot"),
        GeocodingResult("LOC_IXJ", "Jammu", "Jammu", "Jammu & Kashmir", "India", 32.7266, 74.8570, 327, TerrainType.HILLY_GHAT, "Jammu, Jammu & Kashmir, India", "Railhead & Logistics Base"),
        GeocodingResult("LOC_IXL", "Leh", "Leh Ladakh", "Ladakh", "India", 34.1526, 77.5771, 3500, TerrainType.HIGH_ALTITUDE_PASS, "Leh, Ladakh UT, India", "High-Altitude Base"),
        GeocodingResult("LOC_IDR", "Indore", "Indore", "Madhya Pradesh", "India", 22.7196, 75.8577, 553, TerrainType.PLAINS, "Indore, Madhya Pradesh, India", "Logistics Hub"),
        GeocodingResult("LOC_NAG", "Nagpur", "Nagpur", "Maharashtra", "India", 21.1458, 79.0882, 310, TerrainType.PLAINS, "Nagpur, Maharashtra, India", "Zero Mile Multi-Modal Hub"),
        GeocodingResult("LOC_VNS", "Varanasi", "Varanasi", "Uttar Pradesh", "India", 25.3176, 82.9739, 81, TerrainType.PLAINS, "Varanasi Freight Terminal, UP, India", "National Waterway 1 Hub"),
        GeocodingResult("LOC_VTZ", "Visakhapatnam", "Visakhapatnam", "Andhra Pradesh", "India", 17.6868, 83.2185, 12, TerrainType.PLAINS, "Visakhapatnam Port & Logistics Node, AP", "Deepwater Port"),
        GeocodingResult("LOC_SUR", "Surat", "Surat", "Gujarat", "India", 21.1702, 72.8311, 13, TerrainType.PLAINS, "Surat Industrial Corridor, Gujarat, India", "Industrial Depot"),
        GeocodingResult("LOC_SIL", "Siliguri", "Darjeeling", "West Bengal", "India", 26.7271, 88.3953, 122, TerrainType.PLAINS, "Siliguri Chicken's Neck Corridor, West Bengal", "Northeast Gateway Chokepoint"),
        GeocodingResult("LOC_ATQ", "Amritsar", "Amritsar", "Punjab", "India", 31.6340, 74.8723, 234, TerrainType.PLAINS, "Amritsar Rail & Cargo Hub, Punjab, India", "Border Trade Depot"),
        GeocodingResult("LOC_LDH", "Ludhiana", "Ludhiana", "Punjab", "India", 30.9010, 75.8573, 244, TerrainType.PLAINS, "Ludhiana Industrial Freight Hub, Punjab", "Manufacturing Center"),
        GeocodingResult("LOC_AGR", "Agra", "Agra", "Uttar Pradesh", "India", 27.1767, 78.0081, 171, TerrainType.PLAINS, "Agra Logistics Corridor, Uttar Pradesh", "Highway Node"),
        GeocodingResult("LOC_KNP", "Kanpur", "Kanpur Nagar", "Uttar Pradesh", "India", 26.4499, 80.3319, 126, TerrainType.PLAINS, "Kanpur Central Industrial Base, UP", "Industrial Center"),
        GeocodingResult("LOC_ALD", "Prayagraj", "Prayagraj", "Uttar Pradesh", "India", 25.4358, 81.8463, 98, TerrainType.PLAINS, "Prayagraj Transit Junction, UP", "River Confluence Depot"),
        GeocodingResult("LOC_NOI", "Noida", "Gautam Buddha Nagar", "Uttar Pradesh", "India", 28.5355, 77.3910, 200, TerrainType.PLAINS, "Noida Express Cargo Terminal, NCR, UP", "NCR Logistics Center"),
        GeocodingResult("LOC_GGN", "Gurugram", "Gurugram", "Haryana", "India", 28.4595, 77.0266, 217, TerrainType.PLAINS, "Gurugram Logistics Depot, NCR, Haryana", "NCR Freight Gateway"),
        GeocodingResult("LOC_CJB", "Coimbatore", "Coimbatore", "Tamil Nadu", "India", 11.0168, 76.9558, 411, TerrainType.PLAINS, "Coimbatore Industrial Hub, Tamil Nadu", "Textile & Engineering Hub"),
        GeocodingResult("LOC_IXM", "Madurai", "Madurai", "Tamil Nadu", "India", 9.9252, 78.1198, 101, TerrainType.PLAINS, "Madurai Logistics Terminal, Tamil Nadu", "South Tamil Nadu Hub"),
        GeocodingResult("LOC_CCJ", "Kozhikode", "Kozhikode", "Kerala", "India", 11.2588, 75.7804, 1, TerrainType.PLAINS, "Kozhikode Malabar Coast Depot, Kerala", "Malabar Trade Port"),
        GeocodingResult("LOC_IXE", "Mangaluru", "Dakshina Kannada", "Karnataka", "India", 12.9141, 74.8560, 22, TerrainType.PLAINS, "Mangaluru Port Base, Karnataka", "Coastal Port Hub"),
        GeocodingResult("LOC_MYQ", "Mysuru", "Mysuru", "Karnataka", "India", 12.2958, 76.6394, 763, TerrainType.PLAINS, "Mysuru Freight Depot, Karnataka", "South Karnataka Node"),
        GeocodingResult("LOC_GOI", "Panaji", "North Goa", "Goa", "India", 15.4909, 73.8278, 7, TerrainType.PLAINS, "Panaji & Mormugao Port Hub, Goa", "Maritime & Tourism Hub"),
        GeocodingResult("LOC_VJA", "Vijayawada", "NTR", "Andhra Pradesh", "India", 16.5062, 80.6480, 23, TerrainType.PLAINS, "Vijayawada Central Rail & Road Hub, AP", "Amaravati Logistics Hub"),
        GeocodingResult("LOC_TIR", "Tirupati", "Tirupati", "Andhra Pradesh", "India", 13.6288, 79.4192, 161, TerrainType.PLAINS, "Tirupati Transit Terminal, AP", "Rayalaseema Logistics Hub"),
        GeocodingResult("LOC_WRG", "Warangal", "Warangal", "Telangana", "India", 17.9689, 79.5941, 266, TerrainType.PLAINS, "Warangal Regional Depot, Telangana", "Central Telangana Terminal"),
        GeocodingResult("LOC_CTC", "Cuttack", "Cuttack", "Odisha", "India", 20.4625, 85.8828, 36, TerrainType.PLAINS, "Cuttack Twin-City Freight Terminal, Odisha", "Mahanadi Basin Hub"),
        GeocodingResult("LOC_RRK", "Rourkela", "Sundargarh", "Odisha", "India", 22.2604, 84.8536, 219, TerrainType.PLAINS, "Rourkela Steel City Depot, Odisha", "Steel & Mineral Hub"),
        GeocodingResult("LOC_IXW", "Jamshedpur", "East Singhbhum", "Jharkhand", "India", 22.8046, 86.2029, 135, TerrainType.PLAINS, "Jamshedpur Tatanagar Freight Base, Jharkhand", "Heavy Industrial Hub"),
        GeocodingResult("LOC_DHN", "Dhanbad", "Dhanbad", "Jharkhand", "India", 23.7957, 86.4304, 227, TerrainType.PLAINS, "Dhanbad Coalfield Railhead, Jharkhand", "Mining Freight Terminal"),
        GeocodingResult("LOC_GAY", "Gaya", "Gaya", "Bihar", "India", 24.7914, 85.0002, 111, TerrainType.PLAINS, "Gaya Grand Trunk Corridor Depot, Bihar", "GT Road Hub"),
        GeocodingResult("LOC_MFP", "Muzaffarpur", "Muzaffarpur", "Bihar", "India", 26.1209, 85.3647, 60, TerrainType.PLAINS, "Muzaffarpur North Bihar Terminal, Bihar", "North Bihar Gateway"),
        GeocodingResult("LOC_GWL", "Gwalior", "Gwalior", "Madhya Pradesh", "India", 26.2183, 78.1828, 197, TerrainType.PLAINS, "Gwalior North MP Depot, Madhya Pradesh", "North-Central Junction"),
        GeocodingResult("LOC_JBP", "Jabalpur", "Jabalpur", "Madhya Pradesh", "India", 23.1815, 79.9864, 411, TerrainType.PLAINS, "Jabalpur Defense & Freight Terminal, MP", "Narmada Valley Hub"),
        GeocodingResult("LOC_JDH", "Jodhpur", "Jodhpur", "Rajasthan", "India", 26.2389, 73.0243, 231, TerrainType.PLAINS, "Jodhpur Marwar Logistics Hub, Rajasthan", "Western Desert Gateway"),
        GeocodingResult("LOC_UDR", "Udaipur", "Udaipur", "Rajasthan", "India", 24.5854, 73.7125, 598, TerrainType.HILLY_GHAT, "Udaipur Mewar Transit Depot, Rajasthan", "Mewar Logistics Node"),
        GeocodingResult("LOC_KOT", "Kota", "Kota", "Rajasthan", "India", 25.2138, 75.8648, 271, TerrainType.PLAINS, "Kota Chambal Industrial Depot, Rajasthan", "Chambal Industrial Hub"),
        GeocodingResult("LOC_BDQ", "Vadodara", "Vadodara", "Gujarat", "India", 22.3072, 73.1812, 39, TerrainType.PLAINS, "Vadodara Golden Corridor Depot, Gujarat", "Chemical & Engineering Hub"),
        GeocodingResult("LOC_RAJ", "Rajkot", "Rajkot", "Gujarat", "India", 22.3039, 70.8022, 128, TerrainType.PLAINS, "Rajkot Saurashtra Central Base, Gujarat", "Saurashtra Hub"),
        GeocodingResult("LOC_ISK", "Nashik", "Nashik", "Maharashtra", "India", 19.9975, 73.7898, 560, TerrainType.HILLY_GHAT, "Nashik Freight Terminal, Maharashtra", "Western Ghats Corridor"),
        GeocodingResult("LOC_CSN", "Chhatrapati Sambhajinagar", "Aurangabad", "Maharashtra", "India", 19.8762, 75.3433, 569, TerrainType.PLAINS, "Chhatrapati Sambhajinagar Depot, Maharashtra", "Marathwada Hub"),
        GeocodingResult("LOC_HRD", "Haridwar", "Haridwar", "Uttarakhand", "India", 29.9457, 78.1642, 314, TerrainType.PLAINS, "Haridwar SIDCUL Industrial Terminal, Uttarakhand", "SIDCUL Freight Terminal"),
        GeocodingResult("LOC_RSK", "Rishikesh", "Dehradun", "Uttarakhand", "India", 30.0869, 78.2676, 372, TerrainType.HILLY_GHAT, "Rishikesh Himalayan Gateway Depot, Uttarakhand", "Garhwal Gateway"),
        GeocodingResult("LOC_DHM", "Dharamshala", "Kangra", "Himachal Pradesh", "India", 32.2190, 76.3234, 1457, TerrainType.HIGH_ALTITUDE_PASS, "Dharamshala Mountain Outpost, Himachal Pradesh", "Kangra Valley Outpost"),
        GeocodingResult("LOC_IXZ", "Port Blair", "South Andaman", "Andaman & Nicobar", "India", 11.6234, 92.7265, 16, TerrainType.PLAINS, "Port Blair Harbor Base, Andaman & Nicobar", "Island Strategic Port"),
        GeocodingResult("LOC_PDY", "Puducherry", "Puducherry", "Puducherry", "India", 11.9416, 79.8083, 3, TerrainType.PLAINS, "Puducherry Coastal Terminal, UT, India", "Coromandel Coast Terminal"),

        // Comprehensive North Eastern Logistics Hubs & Terminals
        GeocodingResult("LOC_GHY", "Guwahati", "Kamrup Metropolitan", "Assam", "India", 26.1445, 91.7362, 55, TerrainType.RIVER_BASIN, "Guwahati Central Logistics Hub, Assam, India", "Primary NER Gateway"),
        GeocodingResult("LOC_SLR", "Silchar", "Cachar", "Assam", "India", 24.8333, 92.7789, 25, TerrainType.RIVER_BASIN, "Silchar Valley Depot, Cachar, Assam, India", "Barak Valley Hub"),
        GeocodingResult("LOC_SHL", "Shillong", "East Khasi Hills", "Meghalaya", "India", 25.5788, 91.8933, 1525, TerrainType.HILLY_GHAT, "Shillong Mountain Depot, Meghalaya, India", "High Plateau Hub"),
        GeocodingResult("LOC_TWG", "Tawang", "Tawang", "Arunachal Pradesh", "India", 27.5861, 91.8594, 3048, TerrainType.HIGH_ALTITUDE_PASS, "Tawang Border Logistics Outpost, Arunachal Pradesh", "Border Forward Depot"),
        GeocodingResult("LOC_ITN", "Itanagar", "Papum Pare", "Arunachal Pradesh", "India", 27.0844, 93.6053, 320, TerrainType.HILLY_GHAT, "Itanagar State Distribution Hub, Arunachal Pradesh", "State Capital Terminal"),
        GeocodingResult("LOC_PAS", "Pasighat", "East Siang", "Arunachal Pradesh", "India", 28.0667, 95.3333, 153, TerrainType.RIVER_BASIN, "Pasighat Siang River Terminal, Arunachal Pradesh", "Siang Valley Terminal"),
        GeocodingResult("LOC_IMP", "Imphal", "Imphal West", "Manipur", "India", 24.8170, 93.9368, 786, TerrainType.PLAINS, "Imphal Valley Forward Terminal, Manipur, India", "Border Trade Depot"),
        GeocodingResult("LOC_JIB", "Jiribam", "Jiribam", "Manipur", "India", 24.8000, 93.1200, 35, TerrainType.PLAINS, "Jiribam Railhead Hub, Manipur, India", "Rail Freight Terminal"),
        GeocodingResult("LOC_AZL", "Aizawl", "Aizawl", "Mizoram", "India", 23.7271, 92.7176, 1132, TerrainType.HILLY_GHAT, "Aizawl Ridge Hub, Mizoram, India", "Ridge Mountain Hub"),
        GeocodingResult("LOC_LGL", "Lunglei", "Lunglei", "Mizoram", "India", 22.8800, 92.7300, 722, TerrainType.HILLY_GHAT, "Lunglei South Depot, Mizoram, India", "South Mizoram Depot"),
        GeocodingResult("LOC_KOH", "Kohima", "Kohima", "Nagaland", "India", 25.6751, 94.1086, 1444, TerrainType.HILLY_GHAT, "Kohima Central Outpost, Nagaland, India", "Mountain Corridor Hub"),
        GeocodingResult("LOC_DMP", "Dimapur", "Dimapur", "Nagaland", "India", 25.9068, 93.7271, 145, TerrainType.PLAINS, "Dimapur Commercial Railhead, Nagaland, India", "Primary Railhead Depot"),
        GeocodingResult("LOC_AGT", "Agartala", "West Tripura", "Tripura", "India", 23.8315, 91.2868, 12, TerrainType.PLAINS, "Agartala Integrated Border Depot, Tripura, India", "International Border Hub"),
        GeocodingResult("LOC_GTK", "Gangtok", "East Sikkim", "Sikkim", "India", 27.3389, 88.6065, 1650, TerrainType.HIGH_ALTITUDE_PASS, "Gangtok Himalayan Depot, Sikkim, India", "Himalayan Ridge Depot"),
        GeocodingResult("LOC_DIB", "Dibrugarh", "Dibrugarh", "Assam", "India", 27.4728, 94.9120, 108, TerrainType.RIVER_BASIN, "Dibrugarh Upper Assam Logistics Base, Assam", "Upper Assam Terminal"),
        GeocodingResult("LOC_JOR", "Jorhat", "Jorhat", "Assam", "India", 26.7509, 94.2037, 116, TerrainType.PLAINS, "Jorhat Tea & Oil Freight Center, Assam", "Mid-Assam Freight Depot"),
        GeocodingResult("LOC_TEZ", "Tezpur", "Sonitpur", "Assam", "India", 26.6338, 92.7926, 48, TerrainType.RIVER_BASIN, "Tezpur Strategic Transit Depot, Assam", "Brahmaputra North Hub"),
        GeocodingResult("LOC_BOM", "Bomdila", "West Kameng", "Arunachal Pradesh", "India", 27.2645, 92.4159, 2415, TerrainType.HIGH_ALTITUDE_PASS, "Bomdila Mountain Pass Transit, Arunachal Pradesh", "Mountain Transit Depot"),
        GeocodingResult("LOC_HFL", "Haflong", "Dima Hasao", "Assam", "India", 25.1833, 93.0167, 966, TerrainType.HILLY_GHAT, "Haflong Hill Outpost, Dima Hasao, Assam", "Barail Hill Outpost"),
        GeocodingResult("LOC_NAG_AS", "Nagaon", "Nagaon", "Assam", "India", 26.3500, 92.6833, 62, TerrainType.PLAINS, "Nagaon Central Assam Junction, Assam", "National Highway Node"),
        GeocodingResult("LOC_BON", "Bongaigaon", "Bongaigaon", "Assam", "India", 26.4833, 90.5667, 54, TerrainType.PLAINS, "Bongaigaon Petrochemical Terminal, Assam", "Industrial Transit Base"),
        GeocodingResult("LOC_TSK", "Tinsukia", "Tinsukia", "Assam", "India", 27.5000, 95.3667, 125, TerrainType.PLAINS, "Tinsukia Commercial Railhead, Assam", "Easternmost Railhead"),
        GeocodingResult("LOC_JOW", "Jowai", "West Jaintia Hills", "Meghalaya", "India", 25.4500, 92.2000, 1380, TerrainType.HILLY_GHAT, "Jowai Coal & Mineral Depot, Meghalaya", "Jaintia Hills Hub"),
        GeocodingResult("LOC_TUR", "Tura", "West Garo Hills", "Meghalaya", "India", 25.5167, 90.2167, 349, TerrainType.HILLY_GHAT, "Tura Garo Hills Transit Base, Meghalaya", "Garo Hills Hub"),
        GeocodingResult("LOC_NPH", "Nongpoh", "Ri-Bhoi", "Meghalaya", "India", 25.9000, 91.8833, 485, TerrainType.HILLY_GHAT, "Nongpoh Highway Depot, Meghalaya", "NH-6 Transit Point"),
        GeocodingResult("LOC_CHR", "Cherrapunji", "East Khasi Hills", "Meghalaya", "India", 25.2702, 91.7323, 1430, TerrainType.HILLY_GHAT, "Cherrapunji Sohra Station, Meghalaya", "High Precipitation Zone"),
        GeocodingResult("LOC_ZIR", "Ziro", "Lower Subansiri", "Arunachal Pradesh", "India", 27.5333, 93.8333, 1572, TerrainType.HILLY_GHAT, "Ziro Valley Logistics Depot, Arunachal Pradesh", "Subansiri Depot"),
        GeocodingResult("LOC_ALO", "Aalo", "West Siang", "Arunachal Pradesh", "India", 28.1667, 94.8000, 300, TerrainType.HILLY_GHAT, "Aalo Central Outpost, Arunachal Pradesh", "Siang Foothills Hub"),
        GeocodingResult("LOC_TEZ_AR", "Tezu", "Lohit", "Arunachal Pradesh", "India", 27.9167, 96.1667, 185, TerrainType.PLAINS, "Tezu Lohit Valley Depot, Arunachal Pradesh", "Eastern Frontier Hub"),
        GeocodingResult("LOC_ROI", "Roing", "Lower Dibang Valley", "Arunachal Pradesh", "India", 28.1500, 95.8333, 390, TerrainType.RIVER_BASIN, "Roing Dibang Valley Base, Arunachal Pradesh", "Dibang Terminal"),
        GeocodingResult("LOC_MOK", "Mokokchung", "Mokokchung", "Nagaland", "India", 26.3256, 94.5244, 1325, TerrainType.HILLY_GHAT, "Mokokchung Hill Station, Nagaland", "Ao Regional Hub"),
        GeocodingResult("LOC_WOK", "Wokha", "Wokha", "Nagaland", "India", 26.1000, 94.2667, 1313, TerrainType.HILLY_GHAT, "Wokha Mountain Transit Depot, Nagaland", "Central Nagaland Hub"),
        GeocodingResult("LOC_CCPUR", "Churachandpur", "Churachandpur", "Manipur", "India", 24.3333, 93.6833, 914, TerrainType.HILLY_GHAT, "Churachandpur Hill Outpost, Manipur", "South Manipur Terminal"),
        GeocodingResult("LOC_UKH", "Ukhrul", "Ukhrul", "Manipur", "India", 25.1167, 94.3667, 2020, TerrainType.HIGH_ALTITUDE_PASS, "Ukhrul Eastern Frontier Station, Manipur", "Highland Outpost"),
        GeocodingResult("LOC_CMP", "Champhai", "Champhai", "Mizoram", "India", 23.4833, 93.3333, 1678, TerrainType.HILLY_GHAT, "Champhai International Trade Station, Mizoram", "Myanmar Border Hub"),
        GeocodingResult("LOC_DMR", "Dharmanagar", "North Tripura", "Tripura", "India", 24.3800, 92.1600, 21, TerrainType.PLAINS, "Dharmanagar Rail Junction, North Tripura", "Rail Freight Terminal"),
        GeocodingResult("LOC_UDP", "Udaipur Tripura", "Gomati", "Tripura", "India", 23.5333, 91.4833, 23, TerrainType.PLAINS, "Udaipur Gomati Depot, Tripura", "South Tripura Hub"),
        GeocodingResult("LOC_NAM", "Namchi", "South Sikkim", "Sikkim", "India", 27.1667, 88.3500, 1315, TerrainType.HILLY_GHAT, "Namchi Ridge Terminal, South Sikkim", "South Sikkim Hub"),
        GeocodingResult("LOC_MAN", "Mangan", "North Sikkim", "Sikkim", "India", 27.5167, 88.5333, 956, TerrainType.HIGH_ALTITUDE_PASS, "Mangan North Sikkim Forward Base, Sikkim", "Forward Logistics Base")
    )

    /**
     * Searches locations matching the query.
     * 1. Checks and matches pre-indexed local catalog for instant sub-millisecond response.
     * 2. Asynchronously queries OpenStreetMap Nominatim for any specific address, street, or city across India.
     * 3. Merges results, deduplicating coordinates.
     */
    suspend fun searchLocations(query: String): List<GeocodingResult> = withContext(Dispatchers.IO) {
        val cleanQuery = query.trim()
        if (cleanQuery.length < 2) {
            return@withContext localCatalog.take(8)
        }

        val localMatches = localCatalog.filter { item ->
            item.name.contains(cleanQuery, ignoreCase = true) ||
            item.displayName.contains(cleanQuery, ignoreCase = true) ||
            item.state.contains(cleanQuery, ignoreCase = true) ||
            (item.district?.contains(cleanQuery, ignoreCase = true) == true)
        }

        // Try querying live Nominatim OpenStreetMap API, fallback to Photon
        var remoteMatches = fetchNominatimResults(cleanQuery)
        if (remoteMatches.isEmpty()) {
            remoteMatches = fetchPhotonResults(cleanQuery)
        }

        // Merge: prioritize exact matching local known hubs, followed by live geocoder results
        val combined = mutableListOf<GeocodingResult>()
        combined.addAll(localMatches)

        for (remote in remoteMatches) {
            val isDuplicate = combined.any {
                Math.abs(it.latitude - remote.latitude) < 0.05 && Math.abs(it.longitude - remote.longitude) < 0.05
            }
            if (!isDuplicate) {
                combined.add(remote)
            }
        }

        if (combined.isEmpty()) {
            // Fuzzy fallback to prevent empty dead-end
            localCatalog.filter { it.name.startsWith(cleanQuery.take(1), ignoreCase = true) }.take(5)
        } else {
            combined.take(12)
        }
    }

    private fun fetchNominatimResults(query: String): List<GeocodingResult> {
        return try {
            val encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8.toString())
            val url = "https://nominatim.openstreetmap.org/search?q=$encodedQuery&format=json&countrycodes=in&addressdetails=1&limit=8"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "NERLogiGuard-GIS/2.0 (Android; Logistics-Route-Intelligence)")
                .header("Accept-Language", "en-IN,en;q=0.9")
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                Log.w(tag, "Nominatim returned status code: ${response.code}")
                return emptyList()
            }

            val bodyString = response.body?.string() ?: return emptyList()
            val jsonArray = JSONArray(bodyString)
            val results = mutableListOf<GeocodingResult>()

            for (i in 0 until jsonArray.length()) {
                val item = jsonArray.getJSONObject(i)
                val lat = item.optDouble("lat", 0.0)
                val lon = item.optDouble("lon", 0.0)
                if (lat == 0.0 && lon == 0.0) continue

                val displayName = item.optString("display_name", "")
                val addressObj = item.optJSONObject("address")

                val cityOrTown = addressObj?.optString("city")
                    ?.takeIf { it.isNotBlank() }
                    ?: addressObj?.optString("town")
                    ?.takeIf { it.isNotBlank() }
                    ?: addressObj?.optString("suburb")
                    ?.takeIf { it.isNotBlank() }
                    ?: addressObj?.optString("village")
                    ?: displayName.split(",").firstOrNull()?.trim()
                    ?: query

                val stateName = addressObj?.optString("state")
                    ?.takeIf { it.isNotBlank() }
                    ?: "India Regional"

                val districtName = addressObj?.optString("state_district")
                    ?: addressObj?.optString("county")

                val placeType = item.optString("type", "Location").replace("_", " ").replaceFirstChar { it.uppercase() }

                // Altitude heuristic based on state / terrain
                val mappedState = NERState.fromStateName(stateName)
                val isMountainous = mappedState in listOf(
                    NERState.ARUNACHAL_PRADESH, NERState.SIKKIM, NERState.MEGHALAYA,
                    NERState.NAGALAND, NERState.MIZORAM, NERState.HIMACHAL_PRADESH,
                    NERState.UTTARAKHAND, NERState.JAMMU_AND_KASHMIR, NERState.LADAKH
                )
                val altitudeEst = if (isMountainous) 1400 else 120
                val terrainEst = if (isMountainous) TerrainType.HILLY_GHAT else TerrainType.PLAINS

                results.add(
                    GeocodingResult(
                        id = "NOM_${item.optString("place_id", i.toString())}",
                        name = cityOrTown,
                        district = districtName,
                        state = stateName,
                        country = "India",
                        latitude = lat,
                        longitude = lon,
                        altitudeMeters = altitudeEst,
                        terrainType = terrainEst,
                        displayName = displayName,
                        placeType = placeType
                    )
                )
            }
            results
        } catch (e: Exception) {
            Log.e(tag, "Failed to query Nominatim: ${e.message}")
            emptyList()
        }
    }

    private fun fetchPhotonResults(query: String): List<GeocodingResult> {
        return try {
            val encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8.toString())
            val url = "https://photon.komoot.io/api/?q=$encodedQuery&limit=8&lat=22.0&lon=80.0"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "NERLogiGuard-GIS/2.0 (Android; Logistics-Route-Intelligence)")
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) return emptyList()

            val bodyString = response.body?.string() ?: return emptyList()
            val root = org.json.JSONObject(bodyString)
            val features = root.optJSONArray("features") ?: return emptyList()
            val results = mutableListOf<GeocodingResult>()

            for (i in 0 until features.length()) {
                val feat = features.getJSONObject(i)
                val geometry = feat.optJSONObject("geometry")
                val coordinates = geometry?.optJSONArray("coordinates") ?: continue
                val lon = coordinates.optDouble(0, 0.0)
                val lat = coordinates.optDouble(1, 0.0)
                if (lat == 0.0 && lon == 0.0) continue

                val props = feat.optJSONObject("properties") ?: continue
                val country = props.optString("country", "")
                // Ensure only Indian results
                if (country.isNotBlank() && !country.equals("India", ignoreCase = true)) continue

                val name = props.optString("name", query)
                val stateName = props.optString("state", "India Regional")
                val districtName = props.optString("county", props.optString("district", null))
                val city = props.optString("city", name)

                val mappedState = NERState.fromStateName(stateName)
                val isMountainous = mappedState in listOf(
                    NERState.ARUNACHAL_PRADESH, NERState.SIKKIM, NERState.MEGHALAYA,
                    NERState.NAGALAND, NERState.MIZORAM, NERState.HIMACHAL_PRADESH,
                    NERState.UTTARAKHAND, NERState.JAMMU_AND_KASHMIR, NERState.LADAKH
                )
                val altitudeEst = if (isMountainous) 1400 else 120
                val terrainEst = if (isMountainous) TerrainType.HILLY_GHAT else TerrainType.PLAINS

                val osmId = props.optLong("osm_id", i.toLong()).toString()
                results.add(
                    GeocodingResult(
                        id = "PHO_$osmId",
                        name = city,
                        district = districtName,
                        state = stateName,
                        country = "India",
                        latitude = lat,
                        longitude = lon,
                        altitudeMeters = altitudeEst,
                        terrainType = terrainEst,
                        displayName = "$name, $stateName, India",
                        placeType = props.optString("type", "City / Town").replaceFirstChar { it.uppercase() }
                    )
                )
            }
            results
        } catch (e: Exception) {
            Log.e(tag, "Failed to query Photon: ${e.message}")
            emptyList()
        }
    }
}
