/**
 * NER LogiGuard - Field Officer IndexedDB Database Layer
 * Provides robust offline-first storage for tactical incident reports, photo metadata, and sync management.
 */

const DB_NAME = 'NER_FieldOfficer_DB';
const DB_VERSION = 1;
const PENDING_STORE = 'pending_reports';
const SYNCED_STORE = 'synced_reports';

let dbInstance = null;

function openDB() {
  return new Promise((resolve, reject) => {
    if (dbInstance) {
      resolve(dbInstance);
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = event.target.result;

      // Store for pending, locally saved reports waiting for network
      if (!db.objectStoreNames.contains(PENDING_STORE)) {
        const pendingStore = db.createObjectStore(PENDING_STORE, { keyPath: 'local_id' });
        pendingStore.createIndex('timestamp', 'timestamp', { unique: false });
        pendingStore.createIndex('severity', 'severity', { unique: false });
        pendingStore.createIndex('incident_type', 'incident_type', { unique: false });
      }

      // Store for successfully synchronized reports
      if (!db.objectStoreNames.contains(SYNCED_STORE)) {
        const syncedStore = db.createObjectStore(SYNCED_STORE, { keyPath: 'local_id' });
        syncedStore.createIndex('server_id', 'server_id', { unique: false });
        syncedStore.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };

    request.onsuccess = (event) => {
      dbInstance = event.target.result;
      resolve(dbInstance);
    };

    request.onerror = (event) => {
      console.error('[IndexedDB] Database open error:', event.target.error);
      reject(event.target.error);
    };
  });
}

/**
 * Saves a new field report into the pending IndexedDB store.
 */
async function savePendingReport(report) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([PENDING_STORE], 'readwrite');
    const store = tx.objectStore(PENDING_STORE);
    
    // Ensure standard fields
    const record = {
      local_id: report.local_id || ('LOC-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7).toUpperCase()),
      officer_name: report.officer_name || 'Field Officer',
      incident_type: report.incident_type || 'LANDSLIDE',
      severity: report.severity || 'MODERATE',
      road_name: report.road_name || 'Unspecified Corridor',
      state: report.state || 'ASSAM',
      description: report.description || '',
      latitude: Number(report.latitude) || 26.1445,
      longitude: Number(report.longitude) || 91.7362,
      altitude_meters: Number(report.altitude_meters) || 120,
      road_blockage_pct: Number(report.road_blockage_pct) || 50,
      clearance_eta_hours: Number(report.clearance_eta_hours) || 3.0,
      photo_metadata: report.photo_metadata || null,
      timestamp: report.timestamp || Date.now(),
      created_at_iso: new Date().toISOString(),
      is_offline_origin: true,
      sync_status: 'SAVED_LOCALLY', // 'SAVED_LOCALLY' | 'PENDING' | 'SYNCED'
      sync_attempt_count: 0,
      last_sync_error: null
    };

    const request = store.put(record);
    request.onsuccess = () => resolve(record);
    request.onerror = (e) => reject(e.target.error);
  });
}

/**
 * Retrieves all pending unsynchronized reports from IndexedDB.
 */
async function getPendingReports() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([PENDING_STORE], 'readonly');
    const store = tx.objectStore(PENDING_STORE);
    const request = store.getAll();

    request.onsuccess = () => resolve(request.result || []);
    request.onerror = (e) => reject(e.target.error);
  });
}

/**
 * Retrieves all synced reports from the archive store.
 */
async function getSyncedReports() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([SYNCED_STORE], 'readonly');
    const store = tx.objectStore(SYNCED_STORE);
    const request = store.getAll();

    request.onsuccess = () => resolve(request.result || []);
    request.onerror = (e) => reject(e.target.error);
  });
}

/**
 * Moves successfully synchronized reports from pending to synced store.
 * Handles duplicate synchronizations safely via transactional swap.
 */
async function markReportsSynced(syncedLocalIds, serverIdMap = {}) {
  if (!syncedLocalIds || syncedLocalIds.length === 0) return;
  const db = await openDB();

  return new Promise((resolve, reject) => {
    const tx = db.transaction([PENDING_STORE, SYNCED_STORE], 'readwrite');
    const pendingStore = tx.objectStore(PENDING_STORE);
    const syncedStore = tx.objectStore(SYNCED_STORE);

    syncedLocalIds.forEach((localId) => {
      const getReq = pendingStore.get(localId);
      getReq.onsuccess = () => {
        const record = getReq.result;
        if (record) {
          record.sync_status = 'SYNCED';
          record.server_id = serverIdMap[localId] || ('FR-' + localId.replace('LOC-', ''));
          record.synced_at = Date.now();
          record.synced_at_iso = new Date().toISOString();

          syncedStore.put(record);
          pendingStore.delete(localId);
        }
      };
    });

    tx.oncomplete = () => resolve(true);
    tx.onerror = (e) => reject(e.target.error);
  });
}

/**
 * Deletes a single pending report from local storage.
 */
async function deletePendingReport(localId) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([PENDING_STORE], 'readwrite');
    const store = tx.objectStore(PENDING_STORE);
    const request = store.delete(localId);

    request.onsuccess = () => resolve(true);
    request.onerror = (e) => reject(e.target.error);
  });
}

/**
 * Clears all test or temporary reports.
 */
async function clearAllReports() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([PENDING_STORE, SYNCED_STORE], 'readwrite');
    tx.objectStore(PENDING_STORE).clear();
    tx.objectStore(SYNCED_STORE).clear();

    tx.oncomplete = () => resolve(true);
    tx.onerror = (e) => reject(e.target.error);
  });
}

window.NER_DB = {
  savePendingReport,
  getPendingReports,
  getSyncedReports,
  markReportsSynced,
  deletePendingReport,
  clearAllReports
};
