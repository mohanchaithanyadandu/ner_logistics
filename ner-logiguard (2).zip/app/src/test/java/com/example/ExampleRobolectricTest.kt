package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.DemoWorkflowManager
import com.example.engine.RouteOptimizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("NER LogiGuard", appName)
  }

  @Test
  fun `verify demo workflow 23 steps configured`() {
    assertEquals(23, DemoWorkflowManager.STEPS.size)
    assertEquals(1, DemoWorkflowManager.STEPS.first().stepIndex)
    assertEquals(23, DemoWorkflowManager.STEPS.last().stepIndex)
  }

  @Test
  fun `verify route optimizer resolves key hubs`() {
    val ghy = RouteOptimizer.getLocationById("GHY")
    val twg = RouteOptimizer.getLocationById("TWG")
    assertNotNull(ghy)
    assertNotNull(twg)
    assertEquals("Guwahati Logistics Hub", ghy?.name)
    assertEquals("Tawang Forward Outpost", twg?.name)
  }

  @Test
  fun `verify navigation endpoint formatter prefers exact coordinates`() {
    val ghy = RouteOptimizer.getLocationById("GHY")!!
    val endpoint = com.example.util.ExternalNavigationLauncher.formatLocationEndpoint(ghy)
    assertEquals("${ghy.latitude},${ghy.longitude}", endpoint)
  }

  @Test
  fun `verify navigation launcher graceful fallback for route`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val ghy = RouteOptimizer.getLocationById("GHY")!!
    val twg = RouteOptimizer.getLocationById("TWG")!!

    val candidates = RouteOptimizer.computeRouteCandidates(ghy, twg)
    assertTrue("Candidates should not be empty", candidates.isNotEmpty())

    val selected = candidates.first()
    val result = com.example.util.ExternalNavigationLauncher.openGoogleMapsDirections(context, selected)
    // On headless test environment without Google Maps app, it should succeed via browser fallback or handle gracefully
    assertTrue(
      "Result should be direct app or browser fallback",
      result is com.example.util.NavigationLaunchResult.SuccessDirectApp ||
      result is com.example.util.NavigationLaunchResult.SuccessBrowserFallback
    )
  }
}

