package com.example

import com.example.data.models.IncidentSeverity
import com.example.data.models.IncidentStatus
import com.example.data.models.IncidentType
import com.example.data.models.NERState
import com.example.data.models.RiskLevel
import com.example.data.models.RoadIncident
import com.example.data.models.UserRole
import com.example.engine.RouteOptimizer
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun `verify multi-factor risk recalculates when incident is injected`() {
    val ghy = RouteOptimizer.getLocationById("GHY")
    val slr = RouteOptimizer.getLocationById("SLR")
    val routesClean = RouteOptimizer.computeRouteCandidates(
      origin = ghy,
      destination = slr,
      currentPrecipitationMm = 10.0,
      currentSoilMoisturePct = 50,
      activeIncidents = emptyList(),
      forceOffline = true
    )
    assertTrue("Should find routes between Guwahati and Silchar", routesClean.isNotEmpty())

    val nh6Route = routesClean.firstOrNull { it.name.contains("NH-6") || it.corridorCode.contains("NH-6") || it.id.contains("NH-6") }
    assertNotNull("NH-6 route should exist", nh6Route)

    val simulatedIncident = RoadIncident(
      id = "SIM_TEST",
      title = "NH-6 Blockage",
      type = IncidentType.LANDSLIDE,
      severity = IncidentSeverity.CRITICAL_BLOCKAGE,
      latitude = 25.10,
      longitude = 92.36,
      locationName = "Sonapur Tunnel",
      state = NERState.MEGHALAYA,
      corridorName = "NH-6",
      description = "Major mudslide blocking both lanes near Sonapur",
      reportedBy = "BRO 42 BRTF",
      reportedRole = UserRole.FIELD_OFFICER,
      reportedTimestamp = System.currentTimeMillis(),
      isVerified = true,
      status = IncidentStatus.ACTIVE,
      clearanceEtaHours = 18.0,
      affectedVehiclesCount = 4
    )

    val routesBlocked = RouteOptimizer.computeRouteCandidates(
      origin = ghy,
      destination = slr,
      currentPrecipitationMm = 85.0,
      currentSoilMoisturePct = 95,
      activeIncidents = listOf(simulatedIncident),
      forceOffline = true
    )
    val nh6Blocked = routesBlocked.firstOrNull { it.name.contains("NH-6") || it.corridorCode.contains("NH-6") || it.id.contains("NH-6") }
    assertNotNull(nh6Blocked)
    assertTrue(
      "Blocked route should have higher risk than clean route (clean: ${nh6Route?.compositeRiskScore}, blocked: ${nh6Blocked?.compositeRiskScore}, level: ${nh6Blocked?.riskLevel})",
      nh6Blocked!!.compositeRiskScore > nh6Route!!.compositeRiskScore
    )
  }

  @Test
  fun `verify India wide geocoding resolves cities across India`() = kotlinx.coroutines.runBlocking {
    val geocoder = com.example.data.remote.GeocodingService()

    val blrResults = geocoder.searchLocations("Bengaluru")
    assertTrue("Should find Bengaluru", blrResults.isNotEmpty())
    val blr = blrResults.first()
    assertEquals("Bengaluru", blr.name)
    assertEquals("Karnataka", blr.state)
    assertTrue(blr.latitude in 12.0..14.0)
    assertTrue(blr.longitude in 76.0..78.5)

    val mumResults = geocoder.searchLocations("Mumbai")
    assertTrue("Should find Mumbai", mumResults.isNotEmpty())
    val mum = mumResults.first()
    assertEquals("Mumbai", mum.name)
    assertEquals("Maharashtra", mum.state)

    val delResults = geocoder.searchLocations("Delhi")
    assertTrue("Should find Delhi", delResults.isNotEmpty())

    val kolResults = geocoder.searchLocations("Kolkata")
    assertTrue("Should find Kolkata", kolResults.isNotEmpty())

    val tawangResults = geocoder.searchLocations("Tawang")
    assertTrue("Should find Tawang", tawangResults.isNotEmpty())
    assertEquals("Arunachal Pradesh", tawangResults.first().state)
  }

  @Test
  fun `verify route computation handles pan-India origins and destinations`() {
    val origin = com.example.data.models.LocationPoint(
      id = "LOC_BLR",
      name = "Bengaluru",
      state = NERState.KARNATAKA,
      latitude = 12.9716,
      longitude = 77.5946
    )
    val dest = com.example.data.models.LocationPoint(
      id = "LOC_DEL",
      name = "Delhi",
      state = NERState.DELHI,
      latitude = 28.6139,
      longitude = 77.2090
    )

    val candidates = RouteOptimizer.computeRouteCandidates(
      origin = origin,
      destination = dest,
      forceOffline = true
    )
    assertTrue("Should generate candidates for pan-India route", candidates.isNotEmpty())
    val primary = candidates.first()
    assertTrue("Distance between BLR and DEL should exceed 1500 km", primary.distanceKm > 1500)
    assertTrue("Should have polyline coordinates", primary.polylineCoordinates.isNotEmpty())
  }

  @Test
  fun `verify external navigation endpoint format`() {
    val point = com.example.data.models.LocationPoint(
      id = "TEST_LOC",
      name = "Guwahati Airport",
      state = NERState.ASSAM,
      latitude = 26.1061,
      longitude = 91.5859
    )
    val endpoint = com.example.util.ExternalNavigationLauncher.formatLocationEndpoint(point)
    assertEquals("26.1061,91.5859", endpoint)
  }

  @Test
  fun `verify fleet corridors have valid waypoints`() {
    val corridors = com.example.engine.FleetSimulationEngine.CORRIDORS
    assertTrue("Fleet corridors should not be empty", corridors.isNotEmpty())
    corridors.forEach { corridor ->
      assertTrue("Corridor ${corridor.corridorName} should have at least 2 waypoints", corridor.waypoints.size >= 2)
      corridor.waypoints.forEach { wp ->
        assertTrue("Latitude should be within India bounds", wp.first in 8.0..37.0)
        assertTrue("Longitude should be within India bounds", wp.second in 68.0..98.0)
      }
    }
  }
}

