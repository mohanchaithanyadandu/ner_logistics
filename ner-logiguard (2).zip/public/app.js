/**
 * NER LogiGuard Tactical Command Center - Web Frontend Logic
 * OpenStreetMap/Leaflet + Real-time WebSockets + Supabase/FastAPI API Sync
 */

// Global Dashboard State
const CommandState = {
  map: null,
  mapLayers: {
    corridors: null,
    hazards: null,
    vehicles: null
  },
  activeVehicles: [
    { id: 'V-101', name: 'Convoy Alpha-1', origin: 'Guwahati (AS)', destination: 'Dimapur (NL)', status: 'ACTIVE', lat: 26.18, lng: 92.85, speed: 44, risk: 24 },
    { id: 'V-102', name: 'Convoy Bravo-2', origin: 'Dimapur (NL)', destination: 'Kohima (NL)', status: 'REROUTING', lat: 25.75, lng: 93.72, speed: 28, risk: 78 },
    { id: 'V-103', name: 'Convoy Charlie-3', origin: 'Siliguri (WB)', destination: 'Gangtok (SK)', status: 'ACTIVE', lat: 27.12, lng: 88.54, speed: 38, risk: 36 },
    { id: 'V-104', name: 'Convoy Delta-4', origin: 'Shillong (ML)', destination: 'Silchar (AS)', status: 'ACTIVE', lat: 25.42, lng: 92.35, speed: 42, risk: 42 },
    { id: 'V-105', name: 'Convoy Echo-5', origin: 'Imphal (MN)', destination: 'Moreh Border (MN)', status: 'EMERGENCY', lat: 24.62, lng: 94.05, speed: 18, risk: 88 }
  ],
  activeHazards: [
    { id: 'HAZ-1', name: 'Chumukedima Mudslide', type: 'LANDSLIDE', state: 'Nagaland', lat: 25.79, lng: 93.77, severity: 'CRITICAL', blockage: 85, eta: 4.5 },
    { id: 'HAZ-2', name: 'NH-10 29th Mile Washout', type: 'ROAD_COLLAPSE', state: 'Sikkim/WB', lat: 27.05, lng: 88.48, severity: 'MODERATE', blockage: 50, eta: 2.5 },
    { id: 'HAZ-3', name: 'Sonapur Tunnel Flood', type: 'FLASH_FLOOD', state: 'Meghalaya', lat: 25.18, lng: 92.38, severity: 'MODERATE', blockage: 40, eta: 1.5 },
    { id: 'HAZ-4', name: 'Sela Pass Snowdrift', type: 'SNOW_ICE', state: 'Arunachal', lat: 27.50, lng: 92.10, severity: 'CRITICAL', blockage: 90, eta: 6.0 }
  ],
  corridors: [
    { name: 'NH-29: Dimapur → Kohima', state: 'Nagaland', lengthKm: 74, avgRisk: 68, coords: [[25.90, 93.73], [25.79, 93.77], [25.75, 93.85], [25.67, 94.10]] },
    { name: 'NH-10: Siliguri → Gangtok', state: 'Sikkim', lengthKm: 114, avgRisk: 54, coords: [[26.72, 88.43], [26.89, 88.45], [27.05, 88.48], [27.33, 88.61]] },
    { name: 'NH-6: Shillong → Silchar', state: 'Meghalaya/Assam', lengthKm: 215, avgRisk: 48, coords: [[25.57, 91.89], [25.35, 92.20], [25.18, 92.38], [24.83, 92.80]] },
    { name: 'NH-102: Imphal → Moreh', state: 'Manipur', lengthKm: 107, avgRisk: 62, coords: [[24.81, 93.94], [24.62, 94.05], [24.24, 94.30]] }
  ],
  wsClient: null,
  isWsConnected: false,
  simInterval: null
};

// Initialize Application on Page Load
window.addEventListener('DOMContentLoaded', async () => {
  initMap();
  initEventListeners();
  renderFleetTable();
  await checkBackendStatus();
  initWebSocket();
});

// Initialize Leaflet Map (OpenStreetMap Dark/Tactical theme, zero API keys required)
function initMap() {
  // Center on North East India
  CommandState.map = L.map('leaflet-map', {
    zoomControl: true,
    attributionControl: true
  }).setView([26.15, 92.85], 7);

  // Free OpenStreetMap CartoDB Dark Matter tiles
  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/">CARTO</a>',
    subdomains: 'abcd',
    maxZoom: 18
  }).addTo(CommandState.map);

  CommandState.mapLayers.corridors = L.layerGroup().addTo(CommandState.map);
  CommandState.mapLayers.hazards = L.layerGroup().addTo(CommandState.map);
  CommandState.mapLayers.vehicles = L.layerGroup().addTo(CommandState.map);

  renderCorridorsOnMap();
  renderHazardsOnMap();
  renderVehiclesOnMap();
}

// Render Corridors on Leaflet Map
function renderCorridorsOnMap() {
  CommandState.mapLayers.corridors.clearLayers();

  CommandState.corridors.forEach(c => {
    const color = c.avgRisk > 65 ? '#ff3d00' : c.avgRisk > 45 ? '#ffb300' : '#00e676';
    const polyline = L.polyline(c.coords, {
      color: color,
      weight: 5,
      opacity: 0.85,
      dashArray: c.avgRisk > 65 ? '8, 8' : null
    }).bindPopup(`
      <div style="color: #0f172a; font-family: sans-serif; font-size: 12px;">
        <strong style="font-size: 14px;">🛣️ ${c.name}</strong><br/>
        <strong>State:</strong> ${c.state}<br/>
        <strong>Length:</strong> ${c.lengthKm} km<br/>
        <strong>Risk Index:</strong> <span style="font-weight: bold; color: ${color};">${c.avgRisk}/100</span>
      </div>
    `);
    CommandState.mapLayers.corridors.addLayer(polyline);
  });
}

// Render Hazards on Leaflet Map
function renderHazardsOnMap() {
  CommandState.mapLayers.hazards.clearLayers();

  CommandState.activeHazards.forEach(h => {
    const marker = L.circleMarker([h.lat, h.lng], {
      radius: 9,
      fillColor: h.severity === 'CRITICAL' ? '#ff3d00' : '#ffb300',
      color: '#ffffff',
      weight: 2,
      opacity: 1,
      fillOpacity: 0.9
    }).bindPopup(`
      <div style="color: #0f172a; font-family: sans-serif; font-size: 12px;">
        <strong style="font-size: 14px; color: #dc2626;">⚠️ ${h.name}</strong><br/>
        <strong>Type:</strong> ${h.type}<br/>
        <strong>State:</strong> ${h.state}<br/>
        <strong>Road Blockage:</strong> ${h.blockage}%<br/>
        <strong>Clearance ETA:</strong> ${h.eta} hrs
      </div>
    `);
    CommandState.mapLayers.hazards.addLayer(marker);
  });
}

// Render Fleet on Leaflet Map
function renderVehiclesOnMap() {
  CommandState.mapLayers.vehicles.clearLayers();

  CommandState.activeVehicles.forEach(v => {
    const color = v.status === 'EMERGENCY' ? '#ff3d00' : v.status === 'REROUTING' ? '#ffb300' : '#00e5ff';
    const marker = L.circleMarker([v.lat, v.lng], {
      radius: 8,
      fillColor: color,
      color: '#ffffff',
      weight: 2,
      opacity: 1,
      fillOpacity: 0.95
    }).bindPopup(`
      <div style="color: #0f172a; font-family: sans-serif; font-size: 12px;">
        <strong style="font-size: 14px; color: #0284c7;">🚛 ${v.name} (${v.id})</strong><br/>
        <strong>Route:</strong> ${v.origin} → ${v.destination}<br/>
        <strong>Status:</strong> <span style="font-weight: bold; color: ${color};">${v.status}</span><br/>
        <strong>Speed:</strong> ${v.speed} km/h | <strong>Risk:</strong> ${v.risk}%
      </div>
    `);
    CommandState.mapLayers.vehicles.addLayer(marker);
  });
}

// Render Fleet Table in DOM
function renderFleetTable() {
  const tbody = document.getElementById('fleet-table-body');
  if (!tbody) return;

  tbody.innerHTML = CommandState.activeVehicles.map(v => {
    const statusClass = v.status === 'EMERGENCY' ? 'emergency' : v.status === 'REROUTING' ? 'rerouting' : 'active';
    return `
      <tr>
        <td><strong>${v.name}</strong><br/><span style="color: var(--text-muted); font-size: 0.72rem;">${v.id}</span></td>
        <td>${v.origin} → ${v.destination}</td>
        <td><span class="badge-status ${statusClass}">${v.status}</span></td>
        <td>${v.speed} km/h</td>
        <td style="font-weight: bold; color: ${v.risk > 70 ? 'var(--crimson-alert)' : v.risk > 40 ? 'var(--amber-warning)' : 'var(--emerald-green)'};">${v.risk}%</td>
      </tr>
    `;
  }).join('');
}

// Initialize UI Event Listeners
function initEventListeners() {
  // Backend Settings Modal
  const settingsBtn = document.getElementById('backend-settings-btn');
  const modal = document.getElementById('settings-modal');
  const closeBtn = document.getElementById('close-modal-btn');
  const saveBtn = document.getElementById('save-backend-url-btn');
  const testPingBtn = document.getElementById('test-ping-btn');
  const backendInput = document.getElementById('backend-url-input');

  if (settingsBtn && modal) {
    settingsBtn.addEventListener('click', () => {
      backendInput.value = window.NER_CONFIG.getApiBaseUrl();
      modal.classList.add('open');
    });
  }

  if (closeBtn && modal) {
    closeBtn.addEventListener('click', () => modal.classList.remove('open'));
  }

  if (saveBtn) {
    saveBtn.addEventListener('click', async () => {
      const url = backendInput.value.trim();
      window.NER_CONFIG.setApiBaseUrl(url);
      modal.classList.remove('open');
      await checkBackendStatus();
      initWebSocket();
    });
  }

  if (testPingBtn) {
    testPingBtn.addEventListener('click', async () => {
      const feedback = document.getElementById('ping-feedback');
      feedback.innerHTML = '<span style="color: var(--amber-warning);">Testing connection...</span>';
      const tempUrl = backendInput.value.trim();
      const testUrl = tempUrl ? `${tempUrl.replace(/\/+$/, '')}/health` : '/health';
      
      const start = Date.now();
      try {
        const res = await fetch(testUrl);
        const lat = Date.now() - start;
        if (res.ok) {
          const data = await res.json();
          feedback.innerHTML = `<span style="color: var(--emerald-green);">✓ Connected! Latency: ${lat}ms | DB: ${data.database || 'OK'}</span>`;
        } else {
          feedback.innerHTML = `<span style="color: var(--crimson-alert);">⚠️ HTTP ${res.status}: Failed</span>`;
        }
      } catch (err) {
        feedback.innerHTML = `<span style="color: var(--crimson-alert);">✗ Error: ${err.message}</span>`;
      }
    });
  }

  // Simulation Controls
  const simStartBtn = document.getElementById('sim-start-btn');
  const simDeviateBtn = document.getElementById('sim-deviate-btn');

  if (simStartBtn) {
    simStartBtn.addEventListener('click', () => {
      if (CommandState.simInterval) {
        clearInterval(CommandState.simInterval);
        CommandState.simInterval = null;
        simStartBtn.innerText = '▶ Start Telemetry Stream';
        simStartBtn.classList.remove('btn-success');
      } else {
        CommandState.simInterval = setInterval(simulateVehicleStep, 2500);
        simStartBtn.innerText = '⏸ Pause Telemetry Stream';
        simStartBtn.classList.add('btn-success');
      }
    });
  }

  if (simDeviateBtn) {
    simDeviateBtn.addEventListener('click', () => {
      const v2 = CommandState.activeVehicles.find(v => v.id === 'V-102');
      if (v2) {
        v2.status = v2.status === 'REROUTING' ? 'ACTIVE' : 'REROUTING';
        v2.risk = v2.status === 'REROUTING' ? 82 : 35;
        renderVehiclesOnMap();
        renderFleetTable();
        appendAiConsole(`[REROUTING ENGINE] Triggered automated dynamic corridor recalculation for Convoy Bravo-2 (V-102) due to Chumukedima NH-29 debris blockage.`);
      }
    });
  }

  // AI Copilot Ask
  const askBtn = document.getElementById('ai-ask-btn');
  const aiInput = document.getElementById('ai-prompt-input');
  if (askBtn && aiInput) {
    askBtn.addEventListener('click', () => handleAiQuery(aiInput.value.trim()));
    aiInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') handleAiQuery(aiInput.value.trim());
    });
  }
}

// Simulate Vehicle Step Movement for Live Demo
function simulateVehicleStep() {
  CommandState.activeVehicles.forEach(v => {
    // Add small realistic GPS jitter/progress
    v.lat += (Math.random() - 0.48) * 0.004;
    v.lng += (Math.random() - 0.48) * 0.004;
    v.speed = Math.max(15, Math.min(65, Math.round(v.speed + (Math.random() * 6 - 3))));
  });
  renderVehiclesOnMap();
  renderFleetTable();
}

// AI Copilot Query Engine (Backend API with intelligent local fallback)
async function handleAiQuery(prompt) {
  if (!prompt) return;
  const inputEl = document.getElementById('ai-prompt-input');
  if (inputEl) inputEl.value = '';

  appendAiConsole(`\n> Operator: ${prompt}`);
  appendAiConsole(`⚡ Analyzing high-altitude terrain, Open-Meteo precipitation models, and active BRO clearance logs...`);

  try {
    const endpoint = window.NER_CONFIG.getEndpointUrl('/api/v1/ai/query');
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: prompt })
    });

    if (res.ok) {
      const data = await res.json();
      appendAiConsole(`🤖 Gemini Copilot: ${data.response || data.analysis || JSON.stringify(data)}`);
      return;
    }
  } catch (e) {
    // Graceful fallback if backend is offline
  }

  // Client-Side Deterministic Mountain Intelligence Fallback
  setTimeout(() => {
    let response = '';
    const q = prompt.toLowerCase();
    if (q.includes('nh-29') || q.includes('chumukedima') || q.includes('dimapur') || q.includes('landslide')) {
      response = 'TACTICAL ADVISORY: NH-29 Chumukedima Ghat sector reports 85% lane obstruction from continuous monsoon saturation. Recommended Detour: Route heavy supply convoys via Niuland-Kohima bypass. Estimated delay: +48 mins. Speed limit: 25 km/h on steep descent.';
    } else if (q.includes('gangtok') || q.includes('sikkim') || q.includes('nh-10')) {
      response = 'TACTICAL ADVISORY: NH-10 Teesta Corridor active monitoring at 29th Mile. Open-Meteo telemetry shows 42mm precipitation in last 6 hours. Single-line convoy operational under BRO supervision.';
    } else if (q.includes('sela') || q.includes('arunachal') || q.includes('tawang')) {
      response = 'HIGH-ALTITUDE PASS ADVISORY: Sela Pass (4,170m) experiencing sub-zero surface temperatures with black ice formation. Anti-skid tire chains required for all multi-axle freight carriers.';
    } else {
      response = `TACTICAL SYNTHESIS: Analyzed 8 NER state corridor networks. 4 active hazard sectors tracked with real-time Open-Meteo satellite feeds. All critical supply lines to Kohima, Imphal, and Gangtok have calculated detour passes operational.`;
    }
    appendAiConsole(`🤖 Tactical Copilot: ${response}`);
  }, 400);
}

function appendAiConsole(text) {
  const consoleEl = document.getElementById('ai-console-log');
  if (consoleEl) {
    consoleEl.innerText += text + '\n';
    consoleEl.scrollTop = consoleEl.scrollHeight;
  }
}

// Check Backend Health & Status
async function checkBackendStatus() {
  const pill = document.getElementById('header-status-pill');
  const dot = document.getElementById('header-status-dot');
  const text = document.getElementById('header-status-text');
  const dbStatus = document.getElementById('hud-db-status');

  const health = await window.NER_CONFIG.checkHealth();
  if (health.ok) {
    if (dot) dot.className = 'status-dot connected';
    if (text) text.innerText = 'BACKEND CONNECTED';
    if (dbStatus) dbStatus.innerText = 'ONLINE (Supabase / Postgres)';
    console.log('[Backend] Successfully linked to API:', window.NER_CONFIG.getApiBaseUrl() || 'Same Origin');
  } else {
    if (dot) dot.className = 'status-dot';
    if (text) text.innerText = 'STANDALONE / LOCAL MODE';
    if (dbStatus) dbStatus.innerText = 'OFFLINE BUFFER (IndexedDB / SQLite)';
    console.log('[Backend] Running in standalone/offline mode. Click Settings to link backend.');
  }
}

// Initialize Real-time WebSocket Connection
function initWebSocket() {
  if (CommandState.wsClient) {
    try { CommandState.wsClient.close(); } catch (e) {}
  }

  const wsUrl = window.NER_CONFIG.getWsUrl('fleet');
  console.log('[WebSocket] Connecting to:', wsUrl);

  try {
    CommandState.wsClient = new WebSocket(wsUrl);

    CommandState.wsClient.onopen = () => {
      console.log('[WebSocket] Live stream connection established.');
      CommandState.isWsConnected = true;
    };

    CommandState.wsClient.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'VEHICLE_POSITION_UPDATE' || msg.type === 'TELEMETRY') {
          const veh = CommandState.activeVehicles.find(v => v.id === msg.vehicle_id);
          if (veh) {
            veh.lat = msg.latitude || veh.lat;
            veh.lng = msg.longitude || veh.lng;
            veh.speed = msg.speed_kmh || veh.speed;
            renderVehiclesOnMap();
            renderFleetTable();
          }
        }
      } catch (e) {}
    };

    CommandState.wsClient.onclose = () => {
      CommandState.isWsConnected = false;
    };
  } catch (err) {
    console.warn('[WebSocket] Init failed (running offline mode):', err);
  }
}
