/**
 * NER LogiGuard - Centralized Client Configuration
 * Supports decoupled deployment (Vercel Frontend + Render/Railway/Fly.io Backend + Supabase Database)
 */
(function (window) {
  // Check URL query parameters for override (e.g. ?backend=https://ner-backend.onrender.com)
  const urlParams = new URLSearchParams(window.location.search);
  const paramBackend = urlParams.get('backend') || urlParams.get('api');
  if (paramBackend) {
    localStorage.setItem('NER_API_BASE_URL', paramBackend.replace(/\/+$/, ''));
  }

  const DEFAULT_BACKEND_URL = (function () {
    // If user explicitly configured in localStorage
    const saved = localStorage.getItem('NER_API_BASE_URL');
    if (saved) return saved.replace(/\/+$/, '');

    // If running on localhost or same origin as backend
    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
      if (window.location.port === '8000') {
        return '';
      }
      return 'http://localhost:8000';
    }

    // Default: If hosted on separate frontend (like Vercel), fall back to relative or stored backend
    return '';
  })();

  const NER_CONFIG = {
    // Returns the base URL for REST API calls (without trailing slash)
    getApiBaseUrl: function () {
      const custom = localStorage.getItem('NER_API_BASE_URL');
      if (custom && custom.trim()) {
        return custom.trim().replace(/\/+$/, '');
      }
      return DEFAULT_BACKEND_URL;
    },

    // Saves custom backend URL
    setApiBaseUrl: function (url) {
      if (!url || !url.trim()) {
        localStorage.removeItem('NER_API_BASE_URL');
      } else {
        localStorage.setItem('NER_API_BASE_URL', url.trim().replace(/\/+$/, ''));
      }
    },

    // Returns the complete URL for an API endpoint
    getEndpointUrl: function (path) {
      const base = this.getApiBaseUrl();
      const cleanPath = path.startsWith('/') ? path : '/' + path;
      return base ? `${base}${cleanPath}` : cleanPath;
    },

    // Returns the WebSocket URL for a specific real-time channel
    getWsUrl: function (channel) {
      const base = this.getApiBaseUrl();
      const ch = channel || 'fleet';
      if (base) {
        const wsProtocol = base.startsWith('https:') ? 'wss:' : 'ws:';
        const host = base.replace(/^https?:\/\//, '');
        return `${wsProtocol}//${host}/ws/${ch}`;
      } else {
        const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        return `${wsProtocol}//${window.location.host}/ws/${ch}`;
      }
    },

    // Checks backend connectivity and health
    checkHealth: async function () {
      try {
        const url = this.getEndpointUrl('/health');
        const res = await fetch(url, { method: 'GET', headers: { 'Accept': 'application/json' } });
        if (res.ok) {
          const data = await res.json();
          return { ok: true, data: data, status: res.status };
        }
        return { ok: false, status: res.status, error: 'Non-200 response' };
      } catch (err) {
        return { ok: false, error: err.message };
      }
    }
  };

  window.NER_CONFIG = NER_CONFIG;
})(window);
