# NER LogiGuard — Weather & Landslide Data Sources Reference

## 1. Weather Data API

- **Provider:** [Open-Meteo API](https://open-meteo.com/)
- **Base URL:** `https://api.open-meteo.com/`
- **Endpoint:** `GET /v1/forecast`
- **API Key Required:** **No** (Open-Meteo is open-access and requires no API key or authentication token)
- **Queried Parameters (`current`):**
  - `temperature_2m` — Ambient temperature (°C)
  - `relative_humidity_2m` — Relative humidity (%)
  - `precipitation` — Total precipitation (mm)
  - `rain` — Rainfall intensity (mm)
  - `weather_code` — WMO weather interpretation code
  - `wind_speed_10m` — Wind speed at 10m altitude (km/h)
- **Fallback Behavior:** If network connectivity is unavailable or the endpoint cannot be reached, the repository automatically falls back to calibrated regional weather baselines for Northeast India.

---

## 2. Landslide & Terrain Vulnerability Engine

- **Provider:** Internal deterministic geotechnical scoring model (`RiskEngine`) paired with the local Room incident database
- **API Key Required:** **No** (No external commercial landslide API is used)

### Landslide Vulnerability Score Formula (`0–100`)

The score combines four weighted factors:

1. **Terrain Geomorphology Weight (up to 40 pts):**
   - `HIGH_ALTITUDE_PASS`: 40 pts
   - `HILLY_GHAT`: 32 pts
   - `FOREST_CORRIDOR`: 18 pts
   - `RIVER_BASIN`: 10 pts
   - `PLAINS`: 4 pts
2. **Elevation Gain Factor (up to 25 pts):**
   - `clamp(elevationGainMeters / 3000.0, 0..1) * 25`
3. **24-Hour Rainfall Saturation Factor (up to 25 pts):**
   - `clamp(rainfallSaturationMm / 120.0, 0..1) * 25` (fed from Open-Meteo precipitation data)
4. **Soil Moisture / Humidity Factor (up to 10 pts):**
   - `(humidityPct / 100.0) * 10` (fed from Open-Meteo relative humidity)

### Composite Risk & Route Scoring

- **Composite Hazard Risk (`0–100`):**
  - 30% Landslide Score + 25% Flood Score + 20% Weather Score + 15% Road Condition Score + 10% Active Incidents
  - Risk levels: `0–30` Low, `31–60` Moderate, `61–80` High, `81–100` Critical
- **Multi-Factor Route Score (`1–100`, lower is better):**
  - 30% Incident/Disruption Risk + 25% Road Accessibility Risk + 20% Weather Risk + 15% ETA Risk + 10% Distance Risk
  - Active critical landslide blockades from the local Room database enforce a minimum route score of `85` and mark the route as blocked.

---

## 3. API Keys Used in the Project

| Feature | Provider / Engine | API Key Required? |
| :--- | :--- | :--- |
| Live Weather Observations | Open-Meteo (`api.open-meteo.com`) | **No** |
| Landslide & Flood Risk Scoring | Local `RiskEngine` + Room DB | **No** |
| Geocoding & Place Search | Local Indian Hub Catalog + OpenStreetMap Nominatim | **No** |
| Turn-by-Turn Navigation | External Google Maps Intent | **No** |
| AI Logistics Copilot (Optional) | Gemini API | **Yes** (`GEMINI_API_KEY` via Secrets panel / `BuildConfig`) |
