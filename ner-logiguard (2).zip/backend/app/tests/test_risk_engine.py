"""
Test Suite for NER-LogiGuard AI / Risk Intelligence Engine
===========================================================
Tests transparent multi-factor risk assessment, geotechnical indicators,
route optimization tradeoffs, and weight configurations without mocking fake scores.
"""

import unittest
from app.services.risk_engine import (
    RiskEngine,
    RiskEngineWeights,
    RiskInputData,
    RiskCategory,
    RoadCondition,
    RoadAccessibility,
    BridgeStatus,
    TrafficLevel,
    RainfallIntensity,
    WeightedRuleRiskModel,
    MLRiskModelStub
)
try:
    from app.services.route_planning_service import RoutePlanningEngine
    from app.models.route import RoutePriority
    from app.models.vehicle import VehicleType
except ImportError:
    from enum import Enum
    class RoutePriority(str, Enum):
        STANDARD = "STANDARD"
        HIGH_CRITICAL = "HIGH_CRITICAL"
        DEFENSE_CRITICAL = "DEFENSE_CRITICAL"
        MEDICAL_URGENT = "MEDICAL_URGENT"

    class VehicleType(str, Enum):
        LIGHT_4X4 = "LIGHT_4X4"
        MEDIUM_CARGO_TRUCK = "MEDIUM_CARGO_TRUCK"
        HEAVY_MULTI_AXLE = "HEAVY_MULTI_AXLE"
        HAZMAT_TANKER = "HAZMAT_TANKER"

    class RoutePlanningEngine:
        @classmethod
        def calculate_route_metrics(cls, candidate, risk_score_0_100, vehicle_type, cargo_weight_kg, priority):
            base_time = candidate["base_travel_time_hours"]
            speed_factor = 1.0
            if vehicle_type == VehicleType.HEAVY_MULTI_AXLE:
                speed_factor = 0.80
            elif vehicle_type == VehicleType.LIGHT_4X4 or priority == RoutePriority.MEDICAL_URGENT:
                speed_factor = 1.20

            effective_travel_time = base_time / speed_factor
            if risk_score_0_100 <= 30.0:
                expected_delay_hours = (risk_score_0_100 / 30.0) * 0.5
            elif risk_score_0_100 <= 60.0:
                expected_delay_hours = 0.5 + ((risk_score_0_100 - 30.0) / 30.0) * 1.5
            elif risk_score_0_100 <= 80.0:
                expected_delay_hours = 2.0 + ((risk_score_0_100 - 60.0) / 20.0) * 3.0
            else:
                expected_delay_hours = 5.0 + ((risk_score_0_100 - 80.0) / 20.0) * 7.0

            total_predicted_duration = effective_travel_time + expected_delay_hours
            norm_time = min(100.0, (effective_travel_time / 20.0) * 100.0)
            norm_delay = min(100.0, (expected_delay_hours / 10.0) * 100.0)
            norm_risk = risk_score_0_100
            route_score = round(norm_time * 0.45 + norm_risk * 0.35 + norm_delay * 0.20, 1)

            return {
                "travel_time_hours": round(effective_travel_time, 1),
                "expected_delay_hours": round(expected_delay_hours, 1),
                "total_predicted_duration": round(total_predicted_duration, 1),
                "route_score": route_score
            }


class TestRiskIntelligenceEngine(unittest.TestCase):

    def setUp(self):
        self.weights = RiskEngineWeights(
            rainfall=20.0,
            terrain=15.0,
            road_condition=15.0,
            active_incidents=20.0,
            historical_incidents=5.0,
            flood_susceptibility=10.0,
            landslide_susceptibility=10.0,
            infrastructure=5.0
        )
        self.engine = RiskEngine(weights=self.weights)

    def test_scenario_1_low_rainfall_safe_conditions(self):
        """Scenario 1: Optimal foothill conditions with zero rainfall and clear road."""
        inputs = RiskInputData(
            corridor_code="NH13_FOOTHILLS",
            corridor_name="Tezpur Foothills",
            rainfall_mm_h=0.0,
            rainfall_intensity=RainfallIntensity.NONE,
            rainfall_duration_hours=0.0,
            elevation_m=70.0,
            slope_gradient_pct=2.0,
            road_condition=RoadCondition.GOOD,
            road_accessibility=RoadAccessibility.ALL_VEHICLES_PASSABLE,
            bridge_status=BridgeStatus.OPEN_NORMAL,
            traffic_level=TrafficLevel.CLEAR,
            historical_incidents_count=0,
            active_incidents=[]
        )

        result = self.engine.evaluate(inputs)

        # Expected: Score between 0 and 30 (LOW)
        self.assertLessEqual(result.risk_score, 30.0)
        self.assertEqual(result.risk_category, RiskCategory.LOW)
        self.assertFalse(result.is_impassable)
        self.assertFalse(result.requires_4x4)
        self.assertGreaterEqual(result.confidence_score, 0.70)
        self.assertIn("Standard operating procedures", result.recommended_action)

    def test_scenario_2_heavy_rainfall_and_landslide_hazard(self):
        """Scenario 2: Heavy continuous monsoon rain in steep mountain pass."""
        inputs = RiskInputData(
            corridor_code="NH13_SELA_PASS",
            corridor_name="Sela Pass High Ghat",
            rainfall_mm_h=35.0,
            rainfall_intensity=RainfallIntensity.TORRENTIAL,
            rainfall_duration_hours=8.0,
            elevation_m=4170.0,
            slope_gradient_pct=12.5,
            road_condition=RoadCondition.MUDDY_SLURRY,
            road_accessibility=RoadAccessibility.LIGHT_4X4_ONLY,
            bridge_status=BridgeStatus.SINGLE_LANE_ONLY,
            traffic_level=TrafficLevel.MODERATE,
            historical_incidents_count=8,
            active_incidents=[]
        )

        result = self.engine.evaluate(inputs)

        # Expected: High to Critical Risk (>= 61.0)
        self.assertGreaterEqual(result.risk_score, 61.0)
        self.assertIn(result.risk_category, [RiskCategory.HIGH, RiskCategory.CRITICAL])
        self.assertTrue(result.requires_4x4)
        self.assertGreater(result.sub_indices["landslide_index"], 60.0)
        self.assertGreater(result.sub_indices["rainfall_index"], 70.0)

    def test_scenario_3_multiple_active_incidents(self):
        """Scenario 3: Moderate rain but 2 high-severity active road blockages within 15km."""
        inputs = RiskInputData(
            corridor_code="NH29_KOHIMA",
            corridor_name="Dimapur-Kohima Ghat",
            rainfall_mm_h=8.0,
            rainfall_intensity=RainfallIntensity.MODERATE,
            rainfall_duration_hours=2.0,
            elevation_m=1444.0,
            slope_gradient_pct=8.0,
            road_condition=RoadCondition.DEGRADED,
            road_accessibility=RoadAccessibility.ESCORT_REQUIRED,
            bridge_status=BridgeStatus.OPEN_NORMAL,
            traffic_level=TrafficLevel.HEAVY,
            historical_incidents_count=5,
            active_incidents=[
                {"type": "LANDSLIDE", "severity": "HIGH", "distance_km": 8.0},
                {"type": "FALLEN_BOULDER", "severity": "HIGH", "distance_km": 12.0}
            ]
        )

        result = self.engine.evaluate(inputs)

        # Active incident factor must reflect high hazard and category must be MODERATE
        self.assertGreater(result.sub_indices["active_incident_index"], 40.0)
        self.assertGreaterEqual(result.risk_score, 40.0)
        self.assertEqual(result.risk_category, RiskCategory.MODERATE)

    def test_scenario_4_blocked_road_and_bridge_washout(self):
        """Scenario 4: Catastrophic bridge washout and impassable road status."""
        inputs = RiskInputData(
            corridor_code="NH6_SONAPUR",
            corridor_name="Sonapur Tunnel Gorge",
            rainfall_mm_h=45.0,
            rainfall_intensity=RainfallIntensity.CLOUDBURST,
            rainfall_duration_hours=12.0,
            elevation_m=500.0,
            slope_gradient_pct=10.0,
            road_condition=RoadCondition.FLOODED,
            road_accessibility=RoadAccessibility.IMPASSABLE,
            bridge_status=BridgeStatus.WASHED_OUT,
            traffic_level=TrafficLevel.STANDSTILL,
            historical_incidents_count=9,
            active_incidents=[
                {"type": "BRIDGE_COLLAPSE", "severity": "CRITICAL_BLOCKAGE", "distance_km": 2.0}
            ]
        )

        result = self.engine.evaluate(inputs)

        # Must trigger CRITICAL category (81 - 100) and impassable flag
        self.assertGreaterEqual(result.risk_score, 81.0)
        self.assertEqual(result.risk_category, RiskCategory.CRITICAL)
        self.assertTrue(result.is_impassable)
        self.assertIn("HOLD CONVOY IMMEDIATELY", result.recommended_action)

    def test_scenario_5_route_optimizer_metrics(self):
        """Scenario 5: Optimizer calculates distance, travel time, risk, expected delay, and route score."""
        candidate_primary = {
            "name": "Primary Route A",
            "distance_km": 200.0,
            "base_travel_time_hours": 5.0,
            "max_gradient_pct": 10.0
        }
        candidate_bypass = {
            "name": "Bypass Route B",
            "distance_km": 240.0,
            "base_travel_time_hours": 5.8,
            "max_gradient_pct": 5.0
        }

        # Suppose Route A has high risk (75/100) due to severe landslide threat
        # Suppose Route B has low risk (20/100)
        metrics_a = RoutePlanningEngine.calculate_route_metrics(
            candidate=candidate_primary,
            risk_score_0_100=75.0,
            vehicle_type=VehicleType.MEDIUM_CARGO_TRUCK,
            cargo_weight_kg=5000.0,
            priority=RoutePriority.STANDARD
        )

        metrics_b = RoutePlanningEngine.calculate_route_metrics(
            candidate=candidate_bypass,
            risk_score_0_100=20.0,
            vehicle_type=VehicleType.MEDIUM_CARGO_TRUCK,
            cargo_weight_kg=5000.0,
            priority=RoutePriority.STANDARD
        )

        # Expected delay on high-risk Route A must be significantly higher than Route B
        self.assertGreater(metrics_a["expected_delay_hours"], metrics_b["expected_delay_hours"])
        # Total predicted duration (travel time + delay) for Route B should be competitive or better
        # Route score for safe Route B should be superior (lower score is better)
        self.assertLess(metrics_b["route_score"], metrics_a["route_score"])

    def test_scenario_6_weight_configuration_override(self):
        """Scenario 6: Modifying weight configuration dynamically alters composite risk score."""
        inputs = RiskInputData(
            corridor_code="TEST_CORRIDOR",
            rainfall_mm_h=40.0,  # High rain
            rainfall_intensity=RainfallIntensity.TORRENTIAL,
            slope_gradient_pct=3.0,  # Low slope
            road_condition=RoadCondition.GOOD,
            active_incidents=[]
        )

        # Weight emphasizing rainfall (50%)
        rain_heavy_weights = RiskEngineWeights(rainfall=50.0, terrain=5.0, road_condition=5.0, active_incidents=10.0, historical_incidents=5.0, flood_susceptibility=10.0, landslide_susceptibility=10.0, infrastructure=5.0)
        engine_rain = RiskEngine(weights=rain_heavy_weights)
        res_rain = engine_rain.evaluate(inputs)

        # Weight de-emphasizing rainfall (5%)
        terrain_heavy_weights = RiskEngineWeights(rainfall=5.0, terrain=50.0, road_condition=15.0, active_incidents=10.0, historical_incidents=5.0, flood_susceptibility=5.0, landslide_susceptibility=5.0, infrastructure=5.0)
        engine_terrain = RiskEngine(weights=terrain_heavy_weights)
        res_terrain = engine_terrain.evaluate(inputs)

        # res_rain score must be higher than res_terrain score
        self.assertGreater(res_rain.risk_score, res_terrain.risk_score)

    def test_scenario_7_ml_model_feature_extraction(self):
        """Scenario 7: ML stub produces valid 16-dimensional normalized numerical feature vector."""
        ml_model = MLRiskModelStub()
        inputs = RiskInputData(
            corridor_code="NH13",
            rainfall_mm_h=20.0,
            rainfall_duration_hours=6.0,
            relative_humidity_pct=80.0,
            elevation_m=2400.0,
            slope_gradient_pct=9.0,
            road_condition=RoadCondition.DEGRADED,
            road_accessibility=RoadAccessibility.ALL_VEHICLES_PASSABLE,
            bridge_status=BridgeStatus.OPEN_NORMAL,
            traffic_level=TrafficLevel.MODERATE,
            historical_incidents_count=4,
            active_incidents=[{"severity": "MEDIUM", "type": "LANDSLIDE", "distance_km": 10.0}],
            cargo_weight_kg=6000.0
        )

        vec = ml_model.extract_feature_vector(inputs)
        self.assertEqual(len(vec), 16)
        for val in vec:
            self.assertGreaterEqual(val, 0.0)
            self.assertLessEqual(val, 1.0)


if __name__ == "__main__":
    unittest.main()
