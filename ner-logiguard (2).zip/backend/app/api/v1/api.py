from fastapi import APIRouter

from app.api.v1.endpoints import (
    auth,
    users,
    routes,
    route_planning,
    vehicles,
    gps,
    incidents,
    field_reports,
    weather,
    risk,
    alerts,
    analytics,
    ai_assistant
)

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["Authentication & Roles"])
api_router.include_router(users.router, prefix="/users", tags=["Users & Security Audit"])
api_router.include_router(routes.router, prefix="/routes", tags=["Corridors & Deliveries"])
api_router.include_router(route_planning.router, prefix="/route-planning", tags=["Route Optimization & GIS Planning"])
api_router.include_router(vehicles.router, prefix="/vehicles", tags=["Fleet Management"])
api_router.include_router(gps.router, prefix="/gps", tags=["GPS Telemetry & Live Tracking"])
api_router.include_router(incidents.router, prefix="/incidents", tags=["Road Hazards & Incidents"])
api_router.include_router(field_reports.router, prefix="/field-reports", tags=["Field Reports & Offline Sync"])
api_router.include_router(weather.router, prefix="/weather", tags=["Meteorological Intelligence"])
api_router.include_router(risk.router, prefix="/risk", tags=["Multi-Factor Risk Engine"])
api_router.include_router(alerts.router, prefix="/alerts", tags=["Emergency Alerts & Notifications"])
api_router.include_router(analytics.router, prefix="/analytics", tags=["Dashboard Analytics & KPI"])
api_router.include_router(ai_assistant.router, prefix="/ai-assistant", tags=["Tactical AI Logistics Assistant"])
