import json
import time
import uuid
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User, UserRole
from app.models.route import Route, RouteSegment, Delivery, DeliveryStatus
from app.schemas.route import (
    RouteCreate,
    RouteResponse,
    DeliveryCreate,
    DeliveryResponse
)
from app.services.auth_service import get_current_user, require_roles

router = APIRouter()


@router.get("/", response_model=List[RouteResponse])
async def list_routes(
    skip: int = 0,
    limit: int = 20,
    db: Session = Depends(get_db)
):
    """List all registered transport corridors, bypasses, and topological segments."""
    routes = db.query(Route).offset(skip).limit(limit).all()
    return routes


@router.get("/{corridor_code}", response_model=RouteResponse)
async def get_route_by_corridor_code(
    corridor_code: str,
    db: Session = Depends(get_db)
):
    """Retrieve detailed highway corridor information by corridor code (e.g. NH13_GHY_TWG)."""
    route = db.query(Route).filter(Route.corridor_code == corridor_code).first()
    if not route:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Route corridor '{corridor_code}' not found"
        )
    return route


@router.post("/", response_model=RouteResponse, status_code=status.HTTP_201_CREATED)
async def create_route(
    route_in: RouteCreate,
    current_user: User = Depends(require_roles([UserRole.ADMIN, UserRole.LOGISTICS_OPERATOR])),
    db: Session = Depends(get_db)
):
    """Create a new highway corridor route with segments."""
    existing = db.query(Route).filter(Route.corridor_code == route_in.corridor_code).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Route corridor with code '{route_in.corridor_code}' already exists"
        )

    route_id = f"RTE-{uuid.uuid4().hex[:8].upper()}"
    new_route = Route(
        id=route_id,
        corridor_code=route_in.corridor_code,
        name=route_in.name,
        origin_hub_id=route_in.origin_hub_id,
        origin_name=route_in.origin_name,
        destination_hub_id=route_in.destination_hub_id,
        destination_name=route_in.destination_name,
        total_distance_km=route_in.total_distance_km,
        baseline_eta_hours=route_in.baseline_eta_hours,
        max_altitude_meters=route_in.max_altitude_meters,
        max_gradient_pct=route_in.max_gradient_pct,
        primary_terrain_type=route_in.primary_terrain_type,
        has_alternate_bypass=route_in.has_alternate_bypass,
        waypoints_json=route_in.waypoints_json,
        elevation_profile_json=route_in.elevation_profile_json
    )
    db.add(new_route)

    if route_in.segments:
        for seg in route_in.segments:
            s = RouteSegment(
                id=f"SEG-{uuid.uuid4().hex[:8].upper()}",
                route_id=route_id,
                segment_index=seg.segment_index,
                from_name=seg.from_name,
                to_name=seg.to_name,
                start_lat=seg.start_lat,
                start_lng=seg.start_lng,
                end_lat=seg.end_lat,
                end_lng=seg.end_lng,
                distance_km=seg.distance_km,
                start_altitude_m=seg.start_altitude_m,
                end_altitude_m=seg.end_altitude_m,
                gradient_pct=seg.gradient_pct,
                is_high_risk_zone=seg.is_high_risk_zone,
                hazard_description=seg.hazard_description,
                avg_speed_km_h=seg.avg_speed_km_h
            )
            db.add(s)

    db.commit()
    db.refresh(new_route)
    return new_route


# Deliveries Management under routes
@router.get("/deliveries/active", response_model=List[DeliveryResponse])
async def list_active_deliveries(
    db: Session = Depends(get_db)
):
    """List active in-transit shipments and high-priority supply convoys."""
    return db.query(Delivery).filter(
        Delivery.status.in_([DeliveryStatus.IN_TRANSIT, DeliveryStatus.PENDING_DISPATCH, DeliveryStatus.REROUTED_HAZARD])
    ).all()


@router.post("/deliveries", response_model=DeliveryResponse, status_code=status.HTTP_201_CREATED)
async def create_delivery(
    deliv_in: DeliveryCreate,
    current_user: User = Depends(require_roles([UserRole.ADMIN, UserRole.LOGISTICS_OPERATOR])),
    db: Session = Depends(get_db)
):
    """Create a new tracked delivery consignment."""
    deliv_id = f"DEL-{uuid.uuid4().hex[:8].upper()}"
    tracking_no = f"NER-TRK-{int(time.time()) % 1000000:06d}"

    deliv = Delivery(
        id=deliv_id,
        tracking_number=tracking_no,
        route_id=deliv_in.route_id,
        vehicle_id=deliv_in.vehicle_id,
        origin_name=deliv_in.origin_name,
        destination_name=deliv_in.destination_name,
        cargo_type=deliv_in.cargo_type,
        cargo_weight_kg=deliv_in.cargo_weight_kg,
        priority=deliv_in.priority,
        status=DeliveryStatus.PENDING_DISPATCH,
        dispatch_time=int(time.time() * 1000),
        current_risk_score=0.25
    )
    db.add(deliv)
    db.commit()
    db.refresh(deliv)
    return deliv
