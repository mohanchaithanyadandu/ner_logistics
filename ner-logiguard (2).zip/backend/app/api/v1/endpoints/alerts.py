import time
import uuid
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User, UserRole
from app.models.alert import Alert, AlertSeverity, AlertType, Notification
from app.schemas.alert import (
    AlertCreate,
    AlertResponse,
    NotificationResponse
)
from app.services.auth_service import get_current_user, require_roles
from app.services.websocket_manager import ws_manager

router = APIRouter()


@router.get("/", response_model=List[AlertResponse])
async def list_alerts(
    is_active: Optional[bool] = True,
    severity: Optional[AlertSeverity] = None,
    corridor_code: Optional[str] = None,
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db)
):
    """List active broadcasted alerts, hazards, and emergency broadcasts."""
    query = db.query(Alert)
    if is_active is not None:
        query = query.filter(Alert.is_active == is_active)
    if severity:
        query = query.filter(Alert.severity == severity)
    if corridor_code:
        query = query.filter(Alert.affected_corridor_code == corridor_code)
    return query.order_by(Alert.created_at.desc()).offset(skip).limit(limit).all()


@router.post("/", response_model=AlertResponse, status_code=status.HTTP_201_CREATED)
async def create_custom_alert(
    alert_in: AlertCreate,
    current_user: User = Depends(require_roles([UserRole.ADMIN, UserRole.LOGISTICS_OPERATOR])),
    db: Session = Depends(get_db)
):
    """Publish a custom priority dispatch alert across the fleet."""
    alert_id = f"ALT-MANUAL-{uuid.uuid4().hex[:8].upper()}"
    new_alert = Alert(
        id=alert_id,
        incident_id=alert_in.incident_id,
        vehicle_id=alert_in.vehicle_id,
        title=alert_in.title,
        message=alert_in.message,
        severity=alert_in.severity,
        alert_type=alert_in.alert_type,
        affected_corridor_code=alert_in.affected_corridor_code,
        latitude=alert_in.latitude,
        longitude=alert_in.longitude,
        radius_km=alert_in.radius_km,
        is_active=True,
        is_broadcasted=True,
        broadcast_timestamp=int(time.time() * 1000)
    )
    db.add(new_alert)
    db.commit()
    db.refresh(new_alert)

    # Broadcast to alerts channel
    await ws_manager.broadcast_to_channel("alerts", {
        "type": "NEW_ALERT",
        "alert": {
            "id": new_alert.id,
            "title": new_alert.title,
            "message": new_alert.message,
            "severity": new_alert.severity.value,
            "corridor_code": new_alert.affected_corridor_code,
            "created_at": new_alert.created_at
        }
    })

    return new_alert


@router.put("/{alert_id}/dismiss", response_model=AlertResponse)
async def dismiss_alert(
    alert_id: str,
    current_user: User = Depends(require_roles([UserRole.ADMIN, UserRole.LOGISTICS_OPERATOR])),
    db: Session = Depends(get_db)
):
    """Dismiss or resolve an active alert broadcast."""
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Alert not found")

    alert.is_active = False
    db.commit()
    db.refresh(alert)
    return alert


@router.get("/notifications/me", response_model=List[NotificationResponse])
async def get_my_notifications(
    is_read: Optional[bool] = None,
    limit: int = 30,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieve personal notification inbox for authenticated driver or operator."""
    query = db.query(Notification).filter(Notification.user_id == current_user.id)
    if is_read is not None:
        query = query.filter(Notification.is_read == is_read)
    return query.order_by(Notification.created_at.desc()).limit(limit).all()


@router.put("/notifications/{notif_id}/read", response_model=NotificationResponse)
async def mark_notification_read(
    notif_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Mark personal notification as read."""
    notif = db.query(Notification).filter(
        Notification.id == notif_id,
        Notification.user_id == current_user.id
    ).first()
    if not notif:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Notification not found")

    notif.is_read = True
    notif.read_at = int(time.time() * 1000)
    db.commit()
    db.refresh(notif)
    return notif
