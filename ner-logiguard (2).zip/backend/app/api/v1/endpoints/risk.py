from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.risk import RiskPrediction
from app.schemas.risk import (
    RiskAssessmentResponse,
    RiskAssessmentRequest,
    RiskPredictionResponse,
    CorridorRiskSummary
)
from app.services.risk_service import RiskEngineService
from app.services.risk_engine import RiskEngineWeights

router = APIRouter()


@router.get("/assess", response_model=RiskAssessmentResponse)
async def assess_corridor_risk(
    corridor_code: str = Query("NH13_GHY_TWG", description="Corridor identifier code"),
    latitude: float = Query(27.5042, description="Latitude for risk evaluation"),
    longitude: float = Query(92.1037, description="Longitude for risk evaluation"),
    vehicle_type: str = Query("MEDIUM_CARGO_TRUCK", description="Fleet vehicle classification"),
    cargo_weight_kg: float = Query(4500.0, description="Gross cargo weight in kg"),
    db: Session = Depends(get_db)
):
    """
    Evaluates multi-factor composite risk index (0 to 100) incorporating:
    - Live precipitation and monsoon cloudburst probability
    - Proximity to active verified landslides and road blockages
    - Terrain gradient, elevation, and high-altitude load penalties
    - Infrastructure status and vehicle suspension strain
    """
    return await RiskEngineService.compute_corridor_risk(
        db=db,
        corridor_code=corridor_code,
        lat=latitude,
        lng=longitude,
        vehicle_type=vehicle_type,
        cargo_weight_kg=cargo_weight_kg
    )


@router.post("/evaluate", response_model=RiskAssessmentResponse)
async def evaluate_custom_risk(
    request: RiskAssessmentRequest,
    db: Session = Depends(get_db)
):
    """
    Advanced custom risk evaluation supporting explicit field inputs,
    geotechnical sensors, and weight configuration overrides.
    """
    lat = request.latitude if request.latitude is not None else 27.5042
    lng = request.longitude if request.longitude is not None else 92.1037
    
    return await RiskEngineService.compute_corridor_risk(
        db=db,
        corridor_code=request.corridor_code,
        lat=lat,
        lng=lng,
        vehicle_type=request.vehicle_type or "MEDIUM_CARGO_TRUCK",
        cargo_weight_kg=request.cargo_weight_kg or 4500.0,
        request_override=request
    )


@router.get("/weights", response_model=Dict[str, float])
async def get_risk_weights():
    """Returns the current configurable weight distribution for the AI Risk Engine."""
    w = RiskEngineWeights.from_settings()
    return {
        "rainfall": w.rainfall,
        "terrain": w.terrain,
        "road_condition": w.road_condition,
        "active_incidents": w.active_incidents,
        "historical_incidents": w.historical_incidents,
        "flood_susceptibility": w.flood_susceptibility,
        "landslide_susceptibility": w.landslide_susceptibility,
        "infrastructure": w.infrastructure
    }


@router.get("/history", response_model=List[RiskPredictionResponse])
async def list_risk_predictions(
    corridor_code: Optional[str] = None,
    limit: int = 50,
    db: Session = Depends(get_db)
):
    """Returns historical AI risk model predictions for audit and backtesting."""
    query = db.query(RiskPrediction)
    if corridor_code:
        query = query.filter(RiskPrediction.corridor_code == corridor_code)
    return query.order_by(RiskPrediction.calculation_timestamp.desc()).limit(limit).all()
