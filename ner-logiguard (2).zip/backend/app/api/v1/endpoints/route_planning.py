from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.route import RoutePlanRequest, RoutePlanResponse
from app.services.route_planning_service import RoutePlanningEngine

router = APIRouter()


@router.post("/optimize", response_model=RoutePlanResponse)
async def plan_and_optimize_route(
    request: RoutePlanRequest,
    db: Session = Depends(get_db)
):
    """
    Multi-Criteria GIS Route Planning & Optimization Engine:
    
    Accepts:
    - origin (e.g. 'Guwahati' or 'GHY')
    - destination (e.g. 'Tawang' or 'TWG')
    - vehicle_type (e.g. 'MEDIUM_CARGO_TRUCK', 'HEAVY_MULTI_AXLE', 'LIGHT_4X4')
    - cargo & cargo_weight_kg
    - priority (STANDARD, HIGH_CRITICAL, DEFENSE_ESSENTIAL, MEDICAL_URGENT)
    - departure_time (epoch ms)

    Returns:
    - recommended route with waypoint coordinates & elevation profile
    - alternative routes with tradeoff analysis
    - total distance & dynamic risk-adjusted ETA
    - composite risk score (0.0 to 1.0) & factor penalty breakdown
    - natural language tactical route explanation & BRO clearance status
    """
    try:
        plan = await RoutePlanningEngine.plan_route(db=db, request=request)
        return plan
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Route planning computation error: {str(e)}"
        )
