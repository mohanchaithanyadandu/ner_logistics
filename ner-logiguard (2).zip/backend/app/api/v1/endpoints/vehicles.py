import time
import uuid
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User, UserRole
from app.models.vehicle import Vehicle, VehicleStatus, VehicleType
from app.schemas.vehicle import VehicleCreate, VehicleUpdate, VehicleResponse
from app.services.auth_service import get_current_user, require_roles
from app.services.websocket_manager import ws_manager

router = APIRouter()


@router.get("/", response_model=List[VehicleResponse])
async def list_vehicles(
    status: Optional[VehicleStatus] = None,
    corridor_code: Optional[str] = None,
    vehicle_type: Optional[VehicleType] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """List all registered fleet vehicles with optional status and corridor filtering."""
    query = db.query(Vehicle)
    if status:
        query = query.filter(Vehicle.status == status)
    if corridor_code:
        query = query.filter(Vehicle.active_corridor_code == corridor_code)
    if vehicle_type:
        query = query.filter(Vehicle.type == vehicle_type)
    return query.offset(skip).limit(limit).all()


@router.get("/{vehicle_id}", response_model=VehicleResponse)
async def get_vehicle_by_id(
    vehicle_id: str,
    db: Session = Depends(get_db)
):
    """Retrieve single vehicle telemetry and driver state by ID or Vehicle Number."""
    veh = db.query(Vehicle).filter(
        (Vehicle.id == vehicle_id) | (Vehicle.vehicle_number == vehicle_id)
    ).first()
    if not veh:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Vehicle '{vehicle_id}' not found"
        )
    return veh


@router.post("/", response_model=VehicleResponse, status_code=status.HTTP_201_CREATED)
async def register_vehicle(
    vehicle_in: VehicleCreate,
    current_user: User = Depends(require_roles([UserRole.ADMIN, UserRole.LOGISTICS_OPERATOR])),
    db: Session = Depends(get_db)
):
    """Register a new vehicle in the logistics fleet registry."""
    existing = db.query(Vehicle).filter(Vehicle.vehicle_number == vehicle_in.vehicle_number).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Vehicle with plate number '{vehicle_in.vehicle_number}' is already registered"
        )

    veh_id = f"VEH-{uuid.uuid4().hex[:8].upper()}"
    new_veh = Vehicle(
        id=veh_id,
        vehicle_number=vehicle_in.vehicle_number,
        type=vehicle_in.type,
        driver_id=vehicle_in.driver_id,
        driver_name=vehicle_in.driver_name,
        driver_contact=vehicle_in.driver_contact,
        current_lat=vehicle_in.current_lat,
        current_lng=vehicle_in.current_lng,
        altitude_meters=vehicle_in.altitude_meters,
        speed_km_h=vehicle_in.speed_km_h,
        heading_degrees=vehicle_in.heading_degrees,
        status=vehicle_in.status,
        active_corridor_code=vehicle_in.active_corridor_code,
        active_route_name=vehicle_in.active_route_name,
        fuel_level_pct=vehicle_in.fuel_level_pct,
        cargo_type=vehicle_in.cargo_type,
        cargo_weight_kg=vehicle_in.cargo_weight_kg,
        signal_status=vehicle_in.signal_status,
        last_ping_time=int(time.time() * 1000)
    )
    db.add(new_veh)
    db.commit()
    db.refresh(new_veh)
    return new_veh


@router.put("/{vehicle_id}", response_model=VehicleResponse)
async def update_vehicle(
    vehicle_id: str,
    vehicle_in: VehicleUpdate,
    current_user: User = Depends(require_roles([UserRole.ADMIN, UserRole.LOGISTICS_OPERATOR, UserRole.DRIVER])),
    db: Session = Depends(get_db)
):
    """Update vehicle operational status, driver assignment, or telemetry."""
    veh = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    if not veh:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Vehicle '{vehicle_id}' not found"
        )

    update_data = vehicle_in.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(veh, field, value)

    veh.updated_at = int(time.time() * 1000)
    veh.last_ping_time = int(time.time() * 1000)
    db.commit()
    db.refresh(veh)

    # Broadcast update to fleet dashboard
    await ws_manager.broadcast_to_channel("fleet", {
        "type": "VEHICLE_UPDATED",
        "vehicle": {
            "id": veh.id,
            "vehicle_number": veh.vehicle_number,
            "status": veh.status.value,
            "current_lat": veh.current_lat,
            "current_lng": veh.current_lng,
            "speed_km_h": veh.speed_km_h,
            "timestamp": veh.last_ping_time
        }
    })

    return veh
