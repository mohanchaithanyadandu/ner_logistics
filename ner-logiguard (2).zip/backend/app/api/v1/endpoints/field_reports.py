import json
import time
import uuid
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User, UserRole
from app.models.field_report import FieldReport
from app.models.incident import Incident, IncidentType, IncidentSeverity, IncidentStatus
from app.schemas.field_report import (
    FieldReportCreate,
    FieldReportResponse,
    FieldReportSyncBatch,
    FieldReportSyncResult
)
from app.services.auth_service import get_current_user, require_roles
from app.services.alert_engine import AlertEngine
from app.services.websocket_manager import ws_manager

router = APIRouter()


@router.get("/", response_model=List[FieldReportResponse])
async def list_field_reports(
    is_synced: Optional[bool] = None,
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db)
):
    """List all field observer reports submitted across North East transit corridors."""
    query = db.query(FieldReport)
    if is_synced is not None:
        query = query.filter(FieldReport.is_synced == is_synced)
    return query.order_by(FieldReport.created_at.desc()).offset(skip).limit(limit).all()


@router.post("/", response_model=FieldReportResponse, status_code=status.HTTP_201_CREATED)
async def submit_field_report(
    report_in: FieldReportCreate,
    db: Session = Depends(get_db)
):
    """
    Submits a single tactical field hazard report with GPS, photo metadata, terrain type, and severity.
    Automatically escalates HIGH and CRITICAL reports into the centralized Incidents table.
    """
    # Check for existing local_id to guarantee idempotency
    if report_in.local_id:
        existing = db.query(FieldReport).filter(FieldReport.local_id == report_in.local_id).first()
        if existing:
            return existing

    report_id = f"FR-{uuid.uuid4().hex[:8].upper()}"
    photos_json = json.dumps([p.model_dump() for p in (report_in.photos or [])]) if report_in.photos else report_in.photo_metadata_json

    # Automatically create or link an Incident if severity is HIGH or CRITICAL
    incident_id = report_in.incident_id
    if not incident_id and report_in.severity in ["HIGH", "CRITICAL", "CRITICAL_BLOCKAGE"]:
        inc_id = f"INC-{time.strftime('%Y')}-{uuid.uuid4().hex[:6].upper()}"
        inc = Incident(
            id=inc_id,
            title=f"Field Alert: {report_in.incident_type} at {report_in.road_name}",
            type=IncidentType.LANDSLIDE if "LANDSLIDE" in report_in.incident_type else IncidentType.MUDSLIDE,
            severity=IncidentSeverity.CRITICAL_BLOCKAGE if "CRITICAL" in report_in.severity else IncidentSeverity.HIGH,
            status=IncidentStatus.REPORTED,
            latitude=report_in.latitude,
            longitude=report_in.longitude,
            altitude_meters=report_in.altitude_meters,
            location_name=report_in.road_name,
            state="ASSAM",
            clearance_eta_hours=4.5,
            affected_radius_km=6.0,
            is_blocking=True,
            reported_by=report_in.officer_name,
            description=report_in.description,
            photo_urls_json=photos_json
        )
        db.add(inc)
        db.commit()
        db.refresh(inc)
        incident_id = inc.id
        await AlertEngine.process_new_incident(db=db, incident=inc)

    new_report = FieldReport(
        id=report_id,
        local_id=report_in.local_id,
        officer_id=None,
        officer_name=report_in.officer_name,
        latitude=report_in.latitude,
        longitude=report_in.longitude,
        altitude_meters=report_in.altitude_meters,
        road_name=report_in.road_name,
        terrain_type=report_in.terrain_type,
        incident_type=report_in.incident_type,
        severity=report_in.severity,
        description=report_in.description,
        photo_metadata_json=photos_json,
        is_synced=True,
        sync_timestamp=int(time.time() * 1000),
        is_offline_origin=report_in.is_offline_origin,
        incident_id=incident_id
    )
    db.add(new_report)
    db.commit()
    db.refresh(new_report)

    # Broadcast over WebSockets
    await ws_manager.broadcast_to_channel("field_reports", {
        "type": "NEW_FIELD_REPORT",
        "report_id": new_report.id,
        "road_name": new_report.road_name,
        "severity": new_report.severity,
        "officer_name": new_report.officer_name,
        "latitude": new_report.latitude,
        "longitude": new_report.longitude,
        "is_offline_origin": new_report.is_offline_origin
    })

    return new_report


@router.post("/batch-sync", response_model=FieldReportSyncResult)
async def batch_sync_offline_reports(
    batch: FieldReportSyncBatch,
    db: Session = Depends(get_db)
):
    """
    Idempotent batch synchronization endpoint for Android mobile applets operating in dead-zones.
    Receives buffered offline reports from Room SQLite, merges them into Postgres, and returns server mapping.
    """
    synced_ids = []
    id_map = {}
    failed_count = 0

    for rep in batch.reports:
        try:
            # Check for existing record by local_id
            if rep.local_id:
                existing = db.query(FieldReport).filter(FieldReport.local_id == rep.local_id).first()
                if existing:
                    synced_ids.append(rep.local_id)
                    id_map[rep.local_id] = existing.id
                    continue

            server_id = f"FR-SYNC-{uuid.uuid4().hex[:8].upper()}"
            photos_json = json.dumps([p.model_dump() for p in (rep.photos or [])]) if rep.photos else rep.photo_metadata_json

            entry = FieldReport(
                id=server_id,
                local_id=rep.local_id,
                officer_name=rep.officer_name,
                latitude=rep.latitude,
                longitude=rep.longitude,
                altitude_meters=rep.altitude_meters,
                road_name=rep.road_name,
                terrain_type=rep.terrain_type,
                incident_type=rep.incident_type,
                severity=rep.severity,
                description=rep.description,
                photo_metadata_json=photos_json,
                is_synced=True,
                sync_timestamp=int(time.time() * 1000),
                is_offline_origin=True,
                incident_id=rep.incident_id
            )
            db.add(entry)
            db.commit()
            db.refresh(entry)

            if rep.local_id:
                synced_ids.append(rep.local_id)
                id_map[rep.local_id] = entry.id

        except Exception:
            failed_count += 1

    # Broadcast sync summary
    await ws_manager.broadcast_to_channel("field_reports", {
        "type": "OFFLINE_BATCH_SYNCED",
        "synced_count": len(synced_ids),
        "device_id": batch.client_device_id
    })

    return FieldReportSyncResult(
        synced_count=len(synced_ids),
        failed_count=failed_count,
        synced_local_ids=synced_ids,
        server_assigned_ids=id_map,
        message=f"Successfully synced {len(synced_ids)} offline field reports with zero data loss."
    )
