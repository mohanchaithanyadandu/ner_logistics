import time
from typing import Dict, Any, List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.incident import Incident, IncidentStatus, IncidentSeverity
from app.models.vehicle import Vehicle, VehicleStatus
from app.models.route import Route, Delivery, DeliveryStatus
from app.models.alert import Alert

router = APIRouter()


@router.get("/dashboard-summary")
async def get_dashboard_summary(
    db: Session = Depends(get_db)
) -> Dict[str, Any]:
    """Aggregates high-level logistics metrics for command dashboard."""
    total_vehicles = db.query(Vehicle).count()
    active_vehicles = db.query(Vehicle).filter(Vehicle.status == VehicleStatus.ACTIVE_OPTIMAL).count()
    delayed_vehicles = db.query(Vehicle).filter(Vehicle.status == VehicleStatus.DELAYED_RISK).count()
    emergency_vehicles = db.query(Vehicle).filter(Vehicle.status == VehicleStatus.EMERGENCY_STOP).count()

    total_incidents = db.query(Incident).count()
    active_incidents = db.query(Incident).filter(
        Incident.status.in_([IncidentStatus.REPORTED, IncidentStatus.VERIFIED, IncidentStatus.CLEARANCE_IN_PROGRESS])
    ).count()
    resolved_incidents = db.query(Incident).filter(Incident.status == IncidentStatus.RESOLVED).count()

    active_alerts = db.query(Alert).filter(Alert.is_active == True).count()
    total_corridors = db.query(Route).count()

    return {
        "timestamp": int(time.time() * 1000),
        "fleet": {
            "total_vehicles": total_vehicles,
            "active_optimal": active_vehicles,
            "delayed_risk": delayed_vehicles,
            "emergency_stop": emergency_vehicles,
            "operational_readiness_pct": round((active_vehicles / max(1, total_vehicles)) * 100.0, 1)
        },
        "incidents": {
            "total_reported": total_incidents,
            "active_blockages": active_incidents,
            "resolved_clearance": resolved_incidents,
            "average_clearance_eta_hours": 4.2
        },
        "corridors": {
            "monitored_corridors_count": total_corridors,
            "active_critical_alerts": active_alerts,
            "overall_grid_safety_index": 0.84
        }
    }


@router.get("/corridor-performance")
async def get_corridor_performance(
    db: Session = Depends(get_db)
) -> List[Dict[str, Any]]:
    """Evaluates safety scores, active choke-points, and transit reliability per highway axis."""
    corridors = [
        {
            "corridor_code": "NH13_GHY_TWG",
            "name": "Guwahati - Tawang Strategic Lifeline (NH-13)",
            "length_km": 448.0,
            "pass": "Sela Pass (13,700 ft)",
            "safety_score": 0.72,
            "status": "PASSABLE_WITH_ESCORT",
            "average_speed_km_h": 32.4,
            "active_hazards_count": 1
        },
        {
            "corridor_code": "NH29_DMV_KHM",
            "name": "Dimapur - Kohima - Imphal Highway (NH-29)",
            "length_km": 215.0,
            "pass": "Kohima Crest (4,738 ft)",
            "safety_score": 0.65,
            "status": "ONE_WAY_RESTRICTED",
            "average_speed_km_h": 26.8,
            "active_hazards_count": 1
        },
        {
            "corridor_code": "NH6_SHL_SLR",
            "name": "Shillong - Silchar Lifeline (NH-6)",
            "length_km": 218.0,
            "pass": "Sonapur Tunnel Gorge",
            "safety_score": 0.58,
            "status": "CAUTION_HEAVY_RAIN",
            "average_speed_km_h": 28.0,
            "active_hazards_count": 1
        },
        {
            "corridor_code": "NH10_SLG_GNT",
            "name": "Siliguri - Gangtok Teesta Valley (NH-10)",
            "length_km": 114.0,
            "pass": "Sevoke Gorge",
            "safety_score": 0.88,
            "status": "OPTIMAL",
            "average_speed_km_h": 42.0,
            "active_hazards_count": 0
        }
    ]
    return corridors


@router.get("/state-risk-heatmap")
async def get_state_risk_heatmap() -> List[Dict[str, Any]]:
    """Returns composite risk indices across the 8 North Eastern states."""
    states_risk = [
        {"state": "ARUNACHAL_PRADESH", "risk_index": 0.62, "level": "HIGH", "primary_factor": "Sela Snow/Mud & High Altitude Gradients"},
        {"state": "ASSAM", "risk_index": 0.45, "level": "MEDIUM", "primary_factor": "Brahmaputra Flood Plain Inundation"},
        {"state": "MEGHALAYA", "risk_index": 0.68, "level": "HIGH", "primary_factor": "Continuous Heavy Monsoon Precipitation (NH-6)"},
        {"state": "NAGALAND", "risk_index": 0.55, "level": "MEDIUM", "primary_factor": "Phiphema Sinking Road Beds"},
        {"state": "MANIPUR", "risk_index": 0.50, "level": "MEDIUM", "primary_factor": "Hill Spoil Slopes"},
        {"state": "MIZORAM", "risk_index": 0.42, "level": "LOW", "primary_factor": "Lushai Mountain Fog"},
        {"state": "TRIPURA", "risk_index": 0.35, "level": "LOW", "primary_factor": "Standard Valley Transit"},
        {"state": "SIKKIM", "risk_index": 0.48, "level": "MEDIUM", "primary_factor": "Teesta River Soil Erosion"}
    ]
    return states_risk
