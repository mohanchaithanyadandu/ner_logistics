from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.ai_assistant import AIChatRequest, AIChatResponse
from app.services.ai_assistant_service import AIAssistantService

router = APIRouter()


@router.post("/query", response_model=AIChatResponse)
async def query_ai_assistant(
    request: AIChatRequest,
    db: Session = Depends(get_db)
):
    """
    Tactical AI Logistics & Mountain Pass Advisor:
    
    Accepts natural language driver and logistics operator queries regarding:
    - Sela Pass, Sonapur Tunnel, and NH-13/NH-29 road clearance
    - Landslide safety protocols, brake maintenance, tire chains
    - High-altitude convoy rest stops and oxygen protocols
    - Offline tile cache and field report synchronization
    """
    try:
        return await AIAssistantService.process_query(db=db, request=request)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"AI Assistant execution error: {str(e)}"
        )
