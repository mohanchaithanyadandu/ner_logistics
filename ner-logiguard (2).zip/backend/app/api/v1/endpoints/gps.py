import time
import uuid
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.gps import GPSPoint
from app.models.vehicle import Vehicle, VehicleStatus
from app.schemas.gps import (
    GPSPointCreate,
    GPSPointResponse,
    VehicleLocationUpdate,
    LiveFleetState
)
from app.services.alert_engine import AlertEngine
from app.services.websocket_manager import ws_manager

router = APIRouter()


@router.post("/telemetry", response_model=GPSPointResponse, status_code=status.HTTP_201_CREATED)
async def record_gps_telemetry(
    gps_in: GPSPointCreate,
    db: Session = Depends(get_db)
):
    """
    Accepts vehicle GPS location updates, updates Vehicle master table,
    logs track point, checks for emergency panic trigger, and broadcasts live position over WebSockets.
    """
    veh = db.query(Vehicle).filter(
        (Vehicle.id == gps_in.vehicle_id) | (Vehicle.vehicle_number == gps_in.vehicle_id)
    ).first()

    if not veh:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Vehicle '{gps_in.vehicle_id}' not found in fleet"
        )

    ts = gps_in.timestamp or int(time.time() * 1000)

    # 1. Update vehicle real-time coordinates & speed
    veh.current_lat = gps_in.latitude
    veh.current_lng = gps_in.longitude
    veh.altitude_meters = gps_in.altitude_meters
    veh.speed_km_h = gps_in.speed_km_h
    veh.heading_degrees = gps_in.heading_degrees
    veh.last_ping_time = ts

    # 2. Save GPS historical breadcrumb point
    point_id = f"GPS-{uuid.uuid4().hex[:8].upper()}"
    gps_point = GPSPoint(
        id=point_id,
        vehicle_id=veh.id,
        latitude=gps_in.latitude,
        longitude=gps_in.longitude,
        altitude_meters=gps_in.altitude_meters,
        speed_km_h=gps_in.speed_km_h,
        heading_degrees=gps_in.heading_degrees,
        accuracy_meters=gps_in.accuracy_meters,
        battery_level_pct=gps_in.battery_level_pct,
        signal_strength_dbm=gps_in.signal_strength_dbm,
        network_carrier=gps_in.network_carrier,
        is_panic_button=gps_in.is_panic_button,
        timestamp=ts
    )
    db.add(gps_point)

    # 3. Check for Panic / Emergency Trigger via Alert Engine
    if gps_in.is_panic_button:
        await AlertEngine.process_gps_telemetry(db=db, vehicle=veh, is_panic_button=True)

    db.commit()
    db.refresh(gps_point)

    # 4. Broadcast live position to WebSocket dashboard clients
    update_payload = {
        "type": "VEHICLE_POSITION_UPDATE",
        "vehicle_id": veh.id,
        "vehicle_number": veh.vehicle_number,
        "current_lat": veh.current_lat,
        "current_lng": veh.current_lng,
        "altitude_meters": veh.altitude_meters,
        "speed_km_h": veh.speed_km_h,
        "heading_degrees": veh.heading_degrees,
        "status": veh.status.value,
        "active_corridor_code": veh.active_corridor_code,
        "signal_status": veh.signal_status,
        "is_panic_button": gps_in.is_panic_button,
        "timestamp": ts
    }
    await ws_manager.broadcast_to_channel("fleet", update_payload)

    return gps_point


@router.get("/fleet-live", response_model=LiveFleetState)
async def get_live_fleet_positions(
    db: Session = Depends(get_db)
):
    """Returns aggregated real-time fleet positions and movement metrics for the dashboard."""
    vehicles = db.query(Vehicle).all()
    updates = []
    moving_count = 0
    stopped_count = 0
    at_risk_count = 0
    emergency_count = 0

    for v in vehicles:
        if v.speed_km_h > 2.0:
            moving_count += 1
        else:
            stopped_count += 1

        if v.status == VehicleStatus.DELAYED_RISK:
            at_risk_count += 1
        elif v.status == VehicleStatus.EMERGENCY_STOP:
            emergency_count += 1

        updates.append(VehicleLocationUpdate(
            vehicle_id=v.id,
            vehicle_number=v.vehicle_number,
            current_lat=v.current_lat,
            current_lng=v.current_lng,
            altitude_meters=v.altitude_meters,
            speed_km_h=v.speed_km_h,
            heading_degrees=v.heading_degrees,
            status=v.status.value,
            active_corridor_code=v.active_corridor_code,
            signal_status=v.signal_status,
            is_panic_button=False,
            timestamp=v.last_ping_time
        ))

    return LiveFleetState(
        total_active_vehicles=len(vehicles),
        vehicles_at_risk=at_risk_count,
        moving_count=moving_count,
        stopped_count=stopped_count,
        emergency_count=emergency_count,
        vehicles=updates
    )


@router.get("/history/{vehicle_id}", response_model=List[GPSPointResponse])
async def get_vehicle_gps_history(
    vehicle_id: str,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """Fetch recent GPS breadcrumb trail points for a specific vehicle."""
    veh = db.query(Vehicle).filter(
        (Vehicle.id == vehicle_id) | (Vehicle.vehicle_number == vehicle_id)
    ).first()
    if not veh:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Vehicle '{vehicle_id}' not found"
        )

    points = db.query(GPSPoint).filter(
        GPSPoint.vehicle_id == veh.id
    ).order_by(GPSPoint.timestamp.desc()).limit(limit).all()

    return points
