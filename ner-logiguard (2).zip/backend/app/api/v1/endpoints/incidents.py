import time
import uuid
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User, UserRole
from app.models.incident import (
    Incident,
    IncidentType,
    IncidentSeverity,
    IncidentStatus
)
from app.schemas.incident import (
    IncidentCreate,
    IncidentUpdate,
    IncidentResponse,
    IncidentFilter
)
from app.services.auth_service import get_current_user, require_roles
from app.services.alert_engine import AlertEngine
from app.services.risk_service import calculate_haversine_distance_km
from app.services.websocket_manager import ws_manager

router = APIRouter()


@router.get("/", response_model=List[IncidentResponse])
async def list_incidents(
    status: Optional[IncidentStatus] = None,
    severity: Optional[IncidentSeverity] = None,
    incident_type: Optional[IncidentType] = None,
    corridor_code: Optional[str] = None,
    state: Optional[str] = None,
    is_blocking: Optional[bool] = None,
    near_lat: Optional[float] = None,
    near_lng: Optional[float] = None,
    radius_km: Optional[float] = 50.0,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """
    List and filter incidents by:
    - severity (LOW, MEDIUM, HIGH, CRITICAL_BLOCKAGE)
    - status (REPORTED, VERIFIED, CLEARANCE_IN_PROGRESS, RESOLVED)
    - incident_type (LANDSLIDE, MUDSLIDE, ROAD_COLLAPSE, FLASH_FLOOD, etc.)
    - corridor_code (e.g. NH13_GHY_TWG)
    - geographic location proximity within radius_km
    """
    query = db.query(Incident)

    if status:
        query = query.filter(Incident.status == status)
    if severity:
        query = query.filter(Incident.severity == severity)
    if incident_type:
        query = query.filter(Incident.type == incident_type)
    if corridor_code:
        query = query.filter(Incident.corridor_code == corridor_code)
    if state:
        query = query.filter(Incident.state == state)
    if is_blocking is not None:
        query = query.filter(Incident.is_blocking == is_blocking)

    incidents = query.order_by(Incident.created_at.desc()).all()

    # Apply geographic proximity filtering if near_lat and near_lng provided
    if near_lat is not None and near_lng is not None:
        filtered = []
        for inc in incidents:
            dist = calculate_haversine_distance_km(near_lat, near_lng, inc.latitude, inc.longitude)
            if dist <= (radius_km or 50.0):
                filtered.append(inc)
        incidents = filtered

    return incidents[skip : skip + limit]


@router.get("/{incident_id}", response_model=IncidentResponse)
async def get_incident_by_id(
    incident_id: str,
    db: Session = Depends(get_db)
):
    """Fetch single incident details by ID."""
    incident = db.query(Incident).filter(Incident.id == incident_id).first()
    if not incident:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Incident '{incident_id}' not found"
        )
    return incident


@router.post("/", response_model=IncidentResponse, status_code=status.HTTP_201_CREATED)
async def create_incident(
    incident_in: IncidentCreate,
    current_user: User = Depends(require_roles([UserRole.ADMIN, UserRole.LOGISTICS_OPERATOR, UserRole.FIELD_OFFICER])),
    db: Session = Depends(get_db)
):
    """
    Create a new roadway incident report.
    Automatically evaluates severity, updates adjacent vehicle statuses, and triggers WebSocket alerts.
    """
    inc_id = f"INC-{time.strftime('%Y')}-{uuid.uuid4().hex[:6].upper()}"
    new_inc = Incident(
        id=inc_id,
        title=incident_in.title,
        type=incident_in.type,
        severity=incident_in.severity,
        status=incident_in.status,
        latitude=incident_in.latitude,
        longitude=incident_in.longitude,
        altitude_meters=incident_in.altitude_meters,
        location_name=incident_in.location_name,
        corridor_code=incident_in.corridor_code,
        state=incident_in.state,
        clearance_eta_hours=incident_in.clearance_eta_hours,
        affected_radius_km=incident_in.affected_radius_km,
        is_blocking=incident_in.is_blocking,
        reported_by=incident_in.reported_by or current_user.full_name,
        description=incident_in.description,
        photo_urls_json=incident_in.photo_urls_json
    )
    db.add(new_inc)
    db.commit()
    db.refresh(new_inc)

    # Trigger Alert Engine processing and WebSocket broadcast
    await AlertEngine.process_new_incident(db=db, incident=new_inc)

    # Broadcast to incidents channel
    await ws_manager.broadcast_to_channel("incidents", {
        "type": "INCIDENT_CREATED",
        "incident": {
            "id": new_inc.id,
            "title": new_inc.title,
            "severity": new_inc.severity.value,
            "status": new_inc.status.value,
            "latitude": new_inc.latitude,
            "longitude": new_inc.longitude,
            "location_name": new_inc.location_name,
            "corridor_code": new_inc.corridor_code,
            "created_at": new_inc.created_at
        }
    })

    return new_inc


@router.put("/{incident_id}", response_model=IncidentResponse)
async def update_incident(
    incident_id: str,
    incident_in: IncidentUpdate,
    current_user: User = Depends(require_roles([UserRole.ADMIN, UserRole.LOGISTICS_OPERATOR, UserRole.FIELD_OFFICER])),
    db: Session = Depends(get_db)
):
    """Update incident parameters, clearance progress, or description."""
    inc = db.query(Incident).filter(Incident.id == incident_id).first()
    if not inc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Incident '{incident_id}' not found"
        )

    update_data = incident_in.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(inc, field, value)

    inc.updated_at = int(time.time() * 1000)
    db.commit()
    db.refresh(inc)

    # Broadcast update
    await ws_manager.broadcast_to_channel("incidents", {
        "type": "INCIDENT_UPDATED",
        "incident": {
            "id": inc.id,
            "status": inc.status.value,
            "severity": inc.severity.value,
            "clearance_eta_hours": inc.clearance_eta_hours,
            "updated_at": inc.updated_at
        }
    })

    return inc


@router.post("/{incident_id}/resolve", response_model=IncidentResponse)
async def resolve_incident(
    incident_id: str,
    current_user: User = Depends(require_roles([UserRole.ADMIN, UserRole.LOGISTICS_OPERATOR, UserRole.FIELD_OFFICER])),
    db: Session = Depends(get_db)
):
    """Mark an incident as RESOLVED once BRO clearance is verified."""
    inc = db.query(Incident).filter(Incident.id == incident_id).first()
    if not inc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Incident '{incident_id}' not found"
        )

    inc.status = IncidentStatus.RESOLVED
    inc.is_blocking = False
    inc.resolved_at = int(time.time() * 1000)
    inc.updated_at = int(time.time() * 1000)
    db.commit()
    db.refresh(inc)

    # Broadcast resolution
    await ws_manager.broadcast_to_channel("incidents", {
        "type": "INCIDENT_RESOLVED",
        "incident_id": inc.id,
        "resolved_at": inc.resolved_at
    })

    return inc
