from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.weather import WeatherObservation
from app.schemas.weather import WeatherObservationResponse, WeatherForecastResponse
from app.services.weather_service import WeatherService

router = APIRouter()


@router.get("/current", response_model=WeatherForecastResponse)
async def get_current_weather(
    latitude: float = Query(26.1445, description="Latitude in decimal degrees"),
    longitude: float = Query(91.7362, description="Longitude in decimal degrees"),
    location_name: Optional[str] = Query("Guwahati", description="Descriptive location name")
):
    """
    Fetches real-time meteorological observations and landslide risk indicators for any coordinate in North East India.
    Includes automated fallback to regional climatological heuristics if external API times out.
    """
    return await WeatherService.fetch_weather_forecast(latitude, longitude, location_name)


@router.get("/corridors/{corridor_code}", response_model=WeatherForecastResponse)
async def get_corridor_weather(
    corridor_code: str
):
    """Fetches high-altitude weather and precipitation conditions along major North East corridor axes."""
    corridor_coords = {
        "NH13_GHY_TWG": (27.5042, 92.1037, "Sela Pass Summit (NH-13)"),
        "NH29_DMV_KHM": (25.6751, 94.1086, "Kohima Ridge (NH-29)"),
        "NH6_SHL_SLR": (25.1000, 92.3800, "Sonapur Landslide Gorge (NH-6)"),
        "NH10_SLG_GNT": (27.1500, 88.5000, "Teesta Valley Corridor (NH-10)"),
        "NH54_SLR_AIZ": (23.7271, 92.7176, "Aizawl Hill Spine (NH-54)")
    }
    
    info = corridor_coords.get(corridor_code, (26.1445, 91.7362, f"Corridor {corridor_code}"))
    return await WeatherService.fetch_weather_forecast(info[0], info[1], info[2])


@router.get("/observations", response_model=List[WeatherObservationResponse])
async def list_cached_observations(
    limit: int = 50,
    db: Session = Depends(get_db)
):
    """Returns recent persisted weather station records across the 8 North Eastern states."""
    return db.query(WeatherObservation).order_by(WeatherObservation.observation_time.desc()).limit(limit).all()
