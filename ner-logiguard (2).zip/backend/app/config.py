import os
from typing import List, Union
from pydantic import AnyHttpUrl, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    ENVIRONMENT: str = "production"
    DEBUG: bool = False
    APP_NAME: str = "NER-LogiGuard Intelligent Logistics Engine"
    PROJECT_NAME: str = "NER-LogiGuard Intelligent Logistics Engine"
    VERSION: str = "1.0.0"
    LOG_LEVEL: str = "INFO"
    API_V1_STR: str = "/api/v1"

    # JWT Authentication
    SECRET_KEY: str = os.getenv(
        "SECRET_KEY",
        "ner_logiguard_super_secure_jwt_secret_key_sih2026_change_in_production"
    )
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24 hours

    # Database (Supabase PostgreSQL / PostgreSQL / SQLite fallback)
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL",
        "sqlite:///./ner_logistics.db"
    )

    @field_validator("DATABASE_URL", mode="before")
    def normalize_database_url(cls, v: str) -> str:
        if not v or v.strip() == "":
            return "sqlite:///./ner_logistics.db"
        # Supabase / Heroku often provide postgres:// which SQLAlchemy deprecated in favor of postgresql://
        if v.startswith("postgres://"):
            return v.replace("postgres://", "postgresql://", 1)
        return v

    # CORS Configuration
    BACKEND_CORS_ORIGINS: Union[List[str], str] = ["*"]

    @field_validator("BACKEND_CORS_ORIGINS", mode="before")
    def assemble_cors_origins(cls, v: Union[str, List[str]]) -> List[str]:
        if isinstance(v, str):
            if v.strip() == "*":
                return ["*"]
            if not v.startswith("["):
                return [i.strip() for i in v.split(",") if i.strip()]
        elif isinstance(v, list):
            return v
        return ["*"]

    @property
    def cors_origins_list(self) -> List[str]:
        if isinstance(self.BACKEND_CORS_ORIGINS, list):
            return self.BACKEND_CORS_ORIGINS
        if isinstance(self.BACKEND_CORS_ORIGINS, str):
            if self.BACKEND_CORS_ORIGINS == "*":
                return ["*"]
            return [i.strip() for i in self.BACKEND_CORS_ORIGINS.split(",") if i.strip()]
        return ["*"]

    # External APIs
    OPEN_METEO_BASE_URL: str = "https://api.open-meteo.com/v1/forecast"
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    GEMINI_MODEL: str = "gemini-3.5-flash"
    
    # Thresholds & Telemetry
    WS_HEARTBEAT_INTERVAL: int = 30
    ALERT_CRITICAL_NOTIFICATION_RADIUS_KM: float = 25.0
    CRITICAL_RISK_THRESHOLD: float = 70.0  # Scaled 0-100
    HIGH_GRADIENT_WARNING_THRESHOLD_PCT: float = 8.0

    # Risk Engine Default Weights (Total Sum = 100.0)
    RISK_WEIGHT_RAINFALL: float = 20.0          # Rainfall intensity & cumulative duration
    RISK_WEIGHT_TERRAIN: float = 15.0           # Elevation & slope gradient
    RISK_WEIGHT_ROAD_CONDITION: float = 15.0    # Surface type, degradation, pothole index
    RISK_WEIGHT_INCIDENTS_ACTIVE: float = 20.0  # Real-time verified incidents & blockages
    RISK_WEIGHT_INCIDENTS_HISTORIC: float = 5.0 # Historical landslide/washout frequency
    RISK_WEIGHT_FLOOD_SUSCEPTIBILITY: float = 10.0 # Soil moisture, river catchment surge
    RISK_WEIGHT_LANDSLIDE_SUSCEPTIBILITY: float = 10.0 # Geotechnical slope-shear potential
    RISK_WEIGHT_INFRASTRUCTURE: float = 5.0     # Bridge status, tunnel pass clearance

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore"
    )


settings = Settings()
