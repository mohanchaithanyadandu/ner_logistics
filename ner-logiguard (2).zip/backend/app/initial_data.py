import json
import logging
import time
import uuid
from sqlalchemy.orm import Session

from app.database import SessionLocal, init_db
from app.models.user import User, UserRole
from app.models.vehicle import Vehicle, VehicleType, VehicleStatus
from app.models.route import Route, RouteSegment, Delivery, DeliveryStatus, RoutePriority
from app.models.incident import Incident, IncidentType, IncidentSeverity, IncidentStatus
from app.models.alert import Alert, AlertSeverity, AlertType
from app.models.weather import WeatherObservation
from app.models.field_report import FieldReport
from app.services.auth_service import get_password_hash

logger = logging.getLogger(__name__)


def seed_database(db: Session):
    """Populates database with initial baseline data for North East India logistics."""
    # 1. Seed Users if not exists
    if db.query(User).count() == 0:
        logger.info("Seeding initial users with roles...")
        users = [
            User(
                id="USR-ADMIN-001",
                username="admin",
                email="admin@nerlogistics.gov.in",
                hashed_password=get_password_hash("admin123"),
                full_name="Col. R. K. Sharma (Retd.)",
                role=UserRole.ADMIN,
                assigned_region="NORTH_EAST_COMMAND",
                phone_number="+91 94350 11001",
                is_active=True
            ),
            User(
                id="USR-OP-001",
                username="operator",
                email="operator@nerlogistics.gov.in",
                hashed_password=get_password_hash("operator123"),
                full_name="Priyanka Barua",
                role=UserRole.LOGISTICS_OPERATOR,
                assigned_region="ASSAM_CENTRAL",
                phone_number="+91 94350 22002",
                is_active=True
            ),
            User(
                id="USR-FIELD-001",
                username="field_officer",
                email="field.tawang@nerlogistics.gov.in",
                hashed_password=get_password_hash("field123"),
                full_name="Sub-Inspector Tsering Norbu",
                role=UserRole.FIELD_OFFICER,
                assigned_region="ARUNACHAL_WEST",
                phone_number="+91 94350 33003",
                is_active=True
            ),
            User(
                id="USR-DRIVER-001",
                username="driver",
                email="driver1@nerlogistics.gov.in",
                hashed_password=get_password_hash("driver123"),
                full_name="Bhaben Deka",
                role=UserRole.DRIVER,
                assigned_region="GUWAHATI_TAWANG_AXIS",
                phone_number="+91 94350 44004",
                is_active=True
            )
        ]
        db.add_all(users)
        db.commit()
        logger.info("Users seeded successfully.")

    # 2. Seed Routes & Corridors
    if db.query(Route).count() == 0:
        logger.info("Seeding North East transport corridors...")
        r1_waypoints = [
            {"name": "Guwahati Hub", "lat": 26.1445, "lng": 91.7362, "altitude_m": 55},
            {"name": "Tezpur Base Staging", "lat": 26.6338, "lng": 92.7926, "altitude_m": 72},
            {"name": "Bhalukpong Border", "lat": 27.0118, "lng": 92.6450, "altitude_m": 213},
            {"name": "Bomdila Pass", "lat": 27.2645, "lng": 92.4241, "altitude_m": 2415},
            {"name": "Dirang Valley Depot", "lat": 27.3592, "lng": 92.2384, "altitude_m": 1560},
            {"name": "Sela Pass Summit", "lat": 27.5042, "lng": 92.1037, "altitude_m": 4170},
            {"name": "Tawang Forward Logistics Base", "lat": 27.5861, "lng": 91.8594, "altitude_m": 3048}
        ]
        r1 = Route(
            id="RTE-NH13-GHY-TWG",
            corridor_code="NH13_GHY_TWG",
            name="Guwahati - Tezpur - Bomdila - Tawang Strategic Lifeline (NH-13)",
            origin_hub_id="GHY-01",
            origin_name="Guwahati Central Logistics Hub",
            destination_hub_id="TWG-01",
            destination_name="Tawang Forward Supply Depot",
            total_distance_km=448.0,
            baseline_eta_hours=13.5,
            max_altitude_meters=4170,
            max_gradient_pct=11.2,
            primary_terrain_type="HIGH_ALTITUDE_GHAT",
            has_alternate_bypass=True,
            waypoints_json=json.dumps(r1_waypoints)
        )
        db.add(r1)

        # Segments for NH13
        seg1 = RouteSegment(
            id="SEG-NH13-01",
            route_id=r1.id,
            segment_index=1,
            from_name="Guwahati",
            to_name="Tezpur",
            start_lat=26.1445,
            start_lng=91.7362,
            end_lat=26.6338,
            end_lng=92.7926,
            distance_km=180.0,
            start_altitude_m=55,
            end_altitude_m=72,
            gradient_pct=1.2,
            is_high_risk_zone=False,
            avg_speed_km_h=55.0
        )
        seg2 = RouteSegment(
            id="SEG-NH13-02",
            route_id=r1.id,
            segment_index=2,
            from_name="Tezpur",
            to_name="Bomdila",
            start_lat=26.6338,
            start_lng=92.7926,
            end_lat=27.2645,
            end_lng=92.4241,
            distance_km=130.0,
            start_altitude_m=72,
            end_altitude_m=2415,
            gradient_pct=8.4,
            is_high_risk_zone=True,
            hazard_description="Steep hairpin bends & waterfall road slips near Bhalukpong",
            avg_speed_km_h=30.0
        )
        seg3 = RouteSegment(
            id="SEG-NH13-03",
            route_id=r1.id,
            segment_index=3,
            from_name="Bomdila",
            to_name="Tawang",
            start_lat=27.2645,
            start_lng=92.4241,
            end_lat=27.5861,
            end_lng=91.8594,
            distance_km=138.0,
            start_altitude_m=2415,
            end_altitude_m=3048,
            gradient_pct=11.2,
            is_high_risk_zone=True,
            hazard_description="Sela Pass summit (13,700 ft) freezing ice & rockfall zone",
            avg_speed_km_h=25.0
        )
        db.add_all([seg1, seg2, seg3])

        # NH-29 Corridor
        r2 = Route(
            id="RTE-NH29-DMV-IMP",
            corridor_code="NH29_DMV_KHM",
            name="Dimapur - Kohima - Imphal Highway (NH-29)",
            origin_hub_id="DMV-01",
            origin_name="Dimapur Railhead Hub",
            destination_hub_id="IMP-01",
            destination_name="Imphal Valley Base",
            total_distance_km=215.0,
            baseline_eta_hours=7.0,
            max_altitude_meters=1444,
            max_gradient_pct=8.5,
            primary_terrain_type="HILLY_GHAT",
            has_alternate_bypass=True,
            waypoints_json=json.dumps([
                {"name": "Dimapur", "lat": 25.9090, "lng": 93.7270, "altitude_m": 145},
                {"name": "Kohima", "lat": 25.6751, "lng": 94.1086, "altitude_m": 1444},
                {"name": "Senapati", "lat": 25.2600, "lng": 94.0200, "altitude_m": 1050},
                {"name": "Imphal", "lat": 24.8170, "lng": 93.9368, "altitude_m": 786}
            ])
        )
        db.add(r2)

        # NH-6 Corridor
        r3 = Route(
            id="RTE-NH6-SHL-SLR",
            corridor_code="NH6_SHL_SLR",
            name="Shillong - Jowai - Silchar Lifeline (NH-6 Meghalaya Plateau)",
            origin_hub_id="SHL-01",
            origin_name="Shillong Hub",
            destination_hub_id="SLR-01",
            destination_name="Silchar Logistics Terminal",
            total_distance_km=218.0,
            baseline_eta_hours=7.5,
            max_altitude_meters=1525,
            max_gradient_pct=9.8,
            primary_terrain_type="PLATEAU_GHAT",
            has_alternate_bypass=True,
            waypoints_json=json.dumps([
                {"name": "Shillong", "lat": 25.5788, "lng": 91.8933, "altitude_m": 1525},
                {"name": "Jowai", "lat": 25.4500, "lng": 92.2000, "altitude_m": 1380},
                {"name": "Sonapur Tunnel", "lat": 25.1000, "lng": 92.3800, "altitude_m": 450},
                {"name": "Silchar", "lat": 24.8333, "lng": 92.7789, "altitude_m": 35}
            ])
        )
        db.add(r3)
        db.commit()
        logger.info("Corridors & Segments seeded.")

    # 3. Seed Vehicles
    if db.query(Vehicle).count() == 0:
        logger.info("Seeding active fleet vehicles...")
        vehicles = [
            Vehicle(
                id="VEH-AS01-9421",
                vehicle_number="AS-01-EC-9421",
                type=VehicleType.MEDIUM_CARGO_TRUCK,
                driver_id="USR-DRIVER-001",
                driver_name="Bhaben Deka",
                driver_contact="+91 94350 44004",
                current_lat=27.2845,
                current_lng=92.3941,
                altitude_meters=2380,
                speed_km_h=34.5,
                heading_degrees=320.0,
                status=VehicleStatus.ACTIVE_OPTIMAL,
                active_corridor_code="NH13_GHY_TWG",
                active_route_name="Guwahati -> Tawang Lifeline",
                fuel_level_pct=78.5,
                cargo_type="High Altitude Medical Kits & Ration",
                cargo_weight_kg=4800.0,
                signal_status="4G_STRONG"
            ),
            Vehicle(
                id="VEH-NL07-3301",
                vehicle_number="NL-07-A-3301",
                type=VehicleType.HEAVY_MULTI_AXLE,
                driver_name="Kevichusa Angami",
                driver_contact="+91 98620 55112",
                current_lat=25.7500,
                current_lng=93.9500,
                altitude_meters=890,
                speed_km_h=12.0,
                heading_degrees=145.0,
                status=VehicleStatus.DELAYED_RISK,
                active_corridor_code="NH29_DMV_KHM",
                active_route_name="Dimapur -> Imphal Supply Axis",
                fuel_level_pct=62.0,
                cargo_type="Heavy Engineering Spares & Bridge Girder",
                cargo_weight_kg=12500.0,
                signal_status="3G_MODERATE"
            ),
            Vehicle(
                id="VEH-AR01-8820",
                vehicle_number="AR-01-T-8820",
                type=VehicleType.DEFENSE_CONVOY,
                driver_name="Havildar M. Singh",
                driver_contact="+91 94360 88201",
                current_lat=27.4950,
                current_lng=92.1200,
                altitude_meters=3920,
                speed_km_h=22.0,
                heading_degrees=340.0,
                status=VehicleStatus.ACTIVE_OPTIMAL,
                active_corridor_code="NH13_GHY_TWG",
                active_route_name="Sela Pass Forward Convoy",
                fuel_level_pct=88.0,
                cargo_type="Strategic Defense Supplies",
                cargo_weight_kg=6200.0,
                signal_status="SATCOM_ACTIVE"
            ),
            Vehicle(
                id="VEH-ML05-4109",
                vehicle_number="ML-05-F-4109",
                type=VehicleType.REFRIGERATED_VAN,
                driver_name="Wanshanbor Marwein",
                driver_contact="+91 97740 33419",
                current_lat=25.1200,
                current_lng=92.3600,
                altitude_meters=490,
                speed_km_h=0.0,
                heading_degrees=90.0,
                status=VehicleStatus.DELAYED_RISK,
                active_corridor_code="NH6_SHL_SLR",
                active_route_name="Shillong -> Silchar Cold Chain",
                fuel_level_pct=45.0,
                cargo_type="Temperature-Controlled Vaccines",
                cargo_weight_kg=2100.0,
                signal_status="2G_WEAK"
            )
        ]
        db.add_all(vehicles)
        db.commit()
        logger.info("Fleet vehicles seeded.")

    # 4. Seed Incidents
    if db.query(Incident).count() == 0:
        logger.info("Seeding initial road hazard incidents...")
        incidents = [
            Incident(
                id="INC-2026-001",
                title="Major Landslide Blockage near Sela Pass North Approach",
                type=IncidentType.LANDSLIDE,
                severity=IncidentSeverity.CRITICAL_BLOCKAGE,
                status=IncidentStatus.CLEARANCE_IN_PROGRESS,
                latitude=27.5120,
                longitude=92.0980,
                altitude_meters=4100,
                location_name="KM 392 Sela Pass North Ridge",
                corridor_code="NH13_GHY_TWG",
                state="ARUNACHAL_PRADESH",
                clearance_eta_hours=3.5,
                affected_radius_km=15.0,
                is_blocking=True,
                reported_by="BRO Project Vartak Recon Team",
                description="Heavy debris rockfall covering ~60 meters of two-lane carriageway following continuous precipitation. 2 bulldozers actively clearing.",
                photo_urls_json=json.dumps(["https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=600"])
            ),
            Incident(
                id="INC-2026-002",
                title="Severe Sinking Zone & Mudflow at Phiphema",
                type=IncidentType.MUDSLIDE,
                severity=IncidentSeverity.HIGH,
                status=IncidentStatus.VERIFIED,
                latitude=25.7520,
                longitude=93.9480,
                altitude_meters=880,
                location_name="Phiphema Ghat Section (NH-29)",
                corridor_code="NH29_DMV_KHM",
                state="NAGALAND",
                clearance_eta_hours=5.0,
                affected_radius_km=8.0,
                is_blocking=False,
                reported_by="Nagaland Traffic Police Kohima",
                description="Subsurface water saturation causing 15-inch pavement depression. Single-lane one-way traffic regulated.",
                photo_urls_json=json.dumps([])
            ),
            Incident(
                id="INC-2026-003",
                title="Torrential Slurry Overflow at Sonapur Tunnel Portal",
                type=IncidentType.FLASH_FLOOD,
                severity=IncidentSeverity.CRITICAL_BLOCKAGE,
                status=IncidentStatus.REPORTED,
                latitude=25.1050,
                longitude=92.3780,
                altitude_meters=460,
                location_name="Sonapur Tunnel Meghalaya Exit",
                corridor_code="NH6_SHL_SLR",
                state="MEGHALAYA",
                clearance_eta_hours=4.0,
                affected_radius_km=12.0,
                is_blocking=True,
                reported_by="East Jaintia Hills District Control Room",
                description="Hill slope slurry overflow blocking southern portal. Heavy multi-axles halted at Ladrymbai checkpoint.",
                photo_urls_json=json.dumps([])
            )
        ]
        db.add_all(incidents)
        db.commit()
        logger.info("Incidents seeded.")

    # 5. Seed Alerts
    if db.query(Alert).count() == 0:
        logger.info("Seeding initial alerts...")
        alerts = [
            Alert(
                id="ALT-SELA-01",
                incident_id="INC-2026-001",
                title="CRITICAL: Sela Pass Summit Road Clearance in Progress",
                message="BRO bulldozers clearing 60m rockfall. Convoys hold at Dirang Staging Base until 14:00 hrs.",
                severity=AlertSeverity.CRITICAL_EMERGENCY,
                alert_type=AlertType.LANDSLIDE_BLOCKED,
                affected_corridor_code="NH13_GHY_TWG",
                latitude=27.5120,
                longitude=92.0980,
                radius_km=15.0,
                is_active=True,
                is_broadcasted=True,
                broadcast_timestamp=int(time.time() * 1000)
            ),
            Alert(
                id="ALT-SONAPUR-02",
                incident_id="INC-2026-003",
                title="HIGH: Sonapur Tunnel Flash Slurry Overflow",
                message="Traffic suspended on NH-6 connecting Shillong to Silchar. Reroute via Haflong recommended.",
                severity=AlertSeverity.HIGH,
                alert_type=AlertType.FLASH_FLOOD_WARNING,
                affected_corridor_code="NH6_SHL_SLR",
                latitude=25.1050,
                longitude=92.3780,
                radius_km=12.0,
                is_active=True,
                is_broadcasted=True,
                broadcast_timestamp=int(time.time() * 1000)
            )
        ]
        db.add_all(alerts)
        db.commit()
        logger.info("Alerts seeded.")


def run_init():
    """Entry point to initialize schema and seed baseline data."""
    init_db()
    db = SessionLocal()
    try:
        seed_database(db)
    finally:
        db.close()


if __name__ == "__main__":
    run_init()
