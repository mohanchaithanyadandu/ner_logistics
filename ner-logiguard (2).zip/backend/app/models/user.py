import enum
import time
from sqlalchemy import Column, String, Boolean, Enum, BigInteger, Text, Index
from sqlalchemy.orm import relationship
from app.database import Base


class UserRole(str, enum.Enum):
    ADMIN = "ADMIN"
    LOGISTICS_OPERATOR = "LOGISTICS_OPERATOR"
    FIELD_OFFICER = "FIELD_OFFICER"
    DRIVER = "DRIVER"


class User(Base):
    __tablename__ = "users"

    id = Column(String(64), primary_key=True, index=True)
    username = Column(String(64), unique=True, index=True, nullable=False)
    email = Column(String(128), unique=True, index=True, nullable=False)
    hashed_password = Column(String(256), nullable=False)
    full_name = Column(String(128), nullable=False)
    role = Column(Enum(UserRole), default=UserRole.LOGISTICS_OPERATOR, nullable=False, index=True)
    assigned_region = Column(String(64), default="ASSAM", nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    phone_number = Column(String(32), nullable=True)
    created_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False)
    updated_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False)

    # Relationships
    assigned_vehicles = relationship("Vehicle", back_populates="driver")
    field_reports = relationship("FieldReport", back_populates="officer")
    audit_logs = relationship("AuditLog", back_populates="user")
    notifications = relationship("Notification", back_populates="user")


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(String(64), primary_key=True, index=True)
    user_id = Column(String(64), index=True, nullable=True)
    action = Column(String(128), nullable=False, index=True)
    entity_type = Column(String(64), nullable=False, index=True)
    entity_id = Column(String(64), nullable=True)
    details = Column(Text, nullable=True)
    ip_address = Column(String(64), nullable=True)
    created_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False, index=True)

    # Relationship
    user = relationship("User", back_populates="audit_logs", foreign_keys=[user_id], primaryjoin="AuditLog.user_id==User.id")

Index("idx_audit_logs_action_created", AuditLog.action, AuditLog.created_at)
