import enum
import time
from sqlalchemy import Column, String, Float, Enum, BigInteger, Text, Boolean, ForeignKey, Index
from sqlalchemy.orm import relationship
from app.database import Base


class AlertSeverity(str, enum.Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    HIGH = "HIGH"
    CRITICAL_EMERGENCY = "CRITICAL_EMERGENCY"


class AlertType(str, enum.Enum):
    LANDSLIDE_BLOCKED = "LANDSLIDE_BLOCKED"
    FLASH_FLOOD_WARNING = "FLASH_FLOOD_WARNING"
    CONVOY_DELAY = "CONVOY_DELAY"
    VEHICLE_OFF_TRACK = "VEHICLE_OFF_TRACK"
    SOS_PANIC = "SOS_PANIC"
    EXTREME_WEATHER = "EXTREME_WEATHER"
    ROAD_CONDITION_HAZARD = "ROAD_CONDITION_HAZARD"
    GEOFENCE_BREACH = "GEOFENCE_BREACH"


class Alert(Base):
    __tablename__ = "alerts"

    id = Column(String(64), primary_key=True, index=True)
    incident_id = Column(String(64), ForeignKey("incidents.id"), nullable=True, index=True)
    vehicle_id = Column(String(64), ForeignKey("vehicles.id"), nullable=True, index=True)
    title = Column(String(128), nullable=False)
    message = Column(Text, nullable=False)
    severity = Column(Enum(AlertSeverity), default=AlertSeverity.WARNING, nullable=False, index=True)
    alert_type = Column(Enum(AlertType), default=AlertType.ROAD_CONDITION_HAZARD, nullable=False, index=True)
    affected_corridor_code = Column(String(64), nullable=True, index=True)
    latitude = Column(Float, nullable=True)
    longitude = Column(Float, nullable=True)
    radius_km = Column(Float, default=20.0, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False, index=True)
    is_broadcasted = Column(Boolean, default=False, nullable=False)
    broadcast_timestamp = Column(BigInteger, nullable=True)
    created_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False, index=True)
    resolved_at = Column(BigInteger, nullable=True)

    # Relationships
    incident = relationship("Incident", back_populates="alerts")
    vehicle = relationship("Vehicle", back_populates="alerts")


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(String(64), primary_key=True, index=True)
    user_id = Column(String(64), ForeignKey("users.id"), nullable=False, index=True)
    title = Column(String(128), nullable=False)
    body = Column(Text, nullable=False)
    priority = Column(String(32), default="NORMAL", nullable=False)
    is_read = Column(Boolean, default=False, nullable=False, index=True)
    read_at = Column(BigInteger, nullable=True)
    action_url = Column(String(256), nullable=True)
    created_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False, index=True)

    # Relationship
    user = relationship("User", back_populates="notifications")

Index("idx_alerts_severity_active", Alert.severity, Alert.is_active)
Index("idx_notifications_user_read", Notification.user_id, Notification.is_read)
