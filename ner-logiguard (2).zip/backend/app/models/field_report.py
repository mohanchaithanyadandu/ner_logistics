import time
from sqlalchemy import Column, String, Float, Integer, BigInteger, Text, Boolean, ForeignKey, Index
from sqlalchemy.orm import relationship
from app.database import Base


class FieldReport(Base):
    __tablename__ = "field_reports"

    id = Column(String(64), primary_key=True, index=True)
    local_id = Column(String(64), unique=True, index=True, nullable=True)  # Android SQLite ID for idempotent sync
    officer_id = Column(String(64), ForeignKey("users.id"), nullable=True, index=True)
    officer_name = Column(String(128), nullable=False)
    latitude = Column(Float, nullable=False, index=True)
    longitude = Column(Float, nullable=False, index=True)
    altitude_meters = Column(Integer, default=100, nullable=False)
    road_name = Column(String(128), nullable=False)
    terrain_type = Column(String(64), default="HILLY_GHAT", nullable=False)
    incident_type = Column(String(64), default="LANDSLIDE", nullable=False, index=True)
    severity = Column(String(32), default="HIGH", nullable=False, index=True)
    description = Column(Text, nullable=False)
    is_synced = Column(Boolean, default=True, nullable=False, index=True)
    sync_timestamp = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False)
    is_offline_origin = Column(Boolean, default=False, nullable=False)
    photo_metadata_json = Column(Text, default="[]", nullable=False)
    incident_id = Column(String(64), ForeignKey("incidents.id"), nullable=True, index=True)
    created_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False, index=True)

    # Relationships
    officer = relationship("User", back_populates="field_reports")
    incident = relationship("Incident", back_populates="field_reports")

Index("idx_field_reports_sync_created", FieldReport.is_synced, FieldReport.created_at)
