import enum
import time
from sqlalchemy import Column, String, Float, Integer, Enum, BigInteger, Text, Boolean, Index
from sqlalchemy.orm import relationship
from app.database import Base


class IncidentType(str, enum.Enum):
    LANDSLIDE = "LANDSLIDE"
    MUDSLIDE = "MUDSLIDE"
    ROAD_COLLAPSE = "ROAD_COLLAPSE"
    FLASH_FLOOD = "FLASH_FLOOD"
    SNOW_BLOCKAGE = "SNOW_BLOCKAGE"
    VEHICLE_BREAKDOWN = "VEHICLE_BREAKDOWN"
    BRIDGE_DAMAGE = "BRIDGE_DAMAGE"
    FALLING_BOULDERS = "FALLING_BOULDERS"
    FOG_ZERO_VISIBILITY = "FOG_ZERO_VISIBILITY"


class IncidentSeverity(str, enum.Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL_BLOCKAGE = "CRITICAL_BLOCKAGE"


class IncidentStatus(str, enum.Enum):
    REPORTED = "REPORTED"
    VERIFIED = "VERIFIED"
    CLEARANCE_IN_PROGRESS = "CLEARANCE_IN_PROGRESS"
    RESOLVED = "RESOLVED"
    MONITORING = "MONITORING"


class Incident(Base):
    __tablename__ = "incidents"

    id = Column(String(64), primary_key=True, index=True)
    title = Column(String(128), nullable=False)
    type = Column(Enum(IncidentType), default=IncidentType.LANDSLIDE, nullable=False, index=True)
    severity = Column(Enum(IncidentSeverity), default=IncidentSeverity.HIGH, nullable=False, index=True)
    status = Column(Enum(IncidentStatus), default=IncidentStatus.REPORTED, nullable=False, index=True)
    latitude = Column(Float, nullable=False, index=True)
    longitude = Column(Float, nullable=False, index=True)
    altitude_meters = Column(Integer, default=500, nullable=False)
    location_name = Column(String(128), nullable=False)
    corridor_code = Column(String(64), nullable=True, index=True)
    state = Column(String(64), default="ASSAM", nullable=False, index=True)
    clearance_eta_hours = Column(Float, default=4.0, nullable=False)
    affected_radius_km = Column(Float, default=5.0, nullable=False)
    is_blocking = Column(Boolean, default=True, nullable=False, index=True)
    reported_by = Column(String(128), nullable=False)
    description = Column(Text, nullable=False)
    photo_urls_json = Column(Text, default="[]", nullable=False)
    resolved_at = Column(BigInteger, nullable=True)
    created_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False, index=True)
    updated_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False)

    # Relationships
    alerts = relationship("Alert", back_populates="incident")
    field_reports = relationship("FieldReport", back_populates="incident")

Index("idx_incidents_lat_lng_status", Incident.latitude, Incident.longitude, Incident.status)
Index("idx_incidents_severity_created", Incident.severity, Incident.created_at)
