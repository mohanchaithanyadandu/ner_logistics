import enum
import time
from sqlalchemy import Column, String, Float, Enum, BigInteger, Text, ForeignKey, Index
from sqlalchemy.orm import relationship
from app.database import Base


class RiskLevel(str, enum.Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    MODERATE = "MODERATE"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class RiskPrediction(Base):
    __tablename__ = "risk_predictions"

    id = Column(String(64), primary_key=True, index=True)
    corridor_code = Column(String(64), index=True, nullable=False)
    route_id = Column(String(64), ForeignKey("routes.id"), nullable=True, index=True)
    corridor_name = Column(String(128), nullable=False)
    latitude = Column(Float, nullable=False, index=True)
    longitude = Column(Float, nullable=False, index=True)
    overall_risk_score = Column(Float, nullable=False, index=True)
    risk_level = Column(Enum(RiskLevel), default=RiskLevel.MEDIUM, nullable=False, index=True)
    landslide_prob = Column(Float, default=0.0, nullable=False)
    flood_prob = Column(Float, default=0.0, nullable=False)
    road_block_prob = Column(Float, default=0.0, nullable=False)
    weather_severity_score = Column(Float, default=0.0, nullable=False)
    gradient_hazard_score = Column(Float, default=0.0, nullable=False)
    primary_hazard = Column(String(128), nullable=False)
    mitigation_recommendation = Column(Text, nullable=False)
    ai_rationale = Column(Text, nullable=True)
    calculation_timestamp = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False, index=True)
    created_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False)

    # Relationship
    route = relationship("Route", back_populates="risk_predictions")

Index("idx_risk_corridor_time", RiskPrediction.corridor_code, RiskPrediction.calculation_timestamp)
Index("idx_risk_level_score", RiskPrediction.risk_level, RiskPrediction.overall_risk_score)
