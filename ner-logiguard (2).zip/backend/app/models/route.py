import enum
import time
from sqlalchemy import Column, String, Float, Integer, Enum, BigInteger, ForeignKey, Text, Boolean, Index
from sqlalchemy.orm import relationship
from app.database import Base


class DeliveryStatus(str, enum.Enum):
    PENDING_DISPATCH = "PENDING_DISPATCH"
    IN_TRANSIT = "IN_TRANSIT"
    REROUTED_HAZARD = "REROUTED_HAZARD"
    DELIVERED_SUCCESS = "DELIVERED_SUCCESS"
    HALTED_EMERGENCY = "HALTED_EMERGENCY"
    CANCELLED = "CANCELLED"


class RoutePriority(str, enum.Enum):
    STANDARD = "STANDARD"
    HIGH_CRITICAL = "HIGH_CRITICAL"
    DEFENSE_ESSENTIAL = "DEFENSE_ESSENTIAL"
    MEDICAL_URGENT = "MEDICAL_URGENT"


class Route(Base):
    __tablename__ = "routes"

    id = Column(String(64), primary_key=True, index=True)
    corridor_code = Column(String(64), unique=True, index=True, nullable=False)
    name = Column(String(128), nullable=False)
    origin_hub_id = Column(String(64), nullable=False, index=True)
    origin_name = Column(String(128), nullable=False)
    destination_hub_id = Column(String(64), nullable=False, index=True)
    destination_name = Column(String(128), nullable=False)
    total_distance_km = Column(Float, nullable=False)
    baseline_eta_hours = Column(Float, nullable=False)
    max_altitude_meters = Column(Integer, default=0, nullable=False)
    max_gradient_pct = Column(Float, default=0.0, nullable=False)
    primary_terrain_type = Column(String(64), default="HILLY_GHAT", nullable=False)
    has_alternate_bypass = Column(Boolean, default=True, nullable=False)
    waypoints_json = Column(Text, nullable=False)  # JSON array of GeoJSON/coordinate points
    elevation_profile_json = Column(Text, nullable=True)  # JSON array of checkpoints
    created_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False)
    updated_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False)

    # Relationships
    segments = relationship("RouteSegment", back_populates="route", cascade="all, delete-orphan")
    deliveries = relationship("Delivery", back_populates="route")
    risk_predictions = relationship("RiskPrediction", back_populates="route")


class RouteSegment(Base):
    __tablename__ = "route_segments"

    id = Column(String(64), primary_key=True, index=True)
    route_id = Column(String(64), ForeignKey("routes.id", ondelete="CASCADE"), nullable=False, index=True)
    segment_index = Column(Integer, nullable=False)
    from_name = Column(String(128), nullable=False)
    to_name = Column(String(128), nullable=False)
    start_lat = Column(Float, nullable=False)
    start_lng = Column(Float, nullable=False)
    end_lat = Column(Float, nullable=False)
    end_lng = Column(Float, nullable=False)
    distance_km = Column(Float, nullable=False)
    start_altitude_m = Column(Integer, default=0, nullable=False)
    end_altitude_m = Column(Integer, default=0, nullable=False)
    gradient_pct = Column(Float, default=0.0, nullable=False)
    is_high_risk_zone = Column(Boolean, default=False, nullable=False, index=True)
    hazard_description = Column(String(256), nullable=True)
    avg_speed_km_h = Column(Float, default=35.0, nullable=False)

    # Relationship
    route = relationship("Route", back_populates="segments")

Index("idx_route_segments_route_idx", RouteSegment.route_id, RouteSegment.segment_index)


class Delivery(Base):
    __tablename__ = "deliveries"

    id = Column(String(64), primary_key=True, index=True)
    tracking_number = Column(String(64), unique=True, index=True, nullable=False)
    route_id = Column(String(64), ForeignKey("routes.id"), nullable=False, index=True)
    vehicle_id = Column(String(64), ForeignKey("vehicles.id"), nullable=True, index=True)
    origin_name = Column(String(128), nullable=False)
    destination_name = Column(String(128), nullable=False)
    cargo_type = Column(String(64), nullable=False)
    cargo_weight_kg = Column(Float, default=0.0, nullable=False)
    priority = Column(Enum(RoutePriority), default=RoutePriority.STANDARD, nullable=False)
    status = Column(Enum(DeliveryStatus), default=DeliveryStatus.PENDING_DISPATCH, nullable=False, index=True)
    dispatch_time = Column(BigInteger, nullable=True)
    estimated_arrival_time = Column(BigInteger, nullable=True)
    actual_arrival_time = Column(BigInteger, nullable=True)
    current_risk_score = Column(Float, default=0.15, nullable=False)
    route_explanation = Column(Text, nullable=True)
    created_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False)
    updated_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False)

    # Relationships
    route = relationship("Route", back_populates="deliveries")
    vehicle = relationship("Vehicle", back_populates="deliveries")
