import time
from sqlalchemy import Column, String, Float, Integer, BigInteger, Text, Index
from app.database import Base


class WeatherObservation(Base):
    __tablename__ = "weather_observations"

    id = Column(String(64), primary_key=True, index=True)
    station_code = Column(String(64), index=True, nullable=False)
    location_name = Column(String(128), nullable=False)
    state = Column(String(64), default="ASSAM", nullable=False, index=True)
    latitude = Column(Float, nullable=False, index=True)
    longitude = Column(Float, nullable=False, index=True)
    temperature_c = Column(Float, nullable=False)
    relative_humidity_pct = Column(Float, nullable=False)
    precipitation_mm_h = Column(Float, default=0.0, nullable=False)
    rain_intensity = Column(String(32), default="NONE", nullable=False)
    wind_speed_km_h = Column(Float, default=0.0, nullable=False)
    visibility_km = Column(Float, default=10.0, nullable=False)
    cloud_cover_pct = Column(Integer, default=0, nullable=False)
    weather_code = Column(Integer, default=0, nullable=False)
    is_monsoon_surge = Column(String(32), default="NORMAL", nullable=False)
    forecast_summary = Column(Text, nullable=True)
    observation_time = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False, index=True)
    created_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False)

Index("idx_weather_lat_lng_time", WeatherObservation.latitude, WeatherObservation.longitude, WeatherObservation.observation_time)
Index("idx_weather_station_time", WeatherObservation.station_code, WeatherObservation.observation_time)
