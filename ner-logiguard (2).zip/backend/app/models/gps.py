import time
from sqlalchemy import Column, String, Float, Integer, BigInteger, ForeignKey, Boolean, Index
from sqlalchemy.orm import relationship
from app.database import Base


class GPSPoint(Base):
    __tablename__ = "gps_points"

    id = Column(String(64), primary_key=True, index=True)
    vehicle_id = Column(String(64), ForeignKey("vehicles.id", ondelete="CASCADE"), nullable=False, index=True)
    latitude = Column(Float, nullable=False, index=True)
    longitude = Column(Float, nullable=False, index=True)
    altitude_meters = Column(Integer, default=100, nullable=False)
    speed_km_h = Column(Float, default=0.0, nullable=False)
    heading_degrees = Column(Float, default=0.0, nullable=False)
    accuracy_meters = Column(Float, default=5.0, nullable=False)
    battery_level_pct = Column(Float, default=100.0, nullable=False)
    signal_strength_dbm = Column(Integer, default=-70, nullable=False)
    network_carrier = Column(String(32), default="AIRTEL_4G", nullable=False)
    is_panic_button = Column(Boolean, default=False, nullable=False, index=True)
    timestamp = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False, index=True)
    created_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False)

    # Relationship
    vehicle = relationship("Vehicle", back_populates="gps_points")

Index("idx_gps_vehicle_timestamp", GPSPoint.vehicle_id, GPSPoint.timestamp)
Index("idx_gps_lat_lng", GPSPoint.latitude, GPSPoint.longitude)
