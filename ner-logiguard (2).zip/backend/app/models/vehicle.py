import enum
import time
from sqlalchemy import Column, String, Float, Integer, Enum, BigInteger, ForeignKey, Index
from sqlalchemy.orm import relationship
from app.database import Base


class VehicleType(str, enum.Enum):
    LIGHT_4X4 = "LIGHT_4X4"
    MEDIUM_CARGO_TRUCK = "MEDIUM_CARGO_TRUCK"
    HEAVY_MULTI_AXLE = "HEAVY_MULTI_AXLE"
    DEFENSE_CONVOY = "DEFENSE_CONVOY"
    REFRIGERATED_VAN = "REFRIGERATED_VAN"
    EMERGENCY_RESCUE = "EMERGENCY_RESCUE"


class VehicleStatus(str, enum.Enum):
    ACTIVE_OPTIMAL = "ACTIVE_OPTIMAL"
    DELAYED_RISK = "DELAYED_RISK"
    EMERGENCY_STOP = "EMERGENCY_STOP"
    OFFLINE_MAINTENANCE = "OFFLINE_MAINTENANCE"
    STANDBY = "STANDBY"


class Vehicle(Base):
    __tablename__ = "vehicles"

    id = Column(String(64), primary_key=True, index=True)
    vehicle_number = Column(String(64), unique=True, index=True, nullable=False)
    type = Column(Enum(VehicleType), default=VehicleType.MEDIUM_CARGO_TRUCK, nullable=False)
    driver_id = Column(String(64), ForeignKey("users.id"), nullable=True, index=True)
    driver_name = Column(String(128), nullable=False)
    driver_contact = Column(String(32), nullable=True)
    current_lat = Column(Float, nullable=False, index=True)
    current_lng = Column(Float, nullable=False, index=True)
    altitude_meters = Column(Integer, default=100, nullable=False)
    speed_km_h = Column(Float, default=0.0, nullable=False)
    heading_degrees = Column(Float, default=0.0, nullable=False)
    status = Column(Enum(VehicleStatus), default=VehicleStatus.ACTIVE_OPTIMAL, nullable=False, index=True)
    active_corridor_code = Column(String(64), nullable=True, index=True)
    active_route_name = Column(String(128), nullable=True)
    fuel_level_pct = Column(Float, default=100.0, nullable=False)
    cargo_type = Column(String(64), default="Essential Supplies", nullable=False)
    cargo_weight_kg = Column(Float, default=0.0, nullable=False)
    signal_status = Column(String(32), default="4G_STRONG", nullable=False)
    last_ping_time = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False, index=True)
    created_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False)
    updated_at = Column(BigInteger, default=lambda: int(time.time() * 1000), nullable=False)

    # Relationships
    driver = relationship("User", back_populates="assigned_vehicles")
    gps_points = relationship("GPSPoint", back_populates="vehicle", cascade="all, delete-orphan")
    deliveries = relationship("Delivery", back_populates="vehicle")
    alerts = relationship("Alert", back_populates="vehicle")

Index("idx_vehicles_status_lat_lng", Vehicle.status, Vehicle.current_lat, Vehicle.current_lng)
