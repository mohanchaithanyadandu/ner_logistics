"""
NER-LogiGuard AI / Risk Intelligence Engine
============================================
A transparent, multi-factor risk assessment and route safety intelligence engine
specifically engineered for North Eastern Region (NER) Himalayan corridors,
monsoon ghats, and high-altitude logistics supply networks.

Grounding & Transparency:
- Explicit weighted geotechnical, hydrological, and infrastructural models.
- Strict 0-100 Risk Categorization:
    0–30:   LOW
    31–60:  MODERATE
    61–80:  HIGH
    81–100: CRITICAL
- Confidence/Quality assessment based on telemetry freshness & sensor proximity.
- Extensible architecture ready for ML model inference plugins.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Any, Optional
import math
import time

try:
    from app.config import settings
except ImportError:
    settings = None


class RiskCategory(str, Enum):
    LOW = "LOW"             # 0 - 30
    MODERATE = "MODERATE"   # 31 - 60
    HIGH = "HIGH"           # 61 - 80
    CRITICAL = "CRITICAL"   # 81 - 100


class RoadCondition(str, Enum):
    GOOD = "GOOD"
    FAIR = "FAIR"
    DEGRADED = "DEGRADED"
    UNPAVED = "UNPAVED"
    MUDDY_SLURRY = "MUDDY_SLURRY"
    FLOODED = "FLOODED"


class RoadAccessibility(str, Enum):
    ALL_VEHICLES_PASSABLE = "ALL_VEHICLES_PASSABLE"
    LIGHT_4X4_ONLY = "LIGHT_4X4_ONLY"
    ESCORT_REQUIRED = "ESCORT_REQUIRED"
    RESTRICTED = "RESTRICTED"
    IMPASSABLE = "IMPASSABLE"


class BridgeStatus(str, Enum):
    OPEN_NORMAL = "OPEN_NORMAL"
    WEIGHT_RESTRICTED = "WEIGHT_RESTRICTED"
    SINGLE_LANE_ONLY = "SINGLE_LANE_ONLY"
    SUBMERGED_DAMAGED = "SUBMERGED_DAMAGED"
    WASHED_OUT = "WASHED_OUT"


class TrafficLevel(str, Enum):
    CLEAR = "CLEAR"
    MODERATE = "MODERATE"
    HEAVY = "HEAVY"
    STANDSTILL = "STANDSTILL"


class RainfallIntensity(str, Enum):
    NONE = "NONE"
    LIGHT = "LIGHT"              # < 2.5 mm/h
    MODERATE = "MODERATE"        # 2.5 - 10 mm/h
    HEAVY = "HEAVY"              # 10 - 25 mm/h
    TORRENTIAL = "TORRENTIAL"    # 25 - 50 mm/h
    CLOUDBURST = "CLOUDBURST"    # > 50 mm/h


@dataclass
class RiskEngineWeights:
    """Configurable weights for the risk engine (Sum = 100.0)."""
    rainfall: float = 20.0
    terrain: float = 15.0
    road_condition: float = 15.0
    active_incidents: float = 20.0
    historical_incidents: float = 5.0
    flood_susceptibility: float = 10.0
    landslide_susceptibility: float = 10.0
    infrastructure: float = 5.0

    @classmethod
    def from_settings(cls) -> "RiskEngineWeights":
        return cls(
            rainfall=getattr(settings, "RISK_WEIGHT_RAINFALL", 20.0),
            terrain=getattr(settings, "RISK_WEIGHT_TERRAIN", 15.0),
            road_condition=getattr(settings, "RISK_WEIGHT_ROAD_CONDITION", 15.0),
            active_incidents=getattr(settings, "RISK_WEIGHT_INCIDENTS_ACTIVE", 20.0),
            historical_incidents=getattr(settings, "RISK_WEIGHT_INCIDENTS_HISTORIC", 5.0),
            flood_susceptibility=getattr(settings, "RISK_WEIGHT_FLOOD_SUSCEPTIBILITY", 10.0),
            landslide_susceptibility=getattr(settings, "RISK_WEIGHT_LANDSLIDE_SUSCEPTIBILITY", 10.0),
            infrastructure=getattr(settings, "RISK_WEIGHT_INFRASTRUCTURE", 5.0),
        )


@dataclass
class RiskInputData:
    """Comprehensive input metrics for corridor and segment risk evaluation."""
    corridor_code: str = "GENERIC_NER"
    corridor_name: str = "North East Logistics Corridor"
    latitude: float = 26.5
    longitude: float = 92.0
    
    # 1. Weather & Precipitation
    rainfall_mm_h: float = 0.0
    rainfall_intensity: RainfallIntensity = RainfallIntensity.NONE
    rainfall_duration_hours: float = 0.0
    relative_humidity_pct: float = 65.0
    
    # 2. Topography & Terrain
    elevation_m: float = 500.0
    slope_gradient_pct: float = 4.0
    
    # 3. Road & Infrastructure
    road_condition: RoadCondition = RoadCondition.GOOD
    road_accessibility: RoadAccessibility = RoadAccessibility.ALL_VEHICLES_PASSABLE
    bridge_status: BridgeStatus = BridgeStatus.OPEN_NORMAL
    traffic_level: TrafficLevel = TrafficLevel.CLEAR
    
    # 4. Incident Intelligence
    historical_incidents_count: int = 0
    active_incidents: List[Dict[str, Any]] = field(default_factory=list)
    
    # 5. Geotechnical & Hydrological Indicators
    flood_indicator_score: Optional[float] = None        # 0.0 - 1.0 (soil moisture / catchment surge)
    landslide_indicator_score: Optional[float] = None    # 0.0 - 1.0 (geotechnical shear index)
    
    # 6. Logistics Context
    vehicle_type: str = "MEDIUM_CARGO_TRUCK"
    cargo_weight_kg: float = 4500.0
    is_hazardous_cargo: bool = False
    
    # 7. Telemetry & Sensor Metadata (Quality/Confidence)
    weather_station_distance_km: float = 12.0
    data_freshness_seconds: int = 300
    telemetry_sources_available: int = 4  # e.g., Open-Meteo, BRO Reports, Field Pings, GPS Traces


@dataclass
class RiskFactorDetail:
    factor_name: str
    raw_score: float            # 0 - 100
    weight_pct: float           # configured weight %
    weighted_score: float       # raw_score * (weight_pct / 100)
    status: str                 # "LOW", "MODERATE", "HIGH", "CRITICAL"
    impact_description: str


@dataclass
class RiskOutputData:
    corridor_code: str
    corridor_name: str
    risk_score: float           # 0 - 100 scale
    risk_category: RiskCategory
    confidence_score: float     # 0.0 - 1.0
    confidence_level: str       # "HIGH", "MEDIUM", "LOW"
    recommended_action: str
    primary_hazard: str
    factors: List[RiskFactorDetail]
    sub_indices: Dict[str, float]
    rationale: str
    is_impassable: bool
    requires_4x4: bool
    calculated_at: int = field(default_factory=lambda: int(time.time() * 1000))


class AbstractRiskModel(ABC):
    """Abstract interface for risk intelligence evaluation models."""
    
    @abstractmethod
    def evaluate(self, inputs: RiskInputData, weights: RiskEngineWeights) -> RiskOutputData:
        pass


class WeightedRuleRiskModel(AbstractRiskModel):
    """
    Transparent, deterministic geotechnical and meteorological weighted scoring model.
    Fully grounded in measurable atmospheric, topographical, and incident parameters.
    """

    def evaluate(self, inputs: RiskInputData, weights: RiskEngineWeights) -> RiskOutputData:
        # -------------------------------------------------------------
        # 1. Rainfall Index (0 - 100)
        # -------------------------------------------------------------
        # Rate contribution: 0-5mm/h -> 0-25, 5-20mm/h -> 25-65, 20-50mm/h -> 65-90, >50mm/h -> 100
        rate = inputs.rainfall_mm_h
        if rate <= 0.0:
            rate_score = 0.0
        elif rate <= 5.0:
            rate_score = (rate / 5.0) * 25.0
        elif rate <= 20.0:
            rate_score = 25.0 + ((rate - 5.0) / 15.0) * 40.0
        elif rate <= 50.0:
            rate_score = 65.0 + ((rate - 20.0) / 30.0) * 25.0
        else:
            rate_score = min(100.0, 90.0 + ((rate - 50.0) / 50.0) * 10.0)

        # Intensity modifier
        intensity_mult = {
            RainfallIntensity.NONE: 0.0,
            RainfallIntensity.LIGHT: 0.8,
            RainfallIntensity.MODERATE: 1.0,
            RainfallIntensity.HEAVY: 1.25,
            RainfallIntensity.TORRENTIAL: 1.45,
            RainfallIntensity.CLOUDBURST: 1.70,
        }.get(inputs.rainfall_intensity, 1.0)

        # Duration saturation multiplier (soil saturates over hours of persistent rain)
        dur_hrs = inputs.rainfall_duration_hours
        duration_mult = 1.0 + min(0.5, (dur_hrs / 12.0) * 0.5) if rate > 1.0 else 1.0

        rainfall_score = min(100.0, rate_score * intensity_mult * duration_mult)

        # -------------------------------------------------------------
        # 2. Terrain & Topography Index (0 - 100)
        # -------------------------------------------------------------
        # Altitude factor: > 2500m (freezing/fog/thin air), > 3800m (extreme passes like Sela)
        alt = inputs.elevation_m
        if alt <= 500:
            alt_factor = 10.0
        elif alt <= 2000:
            alt_factor = 10.0 + ((alt - 500) / 1500.0) * 25.0
        elif alt <= 3500:
            alt_factor = 35.0 + ((alt - 2000) / 1500.0) * 35.0
        else:
            alt_factor = min(100.0, 70.0 + ((alt - 3500) / 1000.0) * 30.0)

        # Slope gradient factor: standard highway <= 5% (safe), 5-8% (ghat), 8-14% (steep), >14% (extreme)
        gradient = inputs.slope_gradient_pct
        if gradient <= 4.0:
            grad_factor = 10.0
        elif gradient <= 8.0:
            grad_factor = 10.0 + ((gradient - 4.0) / 4.0) * 30.0
        elif gradient <= 12.0:
            grad_factor = 40.0 + ((gradient - 8.0) / 4.0) * 35.0
        else:
            grad_factor = min(100.0, 75.0 + ((gradient - 12.0) / 6.0) * 25.0)

        # Vehicle load penalty on steep terrain
        cargo_load_penalty = 0.0
        if inputs.cargo_weight_kg > 10000.0 and gradient > 7.0:
            cargo_load_penalty = 15.0
        elif inputs.cargo_weight_kg > 6000.0 and gradient > 6.0:
            cargo_load_penalty = 8.0

        terrain_score = min(100.0, (alt_factor * 0.45 + grad_factor * 0.55) + cargo_load_penalty)

        # -------------------------------------------------------------
        # 3. Road Condition Index (0 - 100)
        # -------------------------------------------------------------
        road_cond_map = {
            RoadCondition.GOOD: 10.0,
            RoadCondition.FAIR: 30.0,
            RoadCondition.DEGRADED: 55.0,
            RoadCondition.UNPAVED: 70.0,
            RoadCondition.MUDDY_SLURRY: 85.0,
            RoadCondition.FLOODED: 100.0,
        }
        traffic_map = {
            TrafficLevel.CLEAR: 0.0,
            TrafficLevel.MODERATE: 10.0,
            TrafficLevel.HEAVY: 25.0,
            TrafficLevel.STANDSTILL: 45.0,
        }
        road_score = min(100.0, road_cond_map.get(inputs.road_condition, 20.0) * 0.8 + traffic_map.get(inputs.traffic_level, 0.0) * 0.2)

        # -------------------------------------------------------------
        # 4. Active Incident Index (0 - 100)
        # -------------------------------------------------------------
        incident_penalty = 0.0
        critical_blockage = False
        road_washout = False
        incident_types_seen = []

        for inc in inputs.active_incidents:
            sev = str(inc.get("severity", "MEDIUM")).upper()
            inc_type = str(inc.get("type", "INCIDENT")).upper()
            incident_types_seen.append(inc_type)
            dist_km = inc.get("distance_km", 0.0)

            # Distance decay: closer incidents have higher impact
            dist_factor = 1.0 if dist_km <= 10.0 else max(0.2, 1.0 - (dist_km / 50.0))

            if "CRITICAL" in sev or "BLOCKAGE" in sev or "WASHOUT" in inc_type or "COLLAPSE" in inc_type:
                incident_penalty += 55.0 * dist_factor
                critical_blockage = True
            elif "HIGH" in sev or "LANDSLIDE" in inc_type:
                incident_penalty += 35.0 * dist_factor
            elif "MODERATE" in sev or "MEDIUM" in sev:
                incident_penalty += 20.0 * dist_factor
            else:
                incident_penalty += 10.0 * dist_factor

        active_incident_score = min(100.0, incident_penalty)

        # -------------------------------------------------------------
        # 5. Historical Incident Index (0 - 100)
        # -------------------------------------------------------------
        # Chronic landslide zones (e.g. Sonapur, Chumukedima) have historical recurring count
        hist_count = inputs.historical_incidents_count
        hist_score = min(100.0, (hist_count / 10.0) * 100.0 if hist_count > 0 else 10.0)

        # -------------------------------------------------------------
        # 6. Geotechnical Landslide Susceptibility Index (0 - 100)
        # -------------------------------------------------------------
        if inputs.landslide_indicator_score is not None:
            landslide_score = inputs.landslide_indicator_score * 100.0
        else:
            # Derived landslide formula: f(slope, rainfall rate, soil humidity, elevation)
            slope_term = (gradient / 15.0) * 40.0
            rain_term = (rainfall_score / 100.0) * 45.0
            hist_term = (hist_score / 100.0) * 15.0
            landslide_score = min(100.0, slope_term + rain_term + hist_term)

        # -------------------------------------------------------------
        # 7. Hydrological Flood Susceptibility Index (0 - 100)
        # -------------------------------------------------------------
        if inputs.flood_indicator_score is not None:
            flood_score = inputs.flood_indicator_score * 100.0
        else:
            # Low elevation river valley + heavy rainfall
            valley_bonus = 20.0 if alt < 200.0 else 5.0
            rain_flood = (rainfall_score / 100.0) * 75.0
            flood_score = min(100.0, rain_flood + valley_bonus)

        # -------------------------------------------------------------
        # 8. Infrastructure / Bridge / Pass Clearance Index (0 - 100)
        # -------------------------------------------------------------
        bridge_map = {
            BridgeStatus.OPEN_NORMAL: 5.0,
            BridgeStatus.SINGLE_LANE_ONLY: 30.0,
            BridgeStatus.WEIGHT_RESTRICTED: 50.0,
            BridgeStatus.SUBMERGED_DAMAGED: 85.0,
            BridgeStatus.WASHED_OUT: 100.0,
        }
        access_map = {
            RoadAccessibility.ALL_VEHICLES_PASSABLE: 5.0,
            RoadAccessibility.LIGHT_4X4_ONLY: 45.0,
            RoadAccessibility.ESCORT_REQUIRED: 60.0,
            RoadAccessibility.RESTRICTED: 80.0,
            RoadAccessibility.IMPASSABLE: 100.0,
        }
        infra_score = min(100.0, bridge_map.get(inputs.bridge_status, 10.0) * 0.5 + access_map.get(inputs.road_accessibility, 10.0) * 0.5)

        # -------------------------------------------------------------
        # 9. Composite Weighted Score Calculation
        # -------------------------------------------------------------
        total_weight = (
            weights.rainfall +
            weights.terrain +
            weights.road_condition +
            weights.active_incidents +
            weights.historical_incidents +
            weights.flood_susceptibility +
            weights.landslide_susceptibility +
            weights.infrastructure
        )
        if total_weight <= 0:
            total_weight = 100.0

        composite_score = (
            rainfall_score * weights.rainfall +
            terrain_score * weights.terrain +
            road_score * weights.road_condition +
            active_incident_score * weights.active_incidents +
            hist_score * weights.historical_incidents +
            flood_score * weights.flood_susceptibility +
            landslide_score * weights.landslide_susceptibility +
            infra_score * weights.infrastructure
        ) / total_weight

        # Hard overrides for catastrophic physical barriers
        if inputs.bridge_status == BridgeStatus.WASHED_OUT or inputs.road_accessibility == RoadAccessibility.IMPASSABLE:
            composite_score = max(composite_score, 92.0)
        elif critical_blockage and len(inputs.active_incidents) >= 2:
            composite_score = max(composite_score, 85.0)

        composite_score = round(max(0.0, min(100.0, composite_score)), 1)

        # -------------------------------------------------------------
        # 10. Risk Category Assignment
        # -------------------------------------------------------------
        if composite_score <= 30.0:
            category = RiskCategory.LOW
            primary_hazard = "Optimal Corridor Conditions"
            mitigation = "Standard operating procedures. Maintain recommended convoy speed (45 km/h on ghats)."
        elif composite_score <= 60.0:
            category = RiskCategory.MODERATE
            primary_hazard = "Mountain Fog, Slippery Roadways, or Moderate Inundation"
            mitigation = "Proceed with caution. Turn on fog lamps, maintain >50m convoy separation, and monitor weather radar."
        elif composite_score <= 80.0:
            category = RiskCategory.HIGH
            primary_hazard = "High Landslide Susceptibility & Active Hillside Slope Saturation"
            mitigation = "Deploy 4x4 escort vehicles. Reduce speed to <25 km/h. Inspect brake air pressure and wheel chains."
        else:
            category = RiskCategory.CRITICAL
            primary_hazard = "Critical Landslide / Road Washout / Impassable Chokepoint"
            mitigation = "HOLD CONVOY IMMEDIATELY at nearest staging depot. Reroute via alternate pass or await BRO clearance."

        # -------------------------------------------------------------
        # 11. Confidence / Quality Indicator (0.0 - 1.0)
        # -------------------------------------------------------------
        # Calculated from telemetry freshness, weather station proximity, and multi-source corroboration
        station_penalty = min(0.25, (inputs.weather_station_distance_km / 100.0) * 0.25)
        freshness_penalty = min(0.20, (inputs.data_freshness_seconds / 3600.0) * 0.20)
        sources_bonus = min(0.15, (inputs.telemetry_sources_available / 4.0) * 0.15)
        
        confidence = max(0.50, min(0.99, 0.90 - station_penalty - freshness_penalty + sources_bonus))
        confidence = round(confidence, 2)
        conf_level = "HIGH" if confidence >= 0.85 else ("MEDIUM" if confidence >= 0.65 else "LOW")

        # -------------------------------------------------------------
        # 12. Factors Breakdown
        # -------------------------------------------------------------
        def status_for(score: float) -> str:
            if score <= 30.0: return "LOW"
            if score <= 60.0: return "MODERATE"
            if score <= 80.0: return "HIGH"
            return "CRITICAL"

        factors = [
            RiskFactorDetail(
                factor_name="Rainfall & Atmospheric Intensity",
                raw_score=round(rainfall_score, 1),
                weight_pct=weights.rainfall,
                weighted_score=round(rainfall_score * (weights.rainfall / 100.0), 1),
                status=status_for(rainfall_score),
                impact_description=f"Rain rate {inputs.rainfall_mm_h:.1f} mm/h ({inputs.rainfall_intensity.value}), {inputs.rainfall_duration_hours:.1f}h duration"
            ),
            RiskFactorDetail(
                factor_name="Topography, Elevation & Slope",
                raw_score=round(terrain_score, 1),
                weight_pct=weights.terrain,
                weighted_score=round(terrain_score * (weights.terrain / 100.0), 1),
                status=status_for(terrain_score),
                impact_description=f"Summit {inputs.elevation_m:.0f}m, gradient {inputs.slope_gradient_pct:.1f}%, cargo weight {inputs.cargo_weight_kg:.0f}kg"
            ),
            RiskFactorDetail(
                factor_name="Road Surface & Traffic Condition",
                raw_score=round(road_score, 1),
                weight_pct=weights.road_condition,
                weighted_score=round(road_score * (weights.road_condition / 100.0), 1),
                status=status_for(road_score),
                impact_description=f"Surface {inputs.road_condition.value}, Traffic {inputs.traffic_level.value}"
            ),
            RiskFactorDetail(
                factor_name="Active Incident Proximity",
                raw_score=round(active_incident_score, 1),
                weight_pct=weights.active_incidents,
                weighted_score=round(active_incident_score * (weights.active_incidents / 100.0), 1),
                status=status_for(active_incident_score),
                impact_description=f"{len(inputs.active_incidents)} active hazards along corridor axis"
            ),
            RiskFactorDetail(
                factor_name="Landslide Susceptibility",
                raw_score=round(landslide_score, 1),
                weight_pct=weights.landslide_susceptibility,
                weighted_score=round(landslide_score * (weights.landslide_susceptibility / 100.0), 1),
                status=status_for(landslide_score),
                impact_description=f"Slope-shear index evaluated at {landslide_score:.1f}% under saturated soil conditions"
            ),
            RiskFactorDetail(
                factor_name="Flood & Inundation Hazard",
                raw_score=round(flood_score, 1),
                weight_pct=weights.flood_susceptibility,
                weighted_score=round(flood_score * (weights.flood_susceptibility / 100.0), 1),
                status=status_for(flood_score),
                impact_description=f"Catchment surge score {flood_score:.1f}% at elevation {inputs.elevation_m:.0f}m"
            ),
            RiskFactorDetail(
                factor_name="Infrastructure & Bridge Clearance",
                raw_score=round(infra_score, 1),
                weight_pct=weights.infrastructure,
                weighted_score=round(infra_score * (weights.infrastructure / 100.0), 1),
                status=status_for(infra_score),
                impact_description=f"Bridge: {inputs.bridge_status.value}, Access: {inputs.road_accessibility.value}"
            ),
        ]

        sub_indices = {
            "rainfall_index": round(rainfall_score, 1),
            "terrain_index": round(terrain_score, 1),
            "road_condition_index": round(road_score, 1),
            "active_incident_index": round(active_incident_score, 1),
            "historical_incident_index": round(hist_score, 1),
            "landslide_index": round(landslide_score, 1),
            "flood_index": round(flood_score, 1),
            "infrastructure_index": round(infra_score, 1),
        }

        rationale = (
            f"Risk index evaluated at {composite_score:.1f}/100 ({category.value}) for {inputs.corridor_name}. "
            f"Precipitation: {inputs.rainfall_mm_h:.1f} mm/h ({inputs.rainfall_intensity.value}), Elevation: {inputs.elevation_m:.0f}m. "
            f"Active incident count: {len(inputs.active_incidents)}. "
            f"Confidence score: {int(confidence * 100)}% based on multi-source sensor telemetry."
        )

        return RiskOutputData(
            corridor_code=inputs.corridor_code,
            corridor_name=inputs.corridor_name,
            risk_score=composite_score,
            risk_category=category,
            confidence_score=confidence,
            confidence_level=conf_level,
            recommended_action=mitigation,
            primary_hazard=primary_hazard,
            factors=factors,
            sub_indices=sub_indices,
            rationale=rationale,
            is_impassable=composite_score >= 81.0 or inputs.road_accessibility == RoadAccessibility.IMPASSABLE or inputs.bridge_status == BridgeStatus.WASHED_OUT,
            requires_4x4=composite_score >= 61.0 or inputs.road_accessibility == RoadAccessibility.LIGHT_4X4_ONLY or inputs.road_condition == RoadCondition.MUDDY_SLURRY
        )


class MLRiskModelStub(AbstractRiskModel):
    """
    Extensible Machine Learning Risk Model interface.
    Extracts a dense numerical feature vector for downstream scikit-learn, XGBoost, or ONNX runtimes.
    """

    def extract_feature_vector(self, inputs: RiskInputData) -> List[float]:
        """Extracts normalized 16-dimensional feature vector for ML inference."""
        road_cond_val = {"GOOD": 0.0, "FAIR": 0.2, "DEGRADED": 0.5, "UNPAVED": 0.7, "MUDDY_SLURRY": 0.9, "FLOODED": 1.0}.get(inputs.road_condition.value, 0.0)
        access_val = {"ALL_VEHICLES_PASSABLE": 0.0, "LIGHT_4X4_ONLY": 0.4, "ESCORT_REQUIRED": 0.6, "RESTRICTED": 0.8, "IMPASSABLE": 1.0}.get(inputs.road_accessibility.value, 0.0)
        bridge_val = {"OPEN_NORMAL": 0.0, "SINGLE_LANE_ONLY": 0.3, "WEIGHT_RESTRICTED": 0.5, "SUBMERGED_DAMAGED": 0.8, "WASHED_OUT": 1.0}.get(inputs.bridge_status.value, 0.0)
        traffic_val = {"CLEAR": 0.0, "MODERATE": 0.3, "HEAVY": 0.7, "STANDSTILL": 1.0}.get(inputs.traffic_level.value, 0.0)

        return [
            min(1.0, inputs.rainfall_mm_h / 60.0),
            min(1.0, inputs.rainfall_duration_hours / 24.0),
            inputs.relative_humidity_pct / 100.0,
            min(1.0, inputs.elevation_m / 4500.0),
            min(1.0, inputs.slope_gradient_pct / 20.0),
            road_cond_val,
            access_val,
            bridge_val,
            traffic_val,
            min(1.0, inputs.historical_incidents_count / 15.0),
            min(1.0, len(inputs.active_incidents) / 5.0),
            inputs.flood_indicator_score if inputs.flood_indicator_score is not None else 0.2,
            inputs.landslide_indicator_score if inputs.landslide_indicator_score is not None else 0.2,
            min(1.0, inputs.cargo_weight_kg / 20000.0),
            1.0 if inputs.is_hazardous_cargo else 0.0,
            min(1.0, inputs.weather_station_distance_km / 100.0)
        ]

    def evaluate(self, inputs: RiskInputData, weights: RiskEngineWeights) -> RiskOutputData:
        # Fallback to WeightedRuleRiskModel if ML artifact not loaded
        return WeightedRuleRiskModel().evaluate(inputs, weights)


class RiskEngine:
    """
    Primary Facade & Orchestrator for the Risk Intelligence Engine.
    Handles weight configuration, model selection, and batch corridor evaluations.
    """

    def __init__(self, model: Optional[AbstractRiskModel] = None, weights: Optional[RiskEngineWeights] = None):
        self.model = model or WeightedRuleRiskModel()
        self.weights = weights or RiskEngineWeights.from_settings()

    def set_weights(self, weights: RiskEngineWeights) -> None:
        self.weights = weights

    def evaluate(self, inputs: RiskInputData) -> RiskOutputData:
        return self.model.evaluate(inputs, self.weights)

    def evaluate_batch(self, inputs_list: List[RiskInputData]) -> List[RiskOutputData]:
        return [self.evaluate(inp) for inp in inputs_list]


# Global singleton instance
risk_engine = RiskEngine()
