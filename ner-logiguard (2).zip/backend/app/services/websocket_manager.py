import asyncio
import json
import logging
import math
import time
from typing import List, Dict, Any, Set, Optional
from fastapi import WebSocket

logger = logging.getLogger(__name__)


class ConnectionManager:
    """Manages real-time WebSockets and live fleet telemetry broadcast for the Command Center."""

    def __init__(self):
        # Active connections partitioned by channel
        self.active_connections: Set[WebSocket] = set()
        self.channel_subscriptions: Dict[str, Set[WebSocket]] = {
            "fleet": set(),
            "simulation": set(),
            "alerts": set(),
            "incidents": set(),
            "field_reports": set(),
            "weather": set()
        }
        self.simulation_running: bool = True
        self.simulation_speed: float = 1.0
        self.sim_task: Optional[asyncio.Task] = None
        self._init_simulated_fleet()

    @property
    def active_connections_count(self) -> int:
        """Returns total active connected WebSocket clients."""
        return len(self.active_connections)

    def _init_simulated_fleet(self):
        """Initializes simulated NER logistics vehicles with realistic mountain waypoints."""
        self.simulated_vehicles = [
            {
                "id": "V-101",
                "vehicle_number": "AS-01-GC-4482",
                "driver_name": "Bhaben Deka",
                "cargo": "Essential Medical Supplies & Vaccines",
                "origin": "Guwahati Central Depot",
                "destination": "Silchar District Hospital",
                "corridor": "NH-27 / NH-6 East-West Corridor",
                "current_lat": 26.1445,
                "current_lng": 91.7362,
                "altitude_meters": 55,
                "speed_km_h": 48.0,
                "heading_degrees": 125.0,
                "status": "ON_TIME",
                "fuel_level_pct": 82,
                "battery_level_pct": 94,
                "eta_minutes": 240,
                "is_deviated": False,
                "is_simulated": True,
                "waypoints": [
                    (26.1445, 91.7362, 55),
                    (25.9012, 91.9845, 340),
                    (25.6841, 92.2154, 780),
                    (25.4512, 92.5412, 1150),
                    (25.1845, 92.6841, 620),
                    (24.8333, 92.7789, 110)
                ],
                "waypoint_index": 0,
                "progress_ratio": 0.0
            },
            {
                "id": "V-102",
                "vehicle_number": "AR-01-T-9921",
                "driver_name": "Tsering Norbu",
                "cargo": "High-Altitude Defense Rations & Cold-Chain Kits",
                "origin": "Tezpur Military Transit Depot",
                "destination": "Tawang Forward Logistics Base",
                "corridor": "NH-13 Trans-Arunachal Highway",
                "current_lat": 26.6338,
                "current_lng": 92.7926,
                "altitude_meters": 72,
                "speed_km_h": 36.0,
                "heading_degrees": 340.0,
                "status": "ON_TIME",
                "fuel_level_pct": 74,
                "battery_level_pct": 88,
                "eta_minutes": 310,
                "is_deviated": False,
                "is_simulated": True,
                "waypoints": [
                    (26.6338, 92.7926, 72),
                    (27.0118, 92.6450, 213),
                    (27.2645, 92.4241, 2415),
                    (27.3592, 92.2384, 1560),
                    (27.5042, 92.1037, 4170),
                    (27.5861, 91.8594, 3048)
                ],
                "waypoint_index": 0,
                "progress_ratio": 0.0
            },
            {
                "id": "V-103",
                "vehicle_number": "MN-01-AA-7204",
                "driver_name": "L. Ibomcha Singh",
                "cargo": "Water Purification & Disinfectant Chemicals",
                "origin": "Silchar Logistics Staging Depot",
                "destination": "Imphal Relief Warehouse",
                "corridor": "NH-37 Barak-Imphal Lifeline",
                "current_lat": 24.8333,
                "current_lng": 92.7789,
                "altitude_meters": 110,
                "speed_km_h": 42.0,
                "heading_degrees": 88.0,
                "status": "ON_TIME",
                "fuel_level_pct": 68,
                "battery_level_pct": 91,
                "eta_minutes": 195,
                "is_deviated": False,
                "is_simulated": True,
                "waypoints": [
                    (24.8333, 92.7789, 110),
                    (24.7890, 93.1245, 290),
                    (24.8123, 93.4512, 650),
                    (24.7950, 93.7120, 890),
                    (24.8170, 93.9368, 786)
                ],
                "waypoint_index": 0,
                "progress_ratio": 0.0
            },
            {
                "id": "V-104",
                "vehicle_number": "NL-07-B-3108",
                "driver_name": "Kevichusa Angami",
                "cargo": "Baby Nutrition & Specialized Pharmaceuticals",
                "origin": "Dimapur Railway Freight Terminal",
                "destination": "Kohima State Cold Storage",
                "corridor": "NH-29 Dimapur-Kohima Mountain Express",
                "current_lat": 25.9068,
                "current_lng": 93.7271,
                "altitude_meters": 195,
                "speed_km_h": 32.0,
                "heading_degrees": 145.0,
                "status": "ON_TIME",
                "fuel_level_pct": 89,
                "battery_level_pct": 96,
                "eta_minutes": 110,
                "is_deviated": False,
                "is_simulated": True,
                "waypoints": [
                    (25.9068, 93.7271, 195),
                    (25.8210, 93.8540, 480),
                    (25.7450, 94.0120, 920),
                    (25.6751, 94.1086, 1444)
                ],
                "waypoint_index": 0,
                "progress_ratio": 0.0
            },
            {
                "id": "V-105",
                "vehicle_number": "TR-01-E-5541",
                "driver_name": "Debabrata Debbarma",
                "cargo": "Disaster Relief Shelter Kits & Tarpaulins",
                "origin": "Agartala Central Supply Yard",
                "destination": "Dharmanagar Sub-Depot",
                "corridor": "NH-8 Tripura Spine Corridor",
                "current_lat": 23.8315,
                "current_lng": 91.2868,
                "altitude_meters": 16,
                "speed_km_h": 50.0,
                "heading_degrees": 52.0,
                "status": "ON_TIME",
                "fuel_level_pct": 91,
                "battery_level_pct": 85,
                "eta_minutes": 180,
                "is_deviated": False,
                "is_simulated": True,
                "waypoints": [
                    (23.8315, 91.2868, 16),
                    (24.0120, 91.5420, 45),
                    (24.1890, 91.8120, 68),
                    (24.3780, 92.1640, 52)
                ],
                "waypoint_index": 0,
                "progress_ratio": 0.0
            },
            {
                "id": "V-106",
                "vehicle_number": "SK-02-P-1190",
                "driver_name": "Karma Bhutia",
                "cargo": "Emergency Blood Plasma & Oxygen Cylinders",
                "origin": "Gangtok State Hospital Hub",
                "destination": "Nathu La Border Checkpost Depot",
                "corridor": "Jawaharlal Nehru Road (JN Marg)",
                "current_lat": 27.3389,
                "current_lng": 88.6065,
                "altitude_meters": 1650,
                "speed_km_h": 28.0,
                "heading_degrees": 65.0,
                "status": "ON_TIME",
                "fuel_level_pct": 78,
                "battery_level_pct": 92,
                "eta_minutes": 135,
                "is_deviated": False,
                "is_simulated": True,
                "waypoints": [
                    (27.3389, 88.6065, 1650),
                    (27.3750, 88.6920, 2400),
                    (27.3910, 88.7610, 3100),
                    (27.3865, 88.8310, 4310)
                ],
                "waypoint_index": 0,
                "progress_ratio": 0.0
            }
        ]

    async def connect(self, websocket: WebSocket, channel: str = "fleet"):
        """Accepts WebSocket connection and subscribes to specified channel."""
        await websocket.accept()
        self.active_connections.add(websocket)
        if channel not in self.channel_subscriptions:
            self.channel_subscriptions[channel] = set()
        self.channel_subscriptions[channel].add(websocket)
        logger.info(f"WebSocket client connected to channel [{channel}]. Total connections: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket, channel: Optional[str] = None):
        """Removes disconnected WebSocket from all channels safely."""
        self.active_connections.discard(websocket)
        if channel and channel in self.channel_subscriptions:
            self.channel_subscriptions[channel].discard(websocket)
        for ch in self.channel_subscriptions.values():
            ch.discard(websocket)
        logger.info(f"WebSocket client disconnected. Remaining connections: {len(self.active_connections)}")

    async def broadcast_to_channel(self, channel: str, message: Dict[str, Any]):
        """Broadcasts structured payload to clients subscribed to a specific channel without blocking."""
        if channel not in self.channel_subscriptions or not self.channel_subscriptions[channel]:
            return
        payload_str = json.dumps(message)
        subscribers = list(self.channel_subscriptions.get(channel, set()))
        dead_connections = []
        for connection in subscribers:
            try:
                await connection.send_text(payload_str)
            except Exception as e:
                logger.debug(f"Error sending message to WebSocket client: {e}")
                dead_connections.append(connection)

        for dead in dead_connections:
            self.disconnect(dead, channel=channel)

    async def broadcast_all(self, message: Dict[str, Any]):
        """Broadcasts payload to every single active client."""
        if not self.active_connections:
            return
        payload_str = json.dumps(message)
        dead_connections = []
        for connection in list(self.active_connections):
            try:
                await connection.send_text(payload_str)
            except Exception as e:
                logger.debug(f"Error broadcasting to all: {e}")
                dead_connections.append(connection)

        for dead in dead_connections:
            self.disconnect(dead)

    def start_simulation_loop(self):
        """Starts background periodic simulation broadcaster if not already running."""
        if self.sim_task is None or self.sim_task.done():
            self.sim_task = asyncio.create_task(self._simulation_loop())
            logger.info("Background vehicle telemetry simulation loop started.")

    def pause_simulation(self):
        """Pauses simulation step progression."""
        self.simulation_running = False
        logger.info("Simulation paused.")

    def resume_simulation(self):
        """Resumes simulation step progression."""
        self.simulation_running = True
        logger.info("Simulation resumed.")

    def reset_simulation(self):
        """Resets all vehicles to their origin waypoints."""
        self._init_simulated_fleet()
        logger.info("Simulation reset to initial origin coordinates.")

    def trigger_deviation(self, vehicle_id: str = "V-102"):
        """Injects route corridor deviation for specified vehicle."""
        for v in self.simulated_vehicles:
            if v["id"] == vehicle_id:
                v["is_deviated"] = True
                v["current_lat"] += 0.045
                v["current_lng"] -= 0.038
                v["status"] = "AT_RISK"
                logger.warning(f"Route deviation triggered for vehicle {vehicle_id}")
                return True
        return False

    def clear_deviation(self, vehicle_id: str = "V-102"):
        """Clears deviation for specified vehicle."""
        for v in self.simulated_vehicles:
            if v["id"] == vehicle_id:
                v["is_deviated"] = False
                v["status"] = "ON_TIME"
                return True
        return False

    async def _simulation_loop(self):
        """Asynchronous loop continuously broadcasting vehicle positions without blocking."""
        while True:
            try:
                await asyncio.sleep(2.0)
                if not self.simulation_running:
                    continue

                if not self.active_connections:
                    continue

                now_ts = int(time.time() * 1000)

                for v in self.simulated_vehicles:
                    waypoints = v["waypoints"]
                    idx = v["waypoint_index"]
                    
                    if idx < len(waypoints) - 1 and not v["is_deviated"]:
                        p1 = waypoints[idx]
                        p2 = waypoints[idx + 1]
                        v["progress_ratio"] += 0.05 * self.simulation_speed
                        if v["progress_ratio"] >= 1.0:
                            v["progress_ratio"] = 0.0
                            v["waypoint_index"] += 1
                            idx = v["waypoint_index"]

                        if idx < len(waypoints) - 1:
                            p1 = waypoints[idx]
                            p2 = waypoints[idx + 1]
                            ratio = v["progress_ratio"]
                            v["current_lat"] = p1[0] + (p2[0] - p1[0]) * ratio
                            v["current_lng"] = p1[1] + (p2[1] - p1[1]) * ratio
                            v["altitude_meters"] = int(p1[2] + (p2[2] - p1[2]) * ratio)
                            v["last_update"] = now_ts
                        else:
                            v["status"] = "DELIVERED"
                            v["speed_km_h"] = 0.0
                    elif v["is_deviated"]:
                        # Deviated vehicle drifts off corridor
                        v["current_lat"] += 0.0004
                        v["current_lng"] -= 0.0003
                        v["last_update"] = now_ts

                    # Construct broadcast payload for each vehicle
                    telemetry_payload = {
                        "type": "SIMULATED_VEHICLE_TELEMETRY",
                        "is_simulated": True,
                        "data_source": "DEMO_SIMULATION",
                        "vehicle_id": v["id"],
                        "vehicle_number": v["vehicle_number"],
                        "cargo": v["cargo"],
                        "origin": v["origin"],
                        "destination": v["destination"],
                        "corridor": v["corridor"],
                        "latitude": round(v["current_lat"], 6),
                        "longitude": round(v["current_lng"], 6),
                        "altitude_meters": v["altitude_meters"],
                        "speed_km_h": v["speed_km_h"],
                        "heading_degrees": v["heading_degrees"],
                        "status": v["status"],
                        "eta_minutes": max(0, v["eta_minutes"] - int(v["progress_ratio"] * 20)),
                        "fuel_level_pct": v["fuel_level_pct"],
                        "battery_level_pct": v["battery_level_pct"],
                        "is_deviated": v["is_deviated"],
                        "timestamp": now_ts
                    }

                    # Broadcast to fleet and simulation channels
                    await self.broadcast_to_channel("fleet", telemetry_payload)
                    await self.broadcast_to_channel("simulation", telemetry_payload)

                    # If deviated, broadcast an instant alert
                    if v["is_deviated"]:
                        alert_payload = {
                            "type": "ROUTE_DEVIATION_ALERT",
                            "is_simulated": True,
                            "severity": "CRITICAL",
                            "vehicle_id": v["id"],
                            "message": f"Vehicle {v['id']} has deviated from planned route.",
                            "corridor": v["corridor"],
                            "current_lat": v["current_lat"],
                            "current_lng": v["current_lng"],
                            "timestamp": now_ts
                        }
                        await self.broadcast_to_channel("alerts", alert_payload)

            except asyncio.CancelledError:
                logger.info("Simulation background task cancelled.")
                break
            except Exception as e:
                logger.error(f"Error in simulation loop: {e}", exc_info=False)
                await asyncio.sleep(2.0)


ws_manager = ConnectionManager()

