import logging
import math
import time
from typing import Dict, Any, Optional
import httpx
from app.config import settings
from app.schemas.weather import WeatherForecastResponse, HourlyForecastPoint

logger = logging.getLogger(__name__)

# Weather code mappings (WMO standard used by Open-Meteo)
WMO_CODE_MAP = {
    0: "Clear Sky",
    1: "Mainly Clear",
    2: "Partly Cloudy",
    3: "Overcast",
    45: "Fog / Mist",
    48: "Depositing Rime Fog",
    51: "Light Drizzle",
    53: "Moderate Drizzle",
    55: "Dense Drizzle",
    61: "Slight Rain",
    63: "Moderate Continuous Rain",
    65: "Heavy Monsoon Torrential Rain",
    71: "Slight Snow Fall",
    73: "Moderate Snow Fall",
    75: "Heavy Snow Fall",
    80: "Slight Rain Showers",
    81: "Moderate Rain Showers",
    82: "Violent Cloudburst Rain Showers",
    95: "Thunderstorm with Mountain Gales",
    96: "Thunderstorm with Slight Hail",
    99: "Severe Thunderstorm with Heavy Hail"
}

# Regional presets for fallback telemetry in 8 North Eastern States
NER_STATE_FALLBACKS = {
    "ASSAM": {"temp": 28.5, "humidity": 82.0, "precip": 4.2, "vis": 7.5, "wind": 14.0, "code": 61},
    "ARUNACHAL_PRADESH": {"temp": 14.0, "humidity": 91.0, "precip": 18.5, "vis": 3.2, "wind": 28.0, "code": 65},
    "MEGHALAYA": {"temp": 18.2, "humidity": 94.0, "precip": 24.0, "vis": 2.0, "wind": 22.0, "code": 82},
    "MANIPUR": {"temp": 22.0, "humidity": 78.0, "precip": 6.0, "vis": 8.0, "wind": 11.0, "code": 61},
    "MIZORAM": {"temp": 21.5, "humidity": 80.0, "precip": 8.5, "vis": 6.5, "wind": 12.0, "code": 63},
    "NAGALAND": {"temp": 19.0, "humidity": 85.0, "precip": 12.0, "vis": 4.5, "wind": 16.0, "code": 63},
    "TRIPURA": {"temp": 29.0, "humidity": 75.0, "precip": 2.0, "vis": 9.0, "wind": 8.0, "code": 2},
    "SIKKIM": {"temp": 11.0, "humidity": 89.0, "precip": 15.0, "vis": 3.0, "wind": 25.0, "code": 65}
}


class WeatherService:
    """Service to fetch real-time and forecast weather data from Open-Meteo with fallback."""

    @staticmethod
    def _detect_state(lat: float, lng: float) -> str:
        if lat > 26.5 and lng > 91.5 and lat < 29.5 and lng < 97.5:
            return "ARUNACHAL_PRADESH"
        elif lat > 25.0 and lat < 26.2 and lng > 89.8 and lng < 92.8:
            return "MEGHALAYA"
        elif lat > 27.0 and lng < 89.0:
            return "SIKKIM"
        elif lat > 25.0 and lat < 27.0 and lng > 93.5 and lng < 95.5:
            return "NAGALAND"
        elif lat > 23.8 and lat < 25.7 and lng > 93.0 and lng < 94.8:
            return "MANIPUR"
        elif lat > 21.9 and lat < 24.5 and lng > 92.2 and lng < 93.5:
            return "MIZORAM"
        elif lat > 23.0 and lat < 24.6 and lng > 91.1 and lng < 92.4:
            return "TRIPURA"
        return "ASSAM"

    @classmethod
    async def fetch_weather_forecast(
        cls,
        latitude: float,
        longitude: float,
        location_name: Optional[str] = "NER Station"
    ) -> WeatherForecastResponse:
        """Calls Open-Meteo REST API or uses high-fidelity heuristic fallback if offline/failed."""
        detected_state = cls._detect_state(latitude, longitude)
        
        try:
            params = {
                "latitude": latitude,
                "longitude": longitude,
                "current": "temperature_2m,relative_humidity_2m,precipitation,rain,weather_code,cloud_cover,wind_speed_10m",
                "hourly": "temperature_2m,precipitation,rain,weather_code,wind_speed_10m",
                "timezone": "Asia/Kolkata",
                "forecast_days": 2
            }

            async with httpx.AsyncClient(timeout=4.0) as client:
                response = await client.get(settings.OPEN_METEO_BASE_URL, params=params)

                if response.status_code == 200:
                    data = response.json()
                    curr = data.get("current", {})
                    hourly = data.get("hourly", {})

                    temp = float(curr.get("temperature_2m", 22.0))
                    humidity = float(curr.get("relative_humidity_2m", 80.0))
                    precip = float(curr.get("precipitation", 0.0))
                    weather_code = int(curr.get("weather_code", 0))
                    cloud_cover = int(curr.get("cloud_cover", 50))
                    wind_speed = float(curr.get("wind_speed_10m", 10.0))

                    # Calculate visibility heuristically from humidity, precip and weather code
                    vis_km = max(1.0, round(10.0 - (humidity / 20.0) - (precip * 0.4), 1))
                    if weather_code in [45, 48]:
                        vis_km = 0.8

                    rain_intensity = "NONE"
                    if precip > 15.0:
                        rain_intensity = "TORRENTIAL_MONSOON"
                    elif precip > 7.5:
                        rain_intensity = "HEAVY"
                    elif precip > 2.5:
                        rain_intensity = "MODERATE"
                    elif precip > 0.0:
                        rain_intensity = "LIGHT"

                    is_monsoon = precip >= 10.0 or humidity >= 88.0
                    landslide_trigger = precip >= 12.0 or (precip >= 5.0 and humidity >= 85.0)

                    # Build hourly points
                    hourly_points = []
                    times = hourly.get("time", [])[:12]
                    temps = hourly.get("temperature_2m", [])[:12]
                    precips = hourly.get("precipitation", [])[:12]
                    codes = hourly.get("weather_code", [])[:12]
                    winds = hourly.get("wind_speed_10m", [])[:12]

                    for i in range(len(times)):
                        hourly_points.append(HourlyForecastPoint(
                            time_iso=times[i],
                            temperature_2m=float(temps[i]) if i < len(temps) else temp,
                            precipitation=float(precips[i]) if i < len(precips) else precip,
                            rain=float(precips[i]) if i < len(precips) else precip,
                            weathercode=int(codes[i]) if i < len(codes) else weather_code,
                            visibility=vis_km,
                            windspeed_10m=float(winds[i]) if i < len(winds) else wind_speed
                        ))

                    return WeatherForecastResponse(
                        latitude=latitude,
                        longitude=longitude,
                        location_name=location_name or f"Coords ({latitude:.2f}, {longitude:.2f})",
                        state=detected_state,
                        current_temperature_c=temp,
                        relative_humidity_pct=humidity,
                        precipitation_rate_mm_h=precip,
                        rain_intensity=rain_intensity,
                        wind_speed_km_h=wind_speed,
                        visibility_km=vis_km,
                        weather_condition=WMO_CODE_MAP.get(weather_code, "Cloudy with Rain"),
                        is_monsoon_risk=is_monsoon,
                        landslide_weather_trigger=landslide_trigger,
                        cloud_cover_pct=cloud_cover,
                        hourly_forecast=hourly_points,
                        data_source="Open-Meteo Live API"
                    )

        except Exception as e:
            logger.warning(f"Open-Meteo API unreachable or timed out ({e}). Activating regional fallback engine.")

        # Fallback Heuristic Generation
        fallback = NER_STATE_FALLBACKS.get(detected_state, NER_STATE_FALLBACKS["ASSAM"])
        weather_code = fallback["code"]
        precip = fallback["precip"]
        is_monsoon = precip > 10.0
        landslide_trigger = precip > 12.0

        hourly_points = []
        for hour in range(8):
            hourly_points.append(HourlyForecastPoint(
                time_iso=f"T+{hour}h",
                temperature_2m=fallback["temp"] - (hour * 0.4),
                precipitation=max(0.0, precip + (math.sin(hour) * 2.0)),
                rain=max(0.0, precip + (math.sin(hour) * 2.0)),
                weathercode=weather_code,
                visibility=fallback["vis"],
                windspeed_10m=fallback["wind"]
            ))

        return WeatherForecastResponse(
            latitude=latitude,
            longitude=longitude,
            location_name=location_name or f"Coords ({latitude:.2f}, {longitude:.2f})",
            state=detected_state,
            current_temperature_c=fallback["temp"],
            relative_humidity_pct=fallback["humidity"],
            precipitation_rate_mm_h=precip,
            rain_intensity="HEAVY_MONSOON" if precip > 10.0 else "MODERATE",
            wind_speed_km_h=fallback["wind"],
            visibility_km=fallback["vis"],
            weather_condition=WMO_CODE_MAP.get(weather_code, "Overcast Mountain Mist"),
            is_monsoon_risk=is_monsoon,
            landslide_weather_trigger=landslide_trigger,
            cloud_cover_pct=85,
            hourly_forecast=hourly_points,
            data_source="NER Regional Meteorological Fallback"
        )
