import logging
import time
import uuid
from typing import Optional, List
from sqlalchemy.orm import Session

from app.models.alert import Alert, AlertSeverity, AlertType, Notification
from app.models.incident import Incident, IncidentSeverity
from app.models.vehicle import Vehicle, VehicleStatus
from app.models.user import User
from app.services.websocket_manager import ws_manager
from app.services.risk_service import calculate_haversine_distance_km

logger = logging.getLogger(__name__)


class AlertEngine:
    """Core Intelligent Alert Engine that evaluates incidents, telemetry, and broadcasts over WebSockets."""

    @classmethod
    async def process_new_incident(
        cls,
        db: Session,
        incident: Incident
    ) -> Optional[Alert]:
        """Evaluates a newly created or updated incident and raises broadcast alerts if critical."""
        # Determine severity and alert type
        alert_sev = AlertSeverity.WARNING
        if incident.severity == IncidentSeverity.CRITICAL_BLOCKAGE:
            alert_sev = AlertSeverity.CRITICAL_EMERGENCY
        elif incident.severity == IncidentSeverity.HIGH:
            alert_sev = AlertSeverity.HIGH
        elif incident.severity == IncidentSeverity.MEDIUM:
            alert_sev = AlertSeverity.WARNING
        else:
            alert_sev = AlertSeverity.INFO

        alert_type = AlertType.ROAD_CONDITION_HAZARD
        inc_type_str = incident.type.value if hasattr(incident.type, 'value') else str(incident.type)
        if "LANDSLIDE" in inc_type_str or "MUDSLIDE" in inc_type_str:
            alert_type = AlertType.LANDSLIDE_BLOCKED
        elif "FLASH_FLOOD" in inc_type_str:
            alert_type = AlertType.FLASH_FLOOD_WARNING
        elif "BREAKDOWN" in inc_type_str:
            alert_type = AlertType.CONVOY_DELAY

        alert_id = f"ALT-{uuid.uuid4().hex[:8].upper()}"
        alert_title = f"{alert_sev.value}: {incident.title} at {incident.location_name}"
        alert_msg = (
            f"Road Blockage Alert: {incident.description}. Affected radius: {incident.affected_radius_km} km. "
            f"Expected clearance ETA: ~{incident.clearance_eta_hours} hours. Reported by {incident.reported_by}."
        )

        new_alert = Alert(
            id=alert_id,
            incident_id=incident.id,
            vehicle_id=None,
            title=alert_title,
            message=alert_msg,
            severity=alert_sev,
            alert_type=alert_type,
            affected_corridor_code=incident.corridor_code,
            latitude=incident.latitude,
            longitude=incident.longitude,
            radius_km=incident.affected_radius_km,
            is_active=True,
            is_broadcasted=True,
            broadcast_timestamp=int(time.time() * 1000)
        )

        db.add(new_alert)

        # Notify active users & drivers
        users = db.query(User).filter(User.is_active == True).limit(20).all()
        for u in users:
            notif = Notification(
                id=f"NOTIF-{uuid.uuid4().hex[:8].upper()}",
                user_id=u.id,
                title=alert_title,
                body=alert_msg,
                priority="HIGH" if alert_sev in [AlertSeverity.CRITICAL_EMERGENCY, AlertSeverity.HIGH] else "NORMAL",
                action_url=f"/incidents/{incident.id}"
            )
            db.add(notif)

        # Check if any vehicles are within hazard radius and update their status to DELAYED_RISK
        active_vehicles = db.query(Vehicle).all()
        affected_vehicles = []
        for veh in active_vehicles:
            dist = calculate_haversine_distance_km(
                veh.current_lat, veh.current_lng,
                incident.latitude, incident.longitude
            )
            if dist <= incident.affected_radius_km:
                if alert_sev == AlertSeverity.CRITICAL_EMERGENCY:
                    veh.status = VehicleStatus.DELAYED_RISK
                affected_vehicles.append(veh.vehicle_number)

        db.commit()
        db.refresh(new_alert)

        # Broadcast via WebSockets to 'alerts' and 'fleet' channels
        alert_payload = {
            "type": "NEW_CRITICAL_ALERT",
            "alert": {
                "id": new_alert.id,
                "title": new_alert.title,
                "message": new_alert.message,
                "severity": new_alert.severity.value,
                "alert_type": new_alert.alert_type.value,
                "corridor_code": new_alert.affected_corridor_code,
                "latitude": new_alert.latitude,
                "longitude": new_alert.longitude,
                "radius_km": new_alert.radius_km,
                "created_at": new_alert.created_at,
                "affected_vehicles": affected_vehicles
            }
        }

        await ws_manager.broadcast_to_channel("alerts", alert_payload)
        await ws_manager.broadcast_to_channel("fleet", alert_payload)
        logger.info(f"Broadcasted alert {alert_id} over WebSockets to fleet and operations center.")
        return new_alert

    @classmethod
    async def process_gps_telemetry(
        cls,
        db: Session,
        vehicle: Vehicle,
        is_panic_button: bool = False
    ) -> Optional[Alert]:
        """Evaluates vehicle telemetry for panic triggers, geofence breaches, or emergency halts."""
        if is_panic_button:
            vehicle.status = VehicleStatus.EMERGENCY_STOP
            alert_id = f"ALT-SOS-{uuid.uuid4().hex[:8].upper()}"
            alert = Alert(
                id=alert_id,
                vehicle_id=vehicle.id,
                title=f"EMERGENCY SOS: Driver Panic Triggered ({vehicle.vehicle_number})",
                message=f"SOS alarm active for vehicle {vehicle.vehicle_number} (Driver: {vehicle.driver_name}) at Lat: {vehicle.current_lat:.4f}, Lng: {vehicle.current_lng:.4f}, Alt: {vehicle.altitude_meters}m.",
                severity=AlertSeverity.CRITICAL_EMERGENCY,
                alert_type=AlertType.SOS_PANIC,
                affected_corridor_code=vehicle.active_corridor_code,
                latitude=vehicle.current_lat,
                longitude=vehicle.current_lng,
                radius_km=10.0,
                is_active=True,
                is_broadcasted=True,
                broadcast_timestamp=int(time.time() * 1000)
            )
            db.add(alert)
            db.commit()
            db.refresh(alert)

            payload = {
                "type": "SOS_PANIC_ALERT",
                "vehicle_id": vehicle.id,
                "vehicle_number": vehicle.vehicle_number,
                "driver_name": vehicle.driver_name,
                "latitude": vehicle.current_lat,
                "longitude": vehicle.current_lng,
                "message": alert.message,
                "timestamp": alert.created_at
            }
            await ws_manager.broadcast_all(payload)
            return alert

        return None
