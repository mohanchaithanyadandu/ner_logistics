import json
import time
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session

from app.models.route import Route, RoutePriority
from app.models.vehicle import VehicleType
from app.schemas.route import (
    RoutePlanRequest,
    RoutePlanResponse,
    AlternativeRoute,
    RiskFactorDetail,
    WaypointPoint
)
from app.services.risk_service import RiskEngineService, calculate_haversine_distance_km
from app.services.gemini_service import GeminiAIService


class RoutePlanningEngine:
    """
    Intelligent GIS Route Optimizer for Complex Himalayan and North East Indian Terrains.
    Evaluates candidate routes, balancing travel time vs. disruption risk, slope gradient,
    and live incident chokepoints.
    """

    # Topological multi-candidate highway graph for strategic NER corridors
    CORRIDORS_DB = {
        ("GHY", "TWG"): {
            "candidates": [
                {
                    "corridor_code": "NH13_GHY_TWG_PRIMARY",
                    "name": "NH-13: Guwahati - Tezpur - Bomdila - Sela Tunnel - Tawang",
                    "via_pass": "Sela Tunnel Pass (13,700 ft)",
                    "distance_km": 448.0,
                    "base_travel_time_hours": 13.5,
                    "max_altitude_m": 4170,
                    "max_gradient_pct": 11.2,
                    "terrain_type": "HIGH_ALTITUDE_GHAT",
                    "historical_risk_base": 28.0,
                    "waypoints": [
                        {"name": "Guwahati Hub (Beltola)", "lat": 26.1445, "lng": 91.7362, "altitude_m": 55},
                        {"name": "Tezpur Base Staging (NH-15)", "lat": 26.6338, "lng": 92.7926, "altitude_m": 72},
                        {"name": "Bhalukpong Border Checkgate", "lat": 27.0118, "lng": 92.6450, "altitude_m": 213},
                        {"name": "Bomdila Pass (7,350 ft)", "lat": 27.2645, "lng": 92.4241, "altitude_m": 2415},
                        {"name": "Dirang Valley Depot", "lat": 27.3592, "lng": 92.2384, "altitude_m": 1560},
                        {"name": "Sela Pass / Tunnel Summit", "lat": 27.5042, "lng": 92.1037, "altitude_m": 4170},
                        {"name": "Jaswant Garh Memorial", "lat": 27.5450, "lng": 91.9800, "altitude_m": 3050},
                        {"name": "Jang Falls Crossing", "lat": 27.5750, "lng": 91.8900, "altitude_m": 2100},
                        {"name": "Tawang Forward Logistics Base", "lat": 27.5861, "lng": 91.8594, "altitude_m": 3048}
                    ],
                    "elevation_profile": [
                        {"distance_km": 0, "elevation_m": 55, "name": "Guwahati"},
                        {"distance_km": 180, "elevation_m": 72, "name": "Tezpur"},
                        {"distance_km": 240, "elevation_m": 213, "name": "Bhalukpong"},
                        {"distance_km": 310, "elevation_m": 2415, "name": "Bomdila"},
                        {"distance_km": 350, "elevation_m": 1560, "name": "Dirang"},
                        {"distance_km": 395, "elevation_m": 4170, "name": "Sela Pass"},
                        {"distance_km": 448, "elevation_m": 3048, "name": "Tawang"}
                    ]
                },
                {
                    "corridor_code": "NH13_ORANG_KALAKTANG_ALT",
                    "name": "Bypass: Guwahati - Orang - Kalaktang - Rupa - Bomdila - Tawang",
                    "via_pass": "Kalaktang Valley Bypass",
                    "distance_km": 415.0,
                    "base_travel_time_hours": 12.8,
                    "max_altitude_m": 3048,
                    "max_gradient_pct": 9.5,
                    "terrain_type": "MID_ALTITUDE_VALLEY",
                    "historical_risk_base": 34.0,
                    "waypoints": [
                        {"name": "Guwahati Hub", "lat": 26.1445, "lng": 91.7362, "altitude_m": 55},
                        {"name": "Orang Junction", "lat": 26.5800, "lng": 92.3500, "altitude_m": 60},
                        {"name": "Kalaktang", "lat": 27.1100, "lng": 92.1500, "altitude_m": 1150},
                        {"name": "Rupa Depot", "lat": 27.2000, "lng": 92.3800, "altitude_m": 1600},
                        {"name": "Tawang Base", "lat": 27.5861, "lng": 91.8594, "altitude_m": 3048}
                    ],
                    "elevation_profile": [
                        {"distance_km": 0, "elevation_m": 55, "name": "Guwahati"},
                        {"distance_km": 140, "elevation_m": 60, "name": "Orang"},
                        {"distance_km": 260, "elevation_m": 1150, "name": "Kalaktang"},
                        {"distance_km": 320, "elevation_m": 1600, "name": "Rupa"},
                        {"distance_km": 415, "elevation_m": 3048, "name": "Tawang"}
                    ]
                },
                {
                    "corridor_code": "NH13_DARRANGA_BHUTAN_ALT",
                    "name": "International Transit: Guwahati - Darranga - Trashigang - Tawang",
                    "via_pass": "Eastern Bhutan Low-Land Corridor",
                    "distance_km": 520.0,
                    "base_travel_time_hours": 16.5,
                    "max_altitude_m": 2200,
                    "max_gradient_pct": 6.8,
                    "terrain_type": "LOW_SLOPE_TRANSIT",
                    "historical_risk_base": 20.0,
                    "waypoints": [
                        {"name": "Guwahati Hub", "lat": 26.1445, "lng": 91.7362, "altitude_m": 55},
                        {"name": "Samdrup Jongkhar", "lat": 26.8000, "lng": 91.5000, "altitude_m": 220},
                        {"name": "Trashigang Base", "lat": 27.3300, "lng": 91.5500, "altitude_m": 1200},
                        {"name": "Tawang Post", "lat": 27.5861, "lng": 91.8594, "altitude_m": 3048}
                    ],
                    "elevation_profile": [
                        {"distance_km": 0, "elevation_m": 55, "name": "Guwahati"},
                        {"distance_km": 110, "elevation_m": 220, "name": "Border Post"},
                        {"distance_km": 340, "elevation_m": 1200, "name": "Trashigang"},
                        {"distance_km": 520, "elevation_m": 3048, "name": "Tawang"}
                    ]
                }
            ]
        },
        ("DMV", "IMP"): {
            "candidates": [
                {
                    "corridor_code": "NH29_DMV_IMP_PRIMARY",
                    "name": "NH-29: Dimapur - Kohima - Senapati - Kangpokpi - Imphal Lifeline",
                    "via_pass": "Kohima Crest (4,738 ft)",
                    "distance_km": 215.0,
                    "base_travel_time_hours": 7.0,
                    "max_altitude_m": 1780,
                    "max_gradient_pct": 8.5,
                    "terrain_type": "HILLY_GHAT",
                    "historical_risk_base": 32.0,
                    "waypoints": [
                        {"name": "Dimapur Railhead Hub", "lat": 25.9090, "lng": 93.7270, "altitude_m": 145},
                        {"name": "Chumukedima Checkpoint", "lat": 25.7900, "lng": 93.7700, "altitude_m": 260},
                        {"name": "Phiphema Sinking Zone", "lat": 25.7500, "lng": 93.9500, "altitude_m": 890},
                        {"name": "Kohima Capital Hub", "lat": 25.6751, "lng": 94.1086, "altitude_m": 1444},
                        {"name": "Mao Gate Post", "lat": 25.5000, "lng": 94.1300, "altitude_m": 1780},
                        {"name": "Senapati Depot", "lat": 25.2600, "lng": 94.0200, "altitude_m": 1050},
                        {"name": "Kangpokpi Hub", "lat": 25.1400, "lng": 93.9700, "altitude_m": 990},
                        {"name": "Imphal Valley Base", "lat": 24.8170, "lng": 93.9368, "altitude_m": 786}
                    ],
                    "elevation_profile": [
                        {"distance_km": 0, "elevation_m": 145, "name": "Dimapur"},
                        {"distance_km": 74, "elevation_m": 1444, "name": "Kohima"},
                        {"distance_km": 110, "elevation_m": 1780, "name": "Mao Gate"},
                        {"distance_km": 160, "elevation_m": 1050, "name": "Senapati"},
                        {"distance_km": 215, "elevation_m": 786, "name": "Imphal"}
                    ]
                },
                {
                    "corridor_code": "NH37_SILCHAR_JIRIBAM_IMP_ALT",
                    "name": "NH-37: Silchar - Jiribam - Noney - Imphal Southern Arterial",
                    "via_pass": "Barak River Valley",
                    "distance_km": 222.0,
                    "base_travel_time_hours": 8.5,
                    "max_altitude_m": 786,
                    "max_gradient_pct": 6.5,
                    "terrain_type": "RIVER_VALLEY_FOOTHILL",
                    "historical_risk_base": 24.0,
                    "waypoints": [
                        {"name": "Silchar Depot", "lat": 24.8333, "lng": 92.7789, "altitude_m": 35},
                        {"name": "Jiribam Border", "lat": 24.8000, "lng": 93.1200, "altitude_m": 45},
                        {"name": "Noney Bridge", "lat": 24.8100, "lng": 93.6000, "altitude_m": 320},
                        {"name": "Imphal Hub", "lat": 24.8170, "lng": 93.9368, "altitude_m": 786}
                    ],
                    "elevation_profile": [
                        {"distance_km": 0, "elevation_m": 35, "name": "Silchar"},
                        {"distance_km": 50, "elevation_m": 45, "name": "Jiribam"},
                        {"distance_km": 150, "elevation_m": 320, "name": "Noney"},
                        {"distance_km": 222, "elevation_m": 786, "name": "Imphal"}
                    ]
                }
            ]
        },
        ("SHL", "SLR"): {
            "candidates": [
                {
                    "corridor_code": "NH6_SHL_SLR_PRIMARY",
                    "name": "NH-6: Shillong - Jowai - Ladrymbai - Sonapur Tunnel - Silchar",
                    "via_pass": "Sonapur Tunnel Gorge",
                    "distance_km": 218.0,
                    "base_travel_time_hours": 7.5,
                    "max_altitude_m": 1525,
                    "max_gradient_pct": 9.8,
                    "terrain_type": "PLATEAU_GHAT",
                    "historical_risk_base": 36.0,
                    "waypoints": [
                        {"name": "Shillong Upper Hub", "lat": 25.5788, "lng": 91.8933, "altitude_m": 1525},
                        {"name": "Jowai Jaintia Base", "lat": 25.4500, "lng": 92.2000, "altitude_m": 1380},
                        {"name": "Ladrymbai Coal Belt", "lat": 25.3200, "lng": 92.3500, "altitude_m": 1100},
                        {"name": "Sonapur Landslide Tunnel", "lat": 25.1000, "lng": 92.3800, "altitude_m": 450},
                        {"name": "Kalain Crossing", "lat": 24.9500, "lng": 92.5600, "altitude_m": 60},
                        {"name": "Silchar Logistics Terminal", "lat": 24.8333, "lng": 92.7789, "altitude_m": 35}
                    ],
                    "elevation_profile": [
                        {"distance_km": 0, "elevation_m": 1525, "name": "Shillong"},
                        {"distance_km": 64, "elevation_m": 1380, "name": "Jowai"},
                        {"distance_km": 140, "elevation_m": 450, "name": "Sonapur"},
                        {"distance_km": 218, "elevation_m": 35, "name": "Silchar"}
                    ]
                },
                {
                    "corridor_code": "NH6_UMRANGSO_HAFLONG_ALT",
                    "name": "Bypass: Shillong - Umrangso - Haflong - Silchar (Dima Hasao Bypass)",
                    "via_pass": "Haflong Valley",
                    "distance_km": 285.0,
                    "base_travel_time_hours": 9.8,
                    "max_altitude_m": 960,
                    "max_gradient_pct": 7.0,
                    "terrain_type": "HILL_VALLEY_BYPASS",
                    "historical_risk_base": 22.0,
                    "waypoints": [
                        {"name": "Shillong Hub", "lat": 25.5788, "lng": 91.8933, "altitude_m": 1525},
                        {"name": "Umrangso Reservoir", "lat": 25.5100, "lng": 92.7300, "altitude_m": 650},
                        {"name": "Haflong Pass", "lat": 25.1800, "lng": 93.0200, "altitude_m": 960},
                        {"name": "Silchar Terminal", "lat": 24.8333, "lng": 92.7789, "altitude_m": 35}
                    ],
                    "elevation_profile": [
                        {"distance_km": 0, "elevation_m": 1525, "name": "Shillong"},
                        {"distance_km": 110, "elevation_m": 650, "name": "Umrangso"},
                        {"distance_km": 200, "elevation_m": 960, "name": "Haflong"},
                        {"distance_km": 285, "elevation_m": 35, "name": "Silchar"}
                    ]
                }
            ]
        }
    }

    @classmethod
    def _normalize_key(cls, loc: str) -> str:
        loc = loc.strip().upper()
        if "GUW" in loc or "GHY" in loc or "ASSAM" in loc:
            return "GHY"
        if "TAW" in loc or "TWG" in loc or "BOMDILA" in loc:
            return "TWG"
        if "DIM" in loc or "DMV" in loc:
            return "DMV"
        if "IMP" in loc or "MANIPUR" in loc:
            return "IMP"
        if "SHI" in loc or "SHL" in loc or "MEGHALAYA" in loc:
            return "SHL"
        if "SIL" in loc or "SLR" in loc or "BARAK" in loc:
            return "SLR"
        return "GHY"

    @classmethod
    def calculate_route_metrics(
        cls,
        candidate: Dict[str, Any],
        risk_score_0_100: float,
        vehicle_type: VehicleType,
        cargo_weight_kg: float,
        priority: RoutePriority
    ) -> Dict[str, float]:
        """
        Calculates:
        - Travel time (hours)
        - Expected delay (hours)
        - Route score: composite optimization metric balancing travel time vs. disruption risk
        """
        base_time = candidate["base_travel_time_hours"]
        dist = candidate["distance_km"]

        # Vehicle Speed Multiplier
        speed_factor = 1.0
        if vehicle_type == VehicleType.HEAVY_MULTI_AXLE:
            speed_factor = 0.80
        elif vehicle_type == VehicleType.LIGHT_4X4 or priority == RoutePriority.MEDICAL_URGENT:
            speed_factor = 1.20
        elif vehicle_type == VehicleType.HAZMAT_TANKER:
            speed_factor = 0.75

        # Speed degradation on severe gradients
        if candidate["max_gradient_pct"] > 9.0 and cargo_weight_kg > 5000:
            speed_factor *= 0.85

        effective_travel_time = base_time / speed_factor

        # Expected delay calculation based on risk score (0-100)
        # Risk 0-30 -> negligible delay (0.0 - 0.5h)
        # Risk 31-60 -> moderate delay (0.5 - 2.0h)
        # Risk 61-80 -> severe delay (2.0 - 5.0h)
        # Risk 81-100 -> catastrophic delay (5.0 - 12.0h)
        if risk_score_0_100 <= 30.0:
            expected_delay_hours = (risk_score_0_100 / 30.0) * 0.5
        elif risk_score_0_100 <= 60.0:
            expected_delay_hours = 0.5 + ((risk_score_0_100 - 30.0) / 30.0) * 1.5
        elif risk_score_0_100 <= 80.0:
            expected_delay_hours = 2.0 + ((risk_score_0_100 - 60.0) / 20.0) * 3.0
        else:
            expected_delay_hours = 5.0 + ((risk_score_0_100 - 80.0) / 20.0) * 7.0

        total_predicted_duration = effective_travel_time + expected_delay_hours

        # Optimization Objective: Route Score (Lower is better)
        # Balances travel time vs risk. Priority modifies the weight tradeoff.
        if priority == RoutePriority.MEDICAL_URGENT:
            # Time & Reliability critical: high penalty for risk-induced delays
            w_time = 0.40
            w_risk = 0.40
            w_delay = 0.20
        elif priority == RoutePriority.DEFENSE_CRITICAL:
            # High risk avoidance
            w_time = 0.30
            w_risk = 0.50
            w_delay = 0.20
        else:
            # Standard logistics
            w_time = 0.45
            w_risk = 0.35
            w_delay = 0.20

        # Normalized components (scaled roughly 0-100)
        norm_time = min(100.0, (effective_travel_time / 20.0) * 100.0)
        norm_delay = min(100.0, (expected_delay_hours / 10.0) * 100.0)
        norm_risk = risk_score_0_100

        route_score = round(norm_time * w_time + norm_risk * w_risk + norm_delay * w_delay, 1)

        return {
            "travel_time_hours": round(effective_travel_time, 1),
            "expected_delay_hours": round(expected_delay_hours, 1),
            "total_predicted_duration": round(total_predicted_duration, 1),
            "route_score": route_score
        }

    @classmethod
    async def plan_route(
        cls,
        db: Session,
        request: RoutePlanRequest
    ) -> RoutePlanResponse:
        """
        Generates candidate routes, calculates distance, travel time, risk, expected delay,
        and route score for each, and selects the optimal route.
        """
        norm_orig = cls._normalize_key(request.origin)
        norm_dest = cls._normalize_key(request.destination)

        corridor_bundle = cls.CORRIDORS_DB.get((norm_orig, norm_dest)) or cls.CORRIDORS_DB.get((norm_dest, norm_orig))
        if not corridor_bundle:
            corridor_bundle = cls.CORRIDORS_DB[("GHY", "TWG")]

        candidates = corridor_bundle["candidates"]

        # Evaluate risk and metrics for each candidate route
        evaluated_candidates = []
        for cand in candidates:
            mid_wp = cand["waypoints"][len(cand["waypoints"]) // 2]
            
            # Compute live risk for candidate
            risk_resp = await RiskEngineService.compute_corridor_risk(
                db=db,
                corridor_code=cand["corridor_code"],
                lat=mid_wp["lat"],
                lng=mid_wp["lng"],
                vehicle_type=request.vehicle_type.value,
                cargo_weight_kg=request.cargo_weight_kg
            )

            metrics = cls.calculate_route_metrics(
                candidate=cand,
                risk_score_0_100=risk_resp.overall_risk_score,
                vehicle_type=request.vehicle_type,
                cargo_weight_kg=request.cargo_weight_kg,
                priority=request.priority
            )

            evaluated_candidates.append({
                "candidate": cand,
                "risk_response": risk_resp,
                "metrics": metrics
            })

        # Sort candidate routes by route_score (lowest composite score is optimal)
        evaluated_candidates.sort(key=lambda x: x["metrics"]["route_score"])

        best = evaluated_candidates[0]
        recommended_cand = best["candidate"]
        recommended_risk = best["risk_response"]
        recommended_metrics = best["metrics"]

        # Build Alternative Routes
        alternative_routes: List[AlternativeRoute] = []
        for item in evaluated_candidates[1:]:
            cand = item["candidate"]
            risk = item["risk_response"]
            met = item["metrics"]
            
            # Create clear trade-off summary
            time_diff = met["travel_time_hours"] - recommended_metrics["travel_time_hours"]
            risk_diff = risk.overall_risk_score - recommended_risk.overall_risk_score
            
            if risk_diff > 10:
                tradeoff = f"+{risk_diff:.0f} pts higher disruption risk than recommended route."
            elif time_diff > 0:
                tradeoff = f"{time_diff:.1f} hrs longer travel time; risk score {risk.overall_risk_score:.0f}/100."
            else:
                tradeoff = f"{abs(time_diff):.1f} hrs shorter base time but elevated hazard risk (+{risk_diff:.0f} pts)."

            alt_wp = [WaypointPoint(lat=w["lat"], lng=w["lng"], name=w.get("name"), altitude_m=w.get("altitude_m")) for w in cand["waypoints"]]
            
            alternative_routes.append(AlternativeRoute(
                corridor_code=cand["corridor_code"],
                name=cand["name"],
                via_pass=cand["via_pass"],
                distance_km=cand["distance_km"],
                eta_hours=met["travel_time_hours"],
                travel_time_hours=met["travel_time_hours"],
                risk_score=risk.overall_risk_score,
                expected_delay_hours=met["expected_delay_hours"],
                route_score=met["route_score"],
                risk_level=risk.risk_level.value,
                key_tradeoff=tradeoff,
                waypoints=alt_wp
            ))

        # Generate Grounded Gemini Explanation
        alt_dicts = [
            {
                "name": a.name,
                "distance_km": a.distance_km,
                "eta_hours": a.eta_hours,
                "risk_score": a.risk_score,
                "risk_level": a.risk_level,
                "expected_delay_hours": a.expected_delay_hours,
                "route_score": a.route_score,
                "key_tradeoff": a.key_tradeoff
            }
            for a in alternative_routes
        ]

        rec_dict = {
            "name": recommended_cand["name"],
            "distance_km": recommended_cand["distance_km"],
            "travel_time_hours": recommended_metrics["travel_time_hours"],
            "expected_delay_hours": recommended_metrics["expected_delay_hours"],
            "route_score": recommended_metrics["route_score"],
            "max_gradient_pct": recommended_cand["max_gradient_pct"],
            "max_altitude_m": recommended_cand["max_altitude_m"]
        }

        risk_dict = {
            "risk_score": recommended_risk.overall_risk_score,
            "risk_category": recommended_risk.risk_level.value,
            "primary_hazard": recommended_risk.primary_hazard,
            "recommended_action": recommended_risk.recommended_action
        }

        explanation = await GeminiAIService.explain_route_optimization(
            recommended_route=rec_dict,
            alternatives=alt_dicts,
            risk_data=risk_dict,
            priority=request.priority.value,
            cargo_type=request.cargo,
            cargo_weight_kg=request.cargo_weight_kg
        )

        # Convert Risk Factors
        risk_factors = []
        for factor in recommended_risk.factor_breakdown:
            risk_factors.append(RiskFactorDetail(
                category=factor.name,
                severity=factor.status,
                description=factor.impact_description,
                penalty_points=round(factor.score * factor.weight_pct / 100.0, 1)
            ))

        dep_time = request.departure_time or int(time.time() * 1000)
        waypoints_list = [
            WaypointPoint(lat=w["lat"], lng=w["lng"], name=w.get("name"), altitude_m=w.get("altitude_m"))
            for w in recommended_cand["waypoints"]
        ]

        return RoutePlanResponse(
            origin=request.origin,
            destination=request.destination,
            vehicle_type=request.vehicle_type,
            cargo=request.cargo,
            priority=request.priority,
            departure_time=dep_time,
            recommended_route={
                "corridor_code": recommended_cand["corridor_code"],
                "name": recommended_cand["name"],
                "via_pass": recommended_cand["via_pass"],
                "distance_km": recommended_cand["distance_km"],
                "max_altitude_m": recommended_cand["max_altitude_m"],
                "max_gradient_pct": recommended_cand["max_gradient_pct"],
                "terrain": recommended_cand["terrain_type"]
            },
            alternative_routes=alternative_routes,
            total_distance_km=recommended_cand["distance_km"],
            distance_km=recommended_cand["distance_km"],
            estimated_eta_hours=recommended_metrics["travel_time_hours"],
            travel_time_hours=recommended_metrics["travel_time_hours"],
            expected_delay_hours=recommended_metrics["expected_delay_hours"],
            route_score=recommended_metrics["route_score"],
            overall_risk_score=recommended_risk.overall_risk_score,
            risk_score=recommended_risk.overall_risk_score,
            risk_level=recommended_risk.risk_level.value,
            confidence_score=recommended_risk.confidence_score,
            risk_factors=risk_factors,
            route_explanation=explanation,
            recommended_action=recommended_risk.recommended_action,
            bro_clearance_status="GREEN - PASSABLE" if recommended_risk.overall_risk_score < 60.0 else ("YELLOW - ESCORT ONLY" if recommended_risk.overall_risk_score < 80.0 else "RED - HOLD AT DEPOT"),
            monsoon_advisory="Active Heavy Monsoon Surge Alert" if recommended_risk.flood_prob > 0.4 else "Routine Seasonal Flow",
            elevation_profile=recommended_cand["elevation_profile"],
            waypoints=waypoints_list
        )
