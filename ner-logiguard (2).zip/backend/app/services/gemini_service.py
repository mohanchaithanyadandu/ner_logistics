"""
Grounded Gemini AI Service for NER-LogiGuard
==============================================
Provides high-speed, grounded natural language intelligence for logistics dispatchers,
BRO clearance personnel, and high-altitude convoy drivers.

Core Tenets:
1. STRICT DATA GROUNDING: Prompts explicitly inject real sensor data, active incidents,
   weather metrics, and route evaluations. The LLM is strictly constrained from inventing numbers.
2. ROBUST ZERO-DEPENDENCY FALLBACK: If GEMINI_API_KEY is missing or the network call fails,
   a deterministic rule-based generator produces transparent, professional tactical intelligence.
3. Model: 'gemini-3.5-flash' for low latency and high context adherence.
"""

import json
import logging
import httpx
from typing import Dict, Any, List, Optional

from app.config import settings

logger = logging.getLogger(__name__)


class GeminiAIService:
    """Enterprise Gemini REST API client with guaranteed data-grounding and fallback resilience."""

    BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

    @classmethod
    def is_configured(cls) -> bool:
        return bool(settings.GEMINI_API_KEY and settings.GEMINI_API_KEY.strip())

    @classmethod
    async def generate_grounded_response(
        cls,
        system_instruction: str,
        user_prompt: str,
        structured_context: Dict[str, Any],
        fallback_generator: Optional[callable] = None
    ) -> str:
        """
        Sends grounded context + user prompt to Gemini REST API.
        If unavailable or fails, returns output from the fallback_generator.
        """
        if not cls.is_configured():
            logger.info("GEMINI_API_KEY not configured. Utilizing deterministic rule-based intelligence.")
            return fallback_generator(structured_context, user_prompt) if fallback_generator else cls._default_fallback(structured_context, user_prompt)

        model = getattr(settings, "GEMINI_MODEL", "gemini-3.5-flash")
        url = f"{cls.BASE_URL}/{model}:generateContent?key={settings.GEMINI_API_KEY}"

        # Build grounded prompt payload
        context_json = json.dumps(structured_context, indent=2, default=str)
        full_user_content = (
            f"--- VERIFIED APPLICATION CONTEXT (REAL SENSOR & SYSTEM DATA) ---\n"
            f"{context_json}\n"
            f"--- END VERIFIED CONTEXT ---\n\n"
            f"User Query / Task: {user_prompt}\n\n"
            f"MANDATORY INSTRUCTION: You must strictly base your entire answer on the verified application context above. "
            f"Do not hallucinate, invent, or assume any sensor values, incidents, or routes not present in the verified context."
        )

        payload = {
            "contents": [
                {
                    "role": "user",
                    "parts": [{"text": full_user_content}]
                }
            ],
            "systemInstruction": {
                "parts": [{"text": system_instruction}]
            },
            "generationConfig": {
                "temperature": 0.2,  # Low temperature for strict factual accuracy
                "topP": 0.9,
                "topK": 40,
                "maxOutputTokens": 800
            }
        }

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(
                    url,
                    json=payload,
                    headers={"Content-Type": "application/json"}
                )

                if response.status_code == 200:
                    data = response.json()
                    candidates = data.get("candidates", [])
                    if candidates:
                        parts = candidates[0].get("content", {}).get("parts", [])
                        if parts and "text" in parts[0]:
                            return parts[0]["text"].strip()
                
                logger.warning(f"Gemini API returned status {response.status_code}: {response.text}")
        except Exception as e:
            logger.error(f"Gemini API invocation error: {str(e)}. Switching to fallback generator.")

        # Seamless Fallback
        if fallback_generator:
            return fallback_generator(structured_context, user_prompt)
        return cls._default_fallback(structured_context, user_prompt)

    @classmethod
    def _default_fallback(cls, context: Dict[str, Any], prompt: str) -> str:
        return (
            f"NER-LogiGuard Tactical Advisory (Deterministic Grounded Mode):\n"
            f"Monitored Corridor Status: Operational with verified real-time safety thresholds.\n"
            f"Telemetry summary: {json.dumps(context, default=str)}"
        )


    # -------------------------------------------------------------
    # Specialized Domain Prompt Helpers
    # -------------------------------------------------------------

    @classmethod
    async def explain_route_optimization(
        cls,
        recommended_route: Dict[str, Any],
        alternatives: List[Dict[str, Any]],
        risk_data: Dict[str, Any],
        priority: str,
        cargo_type: str,
        cargo_weight_kg: float
    ) -> str:
        """Generates clear, tactical explanation comparing chosen route vs candidate alternatives."""
        system_instruction = (
            "You are the Chief Logistics AI Officer for the North Eastern Region Highway Grid (NER-LogiGuard). "
            "Explain in 2-3 concise paragraphs why the recommended route was selected over candidate alternatives. "
            "Highlight the balance between travel time, disruption risk, gradient load, and active roadway hazards. "
            "Use a professional, military/logistics dispatch tone (e.g. 'Route A is recommended because...'). "
            "NEVER invent coordinates or unlisted incidents."
        )

        context = {
            "recommended_route": recommended_route,
            "alternatives": alternatives,
            "risk_assessment": risk_data,
            "cargo": {
                "type": cargo_type,
                "weight_kg": cargo_weight_kg,
                "priority": priority
            }
        }

        def fallback_explain(ctx: Dict[str, Any], p: str) -> str:
            rec = ctx["recommended_route"]
            alts = ctx["alternatives"]
            risk = ctx["risk_assessment"]
            
            alt_comparison_str = ""
            if alts:
                best_alt = alts[0]
                alt_comparison_str = (
                    f"Compared to alternative '{best_alt.get('name')}' ({best_alt.get('distance_km')} km, "
                    f"ETA {best_alt.get('eta_hours')}h, Risk: {best_alt.get('risk_level', 'MODERATE')}), "
                    f"the primary path offers {best_alt.get('key_tradeoff', 'superior overall reliability')}."
                )

            return (
                f"Recommended corridor: {rec.get('name')} (Distance: {rec.get('distance_km')} km, "
                f"ETA: ~{rec.get('eta_hours', rec.get('distance_km', 400)/35.0):.1f} hours). "
                f"Evaluated Risk Index is {risk.get('risk_score', 25.0):.1f}/100 ({risk.get('risk_category', 'LOW')}) "
                f"under max gradient of {rec.get('max_gradient_pct', 8.0)}% with {cargo_weight_kg:.0f} kg payload. "
                f"{alt_comparison_str} "
                f"Action: {risk.get('recommended_action', 'Proceed with standard convoy spacing.')}"
            )

        return await cls.generate_grounded_response(
            system_instruction=system_instruction,
            user_prompt="Provide route selection rationale and safety briefing.",
            structured_context=context,
            fallback_generator=fallback_explain
        )
