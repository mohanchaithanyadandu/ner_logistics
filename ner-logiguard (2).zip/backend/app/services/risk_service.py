import math
import time
from typing import List, Dict, Any, Tuple, Optional
from sqlalchemy.orm import Session

from app.models.risk import RiskPrediction, RiskLevel
from app.models.incident import Incident, IncidentStatus, IncidentSeverity
from app.models.route import Route
from app.schemas.risk import RiskAssessmentResponse, RiskFactorBreakdown, RiskAssessmentRequest
from app.services.weather_service import WeatherService
from app.services.risk_engine import (
    RiskEngine,
    RiskEngineWeights,
    RiskInputData,
    RiskCategory,
    RoadCondition,
    RoadAccessibility,
    BridgeStatus,
    TrafficLevel,
    RainfallIntensity,
    risk_engine as global_risk_engine
)


def calculate_haversine_distance_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculates distance between two coordinates in kilometers using Haversine formula."""
    r = 6371.0
    d_lat = math.radians(lat2 - lat1)
    d_lon = math.radians(lon2 - lon1)
    a = (math.sin(d_lat / 2.0) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(d_lon / 2.0) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return r * c


class RiskEngineService:
    """Bridge service connecting database, live meteorological telemetry, and the Risk Intelligence Engine."""

    CORRIDOR_METADATA = {
        "NH13_GHY_TWG": {
            "name": "Guwahati - Tezpur - Bomdila - Tawang (NH-13 / Trans-Arunachal)",
            "elevation_m": 4170.0,
            "slope_gradient_pct": 11.2,
            "base_road_condition": RoadCondition.FAIR,
            "pass_name": "Sela Pass (13,700 ft)",
            "historical_incidents": 8,
            "state": "ARUNACHAL_PRADESH"
        },
        "NH29_DMV_KHM": {
            "name": "Dimapur - Kohima - Imphal Corridor (NH-29)",
            "elevation_m": 1444.0,
            "slope_gradient_pct": 8.5,
            "base_road_condition": RoadCondition.DEGRADED,
            "pass_name": "Kohima Ridge / Phiphema",
            "historical_incidents": 6,
            "state": "NAGALAND"
        },
        "NH6_SHL_SLR": {
            "name": "Shillong - Jowai - Silchar Lifeline (NH-6 Meghalaya Plateau)",
            "elevation_m": 1525.0,
            "slope_gradient_pct": 9.8,
            "base_road_condition": RoadCondition.DEGRADED,
            "pass_name": "Sonapur Tunnel Gorge",
            "historical_incidents": 9,
            "state": "MEGHALAYA"
        },
        "NH10_SLG_GNT": {
            "name": "Siliguri - Sevoke - Gangtok Highway (NH-10 Teesta Valley)",
            "elevation_m": 1650.0,
            "slope_gradient_pct": 10.5,
            "base_road_condition": RoadCondition.FAIR,
            "pass_name": "Teesta River Valley",
            "historical_incidents": 7,
            "state": "SIKKIM"
        },
        "NH54_SLR_AIZ": {
            "name": "Silchar - Vairengte - Aizawl Spine (NH-54 Mizoram)",
            "elevation_m": 1132.0,
            "slope_gradient_pct": 7.5,
            "base_road_condition": RoadCondition.GOOD,
            "pass_name": "Lushai Hills Ridge",
            "historical_incidents": 4,
            "state": "MIZORAM"
        }
    }

    @classmethod
    async def compute_corridor_risk(
        cls,
        db: Session,
        corridor_code: str,
        lat: float = 26.8,
        lng: float = 92.5,
        vehicle_type: str = "MEDIUM_CARGO_TRUCK",
        cargo_weight_kg: float = 4500.0,
        request_override: Optional[RiskAssessmentRequest] = None
    ) -> RiskAssessmentResponse:
        """Evaluates real-time risk index (0.0 to 100.0) combining weather, active incidents, terrain and cargo."""
        meta = cls.CORRIDOR_METADATA.get(corridor_code, {
            "name": f"Corridor {corridor_code}",
            "elevation_m": 1200.0,
            "slope_gradient_pct": 6.0,
            "base_road_condition": RoadCondition.GOOD,
            "pass_name": "NER Mountain Pass",
            "historical_incidents": 3,
            "state": "ASSAM"
        })

        # 1. Fetch live meteorological data
        weather = await WeatherService.fetch_weather_forecast(lat, lng, meta["name"])
        precip = weather.precipitation_rate_mm_h
        humidity = weather.relative_humidity_pct
        
        # Determine rainfall intensity category
        if precip <= 0.0:
            intensity = RainfallIntensity.NONE
        elif precip < 2.5:
            intensity = RainfallIntensity.LIGHT
        elif precip < 10.0:
            intensity = RainfallIntensity.MODERATE
        elif precip < 25.0:
            intensity = RainfallIntensity.HEAVY
        elif precip < 50.0:
            intensity = RainfallIntensity.TORRENTIAL
        else:
            intensity = RainfallIntensity.CLOUDBURST

        # 2. Check active incidents in database within 50km
        active_incidents_db = db.query(Incident).filter(
            Incident.status.in_([IncidentStatus.REPORTED, IncidentStatus.VERIFIED, IncidentStatus.CLEARANCE_IN_PROGRESS])
        ).all()

        active_incidents_payload = []
        for inc in active_incidents_db:
            dist = calculate_haversine_distance_km(lat, lng, inc.latitude, inc.longitude)
            if dist <= 50.0 or inc.corridor_code == corridor_code:
                active_incidents_payload.append({
                    "id": inc.id,
                    "title": inc.title,
                    "severity": inc.severity.value,
                    "type": inc.type.value,
                    "distance_km": dist,
                    "status": inc.status.value
                })

        # 3. Handle manual overrides if provided in request
        elevation = meta["elevation_m"]
        slope_grad = meta["slope_gradient_pct"]
        road_cond = meta["base_road_condition"]
        road_access = RoadAccessibility.ALL_VEHICLES_PASSABLE
        bridge_stat = BridgeStatus.OPEN_NORMAL
        traffic = TrafficLevel.CLEAR
        rainfall_val = precip
        rainfall_dur = 4.0 if precip > 0.5 else 0.0

        if request_override:
            if request_override.rainfall_mm_h is not None:
                rainfall_val = request_override.rainfall_mm_h
            if request_override.rainfall_duration_hours is not None:
                rainfall_dur = request_override.rainfall_duration_hours
            if request_override.elevation_m is not None:
                elevation = request_override.elevation_m
            if request_override.slope_gradient_pct is not None:
                slope_grad = request_override.slope_gradient_pct
            if request_override.road_condition:
                try:
                    road_cond = RoadCondition(request_override.road_condition.upper())
                except ValueError:
                    pass
            if request_override.road_accessibility:
                try:
                    road_access = RoadAccessibility(request_override.road_accessibility.upper())
                except ValueError:
                    pass
            if request_override.bridge_status:
                try:
                    bridge_stat = BridgeStatus(request_override.bridge_status.upper())
                except ValueError:
                    pass
            if request_override.traffic_level:
                try:
                    traffic = TrafficLevel(request_override.traffic_level.upper())
                except ValueError:
                    pass

        # 4. Build RiskInputData
        risk_input = RiskInputData(
            corridor_code=corridor_code,
            corridor_name=meta["name"],
            latitude=lat,
            longitude=lng,
            rainfall_mm_h=rainfall_val,
            rainfall_intensity=intensity,
            rainfall_duration_hours=rainfall_dur,
            relative_humidity_pct=humidity,
            elevation_m=elevation,
            slope_gradient_pct=slope_grad,
            road_condition=road_cond,
            road_accessibility=road_access,
            bridge_status=bridge_stat,
            traffic_level=traffic,
            historical_incidents_count=meta["historical_incidents"],
            active_incidents=active_incidents_payload,
            vehicle_type=vehicle_type,
            cargo_weight_kg=cargo_weight_kg,
            weather_station_distance_km=15.0,
            data_freshness_seconds=120,
            telemetry_sources_available=4
        )

        # 5. Evaluate via Risk Engine
        custom_weights = None
        if request_override and request_override.weights_override:
            custom_weights = RiskEngineWeights(**request_override.weights_override)

        engine = RiskEngine(weights=custom_weights) if custom_weights else global_risk_engine
        eval_result = engine.evaluate(risk_input)

        # 6. Map RiskCategory to RiskLevel
        risk_level_map = {
            RiskCategory.LOW: RiskLevel.LOW,
            RiskCategory.MODERATE: RiskLevel.MODERATE,
            RiskCategory.HIGH: RiskLevel.HIGH,
            RiskCategory.CRITICAL: RiskLevel.CRITICAL
        }
        mapped_risk_level = risk_level_map.get(eval_result.risk_category, RiskLevel.MODERATE)

        # Convert factors
        factors_resp = [
            RiskFactorBreakdown(
                name=f.factor_name,
                weight_pct=f.weight_pct,
                score=f.raw_score,
                weighted_score=f.weighted_score,
                status=f.status,
                impact_description=f.impact_description
            )
            for f in eval_result.factors
        ]

        landslide_prob = round(eval_result.sub_indices.get("landslide_index", 20.0) / 100.0, 2)
        flood_prob = round(eval_result.sub_indices.get("flood_index", 20.0) / 100.0, 2)
        road_block_prob = round(eval_result.sub_indices.get("infrastructure_index", 20.0) / 100.0, 2)

        return RiskAssessmentResponse(
            corridor_code=corridor_code,
            corridor_name=meta["name"],
            overall_risk_score=eval_result.risk_score,
            risk_level=mapped_risk_level,
            confidence_score=eval_result.confidence_score,
            confidence_level=eval_result.confidence_level,
            landslide_prob=landslide_prob,
            flood_prob=flood_prob,
            road_block_prob=road_block_prob,
            weather_severity_score=round(eval_result.sub_indices.get("rainfall_index", 0.0) / 100.0, 2),
            gradient_hazard_score=round(eval_result.sub_indices.get("terrain_index", 0.0) / 100.0, 2),
            primary_hazard=eval_result.primary_hazard,
            mitigation_recommendation=eval_result.recommended_action,
            recommended_action=eval_result.recommended_action,
            ai_rationale=eval_result.rationale,
            factor_breakdown=factors_resp,
            sub_indices=eval_result.sub_indices,
            calculation_timestamp=eval_result.calculated_at
        )
