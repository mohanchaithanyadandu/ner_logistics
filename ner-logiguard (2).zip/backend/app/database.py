import logging
import os
import re
from typing import Generator
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from app.config import settings

logger = logging.getLogger(__name__)

def create_db_engine():
    """Create SQLAlchemy engine with automatic support for Supabase PostgreSQL and SQLite."""
    raw_url = settings.DATABASE_URL.strip()
    
    # Normalize postgres:// to postgresql://
    if raw_url.startswith("postgres://"):
        raw_url = raw_url.replace("postgres://", "postgresql://", 1)

    if raw_url.startswith("sqlite"):
        logger.info("Using SQLite local database: %s", raw_url)
        return create_engine(
            raw_url,
            connect_args={"check_same_thread": False},
            pool_pre_ping=True
        )
    else:
        # Mask password in logs
        masked_url = re.sub(r":([^:@]+)@", ":****@", raw_url)
        logger.info("Connecting to PostgreSQL database at: %s", masked_url)
        
        connect_args = {}
        # Ensure SSL for Supabase, Neon, Render, or any remote cloud PostgreSQL
        if "supabase" in raw_url or "render" in raw_url or "neon.tech" in raw_url or "sslmode=require" in raw_url:
            connect_args["sslmode"] = "require"

        return create_engine(
            raw_url,
            pool_size=10,
            max_overflow=15,
            pool_pre_ping=True,
            pool_recycle=300,
            connect_args=connect_args
        )

engine = create_db_engine()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db() -> Generator[Session, None, None]:
    """Dependency for obtaining a database session per request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Create all database tables and indexes."""
    try:
        logger.info("Initializing database tables...")
        Base.metadata.create_all(bind=engine)
        logger.info("Database tables initialized successfully.")
    except Exception as e:
        logger.error(f"Error creating database tables: {e}")
        # If remote PostgreSQL fails, provide helpful Supabase guidance in logs
        if "supabase" in settings.DATABASE_URL.lower():
            logger.error(
                "Supabase Connection Tip: Make sure you use the Connection Pooling URI (Port 6543) "
                "or Direct Connection URI (Port 5432) with sslmode=require from your Supabase Project Settings."
            )
        raise
