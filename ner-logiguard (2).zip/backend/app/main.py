import json
import logging
import os
import time
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.database import init_db, SessionLocal
from app.initial_data import seed_database
from app.api.v1.api import api_router
from app.services.websocket_manager import ws_manager

# Configure structured logging
logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] [%(name)s]: %(message)s"
)
logger = logging.getLogger("ner_logiguard_backend")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup and shutdown event lifecycle."""
    logger.info("Initializing SIH26002 NER LogiGuard Backend Engine...")
    
    # 1. Initialize SQLite/PostgreSQL Database Tables
    try:
        init_db()
        logger.info("Database schema synchronized successfully.")
        
        # 2. Seed initial baseline users, corridors, vehicles, and active incidents
        db = SessionLocal()
        try:
            seed_database(db)
            logger.info("Database baseline seed verified.")
        finally:
            db.close()
    except Exception as e:
        logger.error(f"Database initialization error: {e}", exc_info=True)

    # 3. Start background telemetry simulation loop
    ws_manager.start_simulation_loop()

    yield

    logger.info("Shutting down NER LogiGuard backend services.")



app = FastAPI(
    title=settings.PROJECT_NAME,
    description="""
# NER LogiGuard — High-Altitude & Mountain Logistics Intelligence Backend

Comprehensive backend for North East India logistics corridor tracking, landslide risk prediction, dynamic route planning, and offline field hazard synchronization.

### Key API Capabilities:
- **Authentication & Roles**: Admin, Logistics Operator, Field Officer, Driver (JWT + Role-Based Access Control)
- **Route Planning & Multi-Criteria Optimizer**: A* GIS routing with gradient, elevation, weather, and incident penalties
- **Fleet Telemetry & GPS**: Real-time position tracking, emergency panic alarm handling
- **Incidents & Road Blockages**: Landslides, mudslides, flash floods with affected radius and clearance ETA
- **Offline Field Reports Sync**: Idempotent batch upload from Android Room SQLite offline caches
- **Weather & Meteorological Engine**: Open-Meteo live sync with 8-state climatological fallback
- **Multi-Factor Risk Engine**: Composite risk scoring (0.0 to 1.0) for mountain passes
- **Real-Time WebSockets**: Live broadcast channels for fleet telemetry, alerts, and incident updates
    """,
    version=settings.VERSION,
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# Cross-Origin Resource Sharing (CORS) Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Middleware to track request processing time and log API access."""
    start_time = time.time()
    response = await call_next(request)
    process_time = (time.time() - start_time) * 1000
    response.headers["X-Process-Time-Ms"] = f"{process_time:.2f}"
    return response


# Mount API V1 Router
app.include_router(api_router, prefix=settings.API_V1_STR)

# Mount PWA Static Files
static_pwa_dir = os.path.join(os.path.dirname(__file__), "static", "pwa")
if os.path.exists(static_pwa_dir):
    app.mount("/pwa", StaticFiles(directory=static_pwa_dir, html=True), name="pwa")
    app.mount("/static/pwa", StaticFiles(directory=static_pwa_dir, html=True), name="static_pwa")


@app.get("/field-officer", tags=["PWA"])
@app.get("/field-officer/", tags=["PWA"])
async def field_officer_terminal():
    """Serves the offline-first Field Officer Progressive Web App."""
    index_file = os.path.join(static_pwa_dir, "index.html")
    if os.path.exists(index_file):
        return FileResponse(index_file, media_type="text/html")
    return RedirectResponse(url="/pwa/index.html")


# Root and Health Check Endpoints
@app.get("/", tags=["Health"])
async def root():
    return {
        "project": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "status": "OPERATIONAL",
        "docs_url": "/docs",
        "redoc_url": "/redoc",
        "api_v1": settings.API_V1_STR,
        "websocket_endpoint": "/ws/{channel}",
        "channels": ["fleet", "alerts", "incidents", "field_reports", "weather"]
    }


@app.get("/health", tags=["Health"])
async def health_check():
    return {
        "status": "healthy",
        "timestamp": int(time.time() * 1000),
        "database": "connected",
        "websocket_connections": ws_manager.active_connections_count
    }


# Centralized WebSocket Endpoint with Channels
@app.websocket("/ws/{channel}")
async def websocket_endpoint(websocket: WebSocket, channel: str):
    """
    Subscribes client to real-time event channels:
    - `fleet`: Live GPS pings, speed, heading, vehicle status updates
    - `simulation`: Demo simulated vehicle movements and corridor deviations
    - `alerts`: Critical landslide blockages, emergency SOS panic alarms
    - `incidents`: Newly reported/verified road hazards and clearance updates
    - `field_reports`: Field officer submissions and offline sync broadcasts
    - `weather`: Precipitation alerts and mountain pass warnings
    """
    valid_channels = {"fleet", "simulation", "alerts", "incidents", "field_reports", "weather"}
    if channel not in valid_channels:
        await websocket.close(code=4000, reason=f"Invalid channel. Must be one of {valid_channels}")
        return

    await ws_manager.connect(websocket, channel=channel)
    logger.info(f"WebSocket client connected on channel '{channel}'. Total: {ws_manager.active_connections_count}")
    
    # Send welcome packet
    try:
        await websocket.send_json({
            "type": "SUBSCRIPTION_CONFIRMED",
            "channel": channel,
            "connected_at": int(time.time() * 1000),
            "message": f"Successfully subscribed to real-time '{channel}' channel stream."
        })
        
        while True:
            # Handle incoming client messages asynchronously without blocking
            data = await websocket.receive_text()
            if data == "ping":
                await websocket.send_text("pong")
                continue

            try:
                msg_json = json.loads(data)
                cmd = msg_json.get("command") or msg_json.get("action") or msg_json.get("type")
                
                if cmd == "START_SIMULATION":
                    ws_manager.resume_simulation()
                    await websocket.send_json({"type": "SIM_STATUS", "status": "RUNNING"})
                elif cmd == "PAUSE_SIMULATION":
                    ws_manager.pause_simulation()
                    await websocket.send_json({"type": "SIM_STATUS", "status": "PAUSED"})
                elif cmd == "RESET_SIMULATION":
                    ws_manager.reset_simulation()
                    await websocket.send_json({"type": "SIM_STATUS", "status": "RESET"})
                elif cmd == "DEVIATE_VEHICLE":
                    veh_id = msg_json.get("vehicle_id", "V-102")
                    ws_manager.trigger_deviation(veh_id)
                    await websocket.send_json({"type": "DEVIATION_TRIGGERED", "vehicle_id": veh_id})
                elif cmd == "CLEAR_DEVIATION":
                    veh_id = msg_json.get("vehicle_id", "V-102")
                    ws_manager.clear_deviation(veh_id)
                    await websocket.send_json({"type": "DEVIATION_CLEARED", "vehicle_id": veh_id})
                elif cmd in ("VEHICLE_POSITION_UPDATE", "GPS_PING", "TELEMETRY"):
                    # Broadcast incoming live telemetry from hardware / GPS devices
                    await ws_manager.broadcast_to_channel("fleet", msg_json)
                    await websocket.send_json({"type": "TELEMETRY_ACK", "status": "PROCESSED"})
                else:
                    # Echo standard acknowledge
                    await websocket.send_json({
                        "type": "CLIENT_ACK",
                        "channel": channel,
                        "received": msg_json
                    })
            except json.JSONDecodeError:
                await websocket.send_json({
                    "type": "CLIENT_ACK",
                    "channel": channel,
                    "received": data
                })
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket, channel=channel)
        logger.info(f"WebSocket client disconnected from channel '{channel}'")
    except Exception as e:
        logger.warning(f"WebSocket error on channel '{channel}': {e}")
        ws_manager.disconnect(websocket, channel=channel)


@app.websocket("/ws")
@app.websocket("/fleet/gps")
async def websocket_default_endpoint(websocket: WebSocket):
    """Default WebSocket endpoint routing to the 'fleet' channel."""
    await websocket_endpoint(websocket, channel="fleet")

