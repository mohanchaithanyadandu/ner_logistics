/**
 * NER LogiGuard - Field Officer PWA Logic
 * Implements robust offline-first caching, IndexedDB persistence, auto-sync, and 4-state network indicators.
 */

// Application State
const AppState = {
  isOnline: navigator.onLine,
  isForcedOffline: false,
  currentStatus: navigator.onLine ? 'ONLINE' : 'OFFLINE', // ONLINE | OFFLINE | SYNCING | SYNC COMPLETE
  selectedSeverity: 'MODERATE',
  currentGps: {
    lat: 25.6841,
    lng: 92.2154,
    altitude: 780,
    accuracy: 4.5
  },
  currentPhotos: []
};

// DOM Elements
const elements = {
  statusPill: document.getElementById('status-pill'),
  statusText: document.getElementById('status-text'),
  offlineBanner: document.getElementById('offline-banner'),
  pendingCountBanner: document.getElementById('pending-count-banner'),
  reportForm: document.getElementById('report-form'),
  pendingList: document.getElementById('pending-list'),
  syncedList: document.getElementById('synced-list'),
  pendingCountBadge: document.getElementById('pending-count-badge'),
  syncedCountBadge: document.getElementById('synced-count-badge'),
  gpsCoordsDisplay: document.getElementById('gps-coords-display'),
  refreshGpsBtn: document.getElementById('refresh-gps-btn'),
  photoInput: document.getElementById('photo-input'),
  photoPreviewGrid: document.getElementById('photo-preview-grid'),
  toggleOfflineBtn: document.getElementById('toggle-offline-btn'),
  manualSyncBtn: document.getElementById('manual-sync-btn'),
  formFeedback: document.getElementById('form-feedback')
};

// Initialize Application
window.addEventListener('DOMContentLoaded', async () => {
  registerServiceWorker();
  initNetworkListeners();
  initFormControls();
  refreshGeolocation();
  await refreshReportLists();

  // Check if we start with pending items while online
  if (isActuallyOnline()) {
    triggerAutoSync();
  }
});

// Register Service Worker for PWA Shell Caching
function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js')
      .then((reg) => {
        console.log('[PWA] Service Worker registered successfully:', reg.scope);
      })
      .catch((err) => {
        console.warn('[PWA] Service Worker registration failed:', err);
      });
  }
}

// Network Connectivity & 4-State Indicator Management
function initNetworkListeners() {
  window.addEventListener('online', () => {
    AppState.isOnline = true;
    if (!AppState.isForcedOffline) {
      updateStatusIndicator('ONLINE');
      triggerAutoSync();
    }
  });

  window.addEventListener('offline', () => {
    AppState.isOnline = false;
    updateStatusIndicator('OFFLINE');
  });

  elements.toggleOfflineBtn.addEventListener('click', () => {
    AppState.isForcedOffline = !AppState.isForcedOffline;
    if (AppState.isForcedOffline) {
      elements.toggleOfflineBtn.innerText = '⚡ Disable Offline Simulation';
      elements.toggleOfflineBtn.classList.add('btn-danger');
      updateStatusIndicator('OFFLINE');
    } else {
      elements.toggleOfflineBtn.innerText = '🛰️ Simulate Offline Mesh';
      elements.toggleOfflineBtn.classList.remove('btn-danger');
      const online = navigator.onLine;
      updateStatusIndicator(online ? 'ONLINE' : 'OFFLINE');
      if (online) triggerAutoSync();
    }
  });

  elements.manualSyncBtn.addEventListener('click', () => {
    if (!isActuallyOnline()) {
      showFeedback('Cannot sync: Terminal is currently OFFLINE.', 'warning');
      return;
    }
    triggerAutoSync(true);
  });
}

function isActuallyOnline() {
  return navigator.onLine && !AppState.isForcedOffline;
}

function updateStatusIndicator(status) {
  AppState.currentStatus = status;
  elements.statusPill.className = 'status-pill ' + status.toLowerCase().replace(' ', '-');
  elements.statusText.innerText = status;

  if (status === 'OFFLINE') {
    elements.offlineBanner.classList.remove('hidden');
  } else {
    elements.offlineBanner.classList.add('hidden');
  }
}

// Geolocation Handling
function refreshGeolocation() {
  if ('geolocation' in navigator) {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        AppState.currentGps = {
          lat: parseFloat(pos.coords.latitude.toFixed(6)),
          lng: parseFloat(pos.coords.longitude.toFixed(6)),
          altitude: Math.round(pos.coords.altitude || 780),
          accuracy: Math.round(pos.coords.accuracy || 5)
        };
        renderGpsDisplay();
      },
      (err) => {
        console.log('[GPS] Using high-precision mountain corridor reference:', err.message);
        renderGpsDisplay();
      },
      { timeout: 5000, enableHighAccuracy: true }
    );
  } else {
    renderGpsDisplay();
  }
}

function renderGpsDisplay() {
  elements.gpsCoordsDisplay.innerText = 
    `${AppState.currentGps.lat}° N, ${AppState.currentGps.lng}° E (Alt: ${AppState.currentGps.altitude}m • Acc: ±${AppState.currentGps.accuracy}m)`;
}

// Form Controls & Photo Metadata Extraction
function initFormControls() {
  elements.refreshGpsBtn.addEventListener('click', () => {
    refreshGeolocation();
    showFeedback('GPS Coordinates updated via satellite lock.', 'info');
  });

  // Severity Buttons
  document.querySelectorAll('.severity-btn').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.severity-btn').forEach(b => b.classList.remove('active'));
      const sev = e.currentTarget.dataset.severity;
      AppState.selectedSeverity = sev;
      e.currentTarget.classList.add('active', sev.toLowerCase());
    });
  });

  // Photo Input & Metadata
  elements.photoInput.addEventListener('change', handlePhotoUpload);

  // Form Submit
  elements.reportForm.addEventListener('submit', handleFormSubmit);
}

function handlePhotoUpload(e) {
  const files = Array.from(e.target.files);
  files.forEach((file) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const meta = {
        name: file.name,
        size_kb: Math.round(file.size / 1024),
        type: file.type || 'image/jpeg',
        last_modified: file.lastModified ? new Date(file.lastModified).toISOString() : new Date().toISOString(),
        thumbnail_base64: event.target.result
      };
      AppState.currentPhotos.push(meta);
      renderPhotoPreviews();
    };
    reader.readAsDataURL(file);
  });
}

function renderPhotoPreviews() {
  elements.photoPreviewGrid.innerHTML = '';
  AppState.currentPhotos.forEach((photo, index) => {
    const card = document.createElement('div');
    card.className = 'photo-card';
    card.innerHTML = `
      <img src="${photo.thumbnail_base64}" alt="Photo ${index + 1}" />
      <div class="photo-meta-text"><strong>${photo.name}</strong></div>
      <div class="photo-meta-text">${photo.size_kb} KB • ${photo.type.split('/')[1]?.toUpperCase()}</div>
      <button type="button" class="btn btn-danger" style="padding: 2px 6px; font-size: 0.65rem; margin-top: 4px; width: 100%;" onclick="removePhoto(${index})">Remove</button>
    `;
    elements.photoPreviewGrid.appendChild(card);
  });
}

window.removePhoto = (index) => {
  AppState.currentPhotos.splice(index, 1);
  renderPhotoPreviews();
};

// Form Submission (Offline-First to IndexedDB)
async function handleFormSubmit(e) {
  e.preventDefault();

  const officerName = document.getElementById('officer-name').value.trim() || 'Field Officer';
  const roadName = document.getElementById('road-name').value.trim() || 'NH-29 Corridor';
  const stateVal = document.getElementById('state-select').value;
  const incidentType = document.getElementById('incident-type').value;
  const blockagePct = parseInt(document.getElementById('blockage-pct').value, 10) || 50;
  const clearanceHours = parseFloat(document.getElementById('clearance-hours').value) || 3.0;
  const description = document.getElementById('description').value.trim();

  if (!description) {
    showFeedback('Please provide hazard observation notes.', 'warning');
    return;
  }

  const reportPayload = {
    local_id: 'LOC-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase(),
    officer_name: officerName,
    incident_type: incidentType,
    severity: AppState.selectedSeverity,
    road_name: roadName,
    state: stateVal,
    road_blockage_pct: blockagePct,
    clearance_eta_hours: clearanceHours,
    description: description,
    latitude: AppState.currentGps.lat,
    longitude: AppState.currentGps.lng,
    altitude_meters: AppState.currentGps.altitude,
    photo_metadata: AppState.currentPhotos.length > 0 ? AppState.currentPhotos : null,
    timestamp: Date.now()
  };

  try {
    // 1. Always store locally in IndexedDB first (Guaranteed zero data loss)
    const savedRecord = await window.NER_DB.savePendingReport(reportPayload);
    console.log('[OfflineStore] Report safely saved in IndexedDB:', savedRecord.local_id);

    // Reset Form
    elements.reportForm.reset();
    AppState.currentPhotos = [];
    renderPhotoPreviews();
    document.getElementById('blockage-pct-val').innerText = '50%';

    // 2. Check connectivity status and display clear message
    if (isActuallyOnline()) {
      showFeedback(`Report saved locally [${savedRecord.local_id}] — Initiating live sync...`, 'info');
      await refreshReportLists();
      await triggerAutoSync();
    } else {
      // Offline: Explicitly state saved locally & pending
      showFeedback(`⚡ OFFLINE: Report [${savedRecord.local_id}] saved locally in IndexedDB (Pending synchronization).`, 'warning');
      await refreshReportLists();
    }
  } catch (err) {
    console.error('Error saving report:', err);
    showFeedback('Failed to write to local storage: ' + err.message, 'danger');
  }
}

// Synchronize Pending Reports with Backend API
async function triggerAutoSync(isManual = false) {
  if (!isActuallyOnline()) {
    if (isManual) showFeedback('Cannot sync while terminal is offline.', 'warning');
    return;
  }

  const pendingReports = await window.NER_DB.getPendingReports();
  if (pendingReports.length === 0) {
    if (isManual) showFeedback('All field reports are already fully synchronized.', 'info');
    updateStatusIndicator('ONLINE');
    return;
  }

  updateStatusIndicator('SYNCING');
  console.log(`[Sync] Starting synchronization of ${pendingReports.length} pending reports...`);

  try {
    // Prepare batch sync payload matching FastAPI schema
    const batchPayload = {
      client_device_id: 'PWA-FO-' + (localStorage.getItem('ner_device_uuid') || generateDeviceId()),
      reports: pendingReports.map((r) => ({
        local_id: r.local_id,
        officer_name: r.officer_name,
        latitude: r.latitude,
        longitude: r.longitude,
        altitude_meters: r.altitude_meters,
        road_name: r.road_name,
        terrain_type: 'STEEP_SLOPE',
        incident_type: r.incident_type,
        severity: r.severity,
        description: r.description,
        is_offline_origin: true,
        photo_metadata_json: r.photo_metadata ? JSON.stringify(r.photo_metadata) : null
      }))
    };

    const syncEndpoint = window.NER_CONFIG ? window.NER_CONFIG.getEndpointUrl('/api/v1/field-reports/batch-sync') : '/api/v1/field-reports/batch-sync';
    const response = await fetch(syncEndpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(batchPayload)
    });

    if (response.ok) {
      const result = await response.json();
      console.log('[Sync] Batch sync success:', result);

      // Idempotently mark synced in IndexedDB
      await window.NER_DB.markReportsSynced(result.synced_local_ids, result.server_assigned_ids);

      updateStatusIndicator('SYNC COMPLETE');
      showFeedback(`✓ SYNC COMPLETE: ${result.synced_count} reports synchronized with Command Center!`, 'success');

      // Revert status to ONLINE after 3 seconds
      setTimeout(() => {
        if (isActuallyOnline() && AppState.currentStatus === 'SYNC COMPLETE') {
          updateStatusIndicator('ONLINE');
        }
      }, 3500);

      await refreshReportLists();
    } else {
      throw new Error(`Server returned HTTP ${response.status}`);
    }
  } catch (err) {
    console.warn('[Sync] Sync failed, preserving pending queue:', err.message);
    updateStatusIndicator(isActuallyOnline() ? 'ONLINE' : 'OFFLINE');
    showFeedback(`Sync delayed (${err.message}). Reports remain safe in local IndexedDB.`, 'warning');
  }
}

function generateDeviceId() {
  const id = 'DEV-' + Math.random().toString(36).substring(2, 9).toUpperCase();
  localStorage.setItem('ner_device_uuid', id);
  return id;
}

// Refresh UI Report Lists from IndexedDB
async function refreshReportLists() {
  const pending = await window.NER_DB.getPendingReports();
  const synced = await window.NER_DB.getSyncedReports();

  elements.pendingCountBadge.innerText = pending.length;
  elements.syncedCountBadge.innerText = synced.length;
  elements.pendingCountBanner.innerText = pending.length;

  // Render Pending List
  if (pending.length === 0) {
    elements.pendingList.innerHTML = '<div class="empty-state">No pending offline reports. All submissions are synced.</div>';
  } else {
    elements.pendingList.innerHTML = pending.map((rep) => `
      <div class="report-item pending">
        <div class="report-header">
          <div class="report-title">${escapeHtml(rep.incident_type)} • ${escapeHtml(rep.road_name)}</div>
          <span class="badge-tag saved-locally">Saved Locally (Pending)</span>
        </div>
        <div class="report-details">${escapeHtml(rep.description)}</div>
        <div class="report-meta">
          <span>🆔 ${rep.local_id}</span>
          <span>⚠️ Severity: <strong>${rep.severity}</strong></span>
          <span>📍 ${rep.latitude}, ${rep.longitude}</span>
          <span>🕒 ${new Date(rep.timestamp).toLocaleTimeString()}</span>
          ${rep.photo_metadata ? `<span>📷 ${rep.photo_metadata.length} Photos</span>` : ''}
        </div>
      </div>
    `).join('');
  }

  // Render Synced List
  if (synced.length === 0) {
    elements.syncedList.innerHTML = '<div class="empty-state">No synchronized reports archived yet.</div>';
  } else {
    elements.syncedList.innerHTML = synced.slice(-10).reverse().map((rep) => `
      <div class="report-item synced">
        <div class="report-header">
          <div class="report-title">${escapeHtml(rep.incident_type)} • ${escapeHtml(rep.road_name)}</div>
          <span class="badge-tag synced-tag">✓ Synchronized</span>
        </div>
        <div class="report-details">${escapeHtml(rep.description)}</div>
        <div class="report-meta">
          <span>🖥️ Server ID: <strong>${rep.server_id || 'FR-SYNC'}</strong></span>
          <span>🆔 Local: ${rep.local_id}</span>
          <span>📍 ${rep.latitude}, ${rep.longitude}</span>
          <span>🕒 Synced: ${rep.synced_at_iso ? new Date(rep.synced_at_iso).toLocaleTimeString() : 'Recent'}</span>
        </div>
      </div>
    `).join('');
  }
}

// User Feedback Notification
function showFeedback(msg, type = 'info') {
  elements.formFeedback.innerText = msg;
  elements.formFeedback.style.display = 'block';
  elements.formFeedback.style.color = type === 'warning' ? 'var(--amber-warning)' :
                                      type === 'danger' ? 'var(--red-offline)' :
                                      type === 'success' ? 'var(--green-online)' : 'var(--cyan-accent)';
  
  setTimeout(() => {
    elements.formFeedback.style.display = 'none';
  }, 5000);
}

function escapeHtml(text) {
  if (!text) return '';
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
