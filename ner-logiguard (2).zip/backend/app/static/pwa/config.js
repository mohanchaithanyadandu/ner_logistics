/**
 * NER LogiGuard - PWA Client Configuration
 * Supports decoupled deployment (Vercel Frontend + Render/Railway/Fly.io Backend + Supabase Database)
 */
(function (window) {
  const urlParams = new URLSearchParams(window.location.search);
  const paramBackend = urlParams.get('backend') || urlParams.get('api');
  if (paramBackend) {
    localStorage.setItem('NER_API_BASE_URL', paramBackend.replace(/\/+$/, ''));
  }

  const DEFAULT_BACKEND_URL = (function () {
    const saved = localStorage.getItem('NER_API_BASE_URL');
    if (saved) return saved.replace(/\/+$/, '');

    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
      if (window.location.port === '8000') {
        return '';
      }
      return 'http://localhost:8000';
    }
    return '';
  })();

  const NER_CONFIG = {
    getApiBaseUrl: function () {
      const custom = localStorage.getItem('NER_API_BASE_URL');
      if (custom && custom.trim()) {
        return custom.trim().replace(/\/+$/, '');
      }
      return DEFAULT_BACKEND_URL;
    },

    setApiBaseUrl: function (url) {
      if (!url || !url.trim()) {
        localStorage.removeItem('NER_API_BASE_URL');
      } else {
        localStorage.setItem('NER_API_BASE_URL', url.trim().replace(/\/+$/, ''));
      }
    },

    getEndpointUrl: function (path) {
      const base = this.getApiBaseUrl();
      const cleanPath = path.startsWith('/') ? path : '/' + path;
      return base ? `${base}${cleanPath}` : cleanPath;
    },

    getWsUrl: function (channel) {
      const base = this.getApiBaseUrl();
      const ch = channel || 'field_reports';
      if (base) {
        const wsProtocol = base.startsWith('https:') ? 'wss:' : 'ws:';
        const host = base.replace(/^https?:\/\//, '');
        return `${wsProtocol}//${host}/ws/${ch}`;
      } else {
        const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        return `${wsProtocol}//${window.location.host}/ws/${ch}`;
      }
    }
  };

  window.NER_CONFIG = NER_CONFIG;
})(window);
