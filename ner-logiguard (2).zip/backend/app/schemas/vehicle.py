from typing import Optional
from pydantic import BaseModel, Field
from app.models.vehicle import VehicleType, VehicleStatus


class VehicleBase(BaseModel):
    vehicle_number: str
    type: VehicleType = VehicleType.MEDIUM_CARGO_TRUCK
    driver_name: str
    driver_contact: Optional[str] = None
    driver_id: Optional[str] = None
    current_lat: float
    current_lng: float
    altitude_meters: int = 100
    speed_km_h: float = 0.0
    heading_degrees: float = 0.0
    status: VehicleStatus = VehicleStatus.ACTIVE_OPTIMAL
    active_corridor_code: Optional[str] = None
    active_route_name: Optional[str] = None
    fuel_level_pct: float = 100.0
    cargo_type: str = "Essential Supplies"
    cargo_weight_kg: float = 0.0
    signal_status: str = "4G_STRONG"


class VehicleCreate(VehicleBase):
    pass


class VehicleUpdate(BaseModel):
    driver_name: Optional[str] = None
    driver_contact: Optional[str] = None
    driver_id: Optional[str] = None
    current_lat: Optional[float] = None
    current_lng: Optional[float] = None
    altitude_meters: Optional[int] = None
    speed_km_h: Optional[float] = None
    heading_degrees: Optional[float] = None
    status: Optional[VehicleStatus] = None
    active_corridor_code: Optional[str] = None
    active_route_name: Optional[str] = None
    fuel_level_pct: Optional[float] = None
    cargo_type: Optional[str] = None
    cargo_weight_kg: Optional[float] = None
    signal_status: Optional[str] = None


class VehicleResponse(VehicleBase):
    id: str
    last_ping_time: int
    created_at: int
    updated_at: int

    class Config:
        from_attributes = True
