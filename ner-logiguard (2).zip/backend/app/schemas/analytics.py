from typing import List, Dict, Any
from pydantic import BaseModel


class CorridorEfficiencyStat(BaseModel):
    corridor_code: str
    name: str
    state: str
    total_trips: int
    avg_speed_km_h: float
    on_time_rate_pct: float
    landslide_delay_hours: float
    safety_score_pct: float
    current_status: str


class IncidentSummaryStat(BaseModel):
    type: str
    count: int
    avg_clearance_hours: float


class LogisticsAnalyticsSummary(BaseModel):
    total_fleet_size: int
    active_in_transit: int
    critical_incidents_active: int
    unresolved_alerts_count: int
    overall_fleet_safety_score: float
    monsoon_vulnerability_index: float
    corridors: List[CorridorEfficiencyStat]
    incident_breakdown: List[IncidentSummaryStat]
    weekly_transit_volume_tons: float
    offline_sync_success_rate_pct: float
