from app.schemas.auth import LoginRequest, Token, TokenPayload
from app.schemas.user import UserCreate, UserUpdate, UserResponse, AuditLogResponse
from app.schemas.vehicle import VehicleCreate, VehicleUpdate, VehicleResponse
from app.schemas.route import (
    RouteCreate,
    RouteResponse,
    RouteSegmentBase,
    RouteSegmentResponse,
    RoutePlanRequest,
    RoutePlanResponse,
    AlternativeRoute,
    DeliveryCreate,
    DeliveryResponse,
    WaypointPoint
)
from app.schemas.incident import IncidentCreate, IncidentUpdate, IncidentResponse, IncidentFilter
from app.schemas.field_report import (
    FieldReportCreate,
    FieldReportResponse,
    FieldReportSyncBatch,
    FieldReportSyncResult,
    PhotoMetadata
)
from app.schemas.weather import (
    WeatherObservationResponse,
    LiveWeatherRequest,
    WeatherForecastResponse,
    HourlyForecastPoint
)
from app.schemas.risk import (
    RiskAssessmentRequest,
    RiskAssessmentResponse,
    CorridorRiskSummary,
    RiskFactorBreakdown
)
from app.schemas.gps import (
    GPSPointCreate,
    GPSPointResponse,
    VehicleLocationUpdate,
    LiveFleetState
)
from app.schemas.alert import AlertCreate, AlertResponse, NotificationResponse
from app.schemas.analytics import LogisticsAnalyticsSummary, CorridorEfficiencyStat, IncidentSummaryStat
from app.schemas.ai_assistant import AIChatRequest, AIChatResponse, AIChatMessage

__all__ = [
    "LoginRequest",
    "Token",
    "TokenPayload",
    "UserCreate",
    "UserUpdate",
    "UserResponse",
    "AuditLogResponse",
    "VehicleCreate",
    "VehicleUpdate",
    "VehicleResponse",
    "RouteCreate",
    "RouteResponse",
    "RouteSegmentBase",
    "RouteSegmentResponse",
    "RoutePlanRequest",
    "RoutePlanResponse",
    "AlternativeRoute",
    "DeliveryCreate",
    "DeliveryResponse",
    "WaypointPoint",
    "IncidentCreate",
    "IncidentUpdate",
    "IncidentResponse",
    "IncidentFilter",
    "FieldReportCreate",
    "FieldReportResponse",
    "FieldReportSyncBatch",
    "FieldReportSyncResult",
    "PhotoMetadata",
    "WeatherObservationResponse",
    "LiveWeatherRequest",
    "WeatherForecastResponse",
    "HourlyForecastPoint",
    "RiskAssessmentRequest",
    "RiskAssessmentResponse",
    "CorridorRiskSummary",
    "RiskFactorBreakdown",
    "GPSPointCreate",
    "GPSPointResponse",
    "VehicleLocationUpdate",
    "LiveFleetState",
    "AlertCreate",
    "AlertResponse",
    "NotificationResponse",
    "LogisticsAnalyticsSummary",
    "CorridorEfficiencyStat",
    "IncidentSummaryStat",
    "AIChatRequest",
    "AIChatResponse",
    "AIChatMessage",
]
