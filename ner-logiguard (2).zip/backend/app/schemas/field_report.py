from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


class PhotoMetadata(BaseModel):
    photo_id: str
    file_name: str
    uri_or_url: str
    captured_at: int
    file_size_bytes: Optional[int] = 0
    mime_type: Optional[str] = "image/jpeg"
    exif_lat: Optional[float] = None
    exif_lng: Optional[float] = None


class FieldReportBase(BaseModel):
    local_id: Optional[str] = None
    officer_name: str
    latitude: float
    longitude: float
    altitude_meters: int = 100
    road_name: str
    terrain_type: str = "HILLY_GHAT"
    incident_type: str = "LANDSLIDE"
    severity: str = "HIGH"
    description: str
    photo_metadata_json: str = "[]"
    is_offline_origin: bool = False
    incident_id: Optional[str] = None


class FieldReportCreate(FieldReportBase):
    photos: Optional[List[PhotoMetadata]] = []


class FieldReportResponse(FieldReportBase):
    id: str
    officer_id: Optional[str]
    is_synced: bool
    sync_timestamp: int
    created_at: int

    class Config:
        from_attributes = True


class FieldReportSyncBatch(BaseModel):
    reports: List[FieldReportCreate]
    client_device_id: Optional[str] = None
    sync_initiated_at: int


class FieldReportSyncResult(BaseModel):
    synced_count: int
    failed_count: int
    synced_local_ids: List[str]
    server_assigned_ids: Dict[str, str]
    message: str
