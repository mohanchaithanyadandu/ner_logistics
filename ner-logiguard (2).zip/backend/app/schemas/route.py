from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from app.models.route import RoutePriority, DeliveryStatus
from app.models.vehicle import VehicleType


class RouteSegmentBase(BaseModel):
    segment_index: int
    from_name: str
    to_name: str
    start_lat: float
    start_lng: float
    end_lat: float
    end_lng: float
    distance_km: float
    start_altitude_m: int
    end_altitude_m: int
    gradient_pct: float
    is_high_risk_zone: bool = False
    hazard_description: Optional[str] = None
    avg_speed_km_h: float = 35.0


class RouteSegmentResponse(RouteSegmentBase):
    id: str
    route_id: str

    class Config:
        from_attributes = True


class RouteBase(BaseModel):
    corridor_code: str
    name: str
    origin_hub_id: str
    origin_name: str
    destination_hub_id: str
    destination_name: str
    total_distance_km: float
    baseline_eta_hours: float
    max_altitude_meters: int
    max_gradient_pct: float
    primary_terrain_type: str = "HILLY_GHAT"
    has_alternate_bypass: bool = True
    waypoints_json: str
    elevation_profile_json: Optional[str] = None


class RouteCreate(RouteBase):
    segments: Optional[List[RouteSegmentBase]] = None


class RouteResponse(RouteBase):
    id: str
    created_at: int
    updated_at: int
    segments: Optional[List[RouteSegmentResponse]] = []

    class Config:
        from_attributes = True


class WaypointPoint(BaseModel):
    lat: float
    lng: float
    name: Optional[str] = None
    altitude_m: Optional[int] = None


class RoutePlanRequest(BaseModel):
    origin: str = Field(..., description="Origin Hub ID or City name e.g. GHY or Guwahati")
    destination: str = Field(..., description="Destination Hub ID or City name e.g. TWG or Tawang")
    vehicle_type: VehicleType = VehicleType.MEDIUM_CARGO_TRUCK
    cargo: str = "Essential Medical & Food Supplies"
    cargo_weight_kg: float = 4500.0
    priority: RoutePriority = RoutePriority.STANDARD
    departure_time: Optional[int] = None  # Epoch milliseconds


class RiskFactorDetail(BaseModel):
    category: str
    severity: str
    description: str
    penalty_points: float


class AlternativeRoute(BaseModel):
    corridor_code: str
    name: str
    via_pass: str
    distance_km: float
    eta_hours: float
    travel_time_hours: Optional[float] = None
    risk_score: float                   # 0 - 100
    expected_delay_hours: float = 0.0   # Predicted delay
    route_score: float = 0.0            # Optimization composite score
    risk_level: str
    key_tradeoff: str
    waypoints: List[WaypointPoint]


class RoutePlanResponse(BaseModel):
    origin: str
    destination: str
    vehicle_type: VehicleType
    cargo: str
    priority: RoutePriority
    departure_time: int
    recommended_route: Dict[str, Any]
    alternative_routes: List[AlternativeRoute]
    
    # Core Optimizer Metrics
    total_distance_km: float
    distance_km: Optional[float] = None             # Alias for distance
    estimated_eta_hours: float
    travel_time_hours: Optional[float] = None       # Alias for travel time
    expected_delay_hours: float = 0.0               # Delay based on weather/hazards
    route_score: float = 0.0                        # Optimizer objective score
    
    # Risk Metrics
    overall_risk_score: float                       # 0 - 100 scale
    risk_score: Optional[float] = None              # Alias
    risk_level: str                                 # LOW, MODERATE, HIGH, CRITICAL
    confidence_score: float = 0.92                  # 0.0 - 1.0 telemetry confidence
    risk_factors: List[RiskFactorDetail]
    
    # Grounded Explanations & Logistics Advisories
    route_explanation: str
    recommended_action: Optional[str] = None
    bro_clearance_status: str
    monsoon_advisory: str
    elevation_profile: List[Dict[str, Any]]
    waypoints: List[WaypointPoint]


class DeliveryCreate(BaseModel):
    route_id: str
    vehicle_id: Optional[str] = None
    origin_name: str
    destination_name: str
    cargo_type: str
    cargo_weight_kg: float
    priority: RoutePriority = RoutePriority.STANDARD


class DeliveryResponse(BaseModel):
    id: str
    tracking_number: str
    route_id: str
    vehicle_id: Optional[str]
    origin_name: str
    destination_name: str
    cargo_type: str
    cargo_weight_kg: float
    priority: RoutePriority
    status: DeliveryStatus
    dispatch_time: Optional[int]
    estimated_arrival_time: Optional[int]
    actual_arrival_time: Optional[int]
    current_risk_score: float
    route_explanation: Optional[str]
    created_at: int
    updated_at: int

    class Config:
        from_attributes = True
