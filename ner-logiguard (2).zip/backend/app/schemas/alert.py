from typing import Optional, List
from pydantic import BaseModel, Field
from app.models.alert import AlertSeverity, AlertType


class AlertBase(BaseModel):
    incident_id: Optional[str] = None
    vehicle_id: Optional[str] = None
    title: str
    message: str
    severity: AlertSeverity = AlertSeverity.WARNING
    alert_type: AlertType = AlertType.ROAD_CONDITION_HAZARD
    affected_corridor_code: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    radius_km: float = 20.0
    is_active: bool = True


class AlertCreate(AlertBase):
    pass


class AlertResponse(AlertBase):
    id: str
    is_broadcasted: bool
    broadcast_timestamp: Optional[int]
    created_at: int
    resolved_at: Optional[int]

    class Config:
        from_attributes = True


class NotificationResponse(BaseModel):
    id: str
    user_id: str
    title: str
    body: str
    priority: str
    is_read: bool
    read_at: Optional[int]
    action_url: Optional[str]
    created_at: int

    class Config:
        from_attributes = True
