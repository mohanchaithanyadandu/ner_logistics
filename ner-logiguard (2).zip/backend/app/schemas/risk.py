from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from app.models.risk import RiskLevel


class RiskAssessmentRequest(BaseModel):
    corridor_code: str = "NH13_GHY_TWG"
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    vehicle_type: Optional[str] = "MEDIUM_CARGO_TRUCK"
    cargo_weight_kg: Optional[float] = 4500.0
    
    # Optional Explicit Inputs for Simulation or Field Telemetry
    rainfall_mm_h: Optional[float] = None
    rainfall_intensity: Optional[str] = None
    rainfall_duration_hours: Optional[float] = None
    elevation_m: Optional[float] = None
    slope_gradient_pct: Optional[float] = None
    road_condition: Optional[str] = None
    road_accessibility: Optional[str] = None
    bridge_status: Optional[str] = None
    traffic_level: Optional[str] = None
    historical_incidents_count: Optional[int] = None
    flood_indicator_score: Optional[float] = None
    landslide_indicator_score: Optional[float] = None
    
    # Custom Weight Configuration Override (Optional)
    weights_override: Optional[Dict[str, float]] = None


class RiskFactorBreakdown(BaseModel):
    name: str
    weight_pct: float
    score: float
    weighted_score: Optional[float] = None
    status: str
    impact_description: str


class RiskAssessmentResponse(BaseModel):
    corridor_code: str
    corridor_name: str
    overall_risk_score: float                   # 0.0 - 100.0 scale
    risk_level: RiskLevel                       # LOW, MODERATE, HIGH, CRITICAL
    confidence_score: float = 0.92              # 0.0 - 1.0 confidence/quality
    confidence_level: str = "HIGH"              # HIGH, MEDIUM, LOW
    landslide_prob: float
    flood_prob: float
    road_block_prob: float
    weather_severity_score: float
    gradient_hazard_score: float
    primary_hazard: str
    mitigation_recommendation: str
    recommended_action: Optional[str] = None
    ai_rationale: str
    factor_breakdown: List[RiskFactorBreakdown]
    sub_indices: Optional[Dict[str, float]] = None
    calculation_timestamp: int


class CorridorRiskSummary(BaseModel):
    corridor_code: str
    name: str
    state: str
    risk_score: float                           # 0 - 100
    risk_level: RiskLevel
    confidence_score: float = 0.90
    active_incidents_count: int
    open_blockages: int
    current_weather: str
    monsoon_alert: bool


class RiskPredictionResponse(BaseModel):
    id: str
    corridor_code: str
    corridor_name: str
    latitude: float
    longitude: float
    overall_risk_score: float
    risk_level: RiskLevel
    landslide_prob: float
    flood_prob: float
    road_block_prob: float
    weather_severity_score: float
    gradient_hazard_score: float
    primary_hazard: str
    mitigation_recommendation: str
    ai_rationale: Optional[str] = None
    calculation_timestamp: int
    created_at: int

    class Config:
        from_attributes = True

