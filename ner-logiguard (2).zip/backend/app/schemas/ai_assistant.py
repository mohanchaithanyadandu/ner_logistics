from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


class AIChatMessage(BaseModel):
    role: str = Field(..., description="'user', 'assistant', or 'system'")
    content: str


class AIChatRequest(BaseModel):
    prompt: str
    corridor_context: Optional[str] = None
    vehicle_context: Optional[str] = None
    weather_context: Optional[str] = None
    conversation_history: Optional[List[AIChatMessage]] = []


class AIChatResponse(BaseModel):
    response: str
    suggested_actions: List[str] = []
    risk_summary: Optional[Dict[str, Any]] = None
    terrain_advisories: List[str] = []
    generated_at: int
