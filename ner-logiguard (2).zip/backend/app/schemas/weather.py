from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


class WeatherObservationResponse(BaseModel):
    id: str
    station_code: str
    location_name: str
    state: str
    latitude: float
    longitude: float
    temperature_c: float
    relative_humidity_pct: float
    precipitation_mm_h: float
    rain_intensity: str
    wind_speed_km_h: float
    visibility_km: float
    cloud_cover_pct: int
    weather_code: int
    is_monsoon_surge: str
    forecast_summary: Optional[str]
    observation_time: int
    created_at: int

    class Config:
        from_attributes = True


class LiveWeatherRequest(BaseModel):
    latitude: float
    longitude: float
    location_name: Optional[str] = "North East Station"


class HourlyForecastPoint(BaseModel):
    time_iso: str
    temperature_2m: float
    precipitation: float
    rain: float
    weathercode: int
    visibility: float
    windspeed_10m: float


class WeatherForecastResponse(BaseModel):
    latitude: float
    longitude: float
    location_name: str
    state: str
    current_temperature_c: float
    relative_humidity_pct: float
    precipitation_rate_mm_h: float
    rain_intensity: str
    wind_speed_km_h: float
    visibility_km: float
    weather_condition: str
    is_monsoon_risk: bool
    landslide_weather_trigger: bool
    cloud_cover_pct: int
    hourly_forecast: List[HourlyForecastPoint]
    data_source: str
