from typing import Optional, List
from pydantic import BaseModel, Field
from app.models.incident import IncidentType, IncidentSeverity, IncidentStatus


class IncidentBase(BaseModel):
    title: str
    type: IncidentType = IncidentType.LANDSLIDE
    severity: IncidentSeverity = IncidentSeverity.HIGH
    status: IncidentStatus = IncidentStatus.REPORTED
    latitude: float
    longitude: float
    altitude_meters: int = 500
    location_name: str
    corridor_code: Optional[str] = None
    state: str = "ASSAM"
    clearance_eta_hours: float = 4.0
    affected_radius_km: float = 5.0
    is_blocking: bool = True
    reported_by: str
    description: str
    photo_urls_json: str = "[]"


class IncidentCreate(IncidentBase):
    pass


class IncidentUpdate(BaseModel):
    title: Optional[str] = None
    type: Optional[IncidentType] = None
    severity: Optional[IncidentSeverity] = None
    status: Optional[IncidentStatus] = None
    clearance_eta_hours: Optional[float] = None
    affected_radius_km: Optional[float] = None
    is_blocking: Optional[bool] = None
    description: Optional[str] = None
    photo_urls_json: Optional[str] = None
    resolved_at: Optional[int] = None


class IncidentResponse(IncidentBase):
    id: str
    resolved_at: Optional[int]
    created_at: int
    updated_at: int

    class Config:
        from_attributes = True


class IncidentFilter(BaseModel):
    status: Optional[IncidentStatus] = None
    severity: Optional[IncidentSeverity] = None
    incident_type: Optional[IncidentType] = None
    corridor_code: Optional[str] = None
    state: Optional[str] = None
    is_blocking: Optional[bool] = None
    near_lat: Optional[float] = None
    near_lng: Optional[float] = None
    radius_km: Optional[float] = 50.0
