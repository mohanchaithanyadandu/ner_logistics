from typing import Optional, List
from pydantic import BaseModel, Field


class GPSPointCreate(BaseModel):
    vehicle_id: str
    latitude: float
    longitude: float
    altitude_meters: int = 100
    speed_km_h: float = 0.0
    heading_degrees: float = 0.0
    accuracy_meters: float = 5.0
    battery_level_pct: float = 100.0
    signal_strength_dbm: int = -70
    network_carrier: str = "AIRTEL_4G"
    is_panic_button: bool = False
    timestamp: Optional[int] = None  # Epoch milliseconds


class GPSPointResponse(GPSPointCreate):
    id: str
    created_at: int

    class Config:
        from_attributes = True


class VehicleLocationUpdate(BaseModel):
    vehicle_id: str
    vehicle_number: str
    current_lat: float
    current_lng: float
    altitude_meters: int
    speed_km_h: float
    heading_degrees: float
    status: str
    active_corridor_code: Optional[str]
    signal_status: str
    is_panic_button: bool = False
    timestamp: int


class LiveFleetState(BaseModel):
    total_active_vehicles: int
    vehicles_at_risk: int
    moving_count: int
    stopped_count: int
    emergency_count: int
    vehicles: List[VehicleLocationUpdate]
