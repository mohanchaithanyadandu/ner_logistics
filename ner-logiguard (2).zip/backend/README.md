# NER LogiGuard — High-Altitude & Mountain Logistics Backend

A production-ready **FastAPI + PostgreSQL / PostGIS + WebSockets** backend tailored for logistics convoy coordination, landslide hazard tracking, route optimization, and offline field synchronization across the 8 North Eastern states of India.

---

## 🛠️ Tech Stack & Architecture

- **Framework**: Python 3.11 + FastAPI (Async ASGI)
- **Database**: PostgreSQL with PostGIS-compatible schemas (and automatic SQLite support for instant local dev)
- **ORM / Migrations**: SQLAlchemy 2.0 + Alembic
- **Real-Time Engine**: WebSocket Manager with channel pub/sub (`fleet`, `alerts`, `incidents`, `field_reports`, `weather`)
- **Authentication**: OAuth2 / JWT (HMAC-SHA256) with Role-Based Access Control (`ADMIN`, `LOGISTICS_OPERATOR`, `FIELD_OFFICER`, `DRIVER`)
- **External Integration**: Open-Meteo REST API with automated fallback heuristics for North East states

---

## 🚀 Quick Start

### Option 1: Run with Docker Compose (PostGIS + Backend)

```bash
cd backend
docker-compose up --build
```
The API server will be accessible at `http://localhost:8000`.
Interactive Swagger documentation will be available at `http://localhost:8000/docs`.

---

### Option 2: Run Locally with Python Virtual Environment

```bash
cd backend

# 1. Create and activate virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Configure environment
cp .env.example .env

# 4. Start the server (auto-initializes schema & demo seed)
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

---

## 🔑 Default Seed Users & Credentials

On startup, the system automatically provisions baseline accounts:

| Username | Password | Role | Description |
| :--- | :--- | :--- | :--- |
| `admin` | `admin123` | `ADMIN` | Col. R. K. Sharma (North East Command) |
| `operator` | `operator123` | `LOGISTICS_OPERATOR` | Priyanka Barua (Assam Logistics Central) |
| `field_officer` | `field123` | `FIELD_OFFICER` | SI Tsering Norbu (Arunachal West / Tawang) |
| `driver` | `driver123` | `DRIVER` | Bhaben Deka (Guwahati - Tawang Convoy) |

---

## 📡 API Groups Overview

### 1. `/api/v1/auth`
- `POST /login`: Authenticate and receive JWT bearer token.
- `GET /me`: Fetch authenticated user profile.

### 2. `/api/v1/users`
- `GET /`: List users with role/region filtering (*Admin / Operator*).
- `POST /`: Create new user (*Admin only*).
- `GET /audit-logs`: Review security and access trail (*Admin only*).

### 3. `/api/v1/routes`
- `GET /`: List all highway corridors (NH-13, NH-29, NH-6, NH-10).
- `GET /{corridor_code}`: Corridor details, elevation profile, and segments.
- `POST /deliveries`: Register in-transit delivery consignment.

### 4. `/api/v1/route-planning`
- `POST /optimize`: Multi-criteria GIS route optimizer.
  - **Inputs**: `origin`, `destination`, `vehicle_type`, `cargo_weight_kg`, `priority`, `departure_time`
  - **Outputs**: Recommended route, alternative routes, distance, ETA, risk score, factor breakdown, tactical route explanation.

### 5. `/api/v1/vehicles`
- `GET /`: Fleet vehicle inventory with status filters (`ACTIVE_OPTIMAL`, `DELAYED_RISK`, `EMERGENCY_STOP`).
- `POST /`: Register new vehicle.
- `PUT /{vehicle_id}`: Update vehicle status or driver assignment.

### 6. `/api/v1/gps`
- `POST /telemetry`: Submit GPS ping, heading, speed, and emergency panic triggers.
- `GET /fleet-live`: Aggregate live positions for live GIS maps.
- `GET /history/{vehicle_id}`: Historical breadcrumb track points.

### 7. `/api/v1/incidents`
- `GET /`: List & filter incidents by severity, state, corridor, or coordinate radius.
- `POST /`: Log new landslide, mudslide, or flash flood (triggers automated alerts).
- `POST /{incident_id}/resolve`: Mark incident resolved after BRO clearance.

### 8. `/api/v1/field-reports`
- `POST /`: Submit immediate field hazard report.
- `POST /batch-sync`: Idempotent batch synchronization for offline Android caches.

### 9. `/api/v1/weather`
- `GET /current`: Live meteorological forecast & landslide rainfall index.
- `GET /corridors/{corridor_code}`: Weather along mountain pass summits.

### 10. `/api/v1/risk`
- `GET /assess`: Dynamic multi-factor risk index (0.0 to 1.0) computation.

### 11. `/api/v1/alerts`
- `GET /`: Active fleet emergency alerts and road hazards.
- `GET /notifications/me`: Driver & operator notification inbox.

### 12. `/api/v1/analytics`
- `GET /dashboard-summary`: High-level metrics for command center.
- `GET /corridor-performance`: Safety scores per highway axis.
- `GET /state-risk-heatmap`: State-by-state risk breakdown.

### 13. `/api/v1/ai-assistant`
- `POST /query`: Domain-specific AI assistant for high-altitude logistics questions and convoy safety advice.

---

## ⚡ WebSocket Channels (`/ws/{channel}`)

Clients connect to real-time streams:
- `ws://localhost:8000/ws/fleet`: Live vehicle position updates.
- `ws://localhost:8000/ws/alerts`: Instant emergency panic & roadblock notifications.
- `ws://localhost:8000/ws/incidents`: Real-time incident reporting & clearance updates.
- `ws://localhost:8000/ws/field_reports`: Field officer submissions & sync events.
