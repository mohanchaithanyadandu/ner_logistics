"""
SIH26002 - NER LogiGuard Backend Entrypoint Wrapper
Enables direct invocation from project root or backend directory.
"""
from app.main import app, lifespan
from app.services.websocket_manager import ws_manager, ConnectionManager

__all__ = ["app", "lifespan", "ws_manager", "ConnectionManager"]
